"""Verify the distribution and run the WSN simulation and HIL examples."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def verify():
    manifest = ROOT / 'CHECKSUMS.sha256'
    if not manifest.is_file():
        raise ValueError('CHECKSUMS.sha256 is missing from the repository root')
    seen = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        digest, name = line.split('  ', 1)
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts or name in seen:
            raise ValueError('Invalid manifest entry: ' + name)
        f = ROOT / rel
        if not f.is_file() or f.is_symlink() or not f.resolve().is_relative_to(ROOT):
            raise ValueError('Missing or unsupported input: ' + name)
        h = hashlib.sha256()
        with f.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
        if h.hexdigest() != digest:
            raise ValueError('Checksum mismatch: ' + name)
        seen.add(name)
    if not seen:
        raise ValueError('Empty checksum list')
    print(f'Verified {len(seen)} distributed files.', flush=True)
    return len(seen)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--only', choices=('all','dynamic-k','da-ies-s','adaptive-sampling-monitoring','stage-ii','hil'), default='all')
    ap.add_argument('--verify-only', action='store_true', help='Check the distributed files without running a study')
    ap.add_argument('--output', type=Path, help='A new or empty directory outside the repository')
    args = ap.parse_args()
    try:
        n = verify()
    except (ValueError, OSError) as exc:
        ap.exit(1, f'{exc}\n')
    if args.verify_only:
        return 0
    if not args.output:
        ap.error('Choose a fresh output path with --output.')
    dest = args.output.expanduser().resolve()
    if dest == ROOT or dest.is_relative_to(ROOT) or (dest.exists() and (not dest.is_dir() or any(dest.iterdir()))):
        ap.error('Choose a new or empty output directory outside the repository.')
    dest.mkdir(parents=True,exist_ok=True)
    studies = []
    if args.only in ('all','stage-ii'):
        stage = ROOT / 'experiments/adaptive-sampling-monitoring/stage-ii'
        studies.append(('stage-ii', [stage/'scripts/run_study.py', '--study', 'transfer', '--seed', '422', '--output-dir', dest/'stage-ii']))
        studies.append(('stage-ii-tables', [stage/'scripts/verify_reference.py', '--output-dir', dest/'stage-ii-tables']))
    if args.only not in ('hil','stage-ii'):
        argv = [ROOT/'experiments'/'run_demos.py','--output',dest/'experiments']
        if args.only != 'all':
            argv += ['--only',args.only]
        studies.append(('experiments',argv))
    if args.only in ('all','hil'):
        studies.append(('hil',[ROOT/'hil'/'check_hil.py','--output',dest/'hil']))
    env = dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',MPLBACKEND='Agg')
    summary = {'verified_files':n,'selected':args.only,'completed':[]}
    for name, argv in studies:
        ret = subprocess.run([sys.executable,'-B',*map(str,argv)],cwd=ROOT,env=env).returncode
        summary['completed'].append({'name':name,'exit_code':ret})
        (dest/'results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
        if ret:
            return ret
    return 0

if __name__=='__main__':
    sys.exit(main())
