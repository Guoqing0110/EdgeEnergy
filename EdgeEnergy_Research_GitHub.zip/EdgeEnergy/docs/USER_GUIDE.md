# Running the studies

Use the [quick start](QUICKSTART.md) to set up CPython 3.12 and its dependencies. Run the commands below from the repository root. Give each invocation of `reproduce.py` a new or empty output directory outside the repository.

## Choose a result

Use `python -B reproduce.py --only NAME --output ../my-results`, substituting one of the names below. The paths in the last column are relative to `../my-results/`.

| `NAME` | What runs | Open first |
|---|---|---|
| `dynamic-k` | Five schedulers under fixed and adaptive donor limits, plus a no-transfer case | `experiments/dynamic-k/nominal_results.csv` |
| `da-ies-s` | One reference-network trajectory and one multihop corridor trajectory; a separate calculation rebuilds the matched policy comparisons | `experiments/da-ies-s/results.json` and `experiments/da-ies-s/matched-policy-tables.txt` |
| `adaptive-sampling-monitoring` | Four Stage I sensing policies on one aligned temperature trace; a separate replay of the ten-node controller | `experiments/adaptive-sampling-monitoring/task10/table_6_3.csv` and `experiments/adaptive-sampling-monitoring/hardware_replay.json` |
| `stage-ii` | One fresh transfer-window simulation and the table checks for the moving-front study | `stage-ii/runs.csv` and `stage-ii-tables/table_comparison.csv` |
| `hil` | Recalculation of Chapter 4 and 5 hardware results from recorded radio sessions | `hil/summary.json`, then `hil/dynamic-k.json` or `hil/da-ies-s.json` |

Omitting `--only` selects all five entries. Chapter 4 and 5 energy transfers are accounted for on the host; the radio records capture actual packet delivery and acknowledgements. The [hardware guide](../hil/README.md) explains the setup and what each replay consumes.

## Full sweeps for the two networks

The DA-IES-S engines write trajectories beneath their own working directories. Copy them outside the repository so the reference inputs stay intact:

```sh
cp -R experiments/da-ies-s/engines/v1 ../edgeenergy-reference-sweep
cp -R experiments/da-ies-s/engines/v2 ../edgeenergy-corridor-sweep
(cd ../edgeenergy-reference-sweep && python -B scripts/run_e6_matched_independent_v1.py run --workers 1)
(cd ../edgeenergy-corridor-sweep && python -B scripts/run_e6_mechanism_stress_v2.py held-out --workers 1)
```

With the supplied settings, the first command block runs 735 reference-network trajectories (15 seeds × 7 conditions × 7 policies); the second runs 1,176 corridor trajectories (24 × 7 × 7). Keep the seed registry with its network. To reconstruct only the policy tables from these archived trajectories, run `python -B experiments/da-ies-s/tables/check_tables.py`.

## Moving fronts and additional thesis tables

For the 80-run primary window, 100-run transfer window, 40-run detector control or the box plots in Figure 6.8, use the [Stage II commands](../experiments/adaptive-sampling-monitoring/stage-ii/README.md). To recalculate the separate Chapter 5 attribution and reporting comparisons and Chapter 6 session summaries, run:

```sh
(cd experiments/thesis-tables && python -B verify.py)
```

The [table guide](../experiments/thesis-tables/README.md) identifies each input and its experimental unit.

## If a run stops

A checksum mismatch identifies the supplied file that differs. Use a fresh, unmodified copy for the comparison. For a simulation error, check `results.json` in the output directory. For the three primary demos, `experiments/run_summary.json` names the individual study logs; for the moving-front simulation, use `stage-ii/simulation.log`. Compare outputs using the units and reference precision in the [results guide](../experiments/RESULTS.md).
