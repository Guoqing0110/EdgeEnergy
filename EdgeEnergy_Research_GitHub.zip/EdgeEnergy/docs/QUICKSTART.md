# Reproduce a first result

From the repository root (the directory containing `reproduce.py`), run:

```sh
python3.12 -B reproduce.py --verify-only
python3.12 -m venv ../edgeenergy-env
. ../edgeenergy-env/bin/activate
python -m pip install -r requirements.txt
python -B reproduce.py --only stage-ii --output ../edgeenergy-front
```

Use 64-bit Linux, or Linux under WSL on Windows. A CPU is sufficient. After installing the dependencies, the example runs offline with the supplied inputs.

Open `../edgeenergy-front/stage-ii/runs.csv`. It contains one new simulation: DF-ReAlert on the 5 March temperature window, seed 422. Look for Front Recall **0.5163934**, **809** routed command receptions and **366.594 J** of modelled energy (the CSV uses mJ). In the same directory, `reference_checks.csv` compares the run against the archived service metrics.

To run all studies and the hardware-record checks, use a second, empty output directory:

```sh
python -B reproduce.py --output ../edgeenergy-results
```

Open `../edgeenergy-results/results.json` for the exit status of each component. The [user guide](USER_GUIDE.md) maps each study to its output files and gives the full-sweep commands.
