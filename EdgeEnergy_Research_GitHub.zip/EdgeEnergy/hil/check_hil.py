"""Recompute the Chapter 4 and 5 hardware study results from archived records."""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--output", required=True, type=Path, help="new or empty output directory outside this repository")
    dest = args.parse_args().output.expanduser().resolve()
    if (dest == root.parent or root.parent in dest.parents
            or dest.exists() and (not dest.is_dir() or any(dest.iterdir()))):
        args.error("Choose a new or empty output directory outside this repository.")
    dest.mkdir(parents=True, exist_ok=True)
    studies = []
    for name in ("dynamic-k", "da-ies-s"):
        target = dest / (name+".json")
        completed = subprocess.run([sys.executable, "-B", str(root/name/"verify.py"),
                                    "--output", str(target)], stdout=subprocess.DEVNULL)
        if completed.returncode:
            return completed.returncode
        with target.open(encoding="utf-8") as file:
            if not json.load(file):
                raise ValueError(f"Missing results: {name}")
        studies.append(dict(study=name, result=target.name))
        print(f"{name}: results verified; wrote {target.name}", flush=True)
    (dest/"summary.json").write_text(json.dumps({"verified":studies}, indent=2)+"\n",
                                     encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
