# DA-IES-S: ten-node hardware-in-the-loop experiments

Ten wireless nodes exchanged periodic reports. A PC recorded arrivals, forwards and acknowledgements; the controller subsequently selected reports and scheduled virtual transfers on that recorded history. Reporting in this experiment was direct. The host charged virtual energy units (EU); the physical radios did not carry an EETOR return or transfer power.

## Recalculate the recorded comparisons

From the repository root, run:

```sh
python -B hil/da-ies-s/verify.py --output ../da-ies-s-hil-result.json
```

The command uses the Python standard library and was tested with CPython 3.12. Omit `--output` to print the JSON. It calculates metrics from the CSV records in `data/` and compares them with `reference.json` and the per-run or per-node references.

## Capture and controller conditions

The default paths were N01/N02 via N03, N04/N05 via N06, and N07/N08/N09 via N10; N03, N06 and N10 could also originate reports. N03 was the primary bridge and N06 the candidate bridge. The selected example is LAB10, pair P01, DA-adapted arm. Physical report receipts, acknowledgements and action events use one elapsed clock, in milliseconds from the first retained host timestamp. The logical identifiers and elapsed timestamps preserve the order of arrivals, including duplicates.

The integrated profiles start with capacity 150 EU, reserve 22.5 EU, target 52.5 EU and virtual WET delivery efficiency 0.8. Each capture maps to 480 logical slots. LAB10 used ten 120-second capture pairs. The two arms share the virtual starting checkpoint, exogenous trace and topology; each has its own radio capture. LAB11 used ten fresh five-profile blocks and 60-second captures. The order, seed, trace and checkpoint hashes are in `data/run_reference.csv`. LAB12 contains 40 nominal/stress pairs (five per disturbance), with a 60-second observation horizon per arm. A packet, a node-slot and an independently paired run are distinct sampling units.

## Results and their experimental units

| Experiment | Data supplied | Reference result |
|---|---|---|
| LAB04: belief | 90 evaluation runs: 15 blocks, two regimes, three reporting intervals; equal numbers of node-slots per run | Pooled CEB RMSE 0.71943 EU; last value 1.28194 EU. The interval covers 26,100 of 27,000 observations. |
| LAB05: ranking | 15 block results for each of five selectors | Average precision 0.4023 for shortlisted VoEI and 0.1192 for age. Average precision excludes the two blocks without positive labels. The archive key `full_voei` denotes the implemented shortlist in this experiment. |
| LAB06–08: reporting and guard | Four 120-second reporting profiles, 30 delivery trials, 15 constructed reserve-boundary blocks | Reporting debit falls from 444.65 EU (5 s) to 26.47 EU (60 s). Repeated arrivals can refer to the same observation. Two constructed blocks end below reserve. |
| LAB09: runtime | 4,800 decision timing records; ten captures | 99th percentile 25.43 ms on the execution host (nearest rank); zero missed recorded deadlines. |
| LAB10: integrated profiles | 20 runs, all 96,000 node-slot service observations and 9,600 slot decisions | DA-adapted minus B4: unmet demand **+4.340 EU**, strict continuity **−0.896 percentage points**, gross virtual transfer **−6.676 EU**, payer reserve event rate **+1.560 points**, null-transfer fraction **+1.583 points**. |
| LAB11: bridge profiles | 50 runs and 24,000 slot decisions | DA-adapted minus B4: unmet demand **+4.478 EU**, strict continuity **−2.292 points**. For these two service outcomes the script aggregates archived run summaries. Slot-level debit, transfer, payer reserve and fallback are recalculated. |
| LAB12: disturbances | 80 one-second health series and registered envelopes | All four measures return inside their bands for five consecutive seconds in 1/40 stressed and 2/40 nominal captures. The other 39 and 38 are right-censored. A recorded 0 s means the qualifying window **started** at disturbance end. |

For the physical LAB10 example, the receiver logged **246 report arrivals** from ten origins, representing **237 unique origin/sequence pairs**. The sample-valid flag is true for 222 arrivals; this is a field on the received packet, independent of deduplication. N03, N06 and N10 account for 74, 76 and 96 final-hop arrivals respectively. The host recorded 120 accepted state acknowledgements and 1,556 action events. The same example's *offline* replay has 383.103128 EU unmet demand, strict continuity of 32.5%, and 16.087518 EU gross virtual transfer. Packet counts describe the capture; service and virtual transfer describe the policy applied afterwards.

## Read the files

| Under `data/` | Observation and columns |
|---|---|
| `capture_packets.csv`, `capture_state_acks.csv`, `capture_action_events.csv` | One received report, state acknowledgement or node event. Each carries elapsed time. Packet identity here is the pair `origin_id, origin_seq`; `path` retains repeated hops if recorded. `retry_count` preserves the device's original counter. |
| `capture_delivery_reference.csv` | Per-origin unique deliveries, duplicates and inferred generation count from archive sequence windows. For this particular capture each origin occupied a single contiguous sequence range. |
| `lab04_belief.csv`, `lab05_ranking.csv`, `lab06_reporting.csv`, `lab07_delivery.csv`, `lab08_payer.csv`, `lab09_runtime.csv.gz` | Study-specific units and reference comparisons are given above. A blank block precision means no positive labels. The four LAB06 debit profiles are archived summaries, one capture per profile. |
| `lab10_service.csv.gz` | One node and logical slot per row: requested, served and unmet visible demand in EU. Strict continuity counts slots in which **all ten** requests were met. |
| `replay_slots.csv.gz` | LAB10/11 decisions keyed by run and slot: selected donor/receiver, null fallback, captured sensing/communication debit, gross and delivered virtual WET, and counts of charged payer instances and reserve events. Pool payer rows within a run before averaging paired results. |
| `run_reference.csv` | Archived run-level metrics and block identifiers. Rates are fractions; a paired difference of 0.01 equals one percentage point. Complete matched profiles share seed, trace and checkpoint within each block. |
| `recovery_criteria.csv`, `recovery_timeline.csv.gz` | LAB12 records the end of disturbance, dwell, empirical pre-stress limits and recorded outcome. For each physical second the timeline gives mean belief age, mean interval width in EU, null-transfer fraction and unmet EU. The first qualifying five-second window defines recovery. |
| `source_members.csv` | Study/run identifier, source table name, original member SHA-256 and size. For a reader holding the archived sources, these identify the exact input bytes before selecting fields, expressing times relative to the capture, or aggregating payer rows by slot. |

Source: DA LAB00–12 (SHA-256: `34860e34dfa721fbc7520e43e38a493890c4373d7acfa87e37df199c165f89e0`). The tables are extracts from that archive; [licence terms](../../legal/LICENSE_SCOPE.md) distinguish the software from the recorded data.
