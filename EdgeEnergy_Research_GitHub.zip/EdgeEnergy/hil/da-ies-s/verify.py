"""Recompute the ten-node capture and replay results using local data tables."""
import argparse
import csv
import gzip
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
NODES = {f"N{i:02d}" for i in range(1, 11)}
METRICS = ("cumulative_unmet_eu", "strict_continuity", "report_debit_eu",
           "gross_wet_eu", "payer_reserve_rate", "fallback_fraction")
HEALTH = ("mean_belief_age", "mean_belief_width_eu", "fallback_fraction", "unmet_eu")


def read(name):
    path = HERE / "data" / name
    reader = gzip.open if path.suffix == ".gz" else open
    with reader(path, "rt", encoding="utf-8", newline="") as stream:
        yield from csv.DictReader(stream)


def check(ok, note):
    if not ok:
        raise ValueError(note)


def near(a, b, note, tol=1e-8):
    check(math.isclose(a, b, rel_tol=0, abs_tol=tol), f"{note}: {a} versus {b}")


def physical():
    records = list(read("capture_packets.csv"))
    sequences = defaultdict(list)
    paths = Counter()
    for r in records:
        node = r["origin_id"]
        sequences[node].append(int(r["origin_seq"]))
        path = r["path"].split("->")
        check(path[0] == node and path[-1] == r["egress_sender"]
              and set(path) <= NODES, "Invalid logical path")
        paths[r["egress_sender"]] += 1
    expected = {r["node_id"]: r for r in read("capture_delivery_reference.csv")}
    check(set(sequences) == set(expected) == NODES, "Missing packet origin")
    for node, seq in sequences.items():
        row = expected[node]
        near(len(set(seq)), int(row["delivered_unique"]), node)
        near(len(seq) - len(set(seq)), int(row["duplicate_count"]), node)
        near(max(seq) - min(seq) + 1, int(row["generated_inferred"]), node)
    acks = list(read("capture_state_acks.csv"))
    events = list(read("capture_action_events.csv"))
    check({r['node_id'] for r in acks} == {r['node_id'] for r in events} == NODES, "Incomplete capture")
    counts = Counter(r["action_type"] for r in events)
    return {"report_receipts": len(records), "unique_origin_sequences": sum(len(set(v)) for v in sequences.values()),
            "valid_sample_receipts": sum(r["sample_valid"] == "True" for r in records),
            "receipts_by_last_hop": dict(sorted(paths.items())),
            "state_ack_records": len(acks), "accepted_state_acks": sum(r["accepted"] == "True" for r in acks),
            "action_events": len(events), "action_counts": dict(sorted(counts.items()))}


def replay():
    refs = {"_".join(r[k] for k in ("campaign", "block", "policy")): r
            for r in read("run_reference.csv")}
    expected_profiles = {"LAB10": {"B4", "DAIES"},
                         "LAB11": {"B4", "WIDE_AGE", "WIDE_RCPG_AGE", "HYBRID_DIRECT", "DAIES"}}
    by_block = defaultdict(list)
    for run, r in refs.items():
        by_block[(r["campaign"], r["block"])].append(r)
    for (campaign, block), rows in by_block.items():
        check({r["policy"] for r in rows} == expected_profiles[campaign], f"Incomplete {block}")
        for key in ("seed", "trace_sha256", "checkpoint_sha256"):
            check(len({r[key] for r in rows}) == 1, f"{block}: {key} not paired")
    check(Counter(k[0] for k in by_block) == {"LAB10": 10, "LAB11": 10}, "Wrong block count")
    slots = defaultdict(dict)
    for r in read("replay_slots.csv.gz"):
        run, slot = r["run"], int(r["slot"])
        check(slot not in slots[run] and run in refs, "Duplicate or unexpected decision")
        near(float(r["delivered_wet_eu"]), 0.8 * float(r["gross_wet_eu"]), "Virtual WET efficiency")
        check((r["fallback"] == "True") == (float(r["gross_wet_eu"]) == 0), "Null action mismatch")
        slots[run][slot] = r
    check(set(slots) == set(refs), "Missing replay run")
    service = defaultdict(lambda: defaultdict(dict))
    for r in read("lab10_service.csv.gz"):
        run, slot, node = r["run"], int(r["slot"]), r["node"]
        check(node not in service[run][slot], "Duplicate node-slot")
        need, served, unmet = (float(r[k]) for k in ("visible_demand_eu", "served_eu", "unmet_eu"))
        near(need-served, unmet, "Demand balance")
        service[run][slot][node] = unmet
    check(set(service) == {k for k, r in refs.items() if r["campaign"] == "LAB10"}, "Missing node service runs")
    measured = {}
    for run, decisions in slots.items():
        check(set(decisions) == set(range(1, 481)), f"Missing decisions: {run}")
        rows = list(decisions.values())
        if run in service:
            groups = service[run]
            check(set(groups) == set(decisions) and all(set(g) == NODES for g in groups.values()), run)
            unmet = math.fsum(x for g in groups.values() for x in g.values())
            strict = sum(max(g.values()) <= 1e-9 for g in groups.values())/len(groups)
        else:
            unmet, strict = (float(refs[run][k]) for k in METRICS[:2])
        measured[run] = dict(zip(METRICS, (
            unmet, strict, math.fsum(float(r["sensor_cost_eu"]) for r in rows),
            math.fsum(float(r["gross_wet_eu"]) for r in rows),
            sum(int(r["reserve_events"]) for r in rows)/sum(int(r["payer_rows"]) for r in rows),
            sum(r["fallback"] == "True" for r in rows)/len(rows))))
        for key, x in measured[run].items():
            near(x, float(refs[run][key]), f"{run}: {key}")
    differences, means = {}, {}
    for campaign in expected_profiles:
        pairs = sorted({r["block"] for r in refs.values() if r["campaign"] == campaign})
        differences[campaign] = {k: statistics.mean(
            measured[f"{campaign}_{p}_DAIES"][k] - measured[f"{campaign}_{p}_B4"][k]
            for p in pairs) for k in METRICS}
        means[campaign] = {s: {k: statistics.mean(measured[f"{campaign}_{p}_{s}"][k] for p in pairs)
                               for k in METRICS} for s in sorted(expected_profiles[campaign])}
    return {"replays": len(refs), "decisions": sum(map(len, slots.values())),
            "lab10_node_slots": sum(len(g) for groups in service.values() for g in groups.values()),
            "lab10_p01_da_adapted": measured["LAB10_P01_DAIES"],
            "policy_means": means, "paired_difference_da_minus_b4": differences}


def recovery():
    timelines = defaultdict(dict)
    for r in read("recovery_timeline.csv.gz"):
        k, s = r["run"], int(r["second"])
        check(s not in timelines[k], "Repeated physical second")
        timelines[k][s] = [float(r[h]) for h in HEALTH]
    pairs, totals, credited = defaultdict(set), defaultdict(Counter), {}
    criteria = list(read("recovery_criteria.csv"))
    check({r["run"] for r in criteria} == set(timelines) and len(criteria) == 80, "Incomplete recovery data")
    for r in criteria:
        run = r["run"]
        pair, mode = run.rsplit("_", 1)
        pairs[pair].add(mode)
        timeline = timelines[run]
        check(set(timeline) == set(range(60)), run)
        end, dwell = int(r["end_s"]), int(r["dwell_s"])
        band = [(float(r[h+"_lo"]), float(r[h+"_hi"])) for h in HEALTH]
        inside = {s: all(lo-1e-15 <= x <= hi+1e-15 for x,(lo,hi) in zip(vals,band))
                  for s,vals in timeline.items()}
        elapsed = next((t-end for t in range(end, 61-dwell)
                        if all(inside[s] for s in range(t, t+dwell))), None)
        check((elapsed is not None) == (r["recovered"] == "True"), run)
        check(("" if elapsed is None else str(elapsed)) == r["recovery_time_s"], run)
        totals[mode]["censored" if elapsed is None else "recovered"] += 1
        if elapsed is not None:
            credited[run] = elapsed
    check(len(pairs) == 40 and all(x == {"NOMINAL", "STRESS"} for x in pairs.values()), "Unmatched recovery")
    return {"pairs": len(pairs), "per_arm": dict(totals), "recovered_after_s": credited}


def components():
    belief = list(read("lab04_belief.csv"))
    ranks = list(read("lab05_ranking.csv"))
    reports = list(read("lab06_reporting.csv"))
    delivery = list(read("lab07_delivery.csv"))
    guard = list(read("lab08_payer.csv"))
    timing = list(read("lab09_runtime.csv.gz"))
    check([len(x) for x in [belief, ranks, reports, delivery, guard, timing]] ==
          [90, 75, 4, 30, 15, 4800], "Incomplete component studies")
    # LAB04 evaluation captures contribute 300 node-slot observations each.
    inside = 27000 - sum(int(r[k]) for r in belief for k in ("under_count","over_count"))
    ranking = {}
    for policy in sorted({r["selector"] for r in ranks}):
        cases = [r for r in ranks if r["selector"] == policy]
        ranking[policy] = {k:statistics.mean(float(r[k]) for r in cases if r[k] != "")
                           for k in ("pr_auc","recall_at_3","value_captured_at_3")}
    actions = {}
    for case in sorted({r["case"] for r in delivery}):
        rows = [r for r in delivery if r["case"] == case]
        actions[case] = {"cost_eu": statistics.mean(float(r["cost_eu"]) for r in rows),
                         "corrections_per_trial": statistics.mean(int(r["correction_count"]) for r in rows),
                         "duplicates_per_trial": statistics.mean(int(r["duplicate_count"]) for r in rows)}
    times = sorted(float(r["runtime_ms"]) for r in timing)
    return {"LAB04_rmse_eu": {k:math.sqrt(statistics.mean(float(r[k])**2 for r in belief))
                               for k in ("last_value_rmse","deterministic_rmse","ceb_rmse")},
            "LAB04_interval_hits": inside, "LAB05_selectors": ranking,
            "LAB06_debit_by_interval_ms": {r["report_interval_ms"]:float(r["total_observed_action_debit_eu"])
                                            for r in reports}, "LAB07_delivery": actions,
            "LAB08_reserve_events": sum(r["reserve_event"] == "True" for r in guard),
            "LAB09_p99_ms":times[math.ceil(0.99 * len(times))-1],
            "LAB09_deadline_misses":sum(float(r["runtime_ms"]) > float(r["deadline_ms"]) for r in timing)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, help="also write the complete result as JSON")
    args = ap.parse_args()
    result = {"capture": physical(), "replay": replay(), "recovery": recovery(), "components": components()}
    reference = json.loads((HERE/"reference.json").read_text())
    check(result["capture"] == reference["capture"], "Capture reference mismatch")
    check(result["recovery"] == reference["recovery"], "Recovery reference mismatch")
    for campaign, values in reference["paired_differences"].items():
        for key, value in values.items():
            near(result["replay"]["paired_difference_da_minus_b4"][campaign][key], value,
                 campaign+" "+key, 5.01e-4 if key.endswith("_eu") else 5.01e-6)
    for path, target in reference["component_examples"].items():
        v = result["components"]
        for k in path.split("/"):
            v = v[k]
        near(v, target, path, 5.01e-5 if "LAB05" in path else 5.01e-3)
    output = json.dumps(result, indent=2, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output+"\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
