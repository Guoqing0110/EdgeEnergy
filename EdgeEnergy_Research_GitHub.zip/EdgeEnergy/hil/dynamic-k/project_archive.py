"""Extract the distributed numerical fields from a holder's original DK1/DK2 bundles."""
import argparse
import csv
import datetime
import gzip
import hashlib
import io
from pathlib import Path
from zipfile import ZipFile

BUNDLES = {
    "DK1": "8ff501a07b91c5e514c3bfe116304104c2adc28291c907001ab93cd60e98df55",
    "DK2": "1bd96c8f403ff2345a08609b770f57e914f38c99f469da5be7e5a1052e59a05a",
}


def digest(file):
    h = hashlib.sha256()
    for block in iter(lambda: file.read(1024 * 1024), b""):
        h.update(block)
    return h.hexdigest()


class Archive:
    def __init__(self, path, expected):
        with path.open("rb") as file:
            if digest(file) != expected:
                raise ValueError(f"Unexpected archive checksum: {path.name}")
        self.file = ZipFile(path)
        with self.file.open("member_index.csv") as member:
            self.index = {row["source_member"]: row
                          for row in csv.DictReader(io.TextIOWrapper(member, encoding="utf-8"))}

    def read(self, suffix, product, sources):
        matches = [n for n in self.index if n.endswith(suffix)]
        if len(matches) != 1:
            raise ValueError(f"{suffix}: expected one member, found {len(matches)}")
        name = matches[0]
        sha = self.index[name]["sha256"]
        data = self.file.read(f"objects/{sha[:2]}/{sha}")
        if hashlib.sha256(data).hexdigest() != sha:
            raise ValueError(f"Member checksum differs: {name}")
        sources.append(dict(product=product, bundle=name.split("/")[0],
                            archived_member=name, source_sha256=sha))
        return list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))))


def write(dest, name, records):
    buff = io.StringIO()
    writer = csv.DictWriter(buff, list(records[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    data = buff.getvalue().encode()
    with (dest / name).open("xb") as file:
        if name.endswith(".gz"):
            with gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0) as gz:
                gz.write(data)
        else:
            file.write(data)


def export(dk1, dk2, dest):
    a = Archive(dk1, BUNDLES["DK1"])
    b = Archive(dk2, BUNDLES["DK2"])
    dest.mkdir(parents=True, exist_ok=False)
    src, runs, packets, transfers = [], [], [], []
    for camp in ("DK05", "DK06", "DK07", "DK08"):
        bundle = a if camp == "DK05" else b
        for r in bundle.read(f"/outputs/{camp}/derived/run_metrics.csv", "runs.csv", src):
            if r[camp.lower()+"_quality_status"] != "PASS":
                raise ValueError(f"Unexpected quality status: {camp} {r['pair_id']}")
            runs.append(dict(
                campaign=camp, condition={"DK05":"C0_BASE", "DK06":"C0_PRED"}.get(camp, r["condition"]),
                scenario=r["scenario_id"], repetition=r.get("repetition", r.get("source_repetition")),
                pair_id=r["pair_id"], order=r["order_in_pair"], policy=r["policy"],
                mean_std_eu=r["M1_AvgStd"], efficiency=r["M2_ModeledEfficiency"],
                final_min_eu=r["M3_FinalMin"], loss_eu=r["M4_TotalLoss"],
                pdr=r.get("M8_PDR", r.get("PDR")), decision_ms=r.get("M5_decision_runtime_mean_ms",""),
                transfer_count=r["committed_transfer_count"], debit_eu=r["total_donor_debit_eu"],
                credit_eu=r["total_receiver_credit_eu"], recovery=r.get("recovery_status","")))
    write(dest, "runs.csv", sorted(runs, key=lambda r:(r["campaign"], r["condition"], r["pair_id"], r["order"])))
    for policy in ("STATIC_K1", "DYNAMIC_K"):
        base = f"/pairs/PAIR_C0_BASE_S001_R01/{policy}/"
        meta = a.read(base+"derived/run_metadata.csv", "relative_times", src)[0]
        start = round(datetime.datetime.fromisoformat(meta["start_time_utc"]).timestamp()*1000)
        boots = a.read(base+"derived/boot_identity_audit.csv", "sequence_windows", src)
        if len(boots) != 10 or any(r["restart_observed"] != "False" for r in boots):
            raise ValueError("A single boot window per node is required for this example")
        for r in a.read(base+"raw/packets.csv", "nominal_packets.csv.gz", src):
            packets.append(dict(policy=policy, t_ms=int(r["host_receive_epoch_ms"])-start,
                                origin=r["origin_id"], seq=r["origin_seq"]))
        for r in a.read(base+"raw/resource_transfer_events.csv", "nominal_transfers.csv.gz", src):
            if r["commit_status"] != "COMMITTED":
                raise ValueError("The example contains an uncommitted transaction")
            transfers.append(dict(policy=policy, t_ms=int(r["host_epoch_ms"])-start,
                                  donor=r["donor"], receiver=r["receiver"], out_eu=r["amount_out_eu"],
                                  credit_eu=r["credited_eu"], loss_eu=r["modeled_loss_eu"]))
    write(dest, "nominal_packets.csv.gz", packets)
    write(dest, "nominal_transfers.csv.gz", transfers)
    sim = [dict(scenario=r["scenario_id"], scheduler=r["scheduler"], condition=r["condition"],
                policy=r["policy"], orbit_seed=r["matched_orbit_seed"], duration_s=r["duration_s"],
                mean_std_eu=r["M1_AvgStd"], efficiency=r["M2_ModeledEfficiency"],
                final_min_eu=r["M3_FinalMin"], loss_eu=r["M4_TotalLoss"],
                recovery=r["recovery_status"])
           for r in b.read("/outputs/DK09/simulation/simulation_run_metrics.csv",
                           "dk09_model_runs.csv", src)]
    write(dest, "dk09_model_runs.csv", sim)
    write(dest, "sources.csv", src)
    a.file.close()
    b.file.close()


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    for name in ("dk1", "dk2", "new_directory"):
        args.add_argument(name, type=Path)
    opts = args.parse_args()
    export(opts.dk1, opts.dk2, opts.new_directory)
