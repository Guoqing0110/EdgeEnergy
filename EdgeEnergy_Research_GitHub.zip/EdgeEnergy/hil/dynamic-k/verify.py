"""Reconstruct two Chapter 4 tables and one paired packet/transfer example."""
import argparse
import csv
import gzip
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
POLICIES = ("STATIC_K1", "DYNAMIC_K")
NODE_IDS = {f"N{i:02d}" for i in range(1, 11)}
PAIR = "PAIR_C0_BASE_S001_R01"


def rows(name):
    file = HERE / "data" / name
    opener = gzip.open if file.suffix == ".gz" else open
    with opener(file, "rt", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def check(ok, message):
    if not ok:
        raise ValueError(message)


def near(value, target, message, tol=1e-7):
    check(math.isfinite(value) and abs(value-target) <= tol,
          f"{message}: got {value:.8g}, expected {target:.8g}")


def match_table(observed, expected):
    check(observed.keys() == expected.keys(), "Table groups differ")
    for key, found in observed.items():
        check(len(found) == len(expected[key]), f"{key}: number of columns")
        for j, (value, target) in enumerate(zip(found, expected[key])):
            near(value, target, f"{key} column {j+1}", tol=0.00050001)


def main():
    runs = rows("runs.csv")
    ref = json.loads((HERE / "reference.json").read_text())
    pairs = defaultdict(dict)
    for r in runs:
        key = (r["campaign"], r["condition"], r["pair_id"])
        check(r["policy"] not in pairs[key], f"{key}: duplicate policy")
        pairs[key][r["policy"]] = r
        debit, credit = (float(r[k]) for k in ("debit_eu", "credit_eu"))
        near(credit / debit, float(r["efficiency"]), f"{key} efficiency")
        near(debit-credit, float(r["loss_eu"]), f"{key} modelled loss")
    check(Counter(k[0] for k in pairs) == {"DK05":20,"DK06":10,"DK07":20,"DK08":18},
          "Expected the four matched campaigns")
    for key, group in pairs.items():
        check(set(group) == set(POLICIES), f"{key}: policy pairing")
        for field in ("repetition", "scenario"):
            check(len({r[field] for r in group.values()}) == 1, f"{key}: {field}")
        check({r["order"] for r in group.values()} == {"1","2"}, f"{key}: order")

    nominal, disturbance = {}, {}
    for key in ref["nominal"]:
        campaign, policy = key.split("/")
        sample = [g[policy] for k, g in pairs.items() if k[0] == campaign]
        nominal[key] = [mean(float(r[m]) for r in sample)*factor for m, factor in
                        (("mean_std_eu",1), ("efficiency",100), ("final_min_eu",1),
                         ("loss_eu",1), ("pdr",100), ("decision_ms",1))]
    for key in ref["paired_changes"]:
        sample = [g for k, g in pairs.items() if "/".join(k[:2]) == key]
        disturbance[key] = [len(sample)] + [
            mean((float(g["DYNAMIC_K"][m])-float(g["STATIC_K1"][m]))*factor
                 for g in sample)
            for m, factor in (("mean_std_eu",1), ("efficiency",100), ("loss_eu",1),
                             ("pdr",100), ("final_min_eu",1))]
    match_table(nominal, ref["nominal"])
    match_table(disturbance, ref["paired_changes"])

    packets, tx = rows("nominal_packets.csv.gz"), rows("nominal_transfers.csv.gz")
    specimen = {}
    for policy in POLICIES:
        row = pairs["DK05", "C0_BASE", PAIR][policy]
        received = [p for p in packets if p["policy"] == policy]
        by_origin = defaultdict(set)
        for p in received:
            by_origin[p["origin"]].add(int(p["seq"]))
        check(set(by_origin) == NODE_IDS, f"{policy}: expected ten origins")
        unique = sum(len(seqs) for seqs in by_origin.values())
        generated = sum(max(seqs)-min(seqs)+1 for seqs in by_origin.values())
        near(unique/generated, float(row["pdr"]), f"{policy} packet delivery")
        entries = [t for t in tx if t["policy"] == policy]
        for t in entries:
            check({t["donor"],t["receiver"]} <= NODE_IDS and t["donor"] != t["receiver"],
                  f"{policy}: invalid transfer endpoints")
            near(float(t["out_eu"])-float(t["credit_eu"]), float(t["loss_eu"]),
                 f"{policy} transfer")
        check(len(entries) == int(row["transfer_count"]), f"{policy}: transfer count")
        for raw, recorded in (("out_eu","debit_eu"),("credit_eu","credit_eu"),("loss_eu","loss_eu")):
            near(math.fsum(float(t[raw]) for t in entries), float(row[recorded]),
                 f"{policy} {recorded}")
        specimen[policy] = dict(received_rows=len(received), unique_packets=unique,
                                generated_inferred=generated, pdr=unique/generated,
                                committed_transfers=len(entries),
                                credited_eu=float(row["credit_eu"]), loss_eu=float(row["loss_eu"]))
    # DK09 has a different number of nominal simulated pairs from the physical campaign.
    sim = rows("dk09_model_runs.csv")
    sim_groups = defaultdict(dict)
    for r in sim:
        key = tuple(r[f] for f in ("scheduler","condition","scenario","orbit_seed"))
        check(r["policy"] not in sim_groups[key], f"Repeated model run {key}")
        sim_groups[key][r["policy"]] = r
    check(len(sim_groups) == 58 and all(set(g) == set(POLICIES) for g in sim_groups.values()),
          "Expected 58 model pairs")
    classifications = Counter()
    effects = []
    recovery_groups = 0
    for campaign, condition in sorted({k[:2] for k in pairs}):
        hg = [g for k, g in pairs.items() if k[:2] == (campaign,condition)]
        sched = "PREDICTION" if campaign == "DK06" else "BASELINE"
        cond = "C0_NOMINAL" if campaign in ("DK05","DK06") else condition
        sg = [g for k,g in sim_groups.items() if k[:2] == (sched,cond)]
        check(bool(sg), f"No matching model condition: {campaign}/{condition}")
        for field in ("mean_std_eu","efficiency","final_min_eu","loss_eu"):
            physical, model = (mean(float(g["DYNAMIC_K"][field])-float(g["STATIC_K1"][field])
                                    for g in groups) for groups in (hg,sg))
            sign = lambda x: 0 if abs(x) < 1e-10 else (1 if x > 0 else -1)
            signs = (sign(physical),sign(model))
            classification = ("same_direction" if signs[0] == signs[1] else
                              ("one_tie" if 0 in signs else "opposite_direction"))
            classifications[classification] += 1
            effects.append(dict(campaign=campaign,condition=condition,metric=field,
                                hil=physical,simulation=model,classification=classification))
        if campaign == "DK08":
            for policy in POLICIES:
                a,b = [Counter(g[policy]["recovery"] for g in group).most_common(1)[0][0]
                       for group in (hg,sg)]
                check(a == b == "CENSORED_NOT_RECOVERED", "DK08 dominant recovery status")
                recovery_groups += 1
    check(classifications == {"same_direction":30,"one_tie":5,"opposite_direction":5}
          and recovery_groups == 8, "DK09 direction/recovery counts")
    return dict(runs=len(runs), pairs=len(pairs), nominal_columns=ref["nominal_columns"],
                nominal=nominal, paired_columns=ref["paired_columns"],
                paired_changes=disturbance, example_pair=PAIR, example=specimen,
                dk09_model_runs=len(sim), direction_counts=classifications, effects=effects,
                recovery_comparisons=recovery_groups)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, help="write the reconstructed tables and counts as JSON")
    args = cli.parse_args()
    result = json.dumps(main(), indent=2, allow_nan=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as handle:
            handle.write(result)
    else:
        print(result, end="")
