# Dynamic-K: paired testbed experiments

Each campaign compared Static K = 1 with Dynamic-K on ten physical nodes. Each policy pair shared a scenario and initial ledger; the radio traffic was recorded separately in the two runs. DK05 used the Baseline scheduler (20 pairs over ten traces); DK06 used Prediction/EWMA (ten pairs, coefficient 0.6). DK07 introduced state delay, version lag, state loss and bridge-path interruption (five pairs each). DK08 introduced resource shock, bridge disturbance, stale state (five pairs each) and a combined disturbance (three pairs). The setup and capture conditions are in the [HIL guide](../README.md).

## Recalculate the paired results

From the repository root:

```sh
python -B hil/dynamic-k/verify.py
```

The command prints tables and counts as JSON; add `--output ../dk-results.json` to save them. To compare with `reference.json`, round once after averaging the runs. For example, DK05 Static efficiency is 12.876523346…%, reported as **12.877%**. For DK07 version lag, the mean paired change in packet delivery is +3.977476849… percentage points, reported as **+3.977**.

## Read the records

| File in `data/` | Contents and unit |
|---|---|
| `runs.csv` | One row per physical run (136). Match on campaign, condition and pair ID; scenario and repetition identify shared inputs, and order records which policy ran first. Dispersion, minimum, debit, credit and loss are modelled EU. Efficiency and physical PDR are fractions. Decision time is a host run mean in milliseconds, provided for the nominal campaigns; recovery status is provided for DK08. |
| `nominal_packets.csv.gz` | All 1,327 received packet records for the first numbered nominal Baseline scenario and repetition, S001/R01. Each row contains policy, milliseconds since its run began, logical origin and origin sequence number. Repeated receptions remain in the file. |
| `nominal_transfers.csv.gz` | All 4,180 committed virtual transactions for that pair: policy, elapsed milliseconds, donor, receiver, donor debit, receiver credit and loss. |
| `dk09_model_runs.csv` | The 116 **offline** DK09 model runs aligned with the ten-node study. Scheduler, condition, scenario and orbit seed identify pairs. They are separate from the 136 physical runs and from the 25-node simulation demo. |
| `sources.csv` | Member paths and SHA-256 fingerprints in the two original source bundles. `relative_times` and `sequence_windows` identify the supporting metadata for the paired example. |

The nominal cells are arithmetic means of run-level outcomes. For each disturbance cell, subtract Static from Dynamic-K inside the same pair, then average the differences. Express efficiency and packet delivery changes in percentage points. Each physical run has equal weight in its condition. The archived mean dispersion is calculated after ledger updates in each recorded integer second; efficiency divides total committed credits by debits; loss is their difference.

For S001/R01, each origin remained in one boot window. For each origin, count distinct received sequence numbers and infer a generated sequence window from the maximum minus minimum plus one. Sum the two counts separately over origins. This gives **726/946 = 76.744%** (Static) and **550/802 = 68.579%** (Dynamic-K). The count does not detect losses before the first or after the last observed sequence. In other runs a restart would require its own window. The corresponding transfer records contain 1,904 and 2,276 commits. The checker sums them and compares the totals with the archived run metrics. The EU accounting is independent of counting packets.

In the nominal Baseline campaign the mean dispersion falls from 30.606 to 30.075 EU, while mean PDR falls from 79.100% to 66.233%. DK09 compares four resource effects across ten conditions: 30 sign agreements, five comparisons with a tied effect and five opposite signs; eight comparisons also give the same dominant censored recovery status. The checker computes these counts from the run rows.

Holders of the original `DK1.zip` and `DK2.zip` may regenerate the numerical files locally:

```sh
python -B hil/dynamic-k/project_archive.py /path/to/DK1.zip /path/to/DK2.zip ../dk-projection
```

Supply a new destination. The extractor checks both bundle and member fingerprints, copies only the listed fields and stores relative rather than absolute times.
