# Ten-node hardware-in-the-loop studies

Ten wireless nodes shared a host PC, but the controller played a different role in each study. For Dynamic-K, the host scheduled transfers during the radio exchange. For DA-IES-S, it replayed a previously captured exchange. In the sensing study it recorded which measurements became available and which wake commands the nodes acknowledged.

| Study | Experiment and records | Where to start |
|---|---|---|
| [Dynamic-K](dynamic-k/README.md) · Chapter 4 | 68 pairs of physical runs; nodes exchanged and acknowledged state while the host updated virtual energy accounts. A detailed pair connects packet receipts and transfer commits to the reported run metrics. | Recalculate the nominal and disturbance comparisons, then compare their directions with 116 aligned model runs. |
| [DA-IES-S](da-ies-s/README.md) · Chapter 5 | Nodes transmitted on a prescribed schedule. In replay, each controller chose which received observations to use and which virtual transfers to schedule. | Follow a capture from ten reporting nodes, compare the service outcomes of matched controller profiles and inspect recovery after disturbance. |
| [Sentinel-assisted sensing](../experiments/adaptive-sampling-monitoring/README.md) · Chapter 6 | Physical acknowledgements and host-admitted virtual sensing values were recorded in a session. | Replay the host decisions for that session. The [sensing tables](../experiments/thesis-tables/README.md) cover 91 recorded sessions and the two 12-block policy comparisons. |

To check the Dynamic-K and DA-IES-S data, run this command from the repository root:

```sh
python -B hil/check_hil.py --output ../hil_results
```

Choose a new or empty directory outside the repository. The standard-library checker writes `dynamic-k.json`, `da-ies-s.json` and a short `summary.json`. The Chapter 6 replay has its own command in the sensing study guide.

## Conditions for collecting new data

A comparable physical experiment requires ten individually identified radios with compatible firmware, a local Wi-Fi network and a host running the appropriate orchestrator and timestamping UDP traffic. N01–N02 normally report through N03, N04–N05 through N06, and N07–N09 through N10. The three forwarding nodes can also originate reports.

For Dynamic-K, load the harvesting and demand trace, initial accounts, policy and disturbance schedule. Check state acknowledgements, run allocation at two-second intervals, and retain the packets, decisions and account commits for each arm of the pair. The nominal sessions lasted 900 s; disturbance sessions lasted 300 s. Virtual accounts had capacity 150 EU, initial balance 120 EU and a 0.9 EU transfer quantum.

For DA-IES-S, set the physical routes and reporting schedule before capture. Retain packet identities and timing, action events, acknowledgements and the replay settings for each block. A later policy decision can change which report is admitted in replay, but cannot change the earlier radio transmission. Both energy studies use host-accounted energy units (EU); they measure wireless communication, not physical energy transfer or battery depletion.

This release contains data extracts and offline replay tools. Device firmware images, live acquisition software and full traffic captures are separate materials. See the [licence scope](../legal/LICENSE_SCOPE.md) for the terms covering code and experimental records.
