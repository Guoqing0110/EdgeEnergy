"""Long-horizon Stage 4 executor with online/offline separation."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from time import perf_counter
from typing import Any

import numpy as np

from src.communication_model.model import execute_communication
from src.digital_twin.baselines import DeterministicTwin, LastValueCache, UncertaintyTwin
from src.digital_twin.calibration import IntervalCalibration
from src.energy_model.model import PhysicalState, SlotEnergyLedger, execute_wet
from src.environment.trace import ExogenousTrace
from src.guard.risk_calibrated import assess_risk_calibrated_candidate
from src.scheduler.stage4 import (
    DA_IES_S_METHOD,
    Stage4Queues,
    choose_action,
    method_spec,
)
from src.scheduler.types import OnlineNodeView, OnlineSnapshot


@dataclass(frozen=True)
class Stage4SimulationResult:
    method: str
    seed: int
    scenario: str
    trace_hash: str
    records: tuple[dict[str, Any], ...]
    summary: dict[str, float | int | None]
    runtime_seconds: float


def _estimator(kind: str, config: dict[str, Any], initial: np.ndarray) -> Any | None:
    capacity = float(config["energy"]["capacity_j"])
    belief = config["belief"]
    if kind == "last_value":
        return LastValueCache(initial, capacity)
    if kind == "deterministic_twin":
        return DeterministicTwin(initial, capacity)
    if kind == "uncertainty_twin":
        return UncertaintyTwin(
            initial,
            capacity,
            float(belief["initial_variance_j2"]),
            float(belief["process_variance_j2"]),
            float(belief["measurement_variance_j2"]),
            float(belief["interval_z"]),
        )
    if kind == "full_state_oracle":
        return None
    raise ValueError(f"unknown Stage 4 estimator: {kind}")


def _snapshot(
    slot: int,
    estimator: Any | None,
    estimator_kind: str,
    roles: tuple[str, ...],
    physical_energy_j: np.ndarray,
    trace: ExogenousTrace,
    config: dict[str, Any],
    calibration: IntervalCalibration,
) -> OnlineSnapshot:
    capacity = float(config["energy"]["capacity_j"])
    reserve = capacity * float(config["energy"]["reserve_fraction"])
    if estimator_kind == "full_state_oracle":
        means = physical_energy_j.copy()
        variances = np.zeros(trace.node_count, dtype=float)
        ages = np.zeros(trace.node_count, dtype=int)
        lower = means.copy()
        upper = means.copy()
    else:
        assert estimator is not None
        means = estimator.means()
        variances = estimator.variances()
        ages = estimator.ages()
        if estimator_kind == "uncertainty_twin":
            multipliers = np.asarray(
                [
                    calibration.lookup(role, int(age)).multiplier
                    for role, age in zip(roles, ages)
                ],
                dtype=float,
            )
            half_width = multipliers * np.sqrt(np.maximum(0.0, variances))
            lower = np.maximum(0.0, means - half_width)
            upper = np.minimum(capacity, means + half_width)
        else:
            lower = means.copy()
            upper = means.copy()
    nodes = tuple(
        OnlineNodeView(
            node_id=node,
            mean_j=float(means[node]),
            variance_j2=float(variances[node]),
            lower_j=float(lower[node]),
            upper_j=float(upper[node]),
            age=int(ages[node]),
            role=roles[node],
        )
        for node in range(trace.node_count)
    )
    return OnlineSnapshot(
        slot=slot,
        nodes=nodes,
        positions=tuple(tuple(float(value) for value in row) for row in trace.positions),
        sink_position=tuple(float(value) for value in trace.sink_position),
        comm_adjacency=tuple(tuple(bool(value) for value in row) for row in trace.comm_adjacency),
        wet_adjacency=tuple(tuple(bool(value) for value in row) for row in trace.wet_adjacency),
        sink_id=trace.sink_id,
        reserve_j=reserve,
        max_report_fields=int(config["stage4"]["maximum_report_fields"]),
    )


def _roles(node_count: int, path: tuple[int, ...]) -> tuple[str, ...]:
    values = ["idle"] * node_count
    if len(path) >= 2:
        values[path[0]] = "donor"
        values[path[-1]] = "receiver"
        for node in path[1:-1]:
            values[node] = "relay"
    return tuple(values)


def _vectors(mapping: dict[str, np.ndarray], prefix: str) -> np.ndarray:
    values = [value for key, value in mapping.items() if key.startswith(prefix)]
    if not values:
        return np.zeros(0, dtype=float)
    return np.sum(np.stack(values), axis=0)


def _jain(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    denominator = values.size * float(np.sum(values**2))
    return float(np.sum(values) ** 2 / denominator) if denominator > 0.0 else 1.0


def _summary(records: list[dict[str, Any]], capacity_j: float) -> dict[str, float | int | None]:
    if not records:
        raise ValueError("no Stage 4 records")
    unmet = sum(float(row["outcomes"]["unmet_visible_demand_j"]) for row in records)
    demand = sum(float(row["outcomes"]["visible_demand_j"]) for row in records)
    served = sum(float(row["outcomes"]["served_visible_demand_j"]) for row in records)
    continuity = np.asarray(
        [float(row["outcomes"]["all_visible_service_met"]) for row in records]
    )
    node_continuity = np.asarray(
        [float(row["outcomes"]["node_service_met_fraction"]) for row in records]
    )
    report = sum(float(row["outcomes"]["reporting_sensor_debit_j"]) for row in records)
    wet_gross = sum(float(row["outcomes"]["wet_gross_debit_j"]) for row in records)
    wet_delivered = sum(float(row["outcomes"]["wet_delivered_j"]) for row in records)
    reserve_events = sum(int(row["outcomes"]["payer_reserve_violation_count"]) for row in records)
    payer_checks = sum(int(row["outcomes"]["payer_count"]) for row in records)
    errors = np.concatenate(
        [np.asarray(row["offline_evaluation"]["belief_error_j"], dtype=float) for row in records]
    )
    death_slots = [
        int(row["slot"])
        for row in records
        if int(row["offline_evaluation"]["dead_node_count"]) >= 1
    ]
    ten_percent = max(1, int(np.ceil(len(records[0]["offline_evaluation"]["energy_after_j"]) * 0.10)))
    ten_slots = [
        int(row["slot"])
        for row in records
        if int(row["offline_evaluation"]["dead_node_count"]) >= ten_percent
    ]
    final_energy = np.asarray(records[-1]["offline_evaluation"]["energy_after_j"], dtype=float)
    cv_rows = [float(row["offline_evaluation"]["energy_cv"]) for row in records]
    return {
        "slots": len(records),
        "cumulative_unmet_visible_demand_j": unmet,
        "total_visible_demand_j": demand,
        "total_served_visible_demand_j": served,
        "served_demand_fraction": served / demand if demand > 0.0 else 1.0,
        "all_service_met_slot_fraction": float(np.mean(continuity)),
        "node_service_continuity_fraction": float(np.mean(node_continuity)),
        "reporting_sensor_debit_j": report,
        "average_reporting_debit_j_per_slot": report / len(records),
        "wet_gross_debit_j": wet_gross,
        "average_wet_gross_debit_j_per_slot": wet_gross / len(records),
        "wet_delivered_j": wet_delivered,
        "wet_conversion_loss_j": wet_gross - wet_delivered,
        "payer_reserve_violations": reserve_events,
        "payer_checks": payer_checks,
        "payer_reserve_violation_rate": reserve_events / payer_checks if payer_checks else 0.0,
        "payer_reserve_violation_depth_j": sum(
            float(row["outcomes"].get("payer_reserve_violation_depth_j", 0.0))
            for row in records
        ),
        "maximum_payer_reserve_violation_depth_j": max(
            float(row["outcomes"].get("maximum_payer_reserve_violation_depth_j", 0.0))
            for row in records
        ),
        "safe_fallback_slot_fraction": float(
            np.mean(
                [
                    bool(row["outcomes"].get("safe_fallback_executed", False))
                    for row in records
                ]
            )
        ),
        "report_execution_shortfall_j": sum(
            float(row["outcomes"]["report_energy_shortfall_j"]) for row in records
        ),
        "wet_execution_shortfall_j": sum(
            float(row["outcomes"]["wet_energy_shortfall_j"]) for row in records
        ),
        "post_belief_mae_j": float(np.mean(np.abs(errors))),
        "post_belief_rmse_j": float(np.sqrt(np.mean(errors**2))),
        "mean_energy_cv": float(np.mean(cv_rows)),
        "final_energy_jain": _jain(final_energy),
        "first_node_death_slot": min(death_slots) if death_slots else None,
        "ten_percent_death_slot": min(ten_slots) if ten_slots else None,
        "final_service_queue_j": float(sum(records[-1]["queues_after"]["service_j"])),
        "final_report_queue_j": float(records[-1]["queues_after"]["report_j"]),
        "final_wet_queue_j": float(records[-1]["queues_after"]["wet_j"]),
        "minimum_final_energy_fraction": float(np.min(final_energy) / capacity_j),
    }


def run_stage4_method(
    config: dict[str, Any],
    trace: ExogenousTrace,
    method: str,
    scenario: str,
    calibration: IntervalCalibration,
) -> Stage4SimulationResult:
    started = perf_counter()
    estimator_kind, _, _ = method_spec(method)
    estimator = _estimator(estimator_kind, config, trace.initial_energy)
    capacity = float(config["energy"]["capacity_j"])
    reserve = capacity * float(config["energy"]["reserve_fraction"])
    state = PhysicalState.from_initial(trace.initial_energy, capacity)
    all_positions = np.vstack([trace.positions, trace.sink_position])
    service_queue = np.zeros(trace.node_count, dtype=float)
    report_queue = 0.0
    wet_queue = 0.0
    donor_queue = np.zeros(trace.node_count, dtype=float)
    roles = tuple("idle" for _ in range(trace.node_count))
    records: list[dict[str, Any]] = []

    for slot in range(trace.slots):
        slot_started = perf_counter()
        truth_before = state.energy_j.copy()
        snapshot = _snapshot(
            slot,
            estimator,
            estimator_kind,
            roles,
            truth_before,
            trace,
            config,
            calibration,
        )
        queue_before = Stage4Queues(
            service_j=tuple(float(value) for value in service_queue),
            report_j=float(report_queue),
            wet_j=float(wet_queue),
            donor_j=tuple(float(value) for value in donor_queue),
        )
        decision = choose_action(
            method,
            snapshot,
            tuple(float(value) for value in trace.visible_load[slot]),
            queue_before,
            config,
            trace.seed,
        )

        selected_risk_guard = None
        _, selected_wet_rule, _ = method_spec(method)
        if selected_wet_rule == "queue_safe":
            planned_payers = set(decision.planned_wet_debits_j) | set(
                decision.planned_report.per_node_debit_j
            )
            planned_debits = {
                node: float(decision.planned_wet_debits_j.get(node, 0.0))
                + float(decision.planned_report.per_node_debit_j.get(node, 0.0))
                + float(trace.visible_load[slot, node])
                for node in planned_payers
            }
            selected_risk_guard = assess_risk_calibrated_candidate(
                snapshot,
                decision.action,
                planned_debits,
                config["da_ies_s"]["risk_guard"],
            )
            if not selected_risk_guard.passed:
                raise RuntimeError("DA-IES-S selected an RCPG-infeasible action")

        ledger = SlotEnergyLedger(state)
        wet_result = execute_wet(
            ledger,
            decision.action.wet_path,
            decision.action.amount_j,
            trace.positions,
            config["wet"],
        )
        served = np.zeros(trace.node_count, dtype=float)
        unmet = np.zeros(trace.node_count, dtype=float)
        for node in range(trace.node_count):
            served[node], unmet[node] = ledger.debit(
                node, float(trace.visible_load[slot, node]), "visible_service"
            )
            ledger.debit(node, float(trace.hidden_load[slot, node]), "hidden_service")
            ledger.credit(node, float(trace.harvest_actual[slot, node]), "harvest")
        measurement_state = state.energy_j.copy()
        report_result = execute_communication(
            decision.report_plan,
            ledger,
            all_positions,
            trace.sink_id,
            trace.comm_success_probability,
            trace.comm_success_uniform[slot],
            config["communication"],
        )
        ledger.assert_conservation()

        wet_tx = ledger.executed_debits.get("wet_tx", np.zeros(trace.node_count))
        wet_rx = ledger.credits.get("wet_rx", np.zeros(trace.node_count))
        report_debit = _vectors(ledger.executed_debits, "report_")
        if report_debit.size == 0:
            report_debit = np.zeros(trace.node_count, dtype=float)
        report_total = float(np.sum(report_debit))
        wet_total = float(np.sum(wet_tx))
        payer_nodes = sorted(
            set(int(node) for node in decision.planned_wet_debits_j)
            | set(int(node) for node in decision.planned_report.per_node_debit_j)
        )
        violations = [node for node in payer_nodes if state.energy_j[node] < reserve]
        violation_depths = [
            max(0.0, reserve - float(state.energy_j[node])) for node in payer_nodes
        ]

        service_queue = service_queue + unmet
        report_queue = max(
            0.0,
            report_queue
            + report_total
            - float(config["stage4"]["report_average_budget_j_per_slot"]),
        )
        wet_queue = max(
            0.0,
            wet_queue
            + wet_total
            - float(config["stage4"]["wet_average_budget_j_per_slot"]),
        )
        donor_queue = np.maximum(
            0.0,
            donor_queue
            + wet_tx
            - float(config["stage4"]["donor_average_budget_j_per_slot"]),
        )
        roles = _roles(trace.node_count, decision.action.wet_path)

        if estimator is not None:
            predicted_delta = (
                trace.harvest_expected[slot]
                - served
                - float(config["belief"]["hidden_load_forecast_j_per_slot"])
                + wet_rx
                - wet_tx
            )
            estimator.advance(predicted_delta, roles)
            for node in report_result.delivered_fields:
                estimator.update(
                    node,
                    float(measurement_state[node] + trace.measurement_noise[slot, node]),
                )
            estimator.apply_confirmed_delta(-report_debit)
            post_means = estimator.means()
        else:
            post_means = state.energy_j.copy()

        energy_after = state.energy_j.copy()
        energy_mean = float(np.mean(energy_after))
        energy_cv = (
            float(np.std(energy_after) / energy_mean) if energy_mean > 0.0 else 0.0
        )
        record = {
            "schema_version": "stage4-slot-v1",
            "scenario": scenario,
            "seed": trace.seed,
            "method": method,
            "slot": slot,
            "online_information": {
                "belief_mean_j": [node.mean_j for node in snapshot.nodes],
                "belief_lower_j": [node.lower_j for node in snapshot.nodes],
                "belief_variance_j2": [node.variance_j2 for node in snapshot.nodes],
                "belief_age": [node.age for node in snapshot.nodes],
                "current_visible_demand_j": trace.visible_load[slot].tolist(),
                "service_queue_j": list(queue_before.service_j),
                "report_queue_j": queue_before.report_j,
                "wet_queue_j": queue_before.wet_j,
                "donor_queue_j": list(queue_before.donor_j),
            },
            "decision": {
                "action": decision.action.serializable(),
                "wet_objective": decision.wet_objective,
                "wet_candidate_count": decision.wet_candidate_count,
                "guard_rejected_wet_candidates": decision.guard_rejected_wet_candidates,
                "information_scores": list(decision.information_scores),
                "report_strategy": decision.report_strategy,
                "report_due": decision.report_due,
                "planned_report": asdict(decision.planned_report),
                "planned_wet_debits_j": decision.planned_wet_debits_j,
                "risk_guard": (
                    {
                        "passed": selected_risk_guard.passed,
                        "assessments": [
                            asdict(item) for item in selected_risk_guard.assessments
                        ],
                    }
                    if selected_risk_guard is not None
                    else None
                ),
            },
            "queues_after": {
                "service_j": service_queue.tolist(),
                "report_j": report_queue,
                "wet_j": wet_queue,
                "donor_j": donor_queue.tolist(),
            },
            "outcomes": {
                "visible_demand_j": float(np.sum(trace.visible_load[slot])),
                "served_visible_demand_j": float(np.sum(served)),
                "unmet_visible_demand_j": float(np.sum(unmet)),
                "all_visible_service_met": bool(np.all(unmet <= 1e-9)),
                "node_service_met_fraction": float(np.mean(unmet <= 1e-9)),
                "wet_gross_debit_j": wet_total,
                "wet_delivered_j": wet_result.delivered_to_receiver_j,
                "wet_energy_shortfall_j": wet_result.shortfall_j,
                "reporting_sensor_debit_j": report_total,
                "report_energy_shortfall_j": report_result.energy_shortfall_j,
                "report_delivered_fields": len(report_result.delivered_fields),
                "report_attempted_fields": len(report_result.attempted_fields),
                "payer_count": len(payer_nodes),
                "payer_reserve_violation_count": len(violations),
                "payer_reserve_violation_depth_j": float(sum(violation_depths)),
                "maximum_payer_reserve_violation_depth_j": float(
                    max(violation_depths, default=0.0)
                ),
                "safe_fallback_executed": bool(
                    selected_wet_rule == "queue_safe"
                    and decision.action.is_null
                    and bool(np.any(service_queue > 0.0))
                ),
            },
            "executor_ledger": ledger.serializable(),
            "offline_truth_only": {
                "hidden_service_j": trace.hidden_load[slot].tolist(),
                "harvest_actual_j": trace.harvest_actual[slot].tolist(),
                "energy_before_j": truth_before.tolist(),
            },
            "offline_evaluation": {
                "energy_after_j": energy_after.tolist(),
                "belief_error_j": (post_means - energy_after).tolist(),
                "dead_node_count": int(np.sum(energy_after <= 1e-9)),
                "energy_cv": energy_cv,
                "energy_jain": _jain(energy_after),
            },
            "runtime_ms": (perf_counter() - slot_started) * 1000.0,
        }
        records.append(record)

    runtime = perf_counter() - started
    return Stage4SimulationResult(
        method=method,
        seed=trace.seed,
        scenario=scenario,
        trace_hash=trace.content_hash(),
        records=tuple(records),
        summary=_summary(records, capacity),
        runtime_seconds=runtime,
    )
