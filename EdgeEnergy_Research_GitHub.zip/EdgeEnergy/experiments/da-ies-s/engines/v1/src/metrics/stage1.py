"""Stage 1 engineering summaries without inferential performance claims."""

from __future__ import annotations

from typing import Any, Iterable

import numpy as np


def summarize_records(records: Iterable[dict[str, Any]]) -> dict[str, float | int]:
    rows = list(records)
    if not rows:
        raise ValueError("cannot summarize an empty run")
    unmet = sum(float(row["outcomes"]["unmet_service_j"]) for row in rows)
    served_slots = sum(int(row["outcomes"]["all_visible_service_met"]) for row in rows)
    reserve_events = sum(int(row["outcomes"]["checked_payer_reserve_violations"]) for row in rows)
    checked_payers = sum(int(row["outcomes"]["checked_payer_count"]) for row in rows)
    reporting = sum(float(row["outcomes"]["reporting_sensor_debit_j"]) for row in rows)
    wet_delivered = sum(float(row["outcomes"]["wet_delivered_j"]) for row in rows)
    wet_loss = sum(float(row["outcomes"]["wet_conversion_loss_j"]) for row in rows)
    bytes_hops = sum(int(row["outcomes"]["report_bytes_over_hops"]) for row in rows)
    errors = np.concatenate(
        [np.asarray(row["offline_evaluation"]["post_belief_abs_error_j"]) for row in rows]
    )
    return {
        "slots": len(rows),
        "cumulative_unmet_service_j": unmet,
        "all_service_met_slot_fraction": served_slots / len(rows),
        "checked_payer_reserve_violations": reserve_events,
        "checked_payer_count": checked_payers,
        "checked_payer_reserve_violation_rate": (
            reserve_events / checked_payers if checked_payers else 0.0
        ),
        "reporting_sensor_debit_j": reporting,
        "report_bytes_over_hops": bytes_hops,
        "wet_delivered_j": wet_delivered,
        "wet_conversion_loss_j": wet_loss,
        "post_belief_mae_j": float(np.mean(errors)),
        "post_belief_rmse_j": float(np.sqrt(np.mean(errors**2))),
    }
