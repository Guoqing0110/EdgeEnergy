"""Trajectory-level metrics; slots are not treated as independent samples."""
