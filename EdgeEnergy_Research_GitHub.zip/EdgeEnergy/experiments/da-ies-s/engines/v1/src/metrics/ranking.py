"""Dependency-light ranking metrics for VoEI validation."""

from __future__ import annotations

import numpy as np


def _rankdata(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(values.size, dtype=float)
    start = 0
    while start < values.size:
        end = start + 1
        while end < values.size and values[order[end]] == values[order[start]]:
            end += 1
        rank = (start + end - 1) / 2.0 + 1.0
        ranks[order[start:end]] = rank
        start = end
    return ranks


def spearman(scores: np.ndarray, labels: np.ndarray) -> float:
    x = _rankdata(np.asarray(scores, dtype=float))
    y = _rankdata(np.asarray(labels, dtype=float))
    if np.std(x) == 0.0 or np.std(y) == 0.0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def ndcg_at_k(scores: np.ndarray, labels: np.ndarray, k: int) -> float:
    scores = np.asarray(scores, dtype=float)
    labels = np.maximum(0.0, np.asarray(labels, dtype=float))
    k = min(int(k), labels.size)
    if k <= 0:
        return float("nan")
    order = np.argsort(-scores, kind="mergesort")[:k]
    ideal = np.argsort(-labels, kind="mergesort")[:k]
    discounts = 1.0 / np.log2(np.arange(2, k + 2))
    dcg = float(np.sum(labels[order] * discounts))
    idcg = float(np.sum(labels[ideal] * discounts))
    return dcg / idcg if idcg > 0.0 else float("nan")


def top_k_precision(scores: np.ndarray, labels: np.ndarray, k: int) -> float:
    k = min(int(k), len(scores))
    if k <= 0:
        return float("nan")
    predicted = set(np.argsort(-np.asarray(scores), kind="mergesort")[:k])
    relevant = set(np.argsort(-np.asarray(labels), kind="mergesort")[:k])
    return len(predicted & relevant) / k


def binary_auc(scores: np.ndarray, outcomes: np.ndarray) -> float:
    scores = np.asarray(scores, dtype=float)
    outcomes = np.asarray(outcomes, dtype=bool)
    positives = scores[outcomes]
    negatives = scores[~outcomes]
    if positives.size == 0 or negatives.size == 0:
        return float("nan")
    greater = sum(float(p > n) for p in positives for n in negatives)
    equal = sum(float(p == n) for p in positives for n in negatives)
    return (greater + 0.5 * equal) / (positives.size * negatives.size)
