"""Stage 1 causal simulator.

The online scheduler and guard receive only ``OnlineSnapshot``. Physical truth is
kept inside this orchestration layer and emitted under an offline-only log key.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from time import perf_counter
from typing import Any

import numpy as np

from src.communication_model.model import (
    CommunicationPlan,
    estimate_plan_cost,
    execute_communication,
)
from src.digital_twin.belief import BeliefSystem
from src.energy_model.model import (
    PhysicalState,
    SlotEnergyLedger,
    execute_wet,
    wet_efficiency,
)
from src.environment.trace import ExogenousTrace
from src.guard.reserve import GuardDecision, assess_candidate
from src.metrics.stage1 import summarize_records
from src.reporting.planner import build_communication_plan
from src.scheduler.policies import Stage1PolicyConfig, Stage1Scheduler
from src.scheduler.types import Action, CandidateAction, OnlineNodeView, OnlineSnapshot


@dataclass(frozen=True)
class SimulationResult:
    method: str
    seed: int
    trace_hash: str
    records: tuple[dict[str, Any], ...]
    summary: dict[str, float | int]
    runtime_seconds: float


def _snapshot(
    slot: int,
    twin: BeliefSystem,
    trace: ExogenousTrace,
    reserve_j: float,
    max_report_fields: int,
) -> OnlineSnapshot:
    lower, upper = twin.intervals()
    nodes = tuple(
        OnlineNodeView(
            node_id=i,
            mean_j=node.mean_j,
            variance_j2=node.variance_j2,
            lower_j=float(lower[i]),
            upper_j=float(upper[i]),
            age=node.age,
            role=node.role,
        )
        for i, node in enumerate(twin.nodes)
    )
    return OnlineSnapshot(
        slot=slot,
        nodes=nodes,
        positions=tuple(tuple(float(x) for x in row) for row in trace.positions),
        sink_position=tuple(float(x) for x in trace.sink_position),
        comm_adjacency=tuple(tuple(bool(x) for x in row) for row in trace.comm_adjacency),
        wet_adjacency=tuple(tuple(bool(x) for x in row) for row in trace.wet_adjacency),
        sink_id=trace.sink_id,
        reserve_j=reserve_j,
        max_report_fields=max_report_fields,
    )


def _planned_wet_debits(
    action: Action, positions: np.ndarray, wet_config: dict[str, Any]
) -> dict[int, float]:
    if action.amount_j <= 0.0 or len(action.wet_path) < 2:
        return {}
    amount = float(action.amount_j)
    result: dict[int, float] = {}
    for sender, receiver in zip(action.wet_path[:-1], action.wet_path[1:]):
        result[sender] = result.get(sender, 0.0) + amount
        distance = float(np.linalg.norm(positions[sender] - positions[receiver]))
        amount *= wet_efficiency(distance, wet_config)
    return result


def _combine_debits(*mappings: dict[int, float]) -> dict[int, float]:
    result: dict[int, float] = {}
    for mapping in mappings:
        for node, amount in mapping.items():
            result[int(node)] = result.get(int(node), 0.0) + float(amount)
    return result


def _roles(node_count: int, action: Action) -> list[str]:
    roles = ["idle"] * node_count
    if action.donor is not None:
        roles[action.donor] = "donor"
    if action.receiver is not None:
        roles[action.receiver] = "receiver"
    for node in action.wet_path[1:-1]:
        roles[node] = "relay"
    return roles


def _candidate_record(
    candidate: CandidateAction,
    plan: CommunicationPlan,
    planned_report: Any,
    wet_debits: dict[int, float],
    combined_debits: dict[int, float],
    guard: GuardDecision,
) -> dict[str, Any]:
    return {
        "candidate_id": candidate.candidate_id,
        "action": candidate.action.serializable(),
        "priority": candidate.priority,
        "construction_note": candidate.construction_note,
        "planned_wet_gross_debit_j": wet_debits,
        "planned_reporting": asdict(planned_report),
        "planned_total_payer_debit_j": combined_debits,
        "guard_passed": guard.passed,
        "guard_rejections": [asdict(item) for item in guard.rejections],
        "packet_plan": [asdict(packet) for packet in plan.packets],
    }


def run_method(
    config: dict[str, Any], trace: ExogenousTrace, method: str
) -> SimulationResult:
    started = perf_counter()
    energy_config = config["energy"]
    belief_config = config["belief"]
    report_config = config["reporting"]
    wet_config = config["wet"]
    comm_config = config["communication"]
    capacity = float(energy_config["capacity_j"])
    reserve = capacity * float(energy_config["reserve_fraction"])
    state = PhysicalState.from_initial(trace.initial_energy, capacity)
    twin = BeliefSystem(
        initial_mean_j=trace.initial_energy,
        capacity_j=capacity,
        initial_variance_j2=float(belief_config["initial_variance_j2"]),
        process_variance_j2=float(belief_config["process_variance_j2"]),
        measurement_variance_j2=float(belief_config["measurement_variance_j2"]),
        interval_z=float(belief_config["interval_z"]),
    )
    scheduler = Stage1Scheduler(
        method,
        Stage1PolicyConfig(
            fixed_amount_j=float(wet_config["stage1_fixed_amount_j"]),
            report_interval=int(report_config["interval_slots"]),
            max_path_hops=int(wet_config["max_path_hops"]),
        ),
    )
    all_positions = np.vstack([trace.positions, trace.sink_position])
    records: list[dict[str, Any]] = []

    for slot in range(trace.slots):
        slot_started = perf_counter()
        online = _snapshot(
            slot, twin, trace, reserve, int(report_config["max_fields_per_slot"])
        )
        truth_before = state.energy_j.copy()
        pre_error = twin.means() - truth_before
        candidate_logs: list[dict[str, Any]] = []
        chosen_action: Action | None = None
        chosen_plan: CommunicationPlan | None = None
        chosen_predicted_debits: dict[int, float] = {}
        chosen_candidate_id = ""

        for candidate in scheduler.propose(online):
            plan = build_communication_plan(candidate.action, online)
            planned_report = estimate_plan_cost(
                plan, all_positions, trace.sink_id, comm_config
            )
            wet_debits = _planned_wet_debits(
                candidate.action, trace.positions, wet_config
            )
            action_payers = set(wet_debits) | set(planned_report.per_node_debit_j)
            baseline_service = {
                node: float(trace.visible_load[slot, node]) for node in action_payers
            }
            combined = _combine_debits(
                wet_debits, planned_report.per_node_debit_j, baseline_service
            )
            guard = assess_candidate(
                online,
                candidate.action,
                combined,
                float(belief_config["guard_margin_j"]),
            )
            candidate_logs.append(
                _candidate_record(
                    candidate, plan, planned_report, wet_debits, combined, guard
                )
            )
            if chosen_action is None and guard.passed:
                chosen_action = candidate.action
                chosen_plan = plan
                chosen_predicted_debits = combined
                chosen_candidate_id = candidate.candidate_id

        if chosen_action is None or chosen_plan is None:
            raise RuntimeError("candidate list did not contain an admissible fallback")

        ledger = SlotEnergyLedger(state)
        wet_result = execute_wet(
            ledger,
            chosen_action.wet_path,
            chosen_action.amount_j,
            trace.positions,
            wet_config,
        )
        served = np.zeros(trace.node_count, dtype=float)
        unmet = np.zeros(trace.node_count, dtype=float)
        for node in range(trace.node_count):
            served[node], unmet[node] = ledger.debit(
                node, float(trace.visible_load[slot, node]), "visible_service"
            )
            ledger.debit(node, float(trace.hidden_load[slot, node]), "hidden_load")
            ledger.credit(node, float(trace.harvest_actual[slot, node]), "harvest")
        measurement_state = state.energy_j.copy()
        communication_result = execute_communication(
            chosen_plan,
            ledger,
            all_positions,
            trace.sink_id,
            trace.comm_success_probability,
            trace.comm_success_uniform[slot],
            comm_config,
        )
        ledger.assert_conservation()

        truth_after = state.energy_j.copy()
        checked_nodes = sorted(node for node, debit in chosen_predicted_debits.items() if debit > 0)
        violation_nodes = [node for node in checked_nodes if truth_after[node] < reserve]

        report_categories = {
            key: value
            for key, value in ledger.executed_debits.items()
            if key.startswith("report_")
        }
        wet_tx = ledger.executed_debits.get("wet_tx", np.zeros(trace.node_count))
        wet_rx = ledger.credits.get("wet_rx", np.zeros(trace.node_count))
        report_debit = (
            np.sum(np.stack(list(report_categories.values())), axis=0)
            if report_categories
            else np.zeros(trace.node_count)
        )
        pre_report_predicted_delta = (
            trace.harvest_expected[slot]
            - trace.visible_load[slot]
            + wet_rx
            - wet_tx
        )
        twin.advance(pre_report_predicted_delta, _roles(trace.node_count, chosen_action))
        for node in communication_result.delivered_fields:
            measurement = measurement_state[node] + trace.measurement_noise[slot, node]
            twin.measurement_update(node, float(measurement))
        twin.apply_confirmed_delta(-report_debit)
        post_error = twin.means() - truth_after

        reporting_sensor_debit = float(
            sum(float(np.sum(vector)) for vector in report_categories.values())
        )
        record = {
            "schema_version": "stage1-slot-v1",
            "seed": trace.seed,
            "method": method,
            "slot": slot,
            "online_information_set": {
                "belief": [asdict(node) for node in online.nodes],
                "reserve_j": online.reserve_j,
                "max_report_fields": online.max_report_fields,
                "comm_adjacency": online.comm_adjacency,
                "wet_adjacency": online.wet_adjacency,
            },
            "candidates": candidate_logs,
            "selected_candidate_id": chosen_candidate_id,
            "selected_action": chosen_action.serializable(),
            "executor_ledger": ledger.serializable(),
            "reporting_execution": asdict(communication_result),
            "wet_execution": asdict(wet_result),
            "outcomes": {
                "unmet_service_j": float(np.sum(unmet)),
                "all_visible_service_met": bool(np.all(unmet <= 1e-9)),
                "checked_payer_count": len(checked_nodes),
                "checked_payer_reserve_violations": len(violation_nodes),
                "checked_payer_violation_nodes": violation_nodes,
                "reporting_sensor_debit_j": reporting_sensor_debit,
                "report_bytes_over_hops": communication_result.bytes_over_hops,
                "wet_delivered_j": wet_result.delivered_to_receiver_j,
                "wet_conversion_loss_j": wet_result.conversion_loss_j,
            },
            "offline_truth_only": {
                "energy_before_j": truth_before.tolist(),
                "energy_after_j": truth_after.tolist(),
                "measurement_state_j": measurement_state.tolist(),
                "harvest_actual_j": trace.harvest_actual[slot].tolist(),
                "visible_load_j": trace.visible_load[slot].tolist(),
                "hidden_load_j": trace.hidden_load[slot].tolist(),
                "packet_success_uniform": trace.comm_success_uniform[slot].tolist(),
            },
            "offline_evaluation": {
                "pre_belief_error_j": pre_error.tolist(),
                "post_belief_error_j": post_error.tolist(),
                "post_belief_abs_error_j": np.abs(post_error).tolist(),
            },
            "runtime_ms": (perf_counter() - slot_started) * 1000.0,
        }
        records.append(record)

    runtime = perf_counter() - started
    summary = summarize_records(records)
    return SimulationResult(
        method=method,
        seed=trace.seed,
        trace_hash=trace.content_hash(),
        records=tuple(records),
        summary=summary,
        runtime_seconds=runtime,
    )
