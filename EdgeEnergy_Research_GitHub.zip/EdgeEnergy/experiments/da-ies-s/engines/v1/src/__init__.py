"""Clean-room simulator for decision-aware information--energy scheduling."""

__version__ = "0.1.0-stage1"
