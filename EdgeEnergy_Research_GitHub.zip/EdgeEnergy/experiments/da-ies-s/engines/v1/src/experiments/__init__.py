"""Experiment-specific causal trace and evaluation helpers."""
