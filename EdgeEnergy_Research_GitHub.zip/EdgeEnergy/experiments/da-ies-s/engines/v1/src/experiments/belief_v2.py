"""Bias-aware causal belief replay for the versioned Stage 2 v2 study."""

from __future__ import annotations

from typing import Any

import numpy as np

from src.digital_twin.baselines import (
    DeterministicTwin,
    FullStateOracle,
    LastValueCache,
    UncertaintyTwin,
)
from src.experiments.belief_benchmark import BeliefBenchmark


def _estimators(config: dict[str, Any], initial: np.ndarray) -> tuple[Any, Any, Any]:
    energy = config["energy"]
    belief = config["belief"]
    capacity = float(energy["capacity_j"])
    return (
        LastValueCache(initial, capacity),
        DeterministicTwin(initial, capacity),
        UncertaintyTwin(
            initial,
            capacity,
            float(belief["initial_variance_j2"]),
            float(belief["process_variance_j2"]),
            float(belief["measurement_variance_j2"]),
            float(belief["interval_z"]),
        ),
    )


def replay_beliefs_v2(
    config: dict[str, Any], benchmark: BeliefBenchmark, scenario: str
) -> list[dict]:
    """Replay with a fixed expected hidden-load debit, never its realization."""

    last, deterministic, uncertainty = _estimators(config, benchmark.initial_energy_j)
    oracle = FullStateOracle(benchmark.initial_energy_j.size)
    hidden_forecast = float(config["belief"]["hidden_load_forecast_j_per_slot"])
    rows: list[dict] = []
    for slot, observation in enumerate(benchmark.observations):
        last.advance(observation.predicted_delta_before_report_j, observation.roles)
        corrected_delta = observation.predicted_delta_before_report_j - hidden_forecast
        deterministic.advance(corrected_delta, observation.roles)
        uncertainty.advance(corrected_delta, observation.roles)
        for estimator in (last, deterministic, uncertainty):
            for node, measurement in observation.measurements_j.items():
                estimator.update(node, measurement)
            estimator.apply_confirmed_delta(
                observation.confirmed_delta_after_measurement_j
            )

        oracle.set_truth(benchmark.truth_after_j[slot])
        for estimator in (last, deterministic, uncertainty, oracle):
            means = estimator.means()
            variances = estimator.variances()
            ages = estimator.ages()
            truth = benchmark.truth_after_j[slot]
            for node in range(truth.size):
                error = float(means[node] - truth[node])
                std = float(np.sqrt(max(0.0, variances[node])))
                rows.append(
                    {
                        "scenario": scenario,
                        "seed": benchmark.seed,
                        "report_interval": benchmark.report_interval,
                        "slot": slot,
                        "node": node,
                        "method": estimator.name,
                        "mean_j": float(means[node]),
                        "variance_j2": float(variances[node]),
                        "age": int(ages[node]),
                        "role": observation.roles[node],
                        "measurement_received": bool(
                            benchmark.report_delivered[slot, node]
                        ),
                        "truth_j_offline_only": float(truth[node]),
                        "error_j_offline_only": error,
                        "standardized_abs_residual": (
                            abs(error) / std if std > 0.0 else float("nan")
                        ),
                    }
                )
    return rows
