"""Generate a policy-independent scripted trajectory and replay belief models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np

from src.communication_model.model import (
    CommunicationPlan,
    PacketPlan,
    execute_communication,
)
from src.digital_twin.baselines import (
    DeterministicTwin,
    FullStateOracle,
    LastValueCache,
    UncertaintyTwin,
)
from src.energy_model.model import PhysicalState, SlotEnergyLedger, execute_wet
from src.environment.routing import shortest_path
from src.environment.trace import ExogenousTrace


@dataclass(frozen=True)
class CausalObservation:
    slot: int
    predicted_delta_before_report_j: np.ndarray
    confirmed_delta_after_measurement_j: np.ndarray
    measurements_j: dict[int, float]
    roles: tuple[str, ...]


@dataclass(frozen=True)
class BeliefBenchmark:
    seed: int
    report_interval: int
    initial_energy_j: np.ndarray
    observations: tuple[CausalObservation, ...]
    truth_after_j: np.ndarray
    measurement_state_j: np.ndarray
    report_delivered: np.ndarray


def _scripted_wet_path(trace: ExogenousTrace, slot: int, max_hops: int) -> tuple[int, ...]:
    n = trace.node_count
    donor_start = (slot // 3) % n
    for donor_offset in range(n):
        donor = (donor_start + donor_offset) % n
        for receiver_offset in range(n // 2, n):
            receiver = (donor + receiver_offset) % n
            if receiver == donor:
                continue
            path = shortest_path(trace.wet_adjacency, donor, receiver)
            if path is not None and len(path) - 1 <= max_hops:
                return path
    return ()


def _report_plan(trace: ExogenousTrace, slot: int, interval: int, field_count: int) -> CommunicationPlan:
    if slot % interval != 0:
        return CommunicationPlan(())
    round_index = slot // interval
    start = (round_index * field_count) % trace.node_count
    selected = tuple((start + offset) % trace.node_count for offset in range(field_count))
    packets: list[PacketPlan] = []
    for node in selected:
        path = shortest_path(trace.comm_adjacency, node, trace.sink_id)
        if path is not None:
            packets.append(PacketPlan(path, (node,), "independent"))
    return CommunicationPlan(tuple(packets))


def generate_benchmark(
    config: dict[str, Any], trace: ExogenousTrace, report_interval: int
) -> BeliefBenchmark:
    energy = config["energy"]
    wet = config["wet"]
    comm = config["communication"]
    fields = int(config["reporting"]["fields_per_opportunity"])
    capacity = float(energy["capacity_j"])
    state = PhysicalState.from_initial(trace.initial_energy, capacity)
    all_positions = np.vstack([trace.positions, trace.sink_position])
    observations: list[CausalObservation] = []
    truth_rows: list[np.ndarray] = []
    measurement_rows: list[np.ndarray] = []
    delivery_rows: list[np.ndarray] = []

    for slot in range(trace.slots):
        ledger = SlotEnergyLedger(state)
        roles = ["idle"] * trace.node_count
        path: tuple[int, ...] = ()
        if slot % int(wet["scripted_interval_slots"]) == 0:
            path = _scripted_wet_path(trace, slot, int(wet["max_path_hops"]))
        if path:
            roles[path[0]] = "donor"
            roles[path[-1]] = "receiver"
            for relay in path[1:-1]:
                roles[relay] = "relay"
            execute_wet(
                ledger,
                path,
                float(wet["scripted_amount_j"]),
                trace.positions,
                wet,
            )

        for node in range(trace.node_count):
            ledger.debit(node, float(trace.visible_load[slot, node]), "visible_service")
            ledger.debit(node, float(trace.hidden_load[slot, node]), "hidden_load")
            ledger.credit(node, float(trace.harvest_actual[slot, node]), "harvest")
        measurement_state = state.energy_j.copy()
        plan = _report_plan(trace, slot, report_interval, fields)
        report = execute_communication(
            plan,
            ledger,
            all_positions,
            trace.sink_id,
            trace.comm_success_probability,
            trace.comm_success_uniform[slot],
            comm,
        )
        ledger.assert_conservation()

        wet_tx = ledger.executed_debits.get("wet_tx", np.zeros(trace.node_count))
        wet_rx = ledger.credits.get("wet_rx", np.zeros(trace.node_count))
        report_vectors = [
            value for key, value in ledger.executed_debits.items() if key.startswith("report_")
        ]
        report_debit = (
            np.sum(np.stack(report_vectors), axis=0)
            if report_vectors
            else np.zeros(trace.node_count)
        )
        predicted_delta = (
            trace.harvest_expected[slot]
            - trace.visible_load[slot]
            + wet_rx
            - wet_tx
        )
        measurements = {
            node: float(measurement_state[node] + trace.measurement_noise[slot, node])
            for node in report.delivered_fields
        }
        delivered = np.zeros(trace.node_count, dtype=bool)
        delivered[list(report.delivered_fields)] = True
        observations.append(
            CausalObservation(
                slot=slot,
                predicted_delta_before_report_j=predicted_delta.copy(),
                confirmed_delta_after_measurement_j=-report_debit.copy(),
                measurements_j=measurements,
                roles=tuple(roles),
            )
        )
        truth_rows.append(state.energy_j.copy())
        measurement_rows.append(measurement_state)
        delivery_rows.append(delivered)

    return BeliefBenchmark(
        seed=trace.seed,
        report_interval=int(report_interval),
        initial_energy_j=trace.initial_energy.copy(),
        observations=tuple(observations),
        truth_after_j=np.stack(truth_rows),
        measurement_state_j=np.stack(measurement_rows),
        report_delivered=np.stack(delivery_rows),
    )


def _online_estimators(config: dict[str, Any], initial: np.ndarray) -> list[Any]:
    energy = config["energy"]
    belief = config["belief"]
    capacity = float(energy["capacity_j"])
    return [
        LastValueCache(initial, capacity),
        DeterministicTwin(initial, capacity),
        UncertaintyTwin(
            initial,
            capacity,
            float(belief["initial_variance_j2"]),
            float(belief["process_variance_j2"]),
            float(belief["measurement_variance_j2"]),
            float(belief["interval_z"]),
        ),
    ]


def replay_beliefs(config: dict[str, Any], benchmark: BeliefBenchmark) -> list[dict]:
    """Replay online estimators; truth is used only when constructing evaluator rows."""

    estimators = _online_estimators(config, benchmark.initial_energy_j)
    oracle = FullStateOracle(benchmark.initial_energy_j.size)
    rows: list[dict] = []
    for slot, observation in enumerate(benchmark.observations):
        for estimator in estimators:
            estimator.advance(
                observation.predicted_delta_before_report_j, observation.roles
            )
            for node, measurement in observation.measurements_j.items():
                estimator.update(node, measurement)
            estimator.apply_confirmed_delta(
                observation.confirmed_delta_after_measurement_j
            )
        oracle.set_truth(benchmark.truth_after_j[slot])
        for estimator in [*estimators, oracle]:
            means = estimator.means()
            variances = estimator.variances()
            ages = estimator.ages()
            truth = benchmark.truth_after_j[slot]
            for node in range(truth.size):
                error = float(means[node] - truth[node])
                std = float(np.sqrt(max(0.0, variances[node])))
                standardized = abs(error) / std if std > 0.0 else float("nan")
                rows.append(
                    {
                        "seed": benchmark.seed,
                        "report_interval": benchmark.report_interval,
                        "slot": slot,
                        "node": node,
                        "method": estimator.name,
                        "mean_j": float(means[node]),
                        "variance_j2": float(variances[node]),
                        "age": int(ages[node]),
                        "role": observation.roles[node],
                        "measurement_received": bool(benchmark.report_delivered[slot, node]),
                        "truth_j_offline_only": float(truth[node]),
                        "error_j_offline_only": error,
                        "standardized_abs_residual": standardized,
                    }
                )
    return rows
