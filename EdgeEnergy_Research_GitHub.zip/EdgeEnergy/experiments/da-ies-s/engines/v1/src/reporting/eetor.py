"""Budget-matched selective EETOR plans for the controlled Stage 3 study."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from src.communication_model.model import (
    CommunicationPlan,
    PacketPlan,
    PlannedCommunicationCost,
    empty_plan,
    estimate_plan_cost,
)


@dataclass(frozen=True)
class SubsetCatalog:
    """All subsets and their exact planned cost for one route/configuration."""

    length: int
    mode: str
    memberships: np.ndarray
    masks: np.ndarray
    costs_j: np.ndarray
    plans: tuple[CommunicationPlan, ...]

    def subset(self, mask: int) -> tuple[int, ...]:
        return tuple(int(i) for i in np.flatnonzero(self.memberships[int(mask)]))


@dataclass(frozen=True)
class SelectionDecision:
    selected_nodes: tuple[int, ...]
    mask: int
    reason: str
    utility: float
    planned_cost_j: float


def chain_positions(length: int, hop_distance_m: float) -> np.ndarray:
    """Return L sensor positions followed by the sink position."""

    if length < 1:
        raise ValueError("route length must be positive")
    return np.asarray(
        [[float(i) * hop_distance_m, 0.0] for i in range(length + 1)],
        dtype=float,
    )


def opportunity_plan(length: int, selected: Sequence[int]) -> CommunicationPlan:
    nodes = tuple(sorted({int(node) for node in selected}))
    if not nodes:
        return empty_plan()
    return CommunicationPlan(
        (
            PacketPlan(
                route=tuple(range(length + 1)),
                selected_nodes=nodes,
                mode="opportunity",
            ),
        )
    )


def independent_direct_plan(
    length: int, selected: Sequence[int]
) -> CommunicationPlan:
    sink = int(length)
    packets = tuple(
        PacketPlan(route=(int(node), sink), selected_nodes=(int(node),), mode="independent")
        for node in sorted({int(item) for item in selected})
    )
    return CommunicationPlan(packets)


def build_subset_catalog(
    length: int,
    mode: str,
    positions: np.ndarray,
    communication_config: dict,
) -> SubsetCatalog:
    if mode not in {"opportunity", "independent"}:
        raise ValueError(f"unsupported catalog mode: {mode}")
    masks = np.arange(1 << length, dtype=np.int64)
    memberships = (
        (masks[:, None] >> np.arange(length, dtype=np.int64)[None, :]) & 1
    ).astype(bool)
    plans: list[CommunicationPlan] = []
    costs: list[float] = []
    for mask in masks:
        selected = tuple(int(i) for i in np.flatnonzero(memberships[int(mask)]))
        plan = (
            opportunity_plan(length, selected)
            if mode == "opportunity"
            else independent_direct_plan(length, selected)
        )
        planned = estimate_plan_cost(plan, positions, length, communication_config)
        plans.append(plan)
        costs.append(planned.total_sensor_debit_j)
    return SubsetCatalog(
        length=length,
        mode=mode,
        memberships=memberships,
        masks=masks,
        costs_j=np.asarray(costs, dtype=float),
        plans=tuple(plans),
    )


def _decision(
    catalog: SubsetCatalog, mask: int, reason: str, utility: float
) -> SelectionDecision:
    return SelectionDecision(
        selected_nodes=catalog.subset(mask),
        mask=int(mask),
        reason=reason,
        utility=float(utility),
        planned_cost_j=float(catalog.costs_j[int(mask)]),
    )


def _max_score_subset(
    catalog: SubsetCatalog, scores: np.ndarray, budget_j: float, reason: str
) -> SelectionDecision:
    score = np.asarray(scores, dtype=float)
    if score.shape != (catalog.length,):
        raise ValueError("score vector does not match eligible route length")
    if np.any(~np.isfinite(score)) or np.any(score < 0.0):
        raise ValueError("subset scores must be finite and nonnegative")
    feasible = catalog.costs_j <= float(budget_j) + 1e-15
    utilities = catalog.memberships.astype(float) @ score
    utilities[~feasible] = -np.inf
    best_utility = float(np.max(utilities))
    if not np.isfinite(best_utility) or best_utility <= 0.0:
        return _decision(catalog, 0, f"{reason}:zero_utility_or_budget", 0.0)
    candidates = np.flatnonzero(np.isclose(utilities, best_utility, rtol=1e-12, atol=1e-12))
    minimum_cost = float(np.min(catalog.costs_j[candidates]))
    candidates = candidates[
        np.isclose(catalog.costs_j[candidates], minimum_cost, rtol=1e-12, atol=1e-15)
    ]
    mask = int(np.min(candidates))
    return _decision(catalog, mask, reason, best_utility)


def select_subset(
    method: str,
    catalog: SubsetCatalog,
    budget_j: float,
    age_scores: np.ndarray,
    voei_scores: np.ndarray,
    random_scores: np.ndarray,
    periodic_offset: int,
) -> SelectionDecision:
    """Choose from online scores only; physical truth is intentionally absent."""

    length = catalog.length
    all_mask = (1 << length) - 1
    if method == "collect_all_eetor":
        if catalog.costs_j[all_mask] <= float(budget_j) + 1e-15:
            return _decision(catalog, all_mask, "collect_all:feasible", float(length))
        return _decision(catalog, 0, "collect_all:atomic_budget_abstain", 0.0)
    if method == "endpoint_only_eetor":
        endpoint_mask = 1 | (1 << (length - 1))
        if catalog.costs_j[endpoint_mask] <= float(budget_j) + 1e-15:
            return _decision(catalog, endpoint_mask, "endpoint_only:feasible", 2.0)
        return _decision(catalog, 0, "endpoint_only:atomic_budget_abstain", 0.0)
    if method == "independent_periodic_direct":
        mask = 0
        for step in range(length):
            node = (int(periodic_offset) + step) % length
            candidate = mask | (1 << node)
            if catalog.costs_j[candidate] <= float(budget_j) + 1e-15:
                mask = candidate
        reason = "independent_periodic:budget_fill" if mask else "independent_periodic:budget_abstain"
        return _decision(catalog, mask, reason, float(catalog.memberships[mask].sum()))
    if method == "random_subset_eetor":
        return _max_score_subset(catalog, random_scores, budget_j, "random_subset")
    if method == "age_ranked_eetor":
        return _max_score_subset(catalog, age_scores, budget_j, "age_ranked")
    if method == "full_voei_selective_eetor":
        return _max_score_subset(catalog, voei_scores, budget_j, "full_voei_selective")
    raise ValueError(f"unknown Stage 3 method: {method}")


def expected_delivery(
    plan: CommunicationPlan, link_success_probability: float
) -> tuple[float, float]:
    """Return expected delivered packets and fields under independent hops."""

    expected_packets = 0.0
    expected_fields = 0.0
    probability = float(link_success_probability)
    for packet in plan.packets:
        success = probability ** (len(packet.route) - 1)
        expected_packets += success
        expected_fields += success * len(packet.selected_nodes)
    return expected_packets, expected_fields


def planned_cost(
    catalog: SubsetCatalog, decision: SelectionDecision
) -> PlannedCommunicationCost:
    """Expose the catalogued exact cost through a typed audit record."""

    plan = catalog.plans[decision.mask]
    # Per-node detail is recomputed by the runner because it owns positions/config.
    return PlannedCommunicationCost(
        per_node_debit_j={},
        total_sensor_debit_j=decision.planned_cost_j,
        bytes_over_hops=0,
        packet_count=len(plan.packets),
        hop_count=sum(len(packet.route) - 1 for packet in plan.packets),
    )
