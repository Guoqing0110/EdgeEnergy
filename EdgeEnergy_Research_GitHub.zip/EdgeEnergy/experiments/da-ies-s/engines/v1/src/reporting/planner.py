"""Translate an online action into an auditable packet plan."""

from __future__ import annotations

from src.communication_model.model import CommunicationPlan, PacketPlan, empty_plan
from src.environment.routing import shortest_path
from src.scheduler.types import Action, OnlineSnapshot


def build_communication_plan(
    action: Action, snapshot: OnlineSnapshot
) -> CommunicationPlan:
    if not action.state_subset or action.return_mode == "none":
        return empty_plan()

    packets: list[PacketPlan] = []
    if action.return_mode == "independent":
        for node in action.state_subset:
            route = shortest_path(snapshot.comm_adjacency, node, snapshot.sink_id)
            if route is not None:
                packets.append(PacketPlan(route, (node,), "independent"))
        return CommunicationPlan(tuple(packets))

    if action.return_mode != "opportunity":
        raise ValueError(f"unknown return mode: {action.return_mode}")
    if len(action.wet_path) < 2 or action.donor is None or action.receiver is None:
        return empty_plan()

    reverse_wet = tuple(reversed(action.wet_path))
    donor_to_sink = shortest_path(
        snapshot.comm_adjacency, action.donor, snapshot.sink_id
    )
    if donor_to_sink is None:
        return empty_plan()
    route = reverse_wet + donor_to_sink[1:]
    # A WET edge must also support the reverse communication packet in this
    # Stage 1 protocol. A path failing this check yields no report packet.
    for sender, receiver in zip(route[:-1], route[1:]):
        if not snapshot.comm_adjacency[sender][receiver]:
            return empty_plan()
    selected = tuple(node for node in action.state_subset if node in route[:-1])
    if selected:
        packets.append(PacketPlan(route, selected, "opportunity"))
    return CommunicationPlan(tuple(packets))
