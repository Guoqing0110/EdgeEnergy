"""Hashes and stable serialization for traceable runs."""

from __future__ import annotations

import json
import os
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable


def canonical_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return sha256(payload.encode("utf-8")).hexdigest()


def code_hash(project_root: Path) -> str:
    digest = sha256()
    paths = sorted(
        list((project_root / "src").rglob("*.py"))
        + list((project_root / "scripts").rglob("*.py"))
        + list((project_root / "configs").rglob("*.yaml"))
    )
    for path in paths:
        digest.update(str(path.relative_to(project_root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_jsonl(path: Path, records: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def deterministic_records_hash(records: Iterable[dict[str, Any]]) -> str:
    sanitized = []
    for row in records:
        copy = dict(row)
        copy.pop("runtime_ms", None)
        sanitized.append(copy)
    return canonical_hash(sanitized)
