"""Belief-only information values and offline counterfactual labels."""
