"""Belief-only ambiguity-opportunity definition for Stage 2 v2."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from src.information_value.voei import DecisionBelief


@dataclass(frozen=True)
class AmbiguityOpportunity:
    is_opportunity: bool
    ambiguity_index: float
    receiver_gap_z: float
    donor_gap_z: float
    reserve_gap_z: float


def _minimum_adjacent_gap_z(
    values: np.ndarray, std: np.ndarray, order: np.ndarray, minimum_std: float
) -> float:
    if order.size < 2:
        return float("inf")
    result = float("inf")
    for left, right in zip(order[:-1], order[1:]):
        denominator = max(
            float(minimum_std),
            float(np.sqrt(std[left] ** 2 + std[right] ** 2)),
        )
        result = min(result, abs(float(values[left] - values[right])) / denominator)
    return result


def belief_ambiguity_opportunity(
    belief: DecisionBelief, config: dict[str, Any]
) -> AmbiguityOpportunity:
    """Classify a slot using belief only; no score or physical truth is accepted."""

    minimum_std = float(config["voei"]["minimum_std_j"])
    count_r = min(
        belief.mean_j.size, int(config["voei"]["receiver_candidate_count"])
    )
    count_d = min(belief.mean_j.size, int(config["voei"]["donor_candidate_count"]))
    receiver_order = np.argsort(belief.mean_j, kind="mergesort")[:count_r]
    donor_order = np.argsort(-belief.mean_j, kind="mergesort")[:count_d]
    receiver_gap = _minimum_adjacent_gap_z(
        belief.mean_j, belief.std_j, receiver_order, minimum_std
    )
    donor_gap = _minimum_adjacent_gap_z(
        belief.mean_j, belief.std_j, donor_order, minimum_std
    )
    positives = sorted(
        float(x) for x in config["voei"]["amount_levels_j"] if float(x) > 0.0
    )
    minimum_amount = positives[0]
    reserve_boundary = belief.reserve_j + minimum_amount
    reserve_gap = float(
        np.min(
            np.abs(belief.mean_j - reserve_boundary)
            / np.maximum(belief.std_j, minimum_std)
        )
    )
    ambiguity = min(receiver_gap, donor_gap, reserve_gap)
    threshold = float(config["voei"]["opportunity_z_threshold"])
    return AmbiguityOpportunity(
        is_opportunity=bool(ambiguity <= threshold),
        ambiguity_index=ambiguity,
        receiver_gap_z=receiver_gap,
        donor_gap_z=donor_gap,
        reserve_gap_z=reserve_gap,
    )
