"""Decision-aware energy information value on a frozen candidate set."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import numpy as np

from src.energy_model.model import wet_efficiency
from src.environment.routing import shortest_path


@dataclass(frozen=True)
class DecisionBelief:
    mean_j: np.ndarray
    std_j: np.ndarray
    lower_j: np.ndarray
    age: np.ndarray
    capacity_j: float
    reserve_j: float
    positions: np.ndarray
    wet_adjacency: tuple[tuple[bool, ...], ...]


@dataclass(frozen=True)
class DecisionAction:
    donor: int | None
    receiver: int | None
    path: tuple[int, ...]
    amount_j: float

    def key(self) -> tuple:
        return (
            -1 if self.donor is None else self.donor,
            -1 if self.receiver is None else self.receiver,
            self.path,
            self.amount_j,
        )


@dataclass(frozen=True)
class OnlineVoEI:
    value: float
    uncertainty: float
    sensitivity: float
    consequence: float
    base_action: DecisionAction


@dataclass(frozen=True)
class OfflineCounterfactualValue:
    value: float
    action_changed: bool
    base_action: DecisionAction
    revealed_action: DecisionAction


def build_candidate_actions(
    belief: DecisionBelief, config: dict[str, Any]
) -> tuple[DecisionAction, ...]:
    actions = [DecisionAction(None, None, (), 0.0)]
    n = belief.mean_j.size
    max_hops = int(config["wet"]["max_path_hops"])
    donor_count = min(n, int(config["voei"]["donor_candidate_count"]))
    receiver_count = min(n, int(config["voei"]["receiver_candidate_count"]))
    donors = np.argsort(-belief.lower_j, kind="mergesort")[:donor_count]
    receivers = np.argsort(belief.mean_j, kind="mergesort")[:receiver_count]
    for donor_value in donors:
        for receiver_value in receivers:
            donor = int(donor_value)
            receiver = int(receiver_value)
            if donor == receiver:
                continue
            path = shortest_path(belief.wet_adjacency, donor, receiver)
            if path is None or len(path) - 1 > max_hops:
                continue
            for amount in config["voei"]["amount_levels_j"]:
                if float(amount) > 0.0:
                    actions.append(
                        DecisionAction(donor, receiver, path, float(amount))
                    )
    return tuple(actions)


def _path_quantities(
    action: DecisionAction,
    belief: DecisionBelief,
    wet_config: dict[str, Any],
) -> tuple[dict[int, float], float]:
    if action.amount_j <= 0.0 or len(action.path) < 2:
        return {}, 0.0
    amount = action.amount_j
    gross: dict[int, float] = {}
    for sender, receiver in zip(action.path[:-1], action.path[1:]):
        gross[sender] = gross.get(sender, 0.0) + amount
        distance = float(
            np.linalg.norm(belief.positions[sender] - belief.positions[receiver])
        )
        amount *= wet_efficiency(distance, wet_config)
    return gross, amount


def action_cost(
    action: DecisionAction,
    belief: DecisionBelief,
    config: dict[str, Any],
) -> float:
    values = belief.mean_j.copy()
    gross, delivered = _path_quantities(action, belief, config["wet"])
    infeasible = False
    for payer, debit in gross.items():
        if belief.lower_j[payer] - debit < belief.reserve_j:
            infeasible = True
    if action.donor is not None:
        values[action.donor] -= action.amount_j
    if action.receiver is not None:
        values[action.receiver] += delivered

    target = float(config["voei"]["service_target_fraction"]) * belief.capacity_j
    unmet = float(np.sum(np.maximum(target - values, 0.0)))
    fairness = float(config["voei"]["fairness_weight"]) * float(np.std(values))
    reserve_deficit = float(np.sum(np.maximum(belief.reserve_j - values, 0.0)))
    reserve_penalty = float(config["voei"]["reserve_penalty_weight"]) * reserve_deficit
    wet_loss = float(config["voei"]["wet_loss_weight"]) * max(
        0.0, action.amount_j - delivered
    )
    infeasible_penalty = (
        float(config["voei"]["infeasible_penalty_j"]) if infeasible else 0.0
    )
    return unmet + fairness + reserve_penalty + wet_loss + infeasible_penalty


def select_action(
    belief: DecisionBelief,
    candidates: tuple[DecisionAction, ...],
    config: dict[str, Any],
) -> tuple[DecisionAction, float]:
    scored = [(action_cost(action, belief, config), action.key(), action) for action in candidates]
    cost, _, action = min(scored, key=lambda item: (item[0], item[1]))
    return action, float(cost)


def reveal_node(
    belief: DecisionBelief, node: int, revealed_energy_j: float
) -> DecisionBelief:
    mean = belief.mean_j.copy()
    std = belief.std_j.copy()
    lower = belief.lower_j.copy()
    value = float(np.clip(revealed_energy_j, 0.0, belief.capacity_j))
    mean[node] = value
    std[node] = 0.0
    lower[node] = value
    return replace(belief, mean_j=mean, std_j=std, lower_j=lower)


def full_decision_aware_voei(
    belief: DecisionBelief,
    node: int,
    candidates: tuple[DecisionAction, ...],
    config: dict[str, Any],
    rng: np.random.Generator,
) -> OnlineVoEI:
    """Compute belief-only expected decision-regret reduction.

    No physical truth argument exists in this online function.
    """

    base_action, _ = select_action(belief, candidates, config)
    count = int(config["voei"]["belief_samples"])
    std = max(0.0, float(belief.std_j[node]))
    samples = (
        np.full(count, belief.mean_j[node])
        if std == 0.0
        else rng.normal(float(belief.mean_j[node]), std, count)
    )
    samples = np.clip(samples, 0.0, belief.capacity_j)
    regrets: list[float] = []
    changed: list[bool] = []
    for sample in samples:
        revealed = reveal_node(belief, node, float(sample))
        optimal, optimal_cost = select_action(revealed, candidates, config)
        base_cost = action_cost(base_action, revealed, config)
        regrets.append(max(0.0, base_cost - optimal_cost))
        changed.append(optimal.key() != base_action.key())
    changed_regrets = [value for value, flag in zip(regrets, changed) if flag]
    uncertainty = 2.0 * std / belief.capacity_j
    sensitivity = float(np.mean(changed))
    consequence = float(np.mean(changed_regrets)) if changed_regrets else 0.0
    return OnlineVoEI(
        value=float(np.mean(regrets)),
        uncertainty=uncertainty,
        sensitivity=sensitivity,
        consequence=consequence,
        base_action=base_action,
    )


def offline_true_counterfactual_value(
    belief: DecisionBelief,
    node: int,
    true_energy_j: float,
    candidates: tuple[DecisionAction, ...],
    config: dict[str, Any],
) -> OfflineCounterfactualValue:
    """Offline-only label; callers must not return it to the controller."""

    base_action, _ = select_action(belief, candidates, config)
    revealed = reveal_node(belief, node, true_energy_j)
    revealed_action, revealed_cost = select_action(revealed, candidates, config)
    base_cost = action_cost(base_action, revealed, config)
    return OfflineCounterfactualValue(
        value=max(0.0, base_cost - revealed_cost),
        action_changed=revealed_action.key() != base_action.key(),
        base_action=base_action,
        revealed_action=revealed_action,
    )


def baseline_information_scores(
    belief: DecisionBelief, config: dict[str, Any], random_scores: np.ndarray
) -> dict[str, np.ndarray]:
    target = float(config["voei"]["service_target_fraction"]) * belief.capacity_j
    return {
        "age": belief.age.astype(float),
        "uncertainty": belief.std_j.astype(float),
        "urgency": np.maximum(target - belief.mean_j, 0.0),
        "random": np.asarray(random_scores, dtype=float),
    }
