"""Causal node-energy belief maintained from reports and confirmed actions."""
