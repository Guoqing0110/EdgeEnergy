"""Split-conformal scaling for role- and age-conditioned energy intervals."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Iterable

import numpy as np


def age_bucket(age: int, edges: Iterable[int]) -> str:
    values = sorted(int(x) for x in edges)
    if not values or values[0] != 0:
        raise ValueError("age bucket edges must start at zero")
    for lo, hi in zip(values[:-1], values[1:]):
        if lo <= age < hi:
            return f"{lo}-{hi - 1}"
    return f"{values[-1]}+"


def finite_sample_quantile(values: Iterable[float], coverage: float) -> float:
    data = np.sort(np.asarray(tuple(values), dtype=float))
    if data.size == 0:
        raise ValueError("cannot calibrate from no residuals")
    rank = min(data.size, max(1, ceil((data.size + 1) * float(coverage))))
    return float(data[rank - 1])


@dataclass(frozen=True)
class CalibrationEntry:
    multiplier: float
    sample_count: int
    source_level: str


@dataclass(frozen=True)
class IntervalCalibration:
    coverage: float
    age_edges: tuple[int, ...]
    entries: dict[str, CalibrationEntry]
    global_entry: CalibrationEntry

    def lookup(self, role: str, age: int) -> CalibrationEntry:
        bucket = age_bucket(age, self.age_edges)
        return self.entries.get(
            f"{role}|{bucket}",
            self.entries.get(f"{role}|*", self.global_entry),
        )

    def serializable(self) -> dict:
        return {
            "coverage": self.coverage,
            "age_edges": list(self.age_edges),
            "entries": {
                key: {
                    "multiplier": value.multiplier,
                    "sample_count": value.sample_count,
                    "source_level": value.source_level,
                }
                for key, value in sorted(self.entries.items())
            },
            "global": {
                "multiplier": self.global_entry.multiplier,
                "sample_count": self.global_entry.sample_count,
                "source_level": self.global_entry.source_level,
            },
        }


def fit_interval_calibration(
    rows: Iterable[dict],
    coverage: float,
    age_edges: Iterable[int],
    minimum_group_samples: int,
) -> IntervalCalibration:
    usable = [
        row
        for row in rows
        if row["method"] == "uncertainty_twin"
        and np.isfinite(row["standardized_abs_residual"])
    ]
    all_values = [float(row["standardized_abs_residual"]) for row in usable]
    global_entry = CalibrationEntry(
        finite_sample_quantile(all_values, coverage), len(all_values), "global"
    )
    edge_tuple = tuple(int(x) for x in age_edges)
    roles = sorted({str(row["role"]) for row in usable})
    entries: dict[str, CalibrationEntry] = {}
    for role in roles:
        role_rows = [row for row in usable if row["role"] == role]
        role_values = [float(row["standardized_abs_residual"]) for row in role_rows]
        if len(role_values) >= minimum_group_samples:
            role_entry = CalibrationEntry(
                finite_sample_quantile(role_values, coverage), len(role_values), "role"
            )
        else:
            role_entry = global_entry
        entries[f"{role}|*"] = role_entry
        buckets = sorted({age_bucket(int(row["age"]), edge_tuple) for row in role_rows})
        for bucket in buckets:
            group_values = [
                float(row["standardized_abs_residual"])
                for row in role_rows
                if age_bucket(int(row["age"]), edge_tuple) == bucket
            ]
            if len(group_values) >= minimum_group_samples:
                entries[f"{role}|{bucket}"] = CalibrationEntry(
                    finite_sample_quantile(group_values, coverage),
                    len(group_values),
                    "role_age",
                )
            else:
                entries[f"{role}|{bucket}"] = CalibrationEntry(
                    role_entry.multiplier,
                    len(group_values),
                    "role_fallback" if role_entry is not global_entry else "global_fallback",
                )
    return IntervalCalibration(
        coverage=float(coverage),
        age_edges=edge_tuple,
        entries=entries,
        global_entry=global_entry,
    )


def calibration_from_dict(value: dict) -> IntervalCalibration:
    entries = {
        key: CalibrationEntry(
            float(item["multiplier"]), int(item["sample_count"]), str(item["source_level"])
        )
        for key, item in value["entries"].items()
    }
    global_value = value["global"]
    return IntervalCalibration(
        coverage=float(value["coverage"]),
        age_edges=tuple(int(x) for x in value["age_edges"]),
        entries=entries,
        global_entry=CalibrationEntry(
            float(global_value["multiplier"]),
            int(global_value["sample_count"]),
            str(global_value["source_level"]),
        ),
    )
