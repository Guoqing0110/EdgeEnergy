"""Minimal uncertainty-aware state-space belief for Stage 1."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

import numpy as np


@dataclass
class NodeBelief:
    mean_j: float
    variance_j2: float
    age: int
    role: str = "idle"
    residuals_j: list[float] = field(default_factory=list)

    def interval(self, z: float, capacity_j: float) -> tuple[float, float]:
        half_width = float(z) * np.sqrt(max(0.0, self.variance_j2))
        return (
            max(0.0, self.mean_j - half_width),
            min(float(capacity_j), self.mean_j + half_width),
        )


class BeliefSystem:
    def __init__(
        self,
        initial_mean_j: Iterable[float],
        capacity_j: float,
        initial_variance_j2: float,
        process_variance_j2: float,
        measurement_variance_j2: float,
        interval_z: float,
    ) -> None:
        self.capacity_j = float(capacity_j)
        self.process_variance_j2 = float(process_variance_j2)
        self.measurement_variance_j2 = float(measurement_variance_j2)
        self.interval_z = float(interval_z)
        self.nodes = [
            NodeBelief(float(value), float(initial_variance_j2), 0)
            for value in initial_mean_j
        ]

    def advance(
        self,
        predicted_delta_j: Iterable[float],
        roles: Iterable[str] | None = None,
    ) -> None:
        delta = tuple(float(x) for x in predicted_delta_j)
        if len(delta) != len(self.nodes):
            raise ValueError("predicted delta has wrong node count")
        role_values = tuple(roles) if roles is not None else tuple(n.role for n in self.nodes)
        if len(role_values) != len(self.nodes):
            raise ValueError("roles have wrong node count")
        role_multiplier = {"idle": 1.0, "receiver": 1.2, "donor": 1.5, "relay": 1.7}
        for node, change, role in zip(self.nodes, delta, role_values):
            node.mean_j = float(np.clip(node.mean_j + change, 0.0, self.capacity_j))
            node.variance_j2 += self.process_variance_j2 * role_multiplier.get(role, 1.0)
            node.age += 1
            node.role = role

    def measurement_update(self, node_id: int, measurement_j: float) -> None:
        node = self.nodes[int(node_id)]
        prior_mean = node.mean_j
        prior_variance = max(node.variance_j2, 0.0)
        denominator = prior_variance + self.measurement_variance_j2
        gain = 0.0 if denominator <= 0.0 else prior_variance / denominator
        residual = float(measurement_j) - prior_mean
        node.mean_j = float(
            np.clip(prior_mean + gain * residual, 0.0, self.capacity_j)
        )
        node.variance_j2 = max(0.0, (1.0 - gain) * prior_variance)
        node.age = 0
        node.residuals_j.append(residual)
        if len(node.residuals_j) > 20:
            del node.residuals_j[:-20]

    def apply_confirmed_delta(self, delta_j: Iterable[float]) -> None:
        """Apply a deterministic, post-measurement debit/credit without aging."""

        values = tuple(float(x) for x in delta_j)
        if len(values) != len(self.nodes):
            raise ValueError("confirmed delta has wrong node count")
        for node, change in zip(self.nodes, values):
            node.mean_j = float(np.clip(node.mean_j + change, 0.0, self.capacity_j))

    def means(self) -> np.ndarray:
        return np.asarray([node.mean_j for node in self.nodes], dtype=float)

    def variances(self) -> np.ndarray:
        return np.asarray([node.variance_j2 for node in self.nodes], dtype=float)

    def ages(self) -> np.ndarray:
        return np.asarray([node.age for node in self.nodes], dtype=int)

    def intervals(self) -> tuple[np.ndarray, np.ndarray]:
        pairs = [node.interval(self.interval_z, self.capacity_j) for node in self.nodes]
        return (
            np.asarray([pair[0] for pair in pairs]),
            np.asarray([pair[1] for pair in pairs]),
        )
