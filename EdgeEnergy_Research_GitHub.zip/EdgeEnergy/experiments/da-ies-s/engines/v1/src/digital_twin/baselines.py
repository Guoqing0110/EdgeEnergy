"""Belief baselines sharing the same causal observation stream."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from src.digital_twin.belief import BeliefSystem


class LastValueCache:
    name = "last_value"

    def __init__(self, initial: Iterable[float], capacity_j: float) -> None:
        self.capacity_j = float(capacity_j)
        self.mean = np.asarray(tuple(initial), dtype=float)
        self.age = np.zeros(self.mean.size, dtype=int)

    def advance(self, predicted_delta_j: Iterable[float], roles: Iterable[str]) -> None:
        del predicted_delta_j, roles
        self.age += 1

    def update(self, node: int, measurement_j: float) -> None:
        self.mean[node] = float(np.clip(measurement_j, 0.0, self.capacity_j))
        self.age[node] = 0

    def apply_confirmed_delta(self, delta_j: Iterable[float]) -> None:
        self.mean = np.clip(
            self.mean + np.asarray(tuple(delta_j), dtype=float),
            0.0,
            self.capacity_j,
        )

    def means(self) -> np.ndarray:
        return self.mean.copy()

    def variances(self) -> np.ndarray:
        return np.zeros_like(self.mean)

    def ages(self) -> np.ndarray:
        return self.age.copy()


class DeterministicTwin(LastValueCache):
    name = "deterministic_twin"

    def advance(self, predicted_delta_j: Iterable[float], roles: Iterable[str]) -> None:
        del roles
        self.mean = np.clip(
            self.mean + np.asarray(tuple(predicted_delta_j), dtype=float),
            0.0,
            self.capacity_j,
        )
        self.age += 1


class UncertaintyTwin:
    name = "uncertainty_twin"

    def __init__(
        self,
        initial: Iterable[float],
        capacity_j: float,
        initial_variance_j2: float,
        process_variance_j2: float,
        measurement_variance_j2: float,
        interval_z: float,
    ) -> None:
        self.system = BeliefSystem(
            initial,
            capacity_j,
            initial_variance_j2,
            process_variance_j2,
            measurement_variance_j2,
            interval_z,
        )

    def advance(self, predicted_delta_j: Iterable[float], roles: Iterable[str]) -> None:
        self.system.advance(predicted_delta_j, roles)

    def update(self, node: int, measurement_j: float) -> None:
        self.system.measurement_update(node, measurement_j)

    def apply_confirmed_delta(self, delta_j: Iterable[float]) -> None:
        self.system.apply_confirmed_delta(delta_j)

    def means(self) -> np.ndarray:
        return self.system.means()

    def variances(self) -> np.ndarray:
        return self.system.variances()

    def ages(self) -> np.ndarray:
        return self.system.ages()


@dataclass
class FullStateOracle:
    """Offline estimator reference; never passed to an online controller."""

    node_count: int
    name: str = "full_state_oracle"
    _truth: np.ndarray | None = None

    def set_truth(self, truth: np.ndarray) -> None:
        self._truth = np.asarray(truth, dtype=float).copy()

    def means(self) -> np.ndarray:
        if self._truth is None:
            raise RuntimeError("oracle truth not set by offline evaluator")
        return self._truth.copy()

    def variances(self) -> np.ndarray:
        return np.zeros(self.node_count)

    def ages(self) -> np.ndarray:
        return np.zeros(self.node_count, dtype=int)
