"""Sequential battery accounting and WET execution."""
