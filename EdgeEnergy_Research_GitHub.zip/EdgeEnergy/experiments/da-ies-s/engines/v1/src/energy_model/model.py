"""Physical energy ledger with explicit credits, debits, clipping, and shortfalls."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np


@dataclass
class PhysicalState:
    """Offline-only physical battery state.

    This type must never be imported by online scheduler or guard modules.
    """

    energy_j: np.ndarray
    capacity_j: np.ndarray

    @classmethod
    def from_initial(cls, initial: np.ndarray, capacity_j: float) -> "PhysicalState":
        initial_array = np.asarray(initial, dtype=float).copy()
        capacity = np.full_like(initial_array, float(capacity_j))
        if np.any(initial_array < 0) or np.any(initial_array > capacity):
            raise ValueError("initial energy outside battery bounds")
        return cls(initial_array, capacity)


@dataclass
class SlotEnergyLedger:
    state: PhysicalState
    energy_before_j: np.ndarray = field(init=False)
    requested_debits: dict[str, np.ndarray] = field(default_factory=dict)
    executed_debits: dict[str, np.ndarray] = field(default_factory=dict)
    credits: dict[str, np.ndarray] = field(default_factory=dict)
    shortfalls: dict[str, np.ndarray] = field(default_factory=dict)
    overflow_j: np.ndarray = field(init=False)

    def __post_init__(self) -> None:
        self.energy_before_j = self.state.energy_j.copy()
        self.overflow_j = np.zeros_like(self.state.energy_j)

    @property
    def node_count(self) -> int:
        return int(self.state.energy_j.size)

    def _vector(self, mapping: dict[str, np.ndarray], category: str) -> np.ndarray:
        if category not in mapping:
            mapping[category] = np.zeros(self.node_count, dtype=float)
        return mapping[category]

    def debit(self, node: int, amount_j: float, category: str) -> tuple[float, float]:
        requested = max(0.0, float(amount_j))
        executed = min(float(self.state.energy_j[node]), requested)
        shortfall = requested - executed
        self.state.energy_j[node] -= executed
        self._vector(self.requested_debits, category)[node] += requested
        self._vector(self.executed_debits, category)[node] += executed
        self._vector(self.shortfalls, category)[node] += shortfall
        return executed, shortfall

    def credit(self, node: int, amount_j: float, category: str) -> tuple[float, float]:
        requested = max(0.0, float(amount_j))
        headroom = float(self.state.capacity_j[node] - self.state.energy_j[node])
        stored = min(headroom, requested)
        overflow = requested - stored
        self.state.energy_j[node] += stored
        self._vector(self.credits, category)[node] += stored
        self.overflow_j[node] += overflow
        return stored, overflow

    def total_executed_debits(self) -> np.ndarray:
        if not self.executed_debits:
            return np.zeros(self.node_count, dtype=float)
        return np.sum(np.stack(list(self.executed_debits.values())), axis=0)

    def total_credits(self) -> np.ndarray:
        if not self.credits:
            return np.zeros(self.node_count, dtype=float)
        return np.sum(np.stack(list(self.credits.values())), axis=0)

    def conservation_residual(self) -> np.ndarray:
        expected = self.energy_before_j + self.total_credits() - self.total_executed_debits()
        return self.state.energy_j - expected

    def assert_conservation(self, atol: float = 1e-8) -> None:
        residual = self.conservation_residual()
        if not np.all(np.abs(residual) <= atol):
            raise AssertionError(f"energy conservation residual: {residual}")
        if np.any(self.state.energy_j < -atol) or np.any(
            self.state.energy_j - self.state.capacity_j > atol
        ):
            raise AssertionError("battery clipping invariant violated")

    def serializable(self) -> dict[str, Any]:
        def vectors(data: dict[str, np.ndarray]) -> dict[str, list[float]]:
            return {key: value.tolist() for key, value in sorted(data.items())}

        return {
            "energy_before_j": self.energy_before_j.tolist(),
            "energy_after_j": self.state.energy_j.tolist(),
            "requested_debits_j": vectors(self.requested_debits),
            "executed_debits_j": vectors(self.executed_debits),
            "credits_j": vectors(self.credits),
            "shortfalls_j": vectors(self.shortfalls),
            "overflow_j": self.overflow_j.tolist(),
            "conservation_residual_j": self.conservation_residual().tolist(),
        }


@dataclass(frozen=True)
class WETResult:
    path: tuple[int, ...]
    requested_first_hop_j: float
    launched_by_node_j: dict[int, float]
    received_by_node_j: dict[int, float]
    delivered_to_receiver_j: float
    conversion_loss_j: float
    shortfall_j: float


def wet_efficiency(distance_m: float, wet_config: dict[str, float]) -> float:
    eta = float(wet_config["eta_0"]) / (
        1.0
        + (float(distance_m) / float(wet_config["d0_m"]))
        ** float(wet_config["distance_exponent"])
    )
    return min(float(wet_config["eta_max"]), max(0.0, eta))


def execute_wet(
    ledger: SlotEnergyLedger,
    path: Iterable[int],
    first_hop_amount_j: float,
    positions: np.ndarray,
    wet_config: dict[str, float],
) -> WETResult:
    nodes = tuple(int(x) for x in path)
    requested = max(0.0, float(first_hop_amount_j))
    if requested == 0.0 or len(nodes) < 2:
        return WETResult(nodes, requested, {}, {}, 0.0, 0.0, 0.0)

    launched: dict[int, float] = {}
    received: dict[int, float] = {}
    conversion_loss = 0.0
    shortfall = 0.0
    amount_to_launch = requested
    for hop, (sender, receiver) in enumerate(zip(nodes[:-1], nodes[1:])):
        executed, missing = ledger.debit(sender, amount_to_launch, "wet_tx")
        launched[sender] = launched.get(sender, 0.0) + executed
        shortfall += missing
        if executed <= 0.0:
            break
        distance = float(np.linalg.norm(positions[sender] - positions[receiver]))
        eta = wet_efficiency(distance, wet_config)
        arrived = eta * executed
        stored, overflow = ledger.credit(receiver, arrived, "wet_rx")
        received[receiver] = received.get(receiver, 0.0) + stored
        conversion_loss += executed - arrived + overflow
        if hop < len(nodes) - 2:
            # The relay forwards only what was actually stored from the preceding
            # hop; its receive credit and gross transmit debit remain separate.
            amount_to_launch = stored

    delivered = received.get(nodes[-1], 0.0)
    return WETResult(
        path=nodes,
        requested_first_hop_j=requested,
        launched_by_node_j=launched,
        received_by_node_j=received,
        delivered_to_receiver_j=delivered,
        conversion_loss_j=conversion_loss,
        shortfall_j=shortfall,
    )
