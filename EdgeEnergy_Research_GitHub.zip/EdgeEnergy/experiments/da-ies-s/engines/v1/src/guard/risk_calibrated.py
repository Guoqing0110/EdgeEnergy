"""Causal tail-calibrated payer guard for DA-IES-S.

The guard consumes only the slot-start online snapshot, the planned action and
planned gross debits.  It has no executor truth or same-slot innovation input.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Any, Mapping

from src.scheduler.types import Action, OnlineSnapshot


@dataclass(frozen=True)
class PayerRiskAssessment:
    node_id: int
    role: str
    lower_j: float
    standard_deviation_j: float
    predicted_gross_debit_j: float
    effective_margin_j: float
    post_action_lower_j: float
    reserve_j: float
    passed: bool


@dataclass(frozen=True)
class RiskGuardDecision:
    passed: bool
    assessments: tuple[PayerRiskAssessment, ...]


def planned_payer_role(action: Action, node_id: int) -> str:
    node = int(node_id)
    if action.donor == node:
        return "donor"
    if len(action.wet_path) >= 3 and node in action.wet_path[1:-1]:
        return "relay"
    if node in action.state_subset:
        return "reporter"
    return "payer"


def effective_margin_j(
    snapshot: OnlineSnapshot,
    action: Action,
    node_id: int,
    risk_config: Mapping[str, Any],
) -> tuple[str, float]:
    view = snapshot.node(node_id)
    role = planned_payer_role(action, node_id)
    role_tail = risk_config.get("role_tail_allowance_j", {})
    tail = float(role_tail.get(role, risk_config["tail_allowance_j"]))
    standard_deviation = sqrt(max(0.0, float(view.variance_j2)))
    age = min(int(view.age), int(risk_config["maximum_age_for_margin_slots"]))
    margin = (
        float(risk_config["base_margin_j"])
        + tail
        + float(risk_config["uncertainty_multiplier"]) * standard_deviation
        + float(risk_config["age_margin_j_per_slot"]) * age
    )
    return role, float(margin)


def assess_risk_calibrated_candidate(
    snapshot: OnlineSnapshot,
    action: Action,
    predicted_debits_j: Mapping[int, float],
    risk_config: Mapping[str, Any],
) -> RiskGuardDecision:
    assessments: list[PayerRiskAssessment] = []
    for node_id, debit in sorted(predicted_debits_j.items()):
        if float(debit) <= 0.0:
            continue
        view = snapshot.node(node_id)
        role, margin = effective_margin_j(
            snapshot, action, int(node_id), risk_config
        )
        standard_deviation = sqrt(max(0.0, float(view.variance_j2)))
        post = float(view.lower_j) - float(debit) - margin
        assessments.append(
            PayerRiskAssessment(
                node_id=int(node_id),
                role=role,
                lower_j=float(view.lower_j),
                standard_deviation_j=standard_deviation,
                predicted_gross_debit_j=float(debit),
                effective_margin_j=margin,
                post_action_lower_j=post,
                reserve_j=float(snapshot.reserve_j),
                passed=post >= float(snapshot.reserve_j),
            )
        )
    return RiskGuardDecision(
        passed=all(item.passed for item in assessments),
        assessments=tuple(assessments),
    )
