"""Fixed causal pre-action reserve filter."""
