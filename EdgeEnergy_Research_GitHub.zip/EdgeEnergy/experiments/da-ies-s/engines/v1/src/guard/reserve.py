"""Belief-only lower-layer guard; no truth state is accessible here."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from src.scheduler.types import Action, OnlineSnapshot


@dataclass(frozen=True)
class GuardRejection:
    node_id: int
    lower_j: float
    predicted_gross_debit_j: float
    margin_j: float
    reserve_j: float
    reason: str


@dataclass(frozen=True)
class GuardDecision:
    passed: bool
    rejections: tuple[GuardRejection, ...]


def assess_candidate(
    snapshot: OnlineSnapshot,
    action: Action,
    predicted_debits_j: Mapping[int, float],
    margin_j: float,
) -> GuardDecision:
    if action.is_null:
        return GuardDecision(True, ())
    rejections: list[GuardRejection] = []
    for node_id, debit in sorted(predicted_debits_j.items()):
        if debit <= 0.0:
            continue
        lower = snapshot.node(node_id).lower_j
        if lower - float(debit) - float(margin_j) < snapshot.reserve_j:
            rejections.append(
                GuardRejection(
                    node_id=node_id,
                    lower_j=lower,
                    predicted_gross_debit_j=float(debit),
                    margin_j=float(margin_j),
                    reserve_j=snapshot.reserve_j,
                    reason="belief_lower_below_reserve_after_predicted_debit",
                )
            )
    return GuardDecision(not rejections, tuple(rejections))
