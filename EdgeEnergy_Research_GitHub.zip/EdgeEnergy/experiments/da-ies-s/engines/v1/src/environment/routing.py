"""Small deterministic graph utilities with stable tie breaking."""

from __future__ import annotations

from collections import deque
from typing import Iterable, Sequence


def shortest_path(
    adjacency: Sequence[Sequence[bool]], source: int, target: int
) -> tuple[int, ...] | None:
    """Return a hop-minimal path; node ids break ties deterministically."""

    if source == target:
        return (source,)
    n = len(adjacency)
    if not (0 <= source < n and 0 <= target < n):
        raise IndexError("source or target outside adjacency")
    parent: dict[int, int | None] = {source: None}
    queue: deque[int] = deque([source])
    while queue:
        current = queue.popleft()
        neighbors = [j for j, connected in enumerate(adjacency[current]) if connected]
        for nxt in sorted(neighbors):
            if nxt in parent:
                continue
            parent[nxt] = current
            if nxt == target:
                path = [target]
                while parent[path[-1]] is not None:
                    path.append(parent[path[-1]])  # type: ignore[arg-type]
                return tuple(reversed(path))
            queue.append(nxt)
    return None


def path_hops(path: Iterable[int]) -> int:
    nodes = tuple(path)
    return max(0, len(nodes) - 1)
