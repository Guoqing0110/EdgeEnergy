"""Generation and serialization of policy-independent exogenous traces."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

import numpy as np


@dataclass(frozen=True)
class ExogenousTrace:
    seed: int
    positions: np.ndarray
    sink_position: np.ndarray
    initial_energy: np.ndarray
    harvest_expected: np.ndarray
    harvest_actual: np.ndarray
    visible_load: np.ndarray
    hidden_load: np.ndarray
    measurement_noise: np.ndarray
    comm_adjacency: np.ndarray
    wet_adjacency: np.ndarray
    comm_success_probability: np.ndarray
    comm_success_uniform: np.ndarray

    @property
    def slots(self) -> int:
        return int(self.harvest_actual.shape[0])

    @property
    def node_count(self) -> int:
        return int(self.initial_energy.shape[0])

    @property
    def sink_id(self) -> int:
        return self.node_count

    def content_hash(self) -> str:
        digest = sha256()
        digest.update(str(self.seed).encode())
        for array in (
            self.positions,
            self.sink_position,
            self.initial_energy,
            self.harvest_expected,
            self.harvest_actual,
            self.visible_load,
            self.hidden_load,
            self.measurement_noise,
            self.comm_adjacency,
            self.wet_adjacency,
            self.comm_success_probability,
            self.comm_success_uniform,
        ):
            digest.update(np.ascontiguousarray(array).tobytes())
        return digest.hexdigest()

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            path,
            seed=np.array([self.seed], dtype=np.uint64),
            positions=self.positions,
            sink_position=self.sink_position,
            initial_energy=self.initial_energy,
            harvest_expected=self.harvest_expected,
            harvest_actual=self.harvest_actual,
            visible_load=self.visible_load,
            hidden_load=self.hidden_load,
            measurement_noise=self.measurement_noise,
            comm_adjacency=self.comm_adjacency,
            wet_adjacency=self.wet_adjacency,
            comm_success_probability=self.comm_success_probability,
            comm_success_uniform=self.comm_success_uniform,
        )


def _pairwise_distances(points: np.ndarray) -> np.ndarray:
    delta = points[:, None, :] - points[None, :, :]
    return np.sqrt(np.sum(delta * delta, axis=-1))


def _spawn_rngs(seed: int, count: int) -> list[np.random.Generator]:
    return [np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(count)]


def generate_trace(config: dict[str, Any], seed: int) -> ExogenousTrace:
    """Generate one trace without consulting or depending on a policy."""

    sim = config["simulation"]
    energy = config["energy"]
    comm = config["communication"]
    wet = config["wet"]
    belief = config["belief"]
    slots = int(sim["slots"])
    nodes = int(sim["node_count"])
    area = np.asarray(sim["area_m"], dtype=float)
    rng_top, rng_energy, rng_harvest, rng_load, rng_link, rng_measure = _spawn_rngs(seed, 6)

    positions = rng_top.uniform([0.0, 0.0], area, size=(nodes, 2))
    sink_position = area / 2.0
    all_positions = np.vstack([positions, sink_position])
    comm_dist = _pairwise_distances(all_positions)
    wet_dist = _pairwise_distances(positions)
    comm_adj = (comm_dist <= float(comm["range_m"])) & (comm_dist > 0)
    wet_adj = (wet_dist <= float(wet["range_m"])) & (wet_dist > 0)

    # The sink is made reachable from every sensor only if the sampled geometric
    # graph would otherwise strand it. This deterministic repair is part of the
    # saved topology and applies to every method.
    for node in range(nodes):
        if not np.any(comm_adj[node]):
            nearest = int(np.argsort(comm_dist[node])[1])
            comm_adj[node, nearest] = comm_adj[nearest, node] = True
    if not np.any(comm_adj[nodes, :nodes]):
        nearest = int(np.argmin(comm_dist[nodes, :nodes]))
        comm_adj[nodes, nearest] = comm_adj[nearest, nodes] = True

    capacity = float(energy["capacity_j"])
    initial_lo, initial_hi = map(float, energy["initial_fraction"])
    initial_energy = capacity * rng_energy.uniform(initial_lo, initial_hi, nodes)

    node_harvest_scale = rng_harvest.uniform(0.75, 1.25, nodes)
    phase = rng_harvest.uniform(-np.pi, np.pi, nodes)
    t = np.arange(slots, dtype=float)[:, None]
    harvest_period = float(energy.get("harvest_period_slots", max(slots, 24)))
    daily = np.sin(2 * np.pi * t / harvest_period + phase[None, :])
    harvest_expected = np.maximum(
        0.0,
        float(energy["harvest_mean_j"]) * node_harvest_scale[None, :]
        + float(energy["harvest_daily_amplitude_j"]) * daily,
    )
    harvest_actual = np.maximum(
        0.0,
        harvest_expected
        + rng_harvest.normal(0.0, float(energy["harvest_noise_sd_j"]), (slots, nodes)),
    )

    node_load = np.maximum(
        0.0,
        rng_load.normal(
            float(energy["visible_load_mean_j"]),
            float(energy["visible_load_node_sd_j"]),
            nodes,
        ),
    )
    visible_load = np.maximum(
        0.0,
        node_load[None, :]
        + rng_load.normal(0.0, float(energy["visible_load_noise_sd_j"]), (slots, nodes)),
    )
    hidden_load = rng_load.exponential(
        float(energy["hidden_load_mean_j"]), size=(slots, nodes)
    )
    bursts = rng_load.random((slots, nodes)) < float(energy["hidden_load_burst_probability"])
    hidden_load = hidden_load + bursts * float(energy["hidden_load_burst_j"])
    measurement_noise = rng_measure.normal(
        0.0,
        np.sqrt(float(belief["measurement_variance_j2"])),
        size=(slots, nodes),
    )

    normalized = np.clip(comm_dist / float(comm["range_m"]), 0.0, 1.0)
    p_hi = float(comm["max_link_success"])
    p_lo = float(comm["min_link_success"])
    probability = p_hi - (p_hi - p_lo) * normalized
    probability[~comm_adj] = 0.0
    np.fill_diagonal(probability, 1.0)
    success_uniform = rng_link.random((slots, nodes + 1, nodes + 1))

    return ExogenousTrace(
        seed=int(seed),
        positions=positions,
        sink_position=sink_position,
        initial_energy=initial_energy,
        harvest_expected=harvest_expected,
        harvest_actual=harvest_actual,
        visible_load=visible_load,
        hidden_load=hidden_load,
        measurement_noise=measurement_noise,
        comm_adjacency=comm_adj,
        wet_adjacency=wet_adj,
        comm_success_probability=probability,
        comm_success_uniform=success_uniform,
    )
