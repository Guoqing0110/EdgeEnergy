"""Physical truth and exogenous trace generation.

Types from this package are intentionally unavailable to the online scheduler.
"""
