"""Two engineering smoke policies for Stage 1.

They are not the proposed Full VoEI/QBCS method and generate no paper claim.
"""

from __future__ import annotations

from dataclasses import dataclass

from src.environment.routing import shortest_path
from src.scheduler.types import Action, CandidateAction, OnlineSnapshot, null_action


@dataclass(frozen=True)
class Stage1PolicyConfig:
    fixed_amount_j: float
    report_interval: int
    max_path_hops: int


class Stage1Scheduler:
    def __init__(self, method: str, config: Stage1PolicyConfig) -> None:
        if method not in {"fixed_periodic", "age_selective"}:
            raise ValueError(f"unsupported Stage 1 method: {method}")
        self.method = method
        self.config = config

    def _energy_endpoints(self, snapshot: OnlineSnapshot) -> tuple[int, int] | None:
        receiver = min(snapshot.nodes, key=lambda n: (n.mean_j, n.node_id)).node_id
        donor_options = [node for node in snapshot.nodes if node.node_id != receiver]
        if not donor_options:
            return None
        donor = max(donor_options, key=lambda n: (n.lower_j, -n.node_id)).node_id
        return donor, receiver

    def propose(self, snapshot: OnlineSnapshot) -> tuple[CandidateAction, ...]:
        endpoints = self._energy_endpoints(snapshot)
        due = snapshot.slot % self.config.report_interval == 0
        action = null_action()
        note = "no feasible endpoint pair"
        if endpoints is not None:
            donor, receiver = endpoints
            wet_path = shortest_path(snapshot.wet_adjacency, donor, receiver)
            if wet_path is not None and len(wet_path) - 1 <= self.config.max_path_hops:
                if self.method == "fixed_periodic":
                    if due:
                        ordered = tuple(node.node_id for node in snapshot.nodes)
                        start = (
                            (snapshot.slot // self.config.report_interval)
                            * snapshot.max_report_fields
                        ) % len(ordered)
                        subset = tuple(
                            ordered[(start + offset) % len(ordered)]
                            for offset in range(snapshot.max_report_fields)
                        )
                    else:
                        subset = ()
                    mode = "independent" if subset else "none"
                else:
                    eligible = [snapshot.node(node_id) for node_id in wet_path]
                    ranked = sorted(eligible, key=lambda n: (-n.age, n.node_id))
                    subset = (
                        tuple(node.node_id for node in ranked[: snapshot.max_report_fields])
                        if due
                        else ()
                    )
                    mode = "opportunity" if subset else "none"
                action = Action(
                    receiver=receiver,
                    donor=donor,
                    wet_path=wet_path,
                    amount_j=self.config.fixed_amount_j,
                    state_subset=tuple(sorted(subset)),
                    return_mode=mode,
                )
                note = "belief-ranked endpoints with fixed Stage 1 amount"
            else:
                note = "no WET path within the registered hop limit"
        return (
            CandidateAction("primary", action, 1.0, note),
            CandidateAction("null", null_action(), 0.0, "always-feasible fallback"),
        )
