"""Online policies that receive only immutable belief snapshots."""
