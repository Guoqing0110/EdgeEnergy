"""Online-only data types. No physical truth fields are defined here."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class OnlineNodeView:
    node_id: int
    mean_j: float
    variance_j2: float
    lower_j: float
    upper_j: float
    age: int
    role: str


@dataclass(frozen=True)
class OnlineSnapshot:
    slot: int
    nodes: tuple[OnlineNodeView, ...]
    positions: tuple[tuple[float, float], ...]
    sink_position: tuple[float, float]
    comm_adjacency: tuple[tuple[bool, ...], ...]
    wet_adjacency: tuple[tuple[bool, ...], ...]
    sink_id: int
    reserve_j: float
    max_report_fields: int

    def node(self, node_id: int) -> OnlineNodeView:
        return self.nodes[int(node_id)]


@dataclass(frozen=True)
class Action:
    receiver: int | None
    donor: int | None
    wet_path: tuple[int, ...]
    amount_j: float
    state_subset: tuple[int, ...]
    return_mode: str

    @property
    def is_null(self) -> bool:
        return self.amount_j <= 0.0 and not self.state_subset

    def serializable(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CandidateAction:
    candidate_id: str
    action: Action
    priority: float
    construction_note: str


def null_action() -> Action:
    return Action(None, None, (), 0.0, (), "none")
