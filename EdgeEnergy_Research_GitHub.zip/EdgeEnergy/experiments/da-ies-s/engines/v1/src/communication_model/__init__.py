"""Packet-size-aware communication planning and execution."""
