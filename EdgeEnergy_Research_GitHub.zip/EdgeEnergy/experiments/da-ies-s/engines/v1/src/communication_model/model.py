"""Explicit per-hop TX/RX/measurement/processing accounting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from src.energy_model.model import SlotEnergyLedger


@dataclass(frozen=True)
class PacketPlan:
    route: tuple[int, ...]
    selected_nodes: tuple[int, ...]
    mode: str

    def __post_init__(self) -> None:
        route_set = set(self.route[:-1])
        if not set(self.selected_nodes).issubset(route_set):
            raise ValueError("selected node must be a sensor sender on packet route")
        if len(self.route) < 2:
            raise ValueError("packet route needs at least one hop")


@dataclass(frozen=True)
class CommunicationPlan:
    packets: tuple[PacketPlan, ...]


@dataclass(frozen=True)
class PlannedCommunicationCost:
    per_node_debit_j: dict[int, float]
    total_sensor_debit_j: float
    bytes_over_hops: int
    packet_count: int
    hop_count: int


@dataclass(frozen=True)
class CommunicationResult:
    delivered_fields: tuple[int, ...]
    attempted_fields: tuple[int, ...]
    bytes_over_hops: int
    packets_attempted: int
    packets_delivered: int
    hops_attempted: int
    latency_ms: float
    failed_hops: tuple[tuple[int, int], ...]
    energy_shortfall_j: float


def tx_energy_j(payload_bytes: int, distance_m: float, config: dict[str, float]) -> float:
    bits = 8.0 * int(payload_bytes)
    return bits * (
        float(config["electronics_j_per_bit"])
        + float(config["amplifier_j_per_bit_mk"])
        * float(distance_m) ** float(config["path_loss_exponent"])
    )


def rx_energy_j(payload_bytes: int, config: dict[str, float]) -> float:
    return 8.0 * int(payload_bytes) * float(config["electronics_j_per_bit"])


def _append_cost(node: int, debit: dict[int, float], config: dict[str, float]) -> None:
    debit[node] = debit.get(node, 0.0) + float(config["measurement_j"])
    debit[node] += float(config["aggregation_j_per_field"])


def estimate_plan_cost(
    plan: CommunicationPlan,
    all_positions: np.ndarray,
    sink_id: int,
    config: dict[str, float],
) -> PlannedCommunicationCost:
    debit: dict[int, float] = {}
    total_bytes = 0
    total_hops = 0
    header = int(config["header_bytes"])
    field = int(config["state_field_bytes"])
    for packet in plan.packets:
        payload = header
        appended: set[int] = set()
        selected = set(packet.selected_nodes)
        for sender, receiver in zip(packet.route[:-1], packet.route[1:]):
            if sender in selected and sender not in appended:
                _append_cost(sender, debit, config)
                payload += field
                appended.add(sender)
            distance = float(np.linalg.norm(all_positions[sender] - all_positions[receiver]))
            debit[sender] = debit.get(sender, 0.0) + tx_energy_j(payload, distance, config)
            if receiver != sink_id:
                debit[receiver] = debit.get(receiver, 0.0) + rx_energy_j(payload, config)
            total_bytes += payload
            total_hops += 1
    return PlannedCommunicationCost(
        per_node_debit_j=debit,
        total_sensor_debit_j=float(sum(debit.values())),
        bytes_over_hops=total_bytes,
        packet_count=len(plan.packets),
        hop_count=total_hops,
    )


def execute_communication(
    plan: CommunicationPlan,
    ledger: SlotEnergyLedger,
    all_positions: np.ndarray,
    sink_id: int,
    success_probability: np.ndarray,
    success_uniform: np.ndarray,
    config: dict[str, float],
) -> CommunicationResult:
    delivered_fields: set[int] = set()
    attempted_fields: set[int] = set()
    failed_hops: list[tuple[int, int]] = []
    bytes_over_hops = 0
    packets_delivered = 0
    hops_attempted = 0
    shortfall_total = 0.0
    header = int(config["header_bytes"])
    field = int(config["state_field_bytes"])

    for packet in plan.packets:
        payload = header
        appended: set[int] = set()
        selected = set(packet.selected_nodes)
        packet_ok = True
        for sender, receiver in zip(packet.route[:-1], packet.route[1:]):
            if sender in selected and sender not in appended:
                measure, missing_measure = ledger.debit(
                    sender, float(config["measurement_j"]), "report_measurement"
                )
                process, missing_process = ledger.debit(
                    sender,
                    float(config["aggregation_j_per_field"]),
                    "report_processing",
                )
                shortfall_total += missing_measure + missing_process
                attempted_fields.add(sender)
                if missing_measure > 0.0 or missing_process > 0.0:
                    packet_ok = False
                    break
                payload += field
                appended.add(sender)

            distance = float(np.linalg.norm(all_positions[sender] - all_positions[receiver]))
            tx_request = tx_energy_j(payload, distance, config)
            _, tx_missing = ledger.debit(sender, tx_request, "report_tx")
            shortfall_total += tx_missing
            if tx_missing > 0.0:
                packet_ok = False
                break
            if receiver != sink_id:
                rx_request = rx_energy_j(payload, config)
                _, rx_missing = ledger.debit(receiver, rx_request, "report_rx")
                shortfall_total += rx_missing
                if rx_missing > 0.0:
                    packet_ok = False
                    break
            bytes_over_hops += payload
            hops_attempted += 1
            if success_uniform[sender, receiver] >= success_probability[sender, receiver]:
                failed_hops.append((sender, receiver))
                packet_ok = False
                break

        if packet_ok:
            packets_delivered += 1
            delivered_fields.update(appended)

    return CommunicationResult(
        delivered_fields=tuple(sorted(delivered_fields)),
        attempted_fields=tuple(sorted(attempted_fields)),
        bytes_over_hops=bytes_over_hops,
        packets_attempted=len(plan.packets),
        packets_delivered=packets_delivered,
        hops_attempted=hops_attempted,
        latency_ms=hops_attempted * float(config["hop_latency_ms"]),
        failed_hops=tuple(failed_hops),
        energy_shortfall_j=shortfall_total,
    )


def empty_plan() -> CommunicationPlan:
    return CommunicationPlan(packets=())


def selected_field_count(plan: CommunicationPlan) -> int:
    return len({node for packet in plan.packets for node in packet.selected_nodes})


def packet_payload_sequence(
    packet: PacketPlan, config: dict[str, float]
) -> tuple[int, ...]:
    """Expose per-hop payload sizes for audit tests and plotting."""

    payload = int(config["header_bytes"])
    field = int(config["state_field_bytes"])
    selected = set(packet.selected_nodes)
    appended: set[int] = set()
    sequence: list[int] = []
    for sender in packet.route[:-1]:
        if sender in selected and sender not in appended:
            payload += field
            appended.add(sender)
        sequence.append(payload)
    return tuple(sequence)
