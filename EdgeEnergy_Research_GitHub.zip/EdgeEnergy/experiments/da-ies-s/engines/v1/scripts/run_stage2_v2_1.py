#!/usr/bin/env python3
"""Run the frozen Stage 2 v2.1 one-shot validation with v2 calibration."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage2_v2 import (  # noqa: E402
    augment_intervals,
    build_voei_rows_v2,
    generate_benchmark,
    generate_trace,
    load_seeds,
    replay_beliefs_v2,
    scenario_config,
)
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.logging.provenance import canonical_hash, code_hash, write_json, write_jsonl  # noqa: E402


def run(config_path: Path, output_root: Path) -> None:
    config_base = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    phase = "validation_v2_1"
    if config_base["experiment"]["allowed_seed_splits"] != [phase]:
        raise RuntimeError("v2.1 config must authorize only validation_v2_1")
    seed_path = ROOT / "seeds" / f"{phase}.txt"
    seeds = load_seeds(seed_path)
    forbidden_files = [
        "development.txt",
        "calibration.txt",
        "validation.txt",
        "calibration_v2.txt",
        "validation_v2.txt",
        "test_held_out.txt",
    ]
    forbidden: set[int] = set()
    for name in forbidden_files:
        forbidden.update(load_seeds(ROOT / "seeds" / name))
    if len(seeds) != 15 or len(set(seeds)) != 15 or not set(seeds).isdisjoint(forbidden):
        raise RuntimeError("invalid or overlapping v2.1 validation seed registry")

    calibration_path = (
        ROOT
        / "outputs"
        / "stage2_belief_voei_v2"
        / "calibration_parameters_v2.json"
    )
    freeze_path = output_root / "stage2_v2_1_freeze_manifest.json"
    if not calibration_path.exists() or not freeze_path.exists():
        raise RuntimeError("v2.1 requires v2 calibration and a pre-validation freeze")
    calibration_payload = json.loads(calibration_path.read_text(encoding="utf-8"))
    calibration = calibration_from_dict(calibration_payload["calibration"])
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    config_hash = canonical_hash(config_base)
    source_hash = code_hash(ROOT)
    expected = {
        "code_hash": source_hash,
        "config_hash": config_hash,
        "calibration_hash": canonical_hash(calibration_payload["calibration"]),
        "validation_seed_hash": canonical_hash(seeds),
    }
    for field, value in expected.items():
        if freeze.get(field) != value:
            raise RuntimeError(f"v2.1 {field} differs from pre-validation freeze")

    for scenario in config_base["scenarios"]:
        config = scenario_config(config_base, scenario)
        for seed in seeds:
            trace = generate_trace(config, seed)
            seed_root = output_root / "raw" / phase / scenario / f"seed={seed}"
            trace.save(seed_root / "trace.npz")
            write_json(
                seed_root / "trace_manifest.json",
                {
                    "version": "v2.1",
                    "phase": phase,
                    "scenario": scenario,
                    "seed": seed,
                    "trace_hash": trace.content_hash(),
                    "config_hash": config_hash,
                    "code_hash": source_hash,
                    "calibration_hash": expected["calibration_hash"],
                    "held_out": False,
                },
            )
            for interval_value in config["reporting"]["intervals_slots"]:
                interval = int(interval_value)
                benchmark = generate_benchmark(config, trace, interval)
                rows = replay_beliefs_v2(config, benchmark, scenario)
                augment_intervals(
                    rows, calibration, float(config["energy"]["capacity_j"])
                )
                interval_root = seed_root / f"report_interval={interval}"
                write_jsonl(interval_root / "belief_rows.jsonl", rows)
                voei_rows = build_voei_rows_v2(
                    config, trace, scenario, interval, rows
                )
                write_jsonl(interval_root / "voei_rows.jsonl", voei_rows)
                write_json(
                    interval_root / "manifest.json",
                    {
                        "version": "v2.1",
                        "phase": phase,
                        "scenario": scenario,
                        "seed": seed,
                        "report_interval": interval,
                        "belief_row_count": len(rows),
                        "voei_row_count": len(voei_rows),
                        "trace_hash": trace.content_hash(),
                        "config_hash": config_hash,
                        "code_hash": source_hash,
                        "calibration_hash": expected["calibration_hash"],
                        "validation_seed_hash": expected["validation_seed_hash"],
                        "truth_fields": "offline-only evaluator columns",
                    },
                )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs" / "stage2_v2_1.yaml"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "outputs" / "stage2_belief_voei_v2_1",
    )
    args = parser.parse_args()
    run(args.config, args.output)


if __name__ == "__main__":
    main()
