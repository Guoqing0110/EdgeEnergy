#!/usr/bin/env python3
"""Run the pre-registered Stage 2 v2 calibration or one-shot validation."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.digital_twin.calibration import (  # noqa: E402
    IntervalCalibration,
    calibration_from_dict,
    fit_interval_calibration,
)
from src.environment.trace import generate_trace  # noqa: E402
from src.experiments.belief_benchmark import generate_benchmark  # noqa: E402
from src.experiments.belief_v2 import replay_beliefs_v2  # noqa: E402
from src.information_value.voei import (  # noqa: E402
    DecisionBelief,
    baseline_information_scores,
    build_candidate_actions,
    full_decision_aware_voei,
    offline_true_counterfactual_value,
)
from src.information_value.voei_v2 import belief_ambiguity_opportunity  # noqa: E402
from src.logging.provenance import canonical_hash, code_hash, write_json, write_jsonl  # noqa: E402


def load_config(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def load_seeds(path: Path) -> list[int]:
    return [int(x) for x in path.read_text().split()]


def scenario_config(base: dict[str, Any], scenario: str) -> dict[str, Any]:
    config = copy.deepcopy(base)
    override = config["scenarios"][scenario]
    config["energy"]["initial_fraction"] = list(override["initial_fraction"])
    config["energy"]["reserve_fraction"] = float(override["reserve_fraction"])
    return config


def augment_intervals(
    rows: list[dict], calibration: IntervalCalibration, capacity_j: float
) -> None:
    for row in rows:
        mean = float(row["mean_j"])
        std = float(np.sqrt(max(0.0, row["variance_j2"])))
        if row["method"] == "uncertainty_twin":
            entry = calibration.lookup(str(row["role"]), int(row["age"]))
            multiplier, source = entry.multiplier, entry.source_level
        elif row["method"] == "full_state_oracle":
            multiplier, source = 0.0, "oracle"
        else:
            multiplier, source = 0.0, "point_estimate"
        lower = max(0.0, mean - multiplier * std)
        upper = min(float(capacity_j), mean + multiplier * std)
        truth = float(row["truth_j_offline_only"])
        row.update(
            {
                "interval_multiplier": multiplier,
                "interval_source": source,
                "interval_lower_j": lower,
                "interval_upper_j": upper,
                "interval_width_j": upper - lower,
                "interval_covered_offline_only": bool(lower <= truth <= upper),
            }
        )


def build_voei_rows_v2(
    config: dict[str, Any], trace: Any, scenario: str, interval: int, rows: list[dict]
) -> list[dict]:
    by_slot: dict[int, list[dict]] = {}
    for row in rows:
        if row["method"] == "uncertainty_twin":
            by_slot.setdefault(int(row["slot"]), []).append(row)
    stride = int(config["voei"]["evaluation_stride_slots"])
    reserve = float(config["energy"]["capacity_j"]) * float(
        config["energy"]["reserve_fraction"]
    )
    scenario_code = 1701 if scenario == "nominal_sparse" else 1702
    output: list[dict] = []
    for slot in sorted(by_slot):
        if slot % stride != 0:
            continue
        node_rows = sorted(by_slot[slot], key=lambda row: int(row["node"]))
        mean = np.asarray([row["mean_j"] for row in node_rows], dtype=float)
        std = np.sqrt(
            np.asarray([max(0.0, row["variance_j2"]) for row in node_rows], dtype=float)
        )
        lower = np.asarray([row["interval_lower_j"] for row in node_rows], dtype=float)
        ages = np.asarray([row["age"] for row in node_rows], dtype=int)
        truth = np.asarray([row["truth_j_offline_only"] for row in node_rows], dtype=float)
        belief = DecisionBelief(
            mean_j=mean,
            std_j=std,
            lower_j=lower,
            age=ages,
            capacity_j=float(config["energy"]["capacity_j"]),
            reserve_j=reserve,
            positions=trace.positions,
            wet_adjacency=tuple(
                tuple(bool(x) for x in line) for line in trace.wet_adjacency
            ),
        )
        opportunity = belief_ambiguity_opportunity(belief, config)
        candidates = build_candidate_actions(belief, config)
        random_rng = np.random.default_rng(
            np.random.SeedSequence([trace.seed, scenario_code, interval, slot, 90125])
        )
        baseline = baseline_information_scores(
            belief, config, random_rng.random(trace.node_count)
        )
        for node in range(trace.node_count):
            online_rng = np.random.default_rng(
                np.random.SeedSequence(
                    [trace.seed, scenario_code, interval, slot, node, 51077]
                )
            )
            full = full_decision_aware_voei(
                belief, node, candidates, config, online_rng
            )
            offline = offline_true_counterfactual_value(
                belief, node, float(truth[node]), candidates, config
            )
            output.append(
                {
                    "scenario": scenario,
                    "seed": trace.seed,
                    "report_interval": interval,
                    "slot": slot,
                    "node": node,
                    "candidate_count": len(candidates),
                    "is_ambiguity_opportunity": opportunity.is_opportunity,
                    "ambiguity_index": opportunity.ambiguity_index,
                    "receiver_gap_z": opportunity.receiver_gap_z,
                    "donor_gap_z": opportunity.donor_gap_z,
                    "reserve_gap_z": opportunity.reserve_gap_z,
                    "age_score": float(baseline["age"][node]),
                    "uncertainty_score": float(baseline["uncertainty"][node]),
                    "urgency_score": float(baseline["urgency"][node]),
                    "random_score": float(baseline["random"][node]),
                    "full_voei_score": full.value,
                    "full_uncertainty_component": full.uncertainty,
                    "full_sensitivity_component": full.sensitivity,
                    "full_consequence_component": full.consequence,
                    "offline_true_value": offline.value,
                    "offline_action_changed": offline.action_changed,
                    "online_base_action": asdict(full.base_action),
                    "offline_revealed_action": asdict(offline.revealed_action),
                }
            )
    return output


def run_phase(config_path: Path, phase: str, output_root: Path) -> None:
    if phase not in {"calibration_v2", "validation_v2"}:
        raise ValueError("invalid v2 phase")
    base = load_config(config_path)
    if phase not in base["experiment"]["allowed_seed_splits"]:
        raise RuntimeError("phase not authorized by v2 configuration")
    seeds = load_seeds(ROOT / "seeds" / f"{phase}.txt")
    held_out = set(load_seeds(ROOT / "seeds" / "test_held_out.txt"))
    old_validation = set(load_seeds(ROOT / "seeds" / "validation.txt"))
    if not set(seeds).isdisjoint(held_out | old_validation):
        raise RuntimeError("v2 phase overlaps held-out or previously viewed validation seeds")

    source_hash = code_hash(ROOT)
    config_hash = canonical_hash(base)
    freeze_path = output_root / "stage2_v2_freeze_manifest.json"
    calibration_path = output_root / "calibration_parameters_v2.json"
    if phase == "validation_v2":
        if not freeze_path.exists() or not calibration_path.exists():
            raise RuntimeError("v2 validation requires calibration freeze")
        freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
        if freeze["code_hash"] != source_hash or freeze["config_hash"] != config_hash:
            raise RuntimeError("current v2 code/config differs from freeze")
        calibration = calibration_from_dict(
            json.loads(calibration_path.read_text(encoding="utf-8"))["calibration"]
        )
    else:
        calibration = None

    queued: list[tuple[Path, list[dict], Any, str, int, dict]] = []
    fit_rows: list[dict] = []
    for scenario in base["scenarios"]:
        config = scenario_config(base, scenario)
        for seed in seeds:
            trace = generate_trace(config, seed)
            seed_root = output_root / "raw" / phase / scenario / f"seed={seed}"
            trace.save(seed_root / "trace.npz")
            write_json(
                seed_root / "trace_manifest.json",
                {
                    "version": "v2",
                    "phase": phase,
                    "scenario": scenario,
                    "seed": seed,
                    "trace_hash": trace.content_hash(),
                    "config_hash": config_hash,
                    "code_hash": source_hash,
                    "held_out": False,
                },
            )
            for interval_value in config["reporting"]["intervals_slots"]:
                interval = int(interval_value)
                benchmark = generate_benchmark(config, trace, interval)
                rows = replay_beliefs_v2(config, benchmark, scenario)
                interval_root = seed_root / f"report_interval={interval}"
                queued.append((interval_root, rows, trace, scenario, interval, config))
                fit_rows.extend(
                    row for row in rows if row["method"] == "uncertainty_twin"
                )

    if phase == "calibration_v2":
        belief_config = base["belief"]
        calibration = fit_interval_calibration(
            fit_rows,
            float(belief_config["nominal_coverage"]),
            belief_config["age_bucket_edges"],
            int(belief_config["minimum_group_samples"]),
        )
        write_json(
            calibration_path,
            {
                "schema_version": "stage2-v2-calibration-v1",
                "phase": phase,
                "seed_count": len(seeds),
                "scenarios": list(base["scenarios"]),
                "config_hash": config_hash,
                "code_hash": source_hash,
                "calibration": calibration.serializable(),
            },
        )
    assert calibration is not None

    for interval_root, rows, trace, scenario, interval, config in queued:
        augment_intervals(rows, calibration, float(config["energy"]["capacity_j"]))
        write_jsonl(interval_root / "belief_rows.jsonl", rows)
        voei_rows = build_voei_rows_v2(config, trace, scenario, interval, rows)
        write_jsonl(interval_root / "voei_rows.jsonl", voei_rows)
        write_json(
            interval_root / "manifest.json",
            {
                "version": "v2",
                "phase": phase,
                "scenario": scenario,
                "seed": trace.seed,
                "report_interval": interval,
                "belief_row_count": len(rows),
                "voei_row_count": len(voei_rows),
                "trace_hash": trace.content_hash(),
                "config_hash": config_hash,
                "code_hash": source_hash,
                "calibration_hash": canonical_hash(calibration.serializable()),
                "truth_fields": "offline-only evaluator columns",
            },
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--phase", choices=["calibration_v2", "validation_v2"], required=True
    )
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs" / "stage2_v2.yaml"
    )
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage2_belief_voei_v2"
    )
    args = parser.parse_args()
    run_phase(args.config, args.phase, args.output)


if __name__ == "__main__":
    main()
