#!/usr/bin/env python3
"""Freeze Stage 4 validation code, protocol, factors and new seeds."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, code_hash, write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def main() -> None:
    config_path = ROOT / "configs" / "stage4.yaml"
    protocol_path = ROOT / "STAGE4_PROTOCOL.md"
    seed_path = ROOT / "seeds" / "stage4_validation.txt"
    output = ROOT / "outputs" / "stage4_long_horizon_v1"
    config = yaml.safe_load(config_path.read_text())
    authorization_path = ROOT / config["experiment"]["stage3_authorization"]
    calibration_path = ROOT / config["experiment"]["calibration_source"]
    for path in (protocol_path, seed_path, authorization_path, calibration_path):
        if not path.exists():
            raise RuntimeError(f"missing Stage 4 freeze input: {path}")
    authorization = json.loads(authorization_path.read_text())
    if authorization.get("stage4_authorized") is not True:
        raise RuntimeError("Stage 3 v1.1 has not authorized Stage 4")
    calibration = json.loads(calibration_path.read_text())
    seeds = _seeds(seed_path)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != seed_path.name:
            forbidden.update(_seeds(path))
    expected = int(config["gate"]["expected_validation_seeds"])
    if len(seeds) != expected or len(set(seeds)) != expected or not set(seeds).isdisjoint(forbidden):
        raise RuntimeError("invalid Stage 4 validation seed registry")
    method_count = len(config["stage4"]["methods"])
    scenario_count = len(config["scenarios"])
    expected_runs = expected * scenario_count * method_count
    write_json(
        output / "stage4_freeze_manifest.json",
        {
            "schema_version": "stage4-freeze-v1",
            "code_hash": code_hash(ROOT),
            "config_hash": canonical_hash(config),
            "calibration_hash": canonical_hash(calibration["calibration"]),
            "stage3_authorization_hash": canonical_hash(authorization),
            "validation_seed_hash": canonical_hash(seeds),
            "validation_seed_file": "seeds/stage4_validation.txt",
            "protocol_file": "STAGE4_PROTOCOL.md",
            "expected_method_runs": expected_runs,
            "expected_slot_rows": expected_runs * int(config["simulation"]["slots"]),
            "held_out_test_used": False,
            "frozen_parameters": [
                "nine method definitions",
                "two scenario overrides and 480-slot horizon",
                "causal information boundary and B8 oracle label",
                "report, WET and donor budgets",
                "queue updates and normalized per-slot objective",
                "16-slot Full-VoEI safety-refresh floor for B5 and B7",
                "calibrated reserve guard and 1000 J margin",
                "primary endpoints and four scientific gates",
                "seed-level paired bootstrap with 20000 resamples",
            ],
        },
    )


if __name__ == "__main__":
    main()
