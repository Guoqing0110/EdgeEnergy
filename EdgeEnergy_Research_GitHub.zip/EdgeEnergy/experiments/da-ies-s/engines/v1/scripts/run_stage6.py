#!/usr/bin/env python3
"""Run one frozen Stage 6 held-out B4/DA-IES-S trajectory."""

from __future__ import annotations

import argparse
import json
import resource
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5_1 import (  # noqa: E402
    BASELINE,
    external_config,
    load_configs,
    method_config,
)
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
    write_jsonl,
)
from src.scheduler.stage4 import DA_IES_S_METHOD  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def load_all(path: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    stage6 = yaml.safe_load(path.read_text())
    stage51_path = ROOT / stage6["experiment"]["stage5_1_config"]
    stage51, stage4, stage5 = load_configs(stage51_path)
    selection = json.loads((ROOT / stage6["experiment"]["stage5_1_selection"]).read_text())
    return stage6, stage51, stage4, stage5, selection


def stage6_hashes(
    stage6: dict[str, Any],
    stage51: dict[str, Any],
    stage4: dict[str, Any],
    stage5: dict[str, Any],
    selection: dict[str, Any],
) -> dict[str, str]:
    authorization = json.loads(
        (ROOT / stage6["experiment"]["stage5_1_authorization"]).read_text()
    )
    seeds = _seeds(ROOT / stage6["experiment"]["held_out_seed_file"])
    return {
        "code_hash": code_hash(ROOT),
        "stage6_config_hash": canonical_hash(stage6),
        "stage5_1_config_hash": canonical_hash(stage51),
        "stage4_base_config_hash": canonical_hash(stage4),
        "stage5_factor_config_hash": canonical_hash(stage5),
        "risk_selection_hash": canonical_hash(selection),
        "stage5_1_authorization_hash": canonical_hash(authorization),
        "held_out_seed_hash": canonical_hash(seeds),
    }


def run_one(
    config_path: Path,
    output: Path,
    condition: str,
    seed: int,
    method: str,
) -> None:
    stage6, stage51, stage4, stage5, selection = load_all(config_path)
    if condition not in stage6["stage6"]["conditions"]:
        raise RuntimeError("condition outside frozen Stage 6 design")
    seeds = _seeds(ROOT / stage6["experiment"]["held_out_seed_file"])
    if seed not in seeds or len(seeds) != int(stage6["stage6"]["held_out_seed_count"]):
        raise RuntimeError("seed outside frozen held-out registry")
    authorization = json.loads(
        (ROOT / stage6["experiment"]["stage5_1_authorization"]).read_text()
    )
    if authorization.get("stage6_authorized") is not True:
        raise RuntimeError("Stage 5.1 has not authorized Stage 6")
    freeze = json.loads((output / "stage6_freeze_manifest.json").read_text())
    current = stage6_hashes(stage6, stage51, stage4, stage5, selection)
    if any(freeze.get(key) != value for key, value in current.items()):
        raise RuntimeError("Stage 6 inputs differ from freeze")
    base = external_config(stage51, stage4, stage5, condition, "validation")
    base["simulation"]["slots"] = int(stage6["stage6"]["slots"])
    if method == BASELINE:
        grid = "baseline"
    elif method == DA_IES_S_METHOD:
        grid = str(selection["selected_grid_id"])
    else:
        raise RuntimeError("method outside frozen Stage 6 comparison")
    config = method_config(base, stage51, method, grid)
    trace = generate_trace(config, seed)
    calibration_payload = json.loads(
        (ROOT / stage51["experiment"]["calibration_source"]).read_text()
    )
    calibration = calibration_from_dict(calibration_payload["calibration"])
    result = run_stage4_method(
        config, trace, method, f"stage6:held_out:{condition}", calibration
    )
    unit = output / "raw" / f"condition={condition}" / f"seed={seed}" / f"method={method}"
    write_jsonl(unit / "slots.jsonl", result.records)
    summary = {
        "schema_version": "stage6-summary-v1",
        "condition": condition,
        "seed": seed,
        "method": method,
        "risk_grid_id": grid,
        "trace_hash": result.trace_hash,
        "deterministic_records_hash": deterministic_records_hash(result.records),
        "runtime_seconds": result.runtime_seconds,
        "process_peak_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
        "slot_rows": len(result.records),
        **current,
        **result.summary,
    }
    write_json(unit / "summary.json", summary)
    write_json(
        unit / "manifest.json",
        {
            "schema_version": "stage6-method-manifest-v1",
            "status": "completed",
            "condition": condition,
            "seed": seed,
            "method": method,
            "risk_grid_id": grid,
            "trace_hash": result.trace_hash,
            "slot_rows": len(result.records),
            "held_out_test_used": True,
            **current,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage6.yaml")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs" / "stage6_held_out_v1")
    parser.add_argument("--condition", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--method", choices=(BASELINE, DA_IES_S_METHOD), required=True)
    args = parser.parse_args()
    run_one(args.config, args.output, args.condition, args.seed, args.method)


if __name__ == "__main__":
    main()
