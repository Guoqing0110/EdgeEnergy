#!/usr/bin/env python3
"""Freeze and run the independently reconstructed E6 matched-policy study."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import resource
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5_1 import external_config, load_configs, method_config  # noqa: E402
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
)
from src.scheduler.stage4 import DA_IES_S_METHOD, E6_METHODS, method_spec  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402

DEFAULT_CONFIG = ROOT / "configs" / "e6_matched_independent_v1.yaml"
DEFAULT_OUTPUT = ROOT / "outputs" / "e6_matched_independent_v1"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_spec(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def seed_rows(spec: dict[str, Any]) -> list[dict[str, Any]]:
    path = ROOT / spec["experiment"]["seed_registry"]
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return [
        {
            "seed_id": row["seed_id"],
            "seed_value": int(row["seed_value"]),
            "generation_counter": int(row["generation_counter"]),
        }
        for row in rows
    ]


def load_inputs(path: Path = DEFAULT_CONFIG) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    spec = load_spec(path)
    stage51, stage4, stage5 = load_configs(ROOT / spec["experiment"]["stage5_1_config"])
    selection = json.loads((ROOT / spec["experiment"]["risk_selection"]).read_text())
    calibration = json.loads((ROOT / spec["experiment"]["calibration_source"]).read_text())
    return spec, stage51, stage4, stage5, selection, calibration


def formal_config(condition: str, path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    spec, stage51, stage4, stage5, selection, _ = load_inputs(path)
    if condition not in spec["formal_run"]["conditions"]:
        raise ValueError(f"unknown E6 condition: {condition}")
    base = external_config(stage51, stage4, stage5, condition, "validation")
    config = method_config(
        base,
        stage51,
        DA_IES_S_METHOD,
        str(selection["selected_grid_id"]),
    )
    config["simulation"]["slots"] = int(spec["formal_run"]["slots"])
    return config


def input_hashes(path: Path = DEFAULT_CONFIG) -> dict[str, str]:
    spec, stage51, stage4, stage5, selection, calibration = load_inputs(path)
    return {
        "code_hash": code_hash(ROOT),
        "e6_config_hash": canonical_hash(spec),
        "stage5_1_config_hash": canonical_hash(stage51),
        "stage4_base_config_hash": canonical_hash(stage4),
        "stage5_factor_config_hash": canonical_hash(stage5),
        "risk_selection_hash": canonical_hash(selection),
        "belief_calibration_hash": canonical_hash(calibration["calibration"]),
        "seed_registry_hash": canonical_hash(seed_rows(spec)),
    }


def validate_registry(spec: dict[str, Any]) -> None:
    rows = seed_rows(spec)
    values = [row["seed_value"] for row in rows]
    expected = int(spec["formal_run"]["seed_count"])
    if len(values) != expected or len(set(values)) != expected or any(value <= 0 for value in values):
        raise RuntimeError("invalid E6 seed registry")
    used: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        used.update(int(value) for value in path.read_text().split())
    if set(values) & used:
        raise RuntimeError("E6 seed registry overlaps a retained partition")


def freeze(config_path: Path, output: Path) -> Path:
    spec = load_spec(config_path)
    validate_registry(spec)
    methods = tuple(spec["formal_run"]["methods"])
    if methods != E6_METHODS:
        raise RuntimeError("configuration method order differs from the frozen E6 registry")
    for method in methods:
        estimator, wet_rule, _ = method_spec(method)
        if estimator != "uncertainty_twin" or wet_rule != "queue_safe":
            raise RuntimeError(f"method is not matched on belief/RCPG: {method}")
    raw = output / "raw"
    if raw.exists() and any(raw.rglob("slots.jsonl.gz")):
        raise RuntimeError("refusing to freeze after formal raw output exists")
    conditions = list(spec["formal_run"]["conditions"])
    expected = len(seed_rows(spec)) * len(conditions) * len(methods)
    if expected != int(spec["formal_run"]["expected_trajectories"]):
        raise RuntimeError("expected trajectory count is inconsistent")
    manifest = output / "e6_prerun_manifest.json"
    _, _, _, _, selection, _ = load_inputs(config_path)
    write_json(
        manifest,
        {
            "schema_version": "e6-independent-prerun-freeze-v1",
            "scientific_status": "independently_reconstructed_not_original_r3",
            **input_hashes(config_path),
            "selected_grid_id": selection["selected_grid_id"],
            "selected_parameters": selection["selected_parameters"],
            "conditions": conditions,
            "methods": list(methods),
            "seed_rows": seed_rows(spec),
            "expected_trajectories": expected,
            "expected_slot_rows": expected * int(spec["formal_run"]["slots"]),
            "formal_results_seen_before_freeze": False,
        },
    )
    return manifest


def verify_freeze(config_path: Path, output: Path) -> dict[str, Any]:
    manifest_path = output / "e6_prerun_manifest.json"
    if not manifest_path.exists():
        raise RuntimeError("formal run requires e6_prerun_manifest.json")
    manifest = json.loads(manifest_path.read_text())
    current = input_hashes(config_path)
    mismatches = [key for key, value in current.items() if manifest.get(key) != value]
    if mismatches:
        raise RuntimeError("frozen E6 inputs changed: " + ", ".join(mismatches))
    return manifest


def _write_gzip_jsonl(path: Path, records: tuple[dict[str, Any], ...]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with io.TextIOWrapper(compressed, encoding="utf-8", newline="\n") as text:
                for record in records:
                    text.write(json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
                    text.write("\n")
    temporary.replace(path)


def _run_one(task: tuple[str, int, str, str, str, str]) -> dict[str, Any]:
    condition, seed, seed_id, method, config_name, output_name = task
    config_path = Path(config_name)
    output = Path(output_name)
    spec, _, _, _, _, calibration_payload = load_inputs(config_path)
    config = formal_config(condition, config_path)
    calibration = calibration_from_dict(calibration_payload["calibration"])
    trace = generate_trace(config, seed)
    result = run_stage4_method(
        config,
        trace,
        method,
        f"e6-independent-v1:{condition}",
        calibration,
    )
    records = tuple(
        {key: value for key, value in record.items() if key != "runtime_ms"}
        for record in result.records
    )
    unit = output / "raw" / condition / seed_id / method
    raw_path = unit / "slots.jsonl.gz"
    _write_gzip_jsonl(raw_path, records)
    max_residual = max(
        abs(float(value))
        for record in records
        for value in record["executor_ledger"]["conservation_residual_j"]
    )
    summary = {
        "schema_version": "e6-independent-trajectory-summary-v1",
        "scientific_status": "independently_reconstructed_not_original_r3",
        "trajectory_id": f"{condition}__{seed_id}__{method}",
        "condition": condition,
        "seed_id": seed_id,
        "seed": seed,
        "method": method,
        "method_spec": list(method_spec(method)),
        "slot_rows": len(records),
        "trace_hash": result.trace_hash,
        "deterministic_records_hash": deterministic_records_hash(records),
        "raw_relative_path": str(raw_path.relative_to(ROOT)),
        "raw_sha256": _sha256(raw_path),
        "config_hash": canonical_hash(config),
        "maximum_conservation_residual_j": max_residual,
        "runtime_seconds": result.runtime_seconds,
        "process_peak_rss_bytes": int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024),
        **result.summary,
    }
    write_json(unit / "summary.json", summary)
    return summary


def _write_index(output: Path) -> int:
    rows = [json.loads(path.read_text()) for path in sorted((output / "raw").rglob("summary.json"))]
    fields = [
        "trajectory_id", "condition", "seed_id", "seed", "method", "slot_rows",
        "trace_hash", "config_hash", "deterministic_records_hash", "raw_relative_path",
        "raw_sha256", "maximum_conservation_residual_j", "runtime_seconds",
        "cumulative_unmet_visible_demand_j", "node_service_continuity_fraction",
        "average_reporting_debit_j_per_slot", "payer_reserve_violation_rate",
    ]
    output.mkdir(parents=True, exist_ok=True)
    temporary = output / "trajectory_index.csv.tmp"
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row[field] for field in fields})
    temporary.replace(output / "trajectory_index.csv")
    return len(rows)


def run(config_path: Path, output: Path, workers: int, condition: str | None, seed: int | None, method: str | None) -> None:
    verify_freeze(config_path, output)
    spec = load_spec(config_path)
    rows = seed_rows(spec)
    tasks = [
        (
            cond,
            row["seed_value"],
            row["seed_id"],
            meth,
            str(config_path.resolve()),
            str(output.resolve()),
        )
        for cond in spec["formal_run"]["conditions"]
        for row in rows
        for meth in spec["formal_run"]["methods"]
        if (condition is None or cond == condition)
        and (seed is None or row["seed_value"] == seed)
        and (method is None or meth == method)
    ]
    if not tasks:
        raise RuntimeError("no formal task matches the requested filters")
    completed = 0
    if workers <= 1:
        for task in tasks:
            _run_one(task)
            completed += 1
            print(f"completed {completed}/{len(tasks)}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_run_one, task) for task in tasks]
            for future in as_completed(futures):
                future.result()
                completed += 1
                print(f"completed {completed}/{len(tasks)}", flush=True)
    observed = _write_index(output)
    print(f"trajectory index rows: {observed}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("freeze", "run", "status"))
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    parser.add_argument("--condition")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--method", choices=E6_METHODS)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.command == "freeze":
        print(freeze(args.config.resolve(), output))
    elif args.command == "run":
        run(args.config.resolve(), output, args.workers, args.condition, args.seed, args.method)
    else:
        manifest = verify_freeze(args.config.resolve(), output)
        print(json.dumps({"freeze_verified": True, "indexed_trajectories": _write_index(output), "expected_trajectories": manifest["expected_trajectories"]}, indent=2))


if __name__ == "__main__":
    main()
