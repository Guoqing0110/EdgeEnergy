#!/usr/bin/env python3
"""Freeze Stage 2 calibration before validation is permitted."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, code_hash, write_json  # noqa: E402


def main() -> None:
    output = ROOT / "outputs" / "stage2_belief_voei_v1"
    calibration_path = output / "calibration_parameters.json"
    if not calibration_path.exists():
        raise RuntimeError("calibration parameters do not exist")
    config = yaml.safe_load((ROOT / "configs" / "stage2.yaml").read_text())
    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    write_json(
        output / "stage2_freeze_manifest.json",
        {
            "schema_version": "stage2-freeze-v1",
            "scope": "belief interval calibration and VoEI validation parameters",
            "code_hash": code_hash(ROOT),
            "config_hash": canonical_hash(config),
            "calibration_hash": canonical_hash(calibration["calibration"]),
            "calibration_seed_file": "seeds/calibration.txt",
            "validation_seed_file": "seeds/validation.txt",
            "held_out_test_used": False,
            "frozen_parameters": [
                "process/measurement variance",
                "role-age interval multipliers",
                "VoEI objective weights",
                "belief sample count",
                "candidate counts",
                "evaluation stride",
                "primary ranking metrics",
            ],
        },
    )


if __name__ == "__main__":
    main()
