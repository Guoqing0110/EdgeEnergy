#!/usr/bin/env python3
"""Freeze Stage 5 code, protocol, factors, authorization and new seeds."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5 import family_conditions, family_methods, stage5_hashes  # noqa: E402
from src.logging.provenance import write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def main() -> None:
    config_path = ROOT / "configs" / "stage5.yaml"
    protocol_path = ROOT / "STAGE5_PROTOCOL.md"
    seed_path = ROOT / "seeds" / "stage5_validation.txt"
    output = ROOT / "outputs" / "stage5_robustness_scalability_v1"
    stage5 = yaml.safe_load(config_path.read_text())
    stage4 = yaml.safe_load(
        (ROOT / stage5["experiment"]["stage4_base_config"]).read_text()
    )
    authorization_path = ROOT / stage5["experiment"]["stage4_authorization"]
    calibration_path = ROOT / stage5["experiment"]["calibration_source"]
    for path in (protocol_path, seed_path, authorization_path, calibration_path):
        if not path.exists():
            raise RuntimeError(f"missing Stage 5 freeze input: {path}")
    authorization = json.loads(authorization_path.read_text())
    if authorization.get("stage5_authorized") is not True:
        raise RuntimeError("Stage 4 has not authorized Stage 5")
    seeds = _seeds(seed_path)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != seed_path.name:
            forbidden.update(_seeds(path))
    expected = int(stage5["stage5"]["validation_seed_count"])
    if len(seeds) != expected or len(set(seeds)) != expected or not set(seeds).isdisjoint(forbidden):
        raise RuntimeError("invalid Stage 5 validation seed registry")

    robustness_runs = (
        expected
        * len(family_conditions(stage5, "robustness"))
        * len(family_methods(stage5, "robustness"))
    )
    scalability_runs = (
        int(stage5["stage5"]["scalability_seed_count"])
        * len(family_conditions(stage5, "scalability"))
        * len(family_methods(stage5, "scalability"))
    )
    complexity_runs = (
        int(stage5["stage5"]["complexity_seed_count"])
        * len(family_conditions(stage5, "complexity"))
        * len(family_methods(stage5, "complexity"))
    )
    expected_runs = robustness_runs + scalability_runs + complexity_runs
    hashes = stage5_hashes(stage5, stage4, seed_path)
    write_json(
        output / "stage5_freeze_manifest.json",
        {
            "schema_version": "stage5-freeze-v1",
            **hashes,
            "validation_seed_file": "seeds/stage5_validation.txt",
            "protocol_file": "STAGE5_PROTOCOL.md",
            "expected_runs_by_family": {
                "robustness": robustness_runs,
                "scalability": scalability_runs,
                "complexity": complexity_runs,
            },
            "expected_method_runs": expected_runs,
            "expected_slot_rows": expected_runs * int(stage5["stage5"]["slots"]),
            "held_out_test_used": False,
            "frozen_parameters": [
                "Stage 4 B0, B4 and B7 implementations without retuning",
                "seven named robustness cells and paired contrasts",
                "N=12,24,48,96 density-scaled topology experiment",
                "Full-VoEI sample and candidate sensitivity cells",
                "480-slot horizon and new disjoint seed registry",
                "all causal, guard, report, WET and queue constraints",
                "engineering, robustness and scaling gates",
                "seed-paired bootstrap with 20000 resamples",
            ],
        },
    )


if __name__ == "__main__":
    main()
