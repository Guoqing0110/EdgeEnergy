#!/usr/bin/env python3
"""Stream Stage 3 raw rows into seed-level and crossover summaries."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


METRICS = (
    "selected_fields",
    "attempted_fields",
    "delivered_fields",
    "measurement_loss_fields",
    "planned_sensor_debit_j",
    "actual_sensor_debit_j",
    "planned_bytes_over_hops",
    "actual_bytes_over_hops",
    "packets_attempted",
    "packets_delivered",
    "planned_hops",
    "actual_hops_attempted",
    "planned_latency_ms",
    "actual_latency_ms",
    "expected_selected_field_delivery_probability",
    "actual_selected_field_delivery_fraction",
    "offline_delivered_counterfactual_value",
    "offline_residual_counterfactual_value",
    "offline_information_value_per_sensor_joule",
    "runtime_ms",
)

FACTOR_FIELDS = (
    "path_length_hops",
    "field_payload_bytes",
    "link_success_probability",
    "report_budget_j",
)


@dataclass
class Accumulator:
    count: int = 0
    sums: dict[str, float] = field(default_factory=lambda: defaultdict(float))
    total_delivered_value: float = 0.0
    total_actual_debit: float = 0.0
    budget_abstentions: int = 0
    zero_utility_abstentions: int = 0

    def add(self, row: dict) -> None:
        self.count += 1
        for metric in METRICS:
            self.sums[metric] += float(row[metric])
        self.total_delivered_value += float(
            row["offline_delivered_counterfactual_value"]
        )
        self.total_actual_debit += float(row["actual_sensor_debit_j"])
        reason = str(row["selection_reason"])
        self.budget_abstentions += int("budget_abstain" in reason)
        self.zero_utility_abstentions += int("zero_utility" in reason)

    def summary(self) -> dict[str, float | int]:
        if self.count == 0:
            raise RuntimeError("cannot summarize an empty accumulator")
        output: dict[str, float | int] = {"observations": self.count}
        for metric in METRICS:
            output[f"mean_{metric}"] = self.sums[metric] / self.count
        output["ratio_information_value_per_sensor_joule"] = (
            self.total_delivered_value / self.total_actual_debit
            if self.total_actual_debit > 0.0
            else 0.0
        )
        output["budget_abstention_rate"] = self.budget_abstentions / self.count
        output["zero_utility_abstention_rate"] = (
            self.zero_utility_abstentions / self.count
        )
        return output


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"no rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _factor(row: dict) -> tuple:
    return tuple(row[field] for field in FACTOR_FIELDS)


def _factor_dict(key: tuple) -> dict:
    return {field: value for field, value in zip(FACTOR_FIELDS, key)}


def _paired(difference: np.ndarray, draws: np.ndarray) -> dict:
    difference = np.asarray(difference, dtype=float)
    means = np.mean(difference[draws], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    sd = float(np.std(difference, ddof=1))
    return {
        "paired_seeds": int(difference.size),
        "mean_difference": float(np.mean(difference)),
        "paired_bootstrap_95_ci_low": float(low),
        "paired_bootstrap_95_ci_high": float(high),
        "paired_effect_dz": float(np.mean(difference) / sd)
        if sd > 0.0
        else float("nan"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage3_selective_eetor_v1"
    )
    parser.add_argument("--seed-split", default="stage3_validation")
    parser.add_argument("--bootstrap-seed", type=int, default=20260723)
    args = parser.parse_args()
    output = args.output
    processed = output / "processed"
    freeze = json.loads((output / "stage3_freeze_manifest.json").read_text())
    seed_groups: dict[tuple, Accumulator] = defaultdict(Accumulator)
    scenario_groups: dict[tuple, Accumulator] = defaultdict(Accumulator)
    method_counts: dict[str, int] = defaultdict(int)
    factor_methods: dict[str, set[str]] = defaultdict(set)
    factor_innovations: dict[str, set[str]] = defaultdict(set)
    factor_permutations: dict[str, set[str]] = defaultdict(set)
    row_count = 0
    max_budget_residual = 0.0
    max_accounting_residual = 0.0
    max_planned_payer_residual = 0.0
    max_energy_shortfall = 0.0
    structural_errors = 0

    paths = sorted(
        output.glob(f"raw/{args.seed_split}/*/seed=*/method_rows.jsonl")
    )
    for path in paths:
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                row_count += 1
                seed = int(row["seed"])
                scenario = str(row["scenario"])
                method = str(row["method"])
                factor = _factor(row)
                seed_groups[(seed, *factor, method)].add(row)
                scenario_groups[(seed, scenario, *factor, method)].add(row)
                method_counts[method] += 1
                event = str(row["factor_event_id"])
                factor_methods[event].add(method)
                factor_innovations[event].add(str(row["link_innovation_id"]))
                factor_permutations[event].add(str(row["path_permutation_id"]))
                max_budget_residual = max(
                    max_budget_residual, abs(float(row["budget_residual_j"]))
                )
                payer_sum = sum(float(x) for x in row["actual_payer_debit_j"].values())
                max_accounting_residual = max(
                    max_accounting_residual,
                    abs(float(row["actual_sensor_debit_j"]) - payer_sum),
                )
                planned_payer_sum = sum(
                    float(x) for x in row["planned_payer_debit_j"].values()
                )
                max_planned_payer_residual = max(
                    max_planned_payer_residual,
                    abs(float(row["planned_sensor_debit_j"]) - planned_payer_sum),
                )
                max_energy_shortfall = max(
                    max_energy_shortfall, abs(float(row["energy_shortfall_j"]))
                )
                structural_errors += int(
                    int(row["selected_fields"]) != len(row["selected_path_nodes"])
                    or int(row["delivered_fields"]) != len(row["delivered_path_nodes"])
                    or int(row["delivered_fields"]) > int(row["selected_fields"])
                )

    per_seed: list[dict] = []
    for key, accumulator in sorted(seed_groups.items()):
        seed, *tail = key
        factor = tuple(tail[:-1])
        method = tail[-1]
        per_seed.append(
            {
                "seed": seed,
                **_factor_dict(factor),
                "method": method,
                **accumulator.summary(),
            }
        )
    _write_csv(processed / "per_seed_factor.csv", per_seed)

    per_seed_scenario: list[dict] = []
    for key, accumulator in sorted(scenario_groups.items()):
        seed, scenario, *tail = key
        factor = tuple(tail[:-1])
        method = tail[-1]
        per_seed_scenario.append(
            {
                "seed": seed,
                "scenario": scenario,
                **_factor_dict(factor),
                "method": method,
                **accumulator.summary(),
            }
        )
    _write_csv(processed / "per_seed_scenario_factor.csv", per_seed_scenario)

    values_by_cell: dict[tuple, list[dict]] = defaultdict(list)
    for row in per_seed:
        key = tuple(row[field] for field in FACTOR_FIELDS) + (row["method"],)
        values_by_cell[key].append(row)
    cell_rows: list[dict] = []
    for key, rows in sorted(values_by_cell.items()):
        factor, method = key[:-1], key[-1]
        output_row = {**_factor_dict(factor), "method": method, "seeds": len(rows)}
        for metric in (
            "mean_selected_fields",
            "mean_delivered_fields",
            "mean_planned_sensor_debit_j",
            "mean_actual_sensor_debit_j",
            "mean_actual_bytes_over_hops",
            "mean_expected_selected_field_delivery_probability",
            "mean_actual_selected_field_delivery_fraction",
            "mean_offline_delivered_counterfactual_value",
            "mean_offline_residual_counterfactual_value",
            "ratio_information_value_per_sensor_joule",
            "budget_abstention_rate",
            "zero_utility_abstention_rate",
            "mean_runtime_ms",
        ):
            values = np.asarray([float(row[metric]) for row in rows], dtype=float)
            output_row[f"{metric}_across_seed_mean"] = float(np.mean(values))
            output_row[f"{metric}_across_seed_sd"] = float(np.std(values, ddof=1))
            output_row[f"{metric}_across_seed_median"] = float(np.median(values))
        cell_rows.append(output_row)
    _write_csv(processed / "crossover_cells.csv", cell_rows)

    seed_values = {
        (
            int(row["seed"]),
            *(row[field] for field in FACTOR_FIELDS),
            row["method"],
        ): row
        for row in per_seed
    }
    seed_ids = sorted({int(row["seed"]) for row in per_seed})
    rng = np.random.default_rng(args.bootstrap_seed)
    draws = rng.integers(0, len(seed_ids), size=(20000, len(seed_ids)))
    comparisons = (
        (
            "full_minus_collect_efficiency",
            "full_voei_selective_eetor",
            "collect_all_eetor",
            "ratio_information_value_per_sensor_joule",
        ),
        (
            "collect_minus_full_raw_value",
            "collect_all_eetor",
            "full_voei_selective_eetor",
            "mean_offline_delivered_counterfactual_value",
        ),
        (
            "independent_minus_collect_raw_value",
            "independent_periodic_direct",
            "collect_all_eetor",
            "mean_offline_delivered_counterfactual_value",
        ),
    )
    paired_rows: list[dict] = []
    factors = sorted({tuple(row[field] for field in FACTOR_FIELDS) for row in per_seed})
    for factor in factors:
        for label, left, right, metric in comparisons:
            difference = np.asarray(
                [
                    float(seed_values[(seed, *factor, left)][metric])
                    - float(seed_values[(seed, *factor, right)][metric])
                    for seed in seed_ids
                ],
                dtype=float,
            )
            paired_rows.append(
                {
                    **_factor_dict(factor),
                    "comparison": label,
                    "metric": metric,
                    **_paired(difference, draws),
                }
            )
    _write_csv(processed / "paired_crossover_cells.csv", paired_rows)

    expected_methods = 6
    factor_event_errors = sum(
        len(methods) != expected_methods
        or len(factor_innovations[event]) != 1
        or len(factor_permutations[event]) != 1
        for event, methods in factor_methods.items()
    )
    write_json(
        output / "stage3_accounting_audit.json",
        {
            "raw_method_rows": row_count,
            "expected_method_rows": int(freeze["expected_method_rows"]),
            "manifest_files": len(paths),
            "method_row_counts": dict(sorted(method_counts.items())),
            "factor_events": len(factor_methods),
            "factor_event_structure_errors": factor_event_errors,
            "row_structure_errors": structural_errors,
            "max_budget_residual_j": max_budget_residual,
            "max_actual_payer_accounting_residual_j": max_accounting_residual,
            "max_planned_payer_accounting_residual_j": max_planned_payer_residual,
            "max_energy_shortfall_j": max_energy_shortfall,
        },
    )


if __name__ == "__main__":
    main()
