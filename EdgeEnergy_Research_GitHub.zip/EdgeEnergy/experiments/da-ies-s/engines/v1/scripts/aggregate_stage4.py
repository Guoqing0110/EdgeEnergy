#!/usr/bin/env python3
"""Aggregate Stage 4 summaries and compute seed-paired comparisons."""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


NUMERIC_METRICS = (
    "cumulative_unmet_visible_demand_j",
    "total_visible_demand_j",
    "total_served_visible_demand_j",
    "served_demand_fraction",
    "all_service_met_slot_fraction",
    "node_service_continuity_fraction",
    "reporting_sensor_debit_j",
    "average_reporting_debit_j_per_slot",
    "wet_gross_debit_j",
    "average_wet_gross_debit_j_per_slot",
    "wet_delivered_j",
    "wet_conversion_loss_j",
    "payer_reserve_violations",
    "payer_checks",
    "payer_reserve_violation_rate",
    "report_execution_shortfall_j",
    "wet_execution_shortfall_j",
    "post_belief_mae_j",
    "post_belief_rmse_j",
    "mean_energy_cv",
    "final_energy_jain",
    "final_service_queue_j",
    "final_report_queue_j",
    "final_wet_queue_j",
    "minimum_final_energy_fraction",
    "runtime_seconds",
)


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"no Stage 4 rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _paired(left: dict[int, float], right: dict[int, float], rng_seed: int, count: int) -> dict:
    common = sorted(set(left) & set(right))
    difference = np.asarray([left[seed] - right[seed] for seed in common], dtype=float)
    rng = np.random.default_rng(rng_seed)
    draws = rng.integers(0, len(difference), size=(count, len(difference)))
    means = np.mean(difference[draws], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    sd = float(np.std(difference, ddof=1))
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(difference)),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "paired_effect_dz": float(np.mean(difference) / sd) if sd > 0.0 else None,
        "seed_differences": {str(seed): float(value) for seed, value in zip(common, difference)},
    }


def main() -> None:
    output = ROOT / "outputs" / "stage4_long_horizon_v1"
    processed = output / "processed"
    config = yaml.safe_load((ROOT / "configs" / "stage4.yaml").read_text())
    summaries: list[dict] = []
    for path in sorted(output.glob("raw/stage4_validation/*/seed=*/method=*/summary.json")):
        summaries.append(json.loads(path.read_text()))
    _write_csv(processed / "per_seed_scenario_method.csv", summaries)

    grouped: dict[tuple[int, str], list[dict]] = defaultdict(list)
    for row in summaries:
        grouped[(int(row["seed"]), str(row["method"]))].append(row)
    per_seed_method: list[dict] = []
    for (seed, method), rows in sorted(grouped.items()):
        result: dict = {"seed": seed, "method": method, "scenario_count": len(rows)}
        for metric in NUMERIC_METRICS:
            result[metric] = float(np.mean([float(row[metric]) for row in rows]))
        per_seed_method.append(result)
    _write_csv(processed / "per_seed_method.csv", per_seed_method)

    method_groups: dict[str, list[dict]] = defaultdict(list)
    for row in per_seed_method:
        method_groups[str(row["method"])].append(row)
    method_summary: list[dict] = []
    for method, rows in sorted(method_groups.items()):
        result = {"method": method, "seeds": len(rows)}
        for metric in NUMERIC_METRICS:
            values = np.asarray([float(row[metric]) for row in rows], dtype=float)
            result[f"mean_{metric}"] = float(np.mean(values))
            result[f"sd_{metric}"] = float(np.std(values, ddof=1))
        method_summary.append(result)
    _write_csv(processed / "method_summary.csv", method_summary)

    lookup = {
        (int(row["seed"]), str(row["method"])): row for row in per_seed_method
    }
    proposed = str(config["stage4"]["proposed_method"])
    no_wet = "b0_no_wet_periodic_direct"
    full_direct = "b5_queue_belief_full_voei_direct"
    count = int(config["stage4"]["bootstrap_resamples"])

    def values(method: str, metric: str) -> dict[int, float]:
        return {
            seed: float(row[metric])
            for (seed, candidate), row in lookup.items()
            if candidate == method
        }

    comparisons = {
        "proposed_minus_no_wet_unmet": _paired(
            values(proposed, "cumulative_unmet_visible_demand_j"),
            values(no_wet, "cumulative_unmet_visible_demand_j"),
            20260729,
            count,
        ),
        "proposed_minus_no_wet_continuity": _paired(
            values(proposed, "all_service_met_slot_fraction"),
            values(no_wet, "all_service_met_slot_fraction"),
            20260730,
            count,
        ),
        "proposed_minus_full_direct_reporting": _paired(
            values(proposed, "average_reporting_debit_j_per_slot"),
            values(full_direct, "average_reporting_debit_j_per_slot"),
            20260731,
            count,
        ),
        "proposed_minus_full_direct_continuity": _paired(
            values(proposed, "all_service_met_slot_fraction"),
            values(full_direct, "all_service_met_slot_fraction"),
            20260801,
            count,
        ),
    }
    write_json(processed / "paired_primary_comparisons.json", comparisons)


if __name__ == "__main__":
    main()
