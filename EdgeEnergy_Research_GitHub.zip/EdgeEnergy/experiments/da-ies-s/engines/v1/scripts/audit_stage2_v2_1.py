#!/usr/bin/env python3
"""Apply the prospective Stage 2 v2.1 gate and authorize or block Stage 3."""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, write_json  # noqa: E402


def _csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _integers(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="utf-8").split()]


def _seed_average(
    rows: list[dict], method: str, metric: str, scenario: str | None = None
) -> dict[int, float]:
    values: dict[int, list[float]] = defaultdict(list)
    for row in rows:
        if row["method"] != method or row.get("scope") != "all":
            continue
        if scenario is not None and row["scenario"] != scenario:
            continue
        value = float(row[metric])
        if math.isfinite(value):
            values[int(row["seed"])].append(value)
    return {seed: float(np.mean(items)) for seed, items in values.items() if items}


def _belief_seed_average(rows: list[dict], method: str, metric: str) -> dict[int, float]:
    values: dict[int, list[float]] = defaultdict(list)
    for row in rows:
        if row["method"] == method:
            values[int(row["seed"])].append(float(row[metric]))
    return {seed: float(np.mean(items)) for seed, items in values.items()}


def _paired(left: dict[int, float], right: dict[int, float], seed: int) -> dict:
    common = sorted(set(left) & set(right))
    difference = np.asarray([left[item] - right[item] for item in common], dtype=float)
    rng = np.random.default_rng(seed)
    if difference.size:
        draws = rng.integers(0, difference.size, size=(20000, difference.size))
        means = np.mean(difference[draws], axis=1)
        low, high = np.quantile(means, [0.025, 0.975])
        sd = float(np.std(difference, ddof=1)) if difference.size > 1 else float("nan")
        effect = float(np.mean(difference) / sd) if sd > 0.0 else float("nan")
    else:
        low = high = effect = float("nan")
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(difference))
        if difference.size
        else float("nan"),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "paired_effect_dz": effect,
    }


def main() -> None:
    config_path = ROOT / "configs" / "stage2_v2_1.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    gate = config["gate"]
    output = ROOT / "outputs" / "stage2_belief_voei_v2_1"
    belief = _csv(output / "processed" / "belief_per_seed.csv")
    voei = _csv(output / "processed" / "voei_per_seed.csv")
    freeze = json.loads(
        (output / "stage2_v2_1_freeze_manifest.json").read_text(encoding="utf-8")
    )
    manifests = list(
        output.glob("raw/validation_v2_1/*/seed=*/report_interval=*/manifest.json")
    )
    manifest_values = [json.loads(path.read_text(encoding="utf-8")) for path in manifests]
    expected_seeds = set(_integers(ROOT / "seeds" / "validation_v2_1.txt"))
    observed_seeds = {int(item["seed"]) for item in manifest_values}
    forbidden: set[int] = set()
    for name in (
        "development.txt",
        "calibration.txt",
        "validation.txt",
        "calibration_v2.txt",
        "validation_v2.txt",
        "test_held_out.txt",
    ):
        forbidden.update(_integers(ROOT / "seeds" / name))
    hashes_match = all(
        item["code_hash"] == freeze["code_hash"]
        and item["config_hash"] == freeze["config_hash"]
        and item["calibration_hash"] == freeze["calibration_hash"]
        and item["validation_seed_hash"] == freeze["validation_seed_hash"]
        for item in manifest_values
    )
    seed_hash_match = freeze["validation_seed_hash"] == canonical_hash(
        _integers(ROOT / "seeds" / "validation_v2_1.txt")
    )

    uncertainty_rows = [row for row in belief if row["method"] == "uncertainty_twin"]
    coverage = float(np.mean([float(row["coverage"]) for row in uncertainty_rows]))
    width = float(
        np.mean([float(row["mean_interval_width_j"]) for row in uncertainty_rows])
    )
    under = float(
        np.mean([float(row["underestimation_rate"]) for row in uncertainty_rows])
    )
    over = float(
        np.mean([float(row["overestimation_rate"]) for row in uncertainty_rows])
    )
    capacity = float(config["energy"]["capacity_j"])
    coverage_error = abs(coverage - float(config["belief"]["nominal_coverage"]))
    width_fraction = width / capacity
    belief_comparison = _paired(
        _belief_seed_average(belief, "uncertainty_twin", "rmse_j"),
        _belief_seed_average(belief, "last_value", "rmse_j"),
        20260721,
    )

    ranking: dict[str, dict] = {}
    for metric in ("spearman", "ndcg_at_k"):
        full = _seed_average(voei, "full_voei", metric)
        for baseline in ("age", "uncertainty"):
            ranking[f"{metric}_full_minus_{baseline}"] = _paired(
                full,
                _seed_average(voei, baseline, metric),
                20260722 + len(ranking),
            )
    scenario_directions: dict[str, float] = {}
    for scenario in config["scenarios"]:
        for metric in ("spearman", "ndcg_at_k"):
            full = _seed_average(voei, "full_voei", metric, scenario)
            for baseline in ("age", "uncertainty"):
                other = _seed_average(voei, baseline, metric, scenario)
                common = sorted(set(full) & set(other))
                scenario_directions[f"{scenario}_{metric}_full_minus_{baseline}"] = (
                    float(np.mean([full[item] - other[item] for item in common]))
                    if common
                    else float("nan")
                )

    full_rows = [
        row for row in voei if row["method"] == "full_voei" and row["scope"] == "all"
    ]
    decisions_per_cell = int(config["simulation"]["slots"]) // int(
        config["voei"]["evaluation_stride_slots"]
    )
    evaluable_by_seed: dict[int, int] = defaultdict(int)
    total_decision_slots = 0
    total_positive_node_slots = 0.0
    total_node_slot_labels = 0
    for row in full_rows:
        seed = int(row["seed"])
        evaluable = int(round(float(row["ndcg_evaluable_slot_fraction"]) * decisions_per_cell))
        evaluable_by_seed[seed] += evaluable
        total_decision_slots += decisions_per_cell
        labels = int(float(row["node_slot_labels"]))
        total_node_slot_labels += labels
        total_positive_node_slots += float(row["positive_label_fraction"]) * labels
    total_evaluable = int(sum(evaluable_by_seed.values()))
    seeds_with_evaluable = int(sum(value > 0 for value in evaluable_by_seed.values()))
    positive_fraction = (
        float(total_positive_node_slots / total_node_slot_labels)
        if total_node_slot_labels
        else float("nan")
    )

    test_log_path = ROOT / "outputs" / "logs" / "stage1_unit_tests.json"
    test_log = json.loads(test_log_path.read_text()) if test_log_path.exists() else {}
    ranking_ci_positive = all(
        value["paired_seeds"] == 15 and value["paired_bootstrap_95_ci"][0] > 0.0
        for value in ranking.values()
    )
    checks = {
        "validation_seed_registry_exact": observed_seeds == expected_seeds
        and len(expected_seeds) == int(gate["minimum_validation_seed_count"]),
        "new_seed_registry_disjoint": expected_seeds.isdisjoint(forbidden),
        "expected_manifest_count": len(manifests) == 2 * 15 * 3,
        "freeze_hashes_match_all_manifests": hashes_match and seed_hash_match,
        "unit_and_no_leakage_tests": test_log.get("successful") is True
        and test_log.get("tests_run", 0) >= 23,
        "belief_rmse_paired_ci_upper_below_zero": belief_comparison[
            "paired_bootstrap_95_ci"
        ][1]
        < 0.0,
        "interval_coverage_error_within_limit": coverage_error
        <= float(gate["maximum_coverage_error"]),
        "interval_width_within_capacity_fraction": width_fraction
        <= float(gate["maximum_interval_width_capacity_fraction"]),
        "ranking_paired_ci_lower_above_zero": ranking_ci_positive,
        "both_scenario_directions_positive": all(
            math.isfinite(value) and value > 0.0
            for value in scenario_directions.values()
        ),
        "minimum_seeds_with_evaluable_slot": seeds_with_evaluable
        >= int(gate["minimum_seeds_with_evaluable_slot"]),
        "minimum_total_evaluable_slots": total_evaluable
        >= int(gate["minimum_total_evaluable_slots"]),
    }
    passed = bool(all(checks.values()))
    result = {
        "stage": "2-v2.1",
        "status": "pass" if passed else "fail",
        "stage3_authorized": passed,
        "checks": checks,
        "belief_uncertainty_minus_last_value_rmse": belief_comparison,
        "validation_uncertainty_coverage": coverage,
        "validation_uncertainty_coverage_error": coverage_error,
        "validation_uncertainty_mean_width_j": width,
        "validation_uncertainty_width_capacity_fraction": width_fraction,
        "validation_uncertainty_underestimation_rate": under,
        "validation_uncertainty_overestimation_rate": over,
        "ranking_paired_diagnostics": ranking,
        "scenario_direction_diagnostics": scenario_directions,
        "decision_support": {
            "total_decision_slots": total_decision_slots,
            "total_evaluable_slots": total_evaluable,
            "evaluable_slot_fraction": total_evaluable / total_decision_slots,
            "seeds_with_evaluable_slot": seeds_with_evaluable,
            "positive_node_slot_fraction": positive_fraction,
        },
        "failed_v2_ambiguity_classifier_used_for_gate": False,
        "parent_v2_failure_retained": True,
        "held_out_test_used": False,
    }
    write_json(output / "stage2_v2_1_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
