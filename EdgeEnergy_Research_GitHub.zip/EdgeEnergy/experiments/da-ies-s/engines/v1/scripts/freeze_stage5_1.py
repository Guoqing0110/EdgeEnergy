#!/usr/bin/env python3
"""Freeze DA-IES-S code, calibrated RCPG and fresh validation registry."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5_1 import hashes, load_configs  # noqa: E402
from src.logging.provenance import write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def main() -> None:
    config_path = ROOT / "configs" / "stage5_1.yaml"
    stage51, stage4, stage5 = load_configs(config_path)
    output = ROOT / "outputs" / "stage5_1_da_ies_s_v1"
    selection_path = output / "calibration_selection.json"
    if not selection_path.exists():
        raise RuntimeError("missing DA-IES-S calibration selection")
    selection = json.loads(selection_path.read_text())
    if selection.get("status") != "selected":
        raise RuntimeError("DA-IES-S calibration did not select a feasible grid")
    validation_path = ROOT / "seeds" / "da_ies_s_validation.txt"
    seeds = _seeds(validation_path)
    expected = int(stage51["stage5_1"]["validation_seed_count"])
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path != validation_path:
            forbidden.update(_seeds(path))
    if len(seeds) != expected or len(set(seeds)) != expected or set(seeds) & forbidden:
        raise RuntimeError("invalid DA-IES-S validation registry")
    failure = json.loads(
        (ROOT / stage51["experiment"]["stage5_failure_audit"]).read_text()
    )
    if failure.get("stage5_gate_passed") is not False:
        raise RuntimeError("Stage 5 safety-remediation provenance is missing")
    current = hashes(stage51, stage4, stage5, validation_path, selection)
    conditions = list(stage51["stage5_1"]["validation_conditions"])
    methods = 2
    runs = expected * len(conditions) * methods
    write_json(
        output / "stage5_1_freeze_manifest.json",
        {
            "schema_version": "stage5.1-freeze-v1",
            **current,
            "selected_grid_id": selection["selected_grid_id"],
            "selected_parameters": selection["selected_parameters"],
            "validation_seed_file": "seeds/da_ies_s_validation.txt",
            "protocol_file": "STAGE5_1_DA_IES_S_PROTOCOL.md",
            "expected_method_runs": runs,
            "expected_slot_rows": runs * int(stage51["stage5_1"]["slots"]),
            "held_out_test_used": False,
            "stage6_authorized": False,
        },
    )


if __name__ == "__main__":
    main()
