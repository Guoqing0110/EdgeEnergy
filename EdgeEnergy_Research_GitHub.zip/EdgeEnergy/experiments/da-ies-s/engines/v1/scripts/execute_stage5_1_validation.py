#!/usr/bin/env python3
"""Run every frozen DA-IES-S validation unit in isolated subprocesses."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_stage5_1.py"


def _seeds() -> list[int]:
    return [int(value) for value in (ROOT / "seeds" / "da_ies_s_validation.txt").read_text().split()]


def build_tasks() -> list[tuple[str, int, str, str]]:
    config = yaml.safe_load((ROOT / "configs" / "stage5_1.yaml").read_text())
    selection = json.loads(
        (ROOT / "outputs" / "stage5_1_da_ies_s_v1" / "calibration_selection.json").read_text()
    )
    proposed_grid = str(selection["selected_grid_id"])
    tasks = []
    for condition in config["stage5_1"]["validation_conditions"]:
        for seed in _seeds():
            tasks.append((condition, seed, "b4_queue_belief_age_direct", "baseline"))
            tasks.append((condition, seed, "p_da_ies_s", proposed_grid))
    return tasks


def _run(task: tuple[str, int, str, str]) -> tuple[str, int, str, str]:
    condition, seed, method, grid = task
    command = [
        sys.executable,
        str(RUNNER),
        "--phase",
        "validation",
        "--condition",
        condition,
        "--seed",
        str(seed),
        "--method",
        method,
        "--grid-id",
        grid,
    ]
    completed = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    if completed.returncode != 0:
        raise RuntimeError(f"Stage 5.1 task failed {task}:\n{completed.stdout}")
    return task


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 4:
        raise RuntimeError("workers must be in [1,4]")
    tasks = build_tasks()
    count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(_run, task) for task in tasks]
        for future in as_completed(futures):
            condition, seed, method, _ = future.result()
            count += 1
            print(
                f"completed {count}/{len(tasks)} {condition}/seed={seed}/{method}",
                flush=True,
            )


if __name__ == "__main__":
    main()
