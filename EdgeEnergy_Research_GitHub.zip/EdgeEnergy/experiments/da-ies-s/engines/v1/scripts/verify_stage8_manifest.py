#!/usr/bin/env python3
"""Verify the Stage 8 file-level SHA-256 manifest."""

from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "manifest",
        nargs="?",
        default="outputs/stage8_submission/full_file_manifest.csv",
    )
    args = parser.parse_args()
    manifest = Path(args.manifest)
    if not manifest.is_absolute():
        manifest = ROOT / manifest

    checked = 0
    errors: list[str] = []
    with manifest.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            path = ROOT / row["relative_path"]
            if not path.is_file():
                errors.append(f"missing: {row['relative_path']}")
                continue
            size = path.stat().st_size
            if size != int(row["size_bytes"]):
                errors.append(
                    f"size mismatch: {row['relative_path']} "
                    f"expected={row['size_bytes']} actual={size}"
                )
                continue
            actual = sha256_file(path)
            if actual != row["sha256"]:
                errors.append(f"hash mismatch: {row['relative_path']}")
                continue
            checked += 1

    if errors:
        for error in errors:
            print(error)
        print(f"FAIL: checked={checked}, errors={len(errors)}")
        return 2
    print(f"PASS: verified {checked} files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
