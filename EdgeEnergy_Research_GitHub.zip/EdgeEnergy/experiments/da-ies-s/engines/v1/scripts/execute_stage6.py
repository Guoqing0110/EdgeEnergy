#!/usr/bin/env python3
"""Execute all frozen Stage 6 held-out units."""

from __future__ import annotations

import argparse
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_stage6.py"


def build_tasks() -> list[tuple[str, int, str]]:
    config = yaml.safe_load((ROOT / "configs" / "stage6.yaml").read_text())
    seeds = [int(value) for value in (ROOT / "seeds" / "test_held_out.txt").read_text().split()]
    return [
        (condition, seed, method)
        for condition in config["stage6"]["conditions"]
        for seed in seeds
        for method in ("b4_queue_belief_age_direct", "p_da_ies_s")
    ]


def _run(task: tuple[str, int, str]) -> tuple[str, int, str]:
    condition, seed, method = task
    command = [
        sys.executable,
        str(RUNNER),
        "--condition",
        condition,
        "--seed",
        str(seed),
        "--method",
        method,
    ]
    completed = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    if completed.returncode != 0:
        raise RuntimeError(f"Stage 6 task failed {task}:\n{completed.stdout}")
    return task


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 4:
        raise RuntimeError("workers must be in [1,4]")
    tasks = build_tasks()
    count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(_run, task) for task in tasks]
        for future in as_completed(futures):
            condition, seed, method = future.result()
            count += 1
            print(f"completed {count}/{len(tasks)} {condition}/seed={seed}/{method}", flush=True)


if __name__ == "__main__":
    main()
