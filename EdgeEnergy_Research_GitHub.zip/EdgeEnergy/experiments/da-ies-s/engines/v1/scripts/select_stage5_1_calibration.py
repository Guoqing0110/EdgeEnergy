#!/usr/bin/env python3
"""Select the pre-registered DA-IES-S RCPG grid on calibration seeds."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, write_json  # noqa: E402
from src.scheduler.stage4 import DA_IES_S_METHOD  # noqa: E402


def main() -> None:
    config = yaml.safe_load((ROOT / "configs" / "stage5_1.yaml").read_text())
    output = ROOT / "outputs" / "stage5_1_da_ies_s_v1"
    rows = [
        json.loads(path.read_text())
        for path in sorted(
            output.glob(
                f"raw/da_ies_s_calibration/grid=*/condition=*/seed=*/method={DA_IES_S_METHOD}/summary.json"
            )
        )
    ]
    expected = (
        len(config["risk_grid"])
        * len(config["stage5_1"]["tuning_conditions"])
        * int(config["stage5_1"]["calibration_seed_count"])
    )
    if len(rows) != expected:
        raise RuntimeError(f"expected {expected} calibration summaries, observed {len(rows)}")
    selection = config["calibration_selection"]
    candidates = []
    for grid_id, params in config["risk_grid"].items():
        members = [row for row in rows if row["risk_grid_id"] == grid_id]
        violations = sum(int(row["payer_reserve_violations"]) for row in members)
        checks = sum(int(row["payer_checks"]) for row in members)
        pooled_rate = violations / checks if checks else 0.0
        condition_rates = {}
        for condition in config["stage5_1"]["tuning_conditions"]:
            local = [row for row in members if row["condition"] == condition]
            local_violations = sum(int(row["payer_reserve_violations"]) for row in local)
            local_checks = sum(int(row["payer_checks"]) for row in local)
            condition_rates[condition] = (
                local_violations / local_checks if local_checks else 0.0
            )
        mean_unmet = float(
            np.mean([float(row["cumulative_unmet_visible_demand_j"]) for row in members])
        )
        mean_continuity = float(
            np.mean([float(row["all_service_met_slot_fraction"]) for row in members])
        )
        score = (
            float(selection["service_score_unmet_weight"]) * mean_unmet
            - float(selection["service_score_continuity_weight_j"]) * mean_continuity
        )
        feasible = (
            pooled_rate <= float(selection["maximum_payer_reserve_violation_rate"])
            and max(condition_rates.values())
            <= float(selection["maximum_condition_reserve_violation_rate"])
        )
        candidates.append(
            {
                "grid_id": grid_id,
                "parameters": params,
                "pooled_payer_reserve_violation_rate": pooled_rate,
                "condition_payer_reserve_violation_rates": condition_rates,
                "mean_cumulative_unmet_visible_demand_j": mean_unmet,
                "mean_all_service_met_slot_fraction": mean_continuity,
                "selection_score": score,
                "feasible": feasible,
            }
        )
    feasible = [item for item in candidates if item["feasible"]]
    if not feasible:
        write_json(
            output / "calibration_selection.json",
            {
                "schema_version": "stage5.1-calibration-selection-v1",
                "status": "no_feasible_grid",
                "candidates": candidates,
                "held_out_test_used": False,
            },
        )
        raise SystemExit(2)
    chosen = min(
        feasible,
        key=lambda item: (
            item["selection_score"],
            float(item["parameters"]["tail_allowance_j"]),
            float(item["parameters"]["uncertainty_multiplier"]),
            item["grid_id"],
        ),
    )
    payload = {
        "schema_version": "stage5.1-calibration-selection-v1",
        "status": "selected",
        "selected_grid_id": chosen["grid_id"],
        "selected_parameters": chosen["parameters"],
        "selection_rule_hash": canonical_hash(selection),
        "candidates": candidates,
        "held_out_test_used": False,
    }
    write_json(output / "calibration_selection.json", payload)


if __name__ == "__main__":
    main()
