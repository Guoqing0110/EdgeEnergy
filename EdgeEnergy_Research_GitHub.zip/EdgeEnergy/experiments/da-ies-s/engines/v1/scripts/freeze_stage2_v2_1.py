#!/usr/bin/env python3
"""Freeze the prospective Stage 2 v2.1 one-shot validation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, code_hash, write_json  # noqa: E402


def _integers(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="utf-8").split()]


def main() -> None:
    output = ROOT / "outputs" / "stage2_belief_voei_v2_1"
    config_path = ROOT / "configs" / "stage2_v2_1.yaml"
    seed_path = ROOT / "seeds" / "validation_v2_1.txt"
    protocol_path = ROOT / "STAGE2_V2_1_PROTOCOL.md"
    calibration_path = (
        ROOT
        / "outputs"
        / "stage2_belief_voei_v2"
        / "calibration_parameters_v2.json"
    )
    for required in (config_path, seed_path, protocol_path, calibration_path):
        if not required.exists():
            raise RuntimeError(f"required freeze input missing: {required}")
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    seeds = _integers(seed_path)
    if len(seeds) != 15 or len(set(seeds)) != 15:
        raise RuntimeError("v2.1 requires exactly 15 unique validation seeds")
    write_json(
        output / "stage2_v2_1_freeze_manifest.json",
        {
            "schema_version": "stage2-v2.1-freeze-v1",
            "parent_v2_status": "failed_and_retained",
            "code_hash": code_hash(ROOT),
            "config_hash": canonical_hash(config),
            "calibration_hash": canonical_hash(calibration["calibration"]),
            "validation_seed_hash": canonical_hash(seeds),
            "validation_seed_file": "seeds/validation_v2_1.txt",
            "calibration_source": str(calibration_path.relative_to(ROOT)),
            "protocol_file": "STAGE2_V2_1_PROTOCOL.md",
            "held_out_test_used": False,
            "frozen_parameters": [
                "v2 hidden-load mean forecast and process model",
                "v2 role-age conformal calibration",
                "v2 scenarios and reporting intervals",
                "v2 VoEI objective, samples, and candidate pruning",
                "all-slot Spearman and conditional NDCG primary metrics",
                "absolute decision-sensitive support gate",
                "paired-seed bootstrap and scenario-direction gates",
            ],
        },
    )


if __name__ == "__main__":
    main()
