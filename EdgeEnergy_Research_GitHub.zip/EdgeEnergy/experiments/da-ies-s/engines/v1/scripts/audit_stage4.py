#!/usr/bin/env python3
"""Apply Stage 4 engineering, budget and scientific gates."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def _csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    output = ROOT / "outputs" / "stage4_long_horizon_v1"
    config = yaml.safe_load((ROOT / "configs" / "stage4.yaml").read_text())
    gate = config["gate"]
    freeze = json.loads((output / "stage4_freeze_manifest.json").read_text())
    comparisons = json.loads(
        (output / "processed" / "paired_primary_comparisons.json").read_text()
    )
    summaries = _csv(output / "processed" / "per_seed_scenario_method.csv")
    manifests = list(
        output.glob("raw/stage4_validation/*/seed=*/method=*/manifest.json")
    )
    manifest_values = [json.loads(path.read_text()) for path in manifests]
    expected_seed_list = _seeds(ROOT / "seeds" / "stage4_validation.txt")
    expected_seeds = set(expected_seed_list)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != "stage4_validation.txt":
            forbidden.update(_seeds(path))
    observed_seeds = {int(item["seed"]) for item in manifest_values}
    hash_fields = (
        "code_hash",
        "config_hash",
        "calibration_hash",
        "stage3_authorization_hash",
        "validation_seed_hash",
    )
    hashes_match = all(
        all(item[field] == freeze[field] for field in hash_fields)
        for item in manifest_values
    )
    trace_methods: dict[tuple[str, int], set[str]] = {}
    for item in manifest_values:
        key = (str(item["scenario"]), int(item["seed"]))
        trace_methods.setdefault(key, set()).add(str(item["trace_hash"]))
    trace_hash_errors = sum(len(values) != 1 for values in trace_methods.values())
    test_log = json.loads((ROOT / "outputs" / "logs" / "stage1_unit_tests.json").read_text())

    maximum_conservation = 0.0
    slot_rows = 0
    online_key_errors = 0
    executor_paths = sorted(
        output.glob("raw/stage4_validation/*/seed=*/method=*/slots.jsonl")
    )
    forbidden_online = {
        "hidden_service_j",
        "harvest_actual_j",
        "energy_before_j",
        "energy_after_j",
    }
    for path in executor_paths:
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                slot_rows += 1
                residual = row["executor_ledger"]["conservation_residual_j"]
                maximum_conservation = max(
                    maximum_conservation, max(abs(float(value)) for value in residual)
                )
                online_key_errors += len(
                    forbidden_online.intersection(row["online_information"])
                )

    report_limit = float(config["stage4"]["report_average_budget_j_per_slot"]) + float(
        gate["maximum_average_report_budget_tolerance_j"]
    )
    wet_limit = float(config["stage4"]["wet_average_budget_j_per_slot"]) + float(
        gate["maximum_average_wet_budget_tolerance_j"]
    )
    report_methods = set(config["stage4"]["methods"]) - {"b8_full_state_queue_oracle"}
    wet_methods = set(config["stage4"]["methods"]) - {
        "b0_no_wet_periodic_direct",
        "b8_full_state_queue_oracle",
    }
    report_budget_ok = all(
        float(row["average_reporting_debit_j_per_slot"]) <= report_limit
        for row in summaries
        if row["method"] in report_methods
    )
    wet_budget_ok = all(
        float(row["average_wet_gross_debit_j_per_slot"]) <= wet_limit
        for row in summaries
        if row["method"] in wet_methods
    )
    expected_runs = int(freeze["expected_method_runs"])
    expected_rows = int(freeze["expected_slot_rows"])
    expected_slots = int(config["simulation"]["slots"])
    expected_methods = int(gate["expected_methods"])
    expected_scenarios = int(gate["expected_scenarios"])
    structure_ok = (
        len(manifests) == expected_runs
        and len(executor_paths) == expected_runs
        and slot_rows == expected_rows
        and all(int(item["slot_rows"]) == expected_slots for item in manifest_values)
        and len(trace_methods) == len(expected_seeds) * expected_scenarios
        and all(
            sum(
                int(item["seed"]) == seed and str(item["scenario"]) == scenario
                for item in manifest_values
            )
            == expected_methods
            for scenario, seed in trace_methods
        )
    )

    unmet = comparisons["proposed_minus_no_wet_unmet"]
    continuity = comparisons["proposed_minus_no_wet_continuity"]
    reporting = comparisons["proposed_minus_full_direct_reporting"]
    direct_continuity = comparisons["proposed_minus_full_direct_continuity"]
    paired_count = int(gate["expected_validation_seeds"])
    checks = {
        "validation_seed_registry_exact": observed_seeds == expected_seeds
        and len(expected_seeds) == paired_count,
        "stage4_seeds_disjoint": expected_seeds.isdisjoint(forbidden),
        "manifest_and_slot_rows_complete": structure_ok,
        "freeze_hashes_match": hashes_match
        and freeze["validation_seed_hash"] == canonical_hash(expected_seed_list),
        "matched_policy_independent_trace_hashes": trace_hash_errors == 0,
        "unit_and_no_leakage_tests": test_log.get("successful") is True
        and int(test_log.get("tests_run", 0)) >= 35
        and online_key_errors == 0,
        "energy_conservation": maximum_conservation
        <= float(gate["maximum_conservation_residual_j"]),
        "realistic_report_budgets_respected": report_budget_ok,
        "realistic_wet_budgets_respected": wet_budget_ok,
        "proposed_vs_no_wet_unmet_ci_upper_negative": unmet["paired_seeds"]
        == paired_count
        and unmet["paired_bootstrap_95_ci"][1] < 0.0,
        "proposed_vs_no_wet_continuity_ci_lower_positive": continuity[
            "paired_seeds"
        ]
        == paired_count
        and continuity["paired_bootstrap_95_ci"][0] > 0.0,
        "proposed_reporting_lower_than_full_direct": reporting["paired_seeds"]
        == paired_count
        and reporting["paired_bootstrap_95_ci"][1] < 0.0,
        "proposed_continuity_noninferior_to_full_direct": direct_continuity[
            "paired_seeds"
        ]
        == paired_count
        and direct_continuity["paired_bootstrap_95_ci"][0]
        > -float(gate["direct_reporting_continuity_noninferiority_margin"]),
    }
    passed = bool(all(checks.values()))
    result = {
        "stage": "4-long-horizon-co-scheduling-v1",
        "status": "pass" if passed else "fail",
        "stage4_completed": passed,
        "stage5_authorized": passed,
        "checks": checks,
        "primary_comparisons": comparisons,
        "accounting": {
            "manifest_files": len(manifests),
            "slot_files": len(executor_paths),
            "slot_rows": slot_rows,
            "expected_slot_rows": expected_rows,
            "maximum_conservation_residual_j": maximum_conservation,
            "online_key_errors": online_key_errors,
            "trace_hash_errors": trace_hash_errors,
            "report_budget_limit_j_per_slot": report_limit,
            "wet_budget_limit_j_per_slot": wet_limit,
        },
        "held_out_test_used": False,
        "full_state_reference_excluded_from_realistic_claims": True,
        "lyapunov_claim_made": False,
    }
    write_json(output / "stage4_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
