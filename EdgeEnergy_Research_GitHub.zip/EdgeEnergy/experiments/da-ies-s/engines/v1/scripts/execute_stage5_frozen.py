#!/usr/bin/env python3
"""Execute each frozen Stage 5 factor/seed unit in an isolated subprocess."""

from __future__ import annotations

import argparse
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_stage5.py"


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def build_tasks(config: dict, family_filter: str | None = None) -> list[tuple[str, str, int]]:
    seeds = _seeds(ROOT / "seeds" / "stage5_validation.txt")
    families = [family_filter] if family_filter else ["robustness", "scalability", "complexity"]
    tasks: list[tuple[str, str, int]] = []
    for family in families:
        if family == "robustness":
            conditions = list(config["robustness"]["conditions"])
            active = seeds
        elif family == "scalability":
            conditions = [f"n{int(value)}" for value in config["scalability"]["node_counts"]]
            active = seeds[: int(config["stage5"]["scalability_seed_count"])]
        elif family == "complexity":
            conditions = list(config["complexity"]["conditions"])
            active = seeds[: int(config["stage5"]["complexity_seed_count"])]
        else:
            raise ValueError("unknown Stage 5 family")
        tasks.extend((family, condition, seed) for condition in conditions for seed in active)
    return tasks


def _run_task(task: tuple[str, str, int]) -> tuple[tuple[str, str, int], str]:
    family, condition, seed = task
    command = [
        sys.executable,
        str(RUNNER),
        "--phase",
        "stage5_validation",
        "--family",
        family,
        "--condition",
        condition,
        "--seed",
        str(seed),
        "--skip-completed",
    ]
    completed = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"Stage 5 task {family}/{condition}/{seed} failed:\n{completed.stdout}"
        )
    return task, completed.stdout


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--family", choices=["robustness", "scalability", "complexity"])
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 4:
        raise RuntimeError("Stage 5 workers must be in [1,4]")
    config = yaml.safe_load((ROOT / "configs" / "stage5.yaml").read_text())
    tasks = build_tasks(config, args.family)
    completed_count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(_run_task, task): task for task in tasks}
        for future in as_completed(futures):
            task, _ = future.result()
            completed_count += 1
            family, condition, seed = task
            print(
                f"completed {completed_count}/{len(tasks)} {family}/{condition}/seed={seed}",
                flush=True,
            )


if __name__ == "__main__":
    main()
