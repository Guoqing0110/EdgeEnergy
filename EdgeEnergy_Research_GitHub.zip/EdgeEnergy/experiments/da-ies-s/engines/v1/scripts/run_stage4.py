#!/usr/bin/env python3
"""Run Stage 4 development or frozen validation trajectories."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
    write_jsonl,
)
from src.scheduler.stage4 import METHODS  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def _deep_update(target: dict[str, Any], override: dict[str, Any]) -> None:
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_update(target[key], value)
        else:
            target[key] = copy.deepcopy(value)


def scenario_config(base: dict[str, Any], scenario: str) -> dict[str, Any]:
    config = copy.deepcopy(base)
    _deep_update(config, base["scenarios"][scenario])
    return config


def run(
    config_path: Path,
    output: Path,
    phase: str,
    scenario_filter: str | None,
    seed_filter: int | None,
    limit_seeds: int | None,
) -> None:
    base = yaml.safe_load(config_path.read_text())
    if phase not in base["experiment"]["allowed_seed_splits"]:
        raise RuntimeError("Stage 4 phase is not authorized by config")
    seed_path = ROOT / "seeds" / f"{phase}.txt"
    seeds = _seeds(seed_path)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != seed_path.name:
            forbidden.update(_seeds(path))
    if len(seeds) != len(set(seeds)) or not set(seeds).isdisjoint(forbidden):
        raise RuntimeError("Stage 4 seed registry is duplicated or overlapping")
    if phase == "stage4_validation" and len(seeds) != int(
        base["gate"]["expected_validation_seeds"]
    ):
        raise RuntimeError("Stage 4 validation registry has wrong seed count")
    if limit_seeds is not None:
        if phase != "development":
            raise RuntimeError("seed limiting is development-only")
        seeds = seeds[: int(limit_seeds)]
    if seed_filter is not None:
        if seed_filter not in seeds:
            raise RuntimeError("seed filter is outside the active Stage 4 registry")
        seeds = [seed_filter]

    authorization_path = ROOT / base["experiment"]["stage3_authorization"]
    authorization = json.loads(authorization_path.read_text())
    if authorization.get("stage4_authorized") is not True:
        raise RuntimeError("Stage 3 v1.1 does not authorize Stage 4")
    calibration_path = ROOT / base["experiment"]["calibration_source"]
    calibration_payload = json.loads(calibration_path.read_text())
    calibration = calibration_from_dict(calibration_payload["calibration"])
    hashes = {
        "code_hash": code_hash(ROOT),
        "config_hash": canonical_hash(base),
        "calibration_hash": canonical_hash(calibration_payload["calibration"]),
        "stage3_authorization_hash": canonical_hash(authorization),
        "validation_seed_hash": canonical_hash(_seeds(seed_path)),
    }
    if phase == "stage4_validation":
        freeze = json.loads((output / "stage4_freeze_manifest.json").read_text())
        for key, value in hashes.items():
            if freeze.get(key) != value:
                raise RuntimeError(f"Stage 4 {key} differs from pre-run freeze")

    scenarios = list(base["scenarios"])
    if scenario_filter is not None:
        if scenario_filter not in scenarios:
            raise RuntimeError("unknown Stage 4 scenario filter")
        scenarios = [scenario_filter]
    methods = list(base["stage4"]["methods"])
    if tuple(methods) != METHODS:
        raise RuntimeError("Stage 4 method registry differs from implementation")

    for scenario in scenarios:
        config = scenario_config(base, scenario)
        for seed in seeds:
            trace = generate_trace(config, seed)
            seed_root = output / "raw" / phase / scenario / f"seed={seed}"
            trace.save(seed_root / "trace.npz")
            write_json(
                seed_root / "trace_manifest.json",
                {
                    "schema_version": "stage4-trace-v1",
                    "phase": phase,
                    "scenario": scenario,
                    "seed": seed,
                    "trace_hash": trace.content_hash(),
                    "policy_independent": True,
                    "methods": methods,
                    **hashes,
                    "held_out_test_used": False,
                },
            )
            for method in methods:
                result = run_stage4_method(config, trace, method, scenario, calibration)
                method_root = seed_root / f"method={method}"
                write_jsonl(method_root / "slots.jsonl", result.records)
                summary = {
                    "schema_version": "stage4-summary-v1",
                    "phase": phase,
                    "scenario": scenario,
                    "seed": seed,
                    "method": method,
                    "trace_hash": result.trace_hash,
                    "deterministic_records_hash": deterministic_records_hash(result.records),
                    "runtime_seconds": result.runtime_seconds,
                    **hashes,
                    **result.summary,
                }
                write_json(method_root / "summary.json", summary)
                write_json(
                    method_root / "manifest.json",
                    {
                        "schema_version": "stage4-method-manifest-v1",
                        "phase": phase,
                        "scenario": scenario,
                        "seed": seed,
                        "method": method,
                        "slot_rows": len(result.records),
                        "trace_hash": result.trace_hash,
                        **hashes,
                        "online_truth_separation": "online_information vs offline_truth_only",
                        "status": "completed",
                    },
                )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage4.yaml")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage4_long_horizon_v1"
    )
    parser.add_argument("--phase", choices=["development", "stage4_validation"], required=True)
    parser.add_argument("--scenario")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--limit-seeds", type=int)
    args = parser.parse_args()
    run(
        args.config,
        args.output,
        args.phase,
        args.scenario,
        args.seed,
        args.limit_seeds,
    )


if __name__ == "__main__":
    main()
