#!/usr/bin/env python3
"""One-command Stage 1 runner, aggregator, and gate audit."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    commands = [
        [sys.executable, str(ROOT / "scripts" / "run_tests.py")],
        [sys.executable, str(ROOT / "scripts" / "run_stage1.py")],
        [sys.executable, str(ROOT / "scripts" / "aggregate_stage1.py")],
        [sys.executable, str(ROOT / "scripts" / "audit_stage1.py")],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
