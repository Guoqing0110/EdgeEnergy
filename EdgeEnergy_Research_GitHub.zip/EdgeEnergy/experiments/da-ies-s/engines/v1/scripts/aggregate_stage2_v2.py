#!/usr/bin/env python3
"""Aggregate Stage 2 v2 belief and all-slot/opportunity VoEI results."""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.metrics.ranking import binary_auc, ndcg_at_k, spearman, top_k_precision  # noqa: E402


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"no rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def belief_metrics(rows: list[dict]) -> dict:
    error = np.asarray([row["error_j_offline_only"] for row in rows], dtype=float)
    coverage = np.asarray(
        [row["interval_covered_offline_only"] for row in rows], dtype=float
    )
    width = np.asarray([row["interval_width_j"] for row in rows], dtype=float)
    return {
        "observations": len(rows),
        "mae_j": float(np.mean(np.abs(error))),
        "rmse_j": float(np.sqrt(np.mean(error**2))),
        "median_abs_error_j": float(np.median(np.abs(error))),
        "underestimation_rate": float(np.mean(error < 0.0)),
        "overestimation_rate": float(np.mean(error > 0.0)),
        "coverage": float(np.mean(coverage)),
        "mean_interval_width_j": float(np.mean(width)),
    }


def aggregate_belief(raw_root: Path, processed: Path, config: dict) -> None:
    groups: dict[tuple, list[dict]] = defaultdict(list)
    role_groups: dict[tuple, list[dict]] = defaultdict(list)
    for path in sorted(
        raw_root.glob("*/*/seed=*/report_interval=*/belief_rows.jsonl")
    ):
        rows = read_jsonl(path)
        for row in rows:
            key = (
                path.parts[-5],
                row["scenario"],
                int(row["seed"]),
                int(row["report_interval"]),
                row["method"],
            )
            groups[key].append(row)
            role_groups[key + (row["role"],)].append(row)
    output = []
    for key, rows in sorted(groups.items()):
        metrics = belief_metrics(rows)
        metrics["calibration_error"] = abs(
            metrics["coverage"] - float(config["belief"]["nominal_coverage"])
        )
        output.append(
            {
                "split": key[0],
                "scenario": key[1],
                "seed": key[2],
                "report_interval": key[3],
                "method": key[4],
                **metrics,
            }
        )
    role_output = [
        {
            "split": key[0],
            "scenario": key[1],
            "seed": key[2],
            "report_interval": key[3],
            "method": key[4],
            "role": key[5],
            **belief_metrics(rows),
        }
        for key, rows in sorted(role_groups.items())
    ]
    write_csv(processed / "belief_per_seed.csv", output)
    write_csv(processed / "belief_role_per_seed.csv", role_output)


def _ranking_metrics(rows: list[dict], score_field: str, k: int) -> dict:
    if not rows:
        return {
            "node_slot_labels": 0,
            "positive_label_fraction": float("nan"),
            "action_change_fraction": float("nan"),
            "spearman": float("nan"),
            "ndcg_at_k": float("nan"),
            "ndcg_evaluable_slot_fraction": float("nan"),
            "top_k_precision": float("nan"),
            "action_change_auc": float("nan"),
        }
    scores = np.asarray([row[score_field] for row in rows], dtype=float)
    labels = np.asarray([row["offline_true_value"] for row in rows], dtype=float)
    changes = np.asarray([row["offline_action_changed"] for row in rows], dtype=bool)
    slots = sorted({int(row["slot"]) for row in rows})
    ndcgs, precisions = [], []
    for slot in slots:
        indices = [idx for idx, row in enumerate(rows) if int(row["slot"]) == slot]
        ndcg = ndcg_at_k(scores[indices], labels[indices], k)
        if math.isfinite(ndcg):
            ndcgs.append(ndcg)
        precisions.append(top_k_precision(scores[indices], labels[indices], k))
    return {
        "node_slot_labels": len(rows),
        "positive_label_fraction": float(np.mean(labels > 0.0)),
        "action_change_fraction": float(np.mean(changes)),
        "spearman": spearman(scores, labels),
        "ndcg_at_k": float(np.mean(ndcgs)) if ndcgs else float("nan"),
        "ndcg_evaluable_slot_fraction": len(ndcgs) / len(slots),
        "top_k_precision": float(np.mean(precisions)),
        "action_change_auc": binary_auc(scores, changes),
    }


def aggregate_voei(raw_root: Path, processed: Path, config: dict) -> None:
    score_fields = {
        "age": "age_score",
        "uncertainty": "uncertainty_score",
        "urgency": "urgency_score",
        "random": "random_score",
        "full_voei": "full_voei_score",
    }
    k = int(config["voei"]["top_k"])
    output = []
    for path in sorted(raw_root.glob("*/*/seed=*/report_interval=*/voei_rows.jsonl")):
        rows = read_jsonl(path)
        if not rows:
            continue
        split = path.parts[-5]
        all_slots = {int(row["slot"]) for row in rows}
        opportunity_slots = {
            int(row["slot"]) for row in rows if row["is_ambiguity_opportunity"]
        }
        opportunity_fraction = len(opportunity_slots) / len(all_slots)
        for scope in ("all", "opportunity"):
            scoped = (
                rows
                if scope == "all"
                else [row for row in rows if row["is_ambiguity_opportunity"]]
            )
            for method, field in score_fields.items():
                output.append(
                    {
                        "split": split,
                        "scenario": rows[0]["scenario"],
                        "seed": int(rows[0]["seed"]),
                        "report_interval": int(rows[0]["report_interval"]),
                        "scope": scope,
                        "method": method,
                        "opportunity_fraction": opportunity_fraction,
                        "mean_candidate_count": float(
                            np.mean([row["candidate_count"] for row in rows])
                        ),
                        **_ranking_metrics(scoped, field, k),
                    }
                )
    write_csv(processed / "voei_per_seed.csv", output)


def main() -> None:
    config = yaml.safe_load((ROOT / "configs" / "stage2_v2.yaml").read_text())
    root = ROOT / "outputs" / "stage2_belief_voei_v2"
    processed = root / "processed"
    aggregate_belief(root / "raw", processed, config)
    aggregate_voei(root / "raw", processed, config)


if __name__ == "__main__":
    main()
