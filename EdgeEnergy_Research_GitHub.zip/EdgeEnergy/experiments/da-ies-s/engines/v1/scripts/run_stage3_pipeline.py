#!/usr/bin/env python3
"""Test, freeze, run, aggregate, and audit the Stage 3 experiment."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    commands = [
        [sys.executable, str(ROOT / "scripts" / "run_tests.py")],
        [sys.executable, str(ROOT / "scripts" / "freeze_stage3.py")],
        [sys.executable, str(ROOT / "scripts" / "run_stage3.py")],
        [sys.executable, str(ROOT / "scripts" / "aggregate_stage3.py")],
        [sys.executable, str(ROOT / "scripts" / "audit_stage3.py")],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
