#!/usr/bin/env python3
"""Run Stage 2 calibration or one-shot validation without held-out seeds."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.digital_twin.calibration import (  # noqa: E402
    IntervalCalibration,
    calibration_from_dict,
    fit_interval_calibration,
)
from src.environment.trace import generate_trace  # noqa: E402
from src.experiments.belief_benchmark import (  # noqa: E402
    generate_benchmark,
    replay_beliefs,
)
from src.information_value.voei import (  # noqa: E402
    DecisionBelief,
    baseline_information_scores,
    build_candidate_actions,
    full_decision_aware_voei,
    offline_true_counterfactual_value,
)
from src.logging.provenance import canonical_hash, code_hash, write_json, write_jsonl  # noqa: E402


def load_config(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def load_seeds(path: Path) -> list[int]:
    return [int(x) for x in path.read_text().split()]


def augment_intervals(
    rows: list[dict], calibration: IntervalCalibration, capacity_j: float
) -> None:
    for row in rows:
        mean = float(row["mean_j"])
        std = float(np.sqrt(max(0.0, row["variance_j2"])))
        if row["method"] == "uncertainty_twin":
            entry = calibration.lookup(str(row["role"]), int(row["age"]))
            multiplier = entry.multiplier
            source = entry.source_level
        elif row["method"] == "full_state_oracle":
            multiplier = 0.0
            source = "oracle"
        else:
            multiplier = 0.0
            source = "point_estimate"
        lower = max(0.0, mean - multiplier * std)
        upper = min(float(capacity_j), mean + multiplier * std)
        truth = float(row["truth_j_offline_only"])
        row.update(
            {
                "interval_multiplier": multiplier,
                "interval_source": source,
                "interval_lower_j": lower,
                "interval_upper_j": upper,
                "interval_width_j": upper - lower,
                "interval_covered_offline_only": bool(lower <= truth <= upper),
            }
        )


def _group_uncertainty_rows(rows: list[dict]) -> dict[int, list[dict]]:
    grouped: dict[int, list[dict]] = {}
    for row in rows:
        if row["method"] == "uncertainty_twin":
            grouped.setdefault(int(row["slot"]), []).append(row)
    return grouped


def build_voei_rows(
    config: dict[str, Any], trace: Any, interval: int, belief_rows: list[dict]
) -> list[dict]:
    stride = int(config["voei"]["evaluation_stride_slots"])
    reserve = float(config["energy"]["capacity_j"]) * float(
        config["energy"]["reserve_fraction"]
    )
    by_slot = _group_uncertainty_rows(belief_rows)
    output: list[dict] = []
    for slot in sorted(by_slot):
        if slot % stride != 0:
            continue
        node_rows = sorted(by_slot[slot], key=lambda row: int(row["node"]))
        mean = np.asarray([row["mean_j"] for row in node_rows], dtype=float)
        std = np.sqrt(
            np.asarray([max(0.0, row["variance_j2"]) for row in node_rows], dtype=float)
        )
        lower = np.asarray([row["interval_lower_j"] for row in node_rows], dtype=float)
        ages = np.asarray([row["age"] for row in node_rows], dtype=int)
        truth = np.asarray([row["truth_j_offline_only"] for row in node_rows], dtype=float)
        belief = DecisionBelief(
            mean_j=mean,
            std_j=std,
            lower_j=lower,
            age=ages,
            capacity_j=float(config["energy"]["capacity_j"]),
            reserve_j=reserve,
            positions=trace.positions,
            wet_adjacency=tuple(
                tuple(bool(x) for x in row) for row in trace.wet_adjacency
            ),
        )
        candidates = build_candidate_actions(belief, config)
        random_rng = np.random.default_rng(
            np.random.SeedSequence([trace.seed, interval, slot, 90125])
        )
        baseline = baseline_information_scores(
            belief, config, random_rng.random(trace.node_count)
        )
        for node in range(trace.node_count):
            online_rng = np.random.default_rng(
                np.random.SeedSequence([trace.seed, interval, slot, node, 51077])
            )
            full = full_decision_aware_voei(
                belief, node, candidates, config, online_rng
            )
            offline = offline_true_counterfactual_value(
                belief, node, float(truth[node]), candidates, config
            )
            output.append(
                {
                    "seed": trace.seed,
                    "report_interval": interval,
                    "slot": slot,
                    "node": node,
                    "candidate_count": len(candidates),
                    "age_score": float(baseline["age"][node]),
                    "uncertainty_score": float(baseline["uncertainty"][node]),
                    "urgency_score": float(baseline["urgency"][node]),
                    "random_score": float(baseline["random"][node]),
                    "full_voei_score": full.value,
                    "full_uncertainty_component": full.uncertainty,
                    "full_sensitivity_component": full.sensitivity,
                    "full_consequence_component": full.consequence,
                    "offline_true_value": offline.value,
                    "offline_action_changed": offline.action_changed,
                    "online_base_action": asdict(full.base_action),
                    "offline_revealed_action": asdict(offline.revealed_action),
                }
            )
    return output


def run_phase(config_path: Path, phase: str, output_root: Path) -> None:
    if phase not in {"calibration", "validation"}:
        raise ValueError("phase must be calibration or validation")
    config = load_config(config_path)
    if phase not in config["experiment"]["allowed_seed_splits"]:
        raise RuntimeError(f"phase {phase} not authorized by configuration")
    seed_path = ROOT / "seeds" / f"{phase}.txt"
    seeds = load_seeds(seed_path)
    held_out = set(load_seeds(ROOT / "seeds" / "test_held_out.txt"))
    if not set(seeds).isdisjoint(held_out):
        raise RuntimeError("Stage 2 seed list intersects held-out test registry")

    source_hash = code_hash(ROOT)
    config_hash = canonical_hash(config)
    freeze_path = output_root / "stage2_freeze_manifest.json"
    calibration_path = output_root / "calibration_parameters.json"
    if phase == "validation":
        if not freeze_path.exists() or not calibration_path.exists():
            raise RuntimeError("validation requires a completed calibration freeze")
        freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
        if freeze["code_hash"] != source_hash or freeze["config_hash"] != config_hash:
            raise RuntimeError("code/config differs from the Stage 2 calibration freeze")
        calibration_value = json.loads(calibration_path.read_text(encoding="utf-8"))
        calibration = calibration_from_dict(calibration_value["calibration"])
    else:
        calibration = None

    phase_rows: list[tuple[Path, list[dict], Any, int]] = []
    calibration_fit_rows: list[dict] = []
    for seed in seeds:
        trace = generate_trace(config, seed)
        seed_root = output_root / "raw" / phase / f"seed={seed}"
        trace.save(seed_root / "trace.npz")
        write_json(
            seed_root / "trace_manifest.json",
            {
                "seed": seed,
                "split": phase,
                "trace_hash": trace.content_hash(),
                "config_hash": config_hash,
                "code_hash": source_hash,
                "held_out": False,
            },
        )
        for interval in config["reporting"]["intervals_slots"]:
            interval = int(interval)
            benchmark = generate_benchmark(config, trace, interval)
            rows = replay_beliefs(config, benchmark)
            interval_root = seed_root / f"report_interval={interval}"
            phase_rows.append((interval_root, rows, trace, interval))
            calibration_fit_rows.extend(
                row for row in rows if row["method"] == "uncertainty_twin"
            )

    if phase == "calibration":
        belief_config = config["belief"]
        calibration = fit_interval_calibration(
            calibration_fit_rows,
            float(belief_config["nominal_coverage"]),
            belief_config["age_bucket_edges"],
            int(belief_config["minimum_group_samples"]),
        )
        write_json(
            calibration_path,
            {
                "schema_version": "stage2-calibration-v1",
                "split": "calibration",
                "seed_count": len(seeds),
                "config_hash": config_hash,
                "code_hash": source_hash,
                "calibration": calibration.serializable(),
            },
        )
    assert calibration is not None

    capacity = float(config["energy"]["capacity_j"])
    for interval_root, rows, trace, interval in phase_rows:
        augment_intervals(rows, calibration, capacity)
        write_jsonl(interval_root / "belief_rows.jsonl", rows)
        voei_rows = build_voei_rows(config, trace, interval, rows)
        write_jsonl(interval_root / "voei_rows.jsonl", voei_rows)
        write_json(
            interval_root / "manifest.json",
            {
                "phase": phase,
                "seed": trace.seed,
                "report_interval": interval,
                "belief_row_count": len(rows),
                "voei_row_count": len(voei_rows),
                "trace_hash": trace.content_hash(),
                "config_hash": config_hash,
                "code_hash": source_hash,
                "calibration_hash": canonical_hash(calibration.serializable()),
                "truth_fields": "offline-only evaluator columns",
            },
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["calibration", "validation"], required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage2.yaml")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "outputs" / "stage2_belief_voei_v1",
    )
    args = parser.parse_args()
    run_phase(args.config, args.phase, args.output)


if __name__ == "__main__":
    main()
