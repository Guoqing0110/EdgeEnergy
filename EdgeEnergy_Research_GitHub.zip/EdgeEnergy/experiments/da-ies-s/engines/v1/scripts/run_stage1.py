#!/usr/bin/env python3
"""Run only the preregistered Stage 1 development seeds."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
    write_jsonl,
)
from src.simulation import run_method  # noqa: E402


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict):
        raise ValueError("configuration root must be a mapping")
    return value


def load_seeds(path: Path) -> list[int]:
    return [int(line.strip()) for line in path.read_text().splitlines() if line.strip()]


def run_stage1(config_path: Path, seed_path: Path, output_root: Path) -> None:
    config = load_config(config_path)
    if config["experiment"]["allowed_seed_split"] != "development":
        raise RuntimeError("Stage 1 configuration is not authorized for development seeds")
    registered_development = load_seeds(ROOT / "seeds" / "development.txt")
    seeds = load_seeds(seed_path)
    if seeds != registered_development:
        raise RuntimeError("Stage 1 may run only the exact registered development seed list")

    methods = list(config["scheduler"]["methods"])
    output_root.mkdir(parents=True, exist_ok=True)
    write_json(output_root / "config_snapshot.json", config)
    source_hash = code_hash(ROOT)
    config_digest = canonical_hash(config)

    for seed in seeds:
        seed_root = output_root / f"seed={seed}"
        trace = generate_trace(config, seed)
        trace_path = seed_root / "trace.npz"
        trace.save(trace_path)
        write_json(
            seed_root / "trace_manifest.json",
            {
                "schema_version": "stage1-trace-v1",
                "seed": seed,
                "trace_hash": trace.content_hash(),
                "config_hash": config_digest,
                "code_hash": source_hash,
                "policy_independent": True,
                "methods": methods,
            },
        )
        for method in methods:
            result = run_method(config, trace, method)
            method_root = seed_root / f"method={method}"
            write_jsonl(method_root / "slots.jsonl", result.records)
            summary = {
                "schema_version": "stage1-summary-v1",
                "seed": seed,
                "method": method,
                "trace_hash": result.trace_hash,
                "config_hash": config_digest,
                "code_hash": source_hash,
                "deterministic_records_hash": deterministic_records_hash(result.records),
                "runtime_seconds": result.runtime_seconds,
                **result.summary,
            }
            write_json(method_root / "summary.json", summary)
            write_json(
                method_root / "manifest.json",
                {
                    "experiment_id": config["experiment"]["id"],
                    "stage": 1,
                    "seed_split": "development",
                    "seed": seed,
                    "method": method,
                    "trace_file": str(trace_path.relative_to(output_root)),
                    "slot_log": str((method_root / "slots.jsonl").relative_to(output_root)),
                    "summary_file": str((method_root / "summary.json").relative_to(output_root)),
                    "trace_hash": result.trace_hash,
                    "config_hash": config_digest,
                    "code_hash": source_hash,
                    "online_truth_separation": "online_information_set vs offline_truth_only",
                    "status": "completed",
                },
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage1.yaml")
    parser.add_argument("--seeds", type=Path, default=ROOT / "seeds" / "development.txt")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "raw" / "stage1_minimal_v1"
    )
    args = parser.parse_args()
    run_stage1(args.config, args.seeds, args.output)


if __name__ == "__main__":
    main()
