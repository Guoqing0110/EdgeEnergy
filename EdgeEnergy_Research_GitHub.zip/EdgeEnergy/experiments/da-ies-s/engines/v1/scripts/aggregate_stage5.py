#!/usr/bin/env python3
"""Aggregate Stage 5 robustness, scalability and complexity outputs."""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


NUMERIC_METRICS = (
    "cumulative_unmet_visible_demand_j",
    "total_visible_demand_j",
    "total_served_visible_demand_j",
    "served_demand_fraction",
    "all_service_met_slot_fraction",
    "node_service_continuity_fraction",
    "reporting_sensor_debit_j",
    "average_reporting_debit_j_per_slot",
    "wet_gross_debit_j",
    "average_wet_gross_debit_j_per_slot",
    "wet_delivered_j",
    "wet_conversion_loss_j",
    "payer_reserve_violations",
    "payer_checks",
    "payer_reserve_violation_rate",
    "report_execution_shortfall_j",
    "wet_execution_shortfall_j",
    "post_belief_mae_j",
    "post_belief_rmse_j",
    "mean_energy_cv",
    "final_energy_jain",
    "final_service_queue_j",
    "final_report_queue_j",
    "final_wet_queue_j",
    "minimum_final_energy_fraction",
    "runtime_seconds",
    "process_peak_rss_bytes",
)


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"no Stage 5 rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _paired(left: dict[int, float], right: dict[int, float], rng_seed: int, count: int) -> dict:
    common = sorted(set(left) & set(right))
    if not common:
        raise RuntimeError("Stage 5 paired comparison has no shared seeds")
    difference = np.asarray([left[seed] - right[seed] for seed in common], dtype=float)
    rng = np.random.default_rng(rng_seed)
    draws = rng.integers(0, len(difference), size=(count, len(difference)))
    means = np.mean(difference[draws], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    sd = float(np.std(difference, ddof=1)) if len(difference) > 1 else 0.0
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(difference)),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "paired_effect_dz": float(np.mean(difference) / sd) if sd > 0.0 else None,
        "seed_differences": {
            str(seed): float(value) for seed, value in zip(common, difference)
        },
    }


def _mean_rows(rows: list[dict], keys: tuple[str, ...]) -> list[dict]:
    grouped: dict[tuple, list[dict]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row[key] for key in keys)].append(row)
    result: list[dict] = []
    for values, members in sorted(grouped.items()):
        item = {key: value for key, value in zip(keys, values)}
        item["runs"] = len(members)
        for metric in NUMERIC_METRICS:
            observed = np.asarray([float(row[metric]) for row in members], dtype=float)
            item[f"mean_{metric}"] = float(np.mean(observed))
            item[f"sd_{metric}"] = (
                float(np.std(observed, ddof=1)) if len(observed) > 1 else 0.0
            )
        result.append(item)
    return result


def _loglog_exponent(x: list[float], y: list[float]) -> float:
    if len(x) < 2 or any(value <= 0.0 for value in x + y):
        raise RuntimeError("invalid Stage 5 log-log scaling values")
    return float(np.polyfit(np.log(np.asarray(x)), np.log(np.asarray(y)), 1)[0])


def main() -> None:
    output = ROOT / "outputs" / "stage5_robustness_scalability_v1"
    processed = output / "processed"
    config = yaml.safe_load((ROOT / "configs" / "stage5.yaml").read_text())
    summaries = [
        json.loads(path.read_text())
        for path in sorted(
            output.glob("raw/stage5_validation/*/*/seed=*/method=*/summary.json")
        )
    ]
    _write_csv(processed / "all_method_runs.csv", summaries)

    robustness = [row for row in summaries if row["family"] == "robustness"]
    robustness_summary = _mean_rows(robustness, ("condition", "method"))
    _write_csv(processed / "robustness_condition_method_summary.csv", robustness_summary)
    lookup = {
        (str(row["condition"]), int(row["seed"]), str(row["method"])): row
        for row in robustness
    }
    proposed = str(config["stage5"]["proposed_method"])
    no_wet = "b0_no_wet_periodic_direct"
    age_direct = "b4_queue_belief_age_direct"
    bootstrap = int(config["stage5"]["bootstrap_resamples"])

    def values(condition: str, method: str, metric: str) -> dict[int, float]:
        return {
            seed: float(row[metric])
            for (cell, seed, candidate), row in lookup.items()
            if cell == condition and candidate == method
        }

    contrasts: dict[str, dict] = {}
    for index, condition in enumerate(config["robustness"]["conditions"]):
        contrasts[condition] = {
            "b7_minus_b0_unmet": _paired(
                values(condition, proposed, "cumulative_unmet_visible_demand_j"),
                values(condition, no_wet, "cumulative_unmet_visible_demand_j"),
                20260810 + index * 10,
                bootstrap,
            ),
            "b7_minus_b0_continuity": _paired(
                values(condition, proposed, "all_service_met_slot_fraction"),
                values(condition, no_wet, "all_service_met_slot_fraction"),
                20260811 + index * 10,
                bootstrap,
            ),
            "b7_minus_b4_reporting": _paired(
                values(condition, proposed, "average_reporting_debit_j_per_slot"),
                values(condition, age_direct, "average_reporting_debit_j_per_slot"),
                20260812 + index * 10,
                bootstrap,
            ),
            "b7_minus_b4_continuity": _paired(
                values(condition, proposed, "all_service_met_slot_fraction"),
                values(condition, age_direct, "all_service_met_slot_fraction"),
                20260813 + index * 10,
                bootstrap,
            ),
            "b7_payer_reserve_violation_rate_mean": float(
                np.mean(
                    list(values(condition, proposed, "payer_reserve_violation_rate").values())
                )
            ),
        }
    write_json(processed / "robustness_paired_comparisons.json", contrasts)

    scalability = [row for row in summaries if row["family"] == "scalability"]
    scalability_summary = _mean_rows(scalability, ("node_count", "method"))
    _write_csv(processed / "scalability_node_method_summary.csv", scalability_summary)
    scaling: dict[str, dict] = {}
    for method in config["stage5"]["scalability_methods"]:
        rows = sorted(
            [row for row in scalability_summary if row["method"] == method],
            key=lambda row: int(row["node_count"]),
        )
        nodes = [float(row["node_count"]) for row in rows]
        runtimes = [float(row["mean_runtime_seconds"]) for row in rows]
        memories = [float(row["mean_process_peak_rss_bytes"]) for row in rows]
        scaling[method] = {
            "node_counts": [int(value) for value in nodes],
            "mean_runtime_seconds": runtimes,
            "mean_process_peak_rss_bytes": memories,
            "runtime_loglog_exponent": _loglog_exponent(nodes, runtimes),
            "process_peak_rss_loglog_exponent": _loglog_exponent(nodes, memories),
            "memory_scope": "resource.getrusage process peak RSS; includes Python/native",
        }
    write_json(processed / "scalability_exponents.json", scaling)

    complexity = [row for row in summaries if row["family"] == "complexity"]
    complexity_summary = _mean_rows(
        complexity,
        ("condition", "belief_samples", "receiver_candidate_count", "method"),
    )
    _write_csv(processed / "complexity_condition_summary.csv", complexity_summary)


if __name__ == "__main__":
    main()
