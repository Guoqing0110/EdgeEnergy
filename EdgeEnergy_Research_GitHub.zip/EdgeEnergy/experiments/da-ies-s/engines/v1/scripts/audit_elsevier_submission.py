#!/usr/bin/env python3
"""Audit the Elsevier 5p paper against frozen evidence and source figures."""

from __future__ import annotations

import csv
import json
import re
import subprocess
from hashlib import sha256
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper" / "ad_hoc_networks_elsarticle_5p"
OUT = ROOT / "outputs" / "stage8_elsevier_5p"


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def check_manifest_inputs(manifest_path: Path) -> list[dict]:
    manifest = read_json(manifest_path)
    rows: list[dict] = []
    for declared, expected in manifest.get("inputs", {}).items():
        candidate = ROOT / declared
        if not candidate.exists():
            stage_candidate = ROOT / "outputs" / manifest_path.parent.name / "processed" / Path(declared).name
            if stage_candidate.exists():
                candidate = stage_candidate
        actual = digest(candidate) if candidate.exists() else None
        rows.append(
            {
                "manifest": str(manifest_path.relative_to(ROOT)),
                "input": str(candidate.relative_to(ROOT)) if candidate.exists() else declared,
                "expected_sha256": expected,
                "actual_sha256": actual,
                "match": actual == expected,
            }
        )
    return rows


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    tex_path = PAPER / "manuscript.tex"
    pdf_path = PAPER / "manuscript.pdf"
    log_path = PAPER / "manuscript.log"
    tex = tex_path.read_text(encoding="utf-8")
    log = log_path.read_text(encoding="utf-8", errors="replace")

    figure_map = {
        "figures/Figure_experimental_topology.pdf": "outputs/figures/stage8_elsevier_5p/Figure_experimental_topology.pdf",
        "figures/Figure_3_belief_rmse.pdf": "outputs/figures/stage2_belief_voei_v2_1/fig_a_v21_belief_rmse.pdf",
        "figures/Figure_4_voei_ranking.pdf": "outputs/figures/stage2_belief_voei_v2_1/fig_b_v21_voei_ranking.pdf",
        "figures/Figure_5a_selective_efficiency.pdf": "outputs/figures/stage3_selective_eetor_v1_1/fig_a_selective_efficiency_vs_path.pdf",
        "figures/Figure_5_reporting_crossover.pdf": "outputs/figures/stage3_selective_eetor_v1_1/fig_d_independent_collect_crossover_heatmap.pdf",
        "figures/Figure_6_long_horizon_tradeoff.pdf": "outputs/figures/stage4_long_horizon_v1/fig_c_reporting_continuity_tradeoff.pdf",
        "figures/Figure_7_heldout_service.pdf": "outputs/figures/stage6_da_ies_s_v1/stage6_held_out_service_effects.pdf",
        "figures/Figure_8_safety_reporting.pdf": "outputs/figures/stage6_da_ies_s_v1/stage6_safety_reporting.pdf",
        "figures/Figure_9_replication.pdf": "outputs/figures/stage6_da_ies_s_v1/stage6_validation_held_out_replication.pdf",
        "figures/Figure_10_scalability_runtime.pdf": "outputs/figures/stage5_robustness_scalability_v1/stage5_scalability_runtime.pdf",
        "figures/Figure_11_voei_compute.pdf": "outputs/figures/stage5_robustness_scalability_v1/stage5_full_voei_complexity.pdf",
    }
    provenance_rows = []
    for paper_rel, source_rel in figure_map.items():
        paper_file = PAPER / paper_rel
        source_file = ROOT / source_rel
        paper_hash = digest(paper_file) if paper_file.exists() else None
        source_hash = digest(source_file) if source_file.exists() else None
        provenance_rows.append(
            {
                "paper_figure": paper_rel,
                "source_figure": source_rel,
                "paper_sha256": paper_hash,
                "source_sha256": source_hash,
                "byte_identical": paper_hash == source_hash and paper_hash is not None,
            }
        )

    manifest_paths = [
        ROOT / "outputs/figures/stage2_belief_voei_v2_1/manifest.json",
        ROOT / "outputs/figures/stage3_selective_eetor_v1_1/manifest.json",
        ROOT / "outputs/figures/stage4_long_horizon_v1/figure_manifest.json",
        ROOT / "outputs/figures/stage5_robustness_scalability_v1/manifest.json",
        ROOT / "outputs/figures/stage6_da_ies_s_v1/manifest.json",
    ]
    manifest_rows = [row for path in manifest_paths for row in check_manifest_inputs(path)]

    stage2 = read_json(ROOT / "outputs/stage2_belief_voei_v2_1/stage2_v2_1_gate_audit.json")
    stage3 = read_json(ROOT / "outputs/stage3_selective_eetor_v1_1/stage3_gate_audit.json")
    stage6 = read_json(ROOT / "outputs/stage6_held_out_v1/stage6_gate_audit.json")

    pdf_info = subprocess.run(
        ["pdfinfo", str(pdf_path)], check=True, capture_output=True, text=True
    ).stdout
    pages_match = re.search(r"^Pages:\s+(\d+)$", pdf_info, flags=re.MULTILINE)
    pages = int(pages_match.group(1)) if pages_match else 0

    abstract_match = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", tex, flags=re.S)
    abstract_plain = re.sub(r"\\[A-Za-z]+\*?(?:\{[^{}]*\})?", " ", abstract_match.group(1)) if abstract_match else ""
    abstract_words = re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*", abstract_plain)

    values = {
        "stage2_rmse": stage2["belief_uncertainty_minus_last_value_rmse"]["mean_difference_left_minus_right"],
        "stage2_coverage": stage2["validation_uncertainty_coverage"],
        "stage3_selective_efficiency": stage3["primary_region_comparisons"]["constrained_full_minus_collect_efficiency"]["mean_difference_left_minus_right"],
        "stage3_independent_value": stage3["primary_region_comparisons"]["stressed_independent_minus_collect_raw_value"]["mean_difference_left_minus_right"],
        "stage6_unmet": stage6["pooled_comparisons"]["cumulative_unmet_visible_demand_j"]["mean_difference_proposed_minus_baseline"],
        "stage6_continuity": stage6["pooled_comparisons"]["all_service_met_slot_fraction"]["mean_difference_proposed_minus_baseline"],
        "stage6_reporting": stage6["pooled_comparisons"]["average_reporting_debit_j_per_slot"]["mean_difference_proposed_minus_baseline"],
    }
    claimed_strings = {
        "stage2_rmse": "899.39",
        "stage2_coverage": "0.9385",
        "stage3_selective_efficiency": "2082.83",
        "stage3_independent_value": "36.43",
        "stage6_unmet": "2988.75",
        "stage6_continuity": "0.02570",
        "stage6_reporting": "0.000559",
    }

    included_graphics = re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", tex)
    included_tikz = re.findall(r"\\input\{(figures/[^}]+\.tikz)\}", tex)
    all_includes_exist = all((PAPER / name).exists() for name in included_graphics + included_tikz)
    checks = {
        "official_elsarticle_5p_twocolumn": tex.startswith("\\documentclass[final,5p,times,twocolumn]{elsarticle}"),
        "elsevier_numbered_bibliography": "\\bibliographystyle{elsarticle-num}" in tex,
        "pdf_exists": pdf_path.exists(),
        "pdf_pages_at_least_14": pages >= 14,
        "abstract_within_250_words": len(abstract_words) <= 250,
        "all_included_figures_exist": all_includes_exist,
        "data_figures_byte_identical_to_frozen_outputs": all(row["byte_identical"] for row in provenance_rows),
        "all_figure_manifest_inputs_match": all(row["match"] for row in manifest_rows),
        "stage2_gate_pass": stage2.get("status") == "pass" and all(stage2["checks"].values()),
        "stage3_v1_1_gate_pass": stage3.get("status") == "pass" and all(stage3["checks"].values()),
        "stage6_gate_pass": stage6.get("status") == "pass" and all(stage6["checks"].values()),
        "critical_claim_values_present": all(text in tex for text in claimed_strings.values()),
        "formal_algorithm_present": "\\begin{algorithm*}" in tex and "\\arg\\min" in tex,
        "architecture_and_flow_sources_present": all((PAPER / name).exists() for name in included_tikz),
        "no_overfull_boxes": "Overfull \\hbox" not in log and "Overfull \\vbox" not in log,
        "no_undefined_references": "undefined references" not in log.lower(),
        "no_undefined_citations": "undefined citations" not in log.lower(),
        "no_missing_files": "not found" not in log.lower(),
    }

    with (OUT / "figure_copy_provenance.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=provenance_rows[0].keys())
        writer.writeheader()
        writer.writerows(provenance_rows)
    with (OUT / "figure_manifest_input_audit.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=manifest_rows[0].keys())
        writer.writeheader()
        writer.writerows(manifest_rows)

    audit = {
        "schema_version": "elsevier-5p-submission-audit-v2",
        "paper": {
            "path": str(pdf_path.relative_to(ROOT)),
            "pages": pages,
            "abstract_words": len(abstract_words),
            "figure_floats": len(re.findall(r"\\begin\{figure\*?\}", tex)),
            "result_figure_files": len(figure_map),
            "table_floats": len(re.findall(r"\\begin\{table\*?\}", tex)),
            "algorithm_floats": len(re.findall(r"\\begin\{algorithm\*?\}", tex)),
            "sha256": digest(pdf_path),
        },
        "evidence_values": values,
        "checks": checks,
        "passed": all(checks.values()),
    }
    (OUT / "elsevier_5p_submission_audit.json").write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(audit, indent=2, sort_keys=True))
    return 0 if audit["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
