#!/usr/bin/env python3
"""Aggregate frozen DA-IES-S versus B4 validation evidence."""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


BASELINE = "b4_queue_belief_age_direct"
PROPOSED = "p_da_ies_s"
METRICS = (
    "cumulative_unmet_visible_demand_j",
    "all_service_met_slot_fraction",
    "node_service_continuity_fraction",
    "average_reporting_debit_j_per_slot",
    "average_wet_gross_debit_j_per_slot",
    "payer_reserve_violation_rate",
    "payer_reserve_violation_depth_j",
    "maximum_payer_reserve_violation_depth_j",
    "safe_fallback_slot_fraction",
    "post_belief_rmse_j",
    "mean_energy_cv",
    "final_energy_jain",
    "runtime_seconds",
)


def paired(left: dict[int, float], right: dict[int, float], seed: int, draws: int) -> dict:
    common = sorted(set(left) & set(right))
    difference = np.asarray([left[item] - right[item] for item in common], dtype=float)
    if not len(difference):
        raise RuntimeError("empty paired comparison")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(difference), size=(draws, len(difference)))
    means = np.mean(difference[indices], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return {
        "paired_seeds": len(common),
        "mean_difference_proposed_minus_baseline": float(np.mean(difference)),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "seed_differences": {
            str(item): float(value) for item, value in zip(common, difference)
        },
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    output = ROOT / "outputs" / "stage5_1_da_ies_s_v1"
    processed = output / "processed"
    config = yaml.safe_load((ROOT / "configs" / "stage5_1.yaml").read_text())
    rows = [
        json.loads(path.read_text())
        for path in sorted(
            output.glob("raw/da_ies_s_validation/grid=*/condition=*/seed=*/method=*/summary.json")
        )
    ]
    write_csv(processed / "all_validation_runs.csv", rows)
    expected = (
        int(config["stage5_1"]["validation_seed_count"])
        * len(config["stage5_1"]["validation_conditions"])
        * 2
    )
    if len(rows) != expected:
        raise RuntimeError(f"expected {expected} validation summaries, observed {len(rows)}")
    lookup = {
        (str(row["condition"]), int(row["seed"]), str(row["method"])): row
        for row in rows
    }
    draws = int(config["stage5_1"]["bootstrap_resamples"])
    cells = {}
    summary_rows = []
    for index, condition in enumerate(config["stage5_1"]["validation_conditions"]):
        cell = {}
        for metric_index, metric in enumerate(METRICS):
            proposed = {
                seed: float(row[metric])
                for (name, seed, method), row in lookup.items()
                if name == condition and method == PROPOSED
            }
            baseline = {
                seed: float(row[metric])
                for (name, seed, method), row in lookup.items()
                if name == condition and method == BASELINE
            }
            cell[metric] = paired(
                proposed, baseline, 20260731 + index * 100 + metric_index, draws
            )
        proposed_rows = [
            row for row in rows if row["condition"] == condition and row["method"] == PROPOSED
        ]
        violations = sum(int(row["payer_reserve_violations"]) for row in proposed_rows)
        checks = sum(int(row["payer_checks"]) for row in proposed_rows)
        cell["proposed_pooled_payer_reserve_violation_rate"] = (
            violations / checks if checks else 0.0
        )
        cells[condition] = cell
        for method in (BASELINE, PROPOSED):
            members = [
                row for row in rows if row["condition"] == condition and row["method"] == method
            ]
            item = {"condition": condition, "method": method, "runs": len(members)}
            for metric in METRICS:
                values = np.asarray([float(row[metric]) for row in members], dtype=float)
                item[f"mean_{metric}"] = float(np.mean(values))
                item[f"sd_{metric}"] = float(np.std(values, ddof=1))
            summary_rows.append(item)
    write_json(processed / "cell_paired_comparisons.json", cells)
    write_csv(processed / "condition_method_summary.csv", summary_rows)

    pooled_by_seed: dict[int, dict[str, dict[str, list[float]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    for row in rows:
        for metric in METRICS:
            pooled_by_seed[int(row["seed"])][str(row["method"])][metric].append(
                float(row[metric])
            )
    pooled = {}
    for metric_index, metric in enumerate(METRICS):
        proposed = {
            seed: float(np.mean(values[PROPOSED][metric]))
            for seed, values in pooled_by_seed.items()
        }
        baseline = {
            seed: float(np.mean(values[BASELINE][metric]))
            for seed, values in pooled_by_seed.items()
        }
        pooled[metric] = paired(
            proposed, baseline, 20260901 + metric_index, draws
        )
    write_json(processed / "pooled_paired_comparisons.json", pooled)


if __name__ == "__main__":
    main()
