#!/usr/bin/env python3
"""Apply the immutable Stage 2 v2 gate and authorize or block Stage 3."""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def seed_average(
    rows: list[dict], split: str, method: str, metric: str, scope: str | None = None
) -> dict[int, float]:
    values: dict[int, list[float]] = defaultdict(list)
    for row in rows:
        if row["split"] != split or row["method"] != method:
            continue
        if scope is not None and row.get("scope") != scope:
            continue
        value = float(row[metric])
        if math.isfinite(value):
            values[int(row["seed"])].append(value)
    return {seed: float(np.mean(items)) for seed, items in values.items() if items}


def paired_stats(left: dict[int, float], right: dict[int, float], seed: int) -> dict:
    common = sorted(set(left) & set(right))
    difference = np.asarray([left[item] - right[item] for item in common], dtype=float)
    rng = np.random.default_rng(seed)
    if difference.size:
        draws = rng.integers(0, difference.size, size=(20000, difference.size))
        means = np.mean(difference[draws], axis=1)
        low, high = np.quantile(means, [0.025, 0.975])
        sd = float(np.std(difference, ddof=1)) if difference.size > 1 else float("nan")
        dz = float(np.mean(difference) / sd) if sd > 0.0 else float("nan")
    else:
        low = high = dz = float("nan")
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(difference))
        if difference.size
        else float("nan"),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "paired_effect_dz": dz,
    }


def main() -> None:
    config = yaml.safe_load((ROOT / "configs" / "stage2_v2.yaml").read_text())
    root = ROOT / "outputs" / "stage2_belief_voei_v2"
    belief = read_csv(root / "processed" / "belief_per_seed.csv")
    voei = read_csv(root / "processed" / "voei_per_seed.csv")
    manifests = list(
        root.glob("raw/*/*/seed=*/report_interval=*/manifest.json")
    )
    manifest_values = [json.loads(path.read_text()) for path in manifests]
    expected = {
        phase: {int(x) for x in (ROOT / "seeds" / f"{phase}.txt").read_text().split()}
        for phase in ("calibration_v2", "validation_v2")
    }
    observed = {
        phase: {int(item["seed"]) for item in manifest_values if item["phase"] == phase}
        for phase in expected
    }
    held_out = {int(x) for x in (ROOT / "seeds" / "test_held_out.txt").read_text().split()}
    old_validation = {int(x) for x in (ROOT / "seeds" / "validation.txt").read_text().split()}
    observed_all = set().union(*observed.values())
    test_log_path = ROOT / "outputs" / "logs" / "stage1_unit_tests.json"
    test_log = json.loads(test_log_path.read_text()) if test_log_path.exists() else {}

    validation_unc = [
        row
        for row in belief
        if row["split"] == "validation_v2" and row["method"] == "uncertainty_twin"
    ]
    coverage = float(np.mean([float(row["coverage"]) for row in validation_unc]))
    coverage_error = abs(coverage - float(config["belief"]["nominal_coverage"]))
    width = float(np.mean([float(row["mean_interval_width_j"]) for row in validation_unc]))
    overestimate = float(np.mean([float(row["overestimation_rate"]) for row in validation_unc]))

    validation_full_all = [
        row
        for row in voei
        if row["split"] == "validation_v2"
        and row["method"] == "full_voei"
        and row["scope"] == "all"
    ]
    opportunity_fraction = float(
        np.mean([float(row["opportunity_fraction"]) for row in validation_full_all])
    )
    validation_full_opp = [
        row
        for row in voei
        if row["split"] == "validation_v2"
        and row["method"] == "full_voei"
        and row["scope"] == "opportunity"
    ]
    pooled_evaluable = float(
        np.nanmean([float(row["ndcg_evaluable_slot_fraction"]) for row in validation_full_opp])
    )
    boundary_evaluable = float(
        np.nanmean(
            [
                float(row["ndcg_evaluable_slot_fraction"])
                for row in validation_full_opp
                if row["scenario"] == "decision_boundary"
            ]
        )
    )

    comparisons: dict[str, dict] = {}
    for split in ("calibration_v2", "validation_v2"):
        for metric in ("spearman", "ndcg_at_k"):
            full = seed_average(voei, split, "full_voei", metric, "opportunity")
            for baseline in ("age", "uncertainty"):
                base = seed_average(voei, split, baseline, metric, "opportunity")
                key = f"{split}_{metric}_full_minus_{baseline}"
                comparisons[key] = paired_stats(full, base, 20260719 + len(comparisons))

    direction_positive = all(
        item["mean_difference_left_minus_right"] > 0.0
        and item["paired_seeds"] == 15
        for item in comparisons.values()
    )
    validation_spearman_ci_positive = all(
        item["paired_bootstrap_95_ci"][0] > 0.0
        for key, item in comparisons.items()
        if key.startswith("validation_v2_spearman")
    )
    gate = config["gate"]
    checks = {
        "calibration_v2_seed_registry_exact": observed["calibration_v2"] == expected["calibration_v2"],
        "validation_v2_seed_registry_exact": observed["validation_v2"] == expected["validation_v2"],
        "no_old_validation_or_held_out_seed": observed_all.isdisjoint(held_out | old_validation),
        "expected_manifest_count": len(manifests) == 2 * 2 * 15 * 3,
        "unit_and_no_leakage_tests": test_log.get("successful") is True
        and test_log.get("tests_run", 0) >= 21,
        "interval_coverage_error_at_most_0_05": coverage_error <= 0.05,
        "opportunity_fraction_within_bounds": float(
            gate["minimum_validation_opportunity_fraction"]
        )
        <= opportunity_fraction
        <= float(gate["maximum_validation_opportunity_fraction"]),
        "decision_boundary_evaluable_opportunities": boundary_evaluable
        >= float(gate["minimum_boundary_evaluable_opportunity_fraction"]),
        "pooled_evaluable_opportunities": pooled_evaluable
        >= float(gate["minimum_pooled_evaluable_opportunity_fraction"]),
        "full_voei_direction_positive": direction_positive,
        "validation_spearman_ci_lower_positive": validation_spearman_ci_positive,
    }
    result = {
        "stage": "2-v2",
        "status": "pass" if all(checks.values()) else "fail",
        "stage3_authorized": bool(all(checks.values())),
        "checks": checks,
        "validation_uncertainty_coverage": coverage,
        "validation_uncertainty_coverage_error": coverage_error,
        "validation_uncertainty_mean_width_j": width,
        "validation_uncertainty_overestimation_rate": overestimate,
        "validation_opportunity_fraction": opportunity_fraction,
        "validation_pooled_evaluable_opportunity_fraction": pooled_evaluable,
        "validation_boundary_evaluable_opportunity_fraction": boundary_evaluable,
        "opportunity_paired_diagnostics": comparisons,
        "held_out_test_used": False,
        "parent_v1_failure_retained": True,
    }
    write_json(root / "stage2_v2_gate_audit.json", result)
    if not all(checks.values()):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
