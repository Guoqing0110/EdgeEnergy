#!/usr/bin/env python3
"""Build the Stage 8 manifest, paper source ZIP, and full data archive."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper" / "ad_hoc_networks_elsarticle_5p"
RELEASE = ROOT / "outputs" / "stage8_submission"
FINAL_PDF_DIR = ROOT / "output" / "pdf"
RELEASE_ID = "R2_20260719"
FINAL_PDF = FINAL_PDF_DIR / f"DA_IES_S_AdHocNetworks_{RELEASE_ID}.pdf"
SOURCE_ZIP = ROOT / "output" / f"DA_IES_S_AdHocNetworks_{RELEASE_ID}_LaTeX_Source.zip"
FULL_ARCHIVE = ROOT.parent / f"decision_aware_information_energy_{RELEASE_ID}_full_reproducibility.tar.gz"
MANIFEST = RELEASE / "full_file_manifest.csv"
AUDIT = RELEASE / "stage8_release_audit.json"

LEGACY_RELEASE_ARTIFACTS = {
    ROOT / "output" / "DA_IES_S_AdHocNetworks_Elsevier_5p_LaTeX_Source.zip",
    ROOT / "output" / "pdf" / "DA_IES_S_AdHocNetworks_Elsevier_5p_Submission.pdf",
}

EXCLUDED_PARTS = {
    "__pycache__",
    ".venv",
    ".pytest_cache",
    ".mypy_cache",
    "tmp",
}
EXCLUDED_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".tmp",
    ".aux",
    ".log",
    ".fls",
    ".fdb_latexmk",
    ".out",
    ".blg",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def included_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        if path.suffix in EXCLUDED_SUFFIXES:
            continue
        if path in {MANIFEST, AUDIT} or path in LEGACY_RELEASE_ARTIFACTS:
            continue
        if path.name == "full_archive_checksum.json":
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.as_posix())


def abstract_word_count() -> int:
    text = (PAPER / "manuscript.tex").read_text(encoding="utf-8")
    body = text.split("\\begin{abstract}", 1)[1].split("\\end{abstract}", 1)[0]
    import re

    plain = re.sub(r"\\[A-Za-z]+\*?(?:\{[^{}]*\})?", " ", body)
    return len(re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*", plain))


def pdf_pages() -> int:
    output = subprocess.check_output(["pdfinfo", str(FINAL_PDF)], text=True)
    for line in output.splitlines():
        if line.startswith("Pages:"):
            return int(line.split(":", 1)[1].strip())
    raise RuntimeError("pdfinfo did not report a page count")


def audit_checks() -> dict[str, bool]:
    stage5 = json.loads(
        (ROOT / "outputs/stage5_1_da_ies_s_v1/stage5_1_gate_audit.json").read_text()
    )
    stage6 = json.loads(
        (ROOT / "outputs/stage6_held_out_v1/stage6_gate_audit.json").read_text()
    )
    tests = json.loads((ROOT / "outputs/logs/stage1_unit_tests.json").read_text())
    tex = (PAPER / "manuscript.tex").read_text(encoding="utf-8")
    keyword_text = tex.split("\\begin{keyword}", 1)[1].split("\\end{keyword}", 1)[0]
    keyword_count = len([item for item in keyword_text.split("\\sep") if item.strip()])
    highlights = (PAPER / "Highlights.txt").read_text(encoding="utf-8").splitlines()
    highlights = [line for line in highlights if line.strip()]
    latex_log = (PAPER / "manuscript.log").read_text(encoding="utf-8")
    stage5_checks = stage5.get("checks", {})
    stage6_checks = stage6.get("checks", {})
    return {
        "all_57_tests_pass": tests.get("successful") is True and tests.get("tests_run") == 57,
        "stage5_1_all_checks_pass": bool(stage5_checks) and all(stage5_checks.values()),
        "stage6_all_checks_pass": bool(stage6_checks) and all(stage6_checks.values()),
        "manuscript_pdf_exists": FINAL_PDF.is_file(),
        "manuscript_is_official_5p_twocolumn": tex.startswith(
            "\\documentclass[final,5p,times,twocolumn]{elsarticle}"
        ),
        "manuscript_is_substantive_length": 14 <= pdf_pages() <= 22,
        "abstract_within_250_words": abstract_word_count() <= 250,
        "keyword_count_within_1_to_7": 1 <= keyword_count <= 7,
        "highlight_count_within_3_to_5": 3 <= len(highlights) <= 5,
        "highlight_lengths_within_85_characters": all(len(line) <= 85 for line in highlights),
        "latex_no_unresolved_references": "undefined references" not in latex_log,
        "latex_no_unresolved_citations": "undefined citations" not in latex_log,
        "latex_no_overfull_boxes": "Overfull \\hbox" not in latex_log,
        "elsevier_evidence_audit_pass": json.loads(
            (ROOT / "outputs/stage8_elsevier_5p/elsevier_5p_submission_audit.json").read_text()
        ).get("passed") is True,
        "user_guide_present": (ROOT / "USER_GUIDE.md").is_file(),
        "raw_data_present": any((ROOT / "outputs").rglob("*.jsonl")),
        "all_required_code_dirs_present": all(
            (ROOT / name).is_dir()
            for name in ("src", "scripts", "postprocessing", "tests", "configs", "seeds")
        ),
    }


def build_source_zip() -> None:
    names = [
        "manuscript.tex",
        "references.bib",
        "manuscript.bbl",
        "elsarticle.cls",
        "elsarticle-num.bst",
        "algorithm2e.sty",
        "Highlights.txt",
        "Cover_Letter.md",
        "Submission_Checklist.md",
        "Graphical_Abstract.pdf",
        "Graphical_Abstract.png",
    ]
    SOURCE_ZIP.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(SOURCE_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in names:
            archive.write(PAPER / name, arcname=name)
        for path in sorted((PAPER / "figures").iterdir()):
            if path.is_file():
                archive.write(path, arcname=f"figures/{path.name}")
        archive.write(ROOT / "RELEASE_VERSION.json", arcname="RELEASE_VERSION.json")
        archive.write(
            ROOT / "REVISION_RESPONSE_9_POINTS.md",
            arcname="REVISION_RESPONSE_9_POINTS.md",
        )


def write_manifest() -> tuple[int, int]:
    files = included_files()
    total_bytes = 0
    with MANIFEST.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["relative_path", "size_bytes", "sha256"]
        )
        writer.writeheader()
        for path in files:
            size = path.stat().st_size
            total_bytes += size
            writer.writerow(
                {
                    "relative_path": path.relative_to(ROOT).as_posix(),
                    "size_bytes": size,
                    "sha256": sha256_file(path),
                }
            )
    return len(files), total_bytes


def build_full_archive() -> None:
    if FULL_ARCHIVE.exists():
        FULL_ARCHIVE.unlink()
    command = [
        "tar",
        "-czf",
        str(FULL_ARCHIVE),
        "--exclude=__pycache__",
        "--exclude=.venv",
        "--exclude=.pytest_cache",
        "--exclude=.mypy_cache",
        "--exclude=tmp",
        "--exclude=*.pyc",
        "--exclude=*.pyo",
        "--exclude=*.tmp",
        "--exclude=*.aux",
        "--exclude=*.log",
        "--exclude=*.fls",
        "--exclude=*.fdb_latexmk",
        "--exclude=*.out",
        "--exclude=*.blg",
        "--exclude=full_archive_checksum.json",
        "--exclude=decision_aware_information_energy/output/DA_IES_S_AdHocNetworks_Elsevier_5p_LaTeX_Source.zip",
        "--exclude=decision_aware_information_energy/output/pdf/DA_IES_S_AdHocNetworks_Elsevier_5p_Submission.pdf",
        ROOT.name,
    ]
    subprocess.run(command, cwd=ROOT.parent, check=True)


def main() -> int:
    RELEASE.mkdir(parents=True, exist_ok=True)
    FINAL_PDF_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(PAPER / "manuscript.pdf", FINAL_PDF)
    build_source_zip()
    file_count, total_bytes = write_manifest()
    checks = audit_checks()
    tex = (PAPER / "manuscript.tex").read_text(encoding="utf-8")
    import re

    figure_count = len(re.findall(r"\\begin\{figure\*?\}", tex))
    table_count = len(re.findall(r"\\begin\{table\*?\}", tex))
    algorithm_count = len(re.findall(r"\\begin\{algorithm\*?\}", tex))
    audit = {
        "schema_version": "1.0",
        "release_id": "DA-IES-S-AdHocNetworks-R2-20260719",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "paper": {
            "title": "Risk-Calibrated Decision-Aware Information and Energy Co-Scheduling under Partial Observability in Energy-Cooperative Sensor Networks",
            "pdf": FINAL_PDF.relative_to(ROOT).as_posix(),
            "pages": pdf_pages(),
            "abstract_word_count": abstract_word_count(),
            "figures_in_tex": figure_count,
            "editable_tables": table_count,
            "formal_algorithms": algorithm_count,
        },
        "manifest": {
            "path": MANIFEST.relative_to(ROOT).as_posix(),
            "listed_files": file_count,
            "listed_bytes": total_bytes,
            "note": "The manifest excludes itself and stage8_release_audit.json.",
        },
        "paper_source_zip": {
            "path": SOURCE_ZIP.relative_to(ROOT).as_posix(),
            "size_bytes": SOURCE_ZIP.stat().st_size,
            "sha256": sha256_file(SOURCE_ZIP),
        },
        "checks": checks,
        "stage8_passed": all(checks.values()),
    }
    AUDIT.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not audit["stage8_passed"]:
        print(json.dumps(audit, indent=2))
        return 2

    build_full_archive()
    archive_hash = sha256_file(FULL_ARCHIVE)
    archive_record = {
        "archive_path": str(FULL_ARCHIVE),
        "size_bytes": FULL_ARCHIVE.stat().st_size,
        "sha256": archive_hash,
    }
    (RELEASE / "full_archive_checksum.json").write_text(
        json.dumps(archive_record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({**audit, "full_archive": archive_record}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
