#!/usr/bin/env python3
"""Evaluate Stage 2 gates without authorizing held-out performance claims."""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


def _read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _seed_average(rows: list[dict], split: str, method: str, metric: str) -> dict[int, float]:
    values: dict[int, list[float]] = defaultdict(list)
    for row in rows:
        if row["split"] == split and row["method"] == method:
            value = float(row[metric])
            if math.isfinite(value):
                values[int(row["seed"])].append(value)
    return {seed: float(np.mean(items)) for seed, items in values.items() if items}


def _paired_stats(left: dict[int, float], right: dict[int, float], seed: int) -> dict:
    common = sorted(set(left) & set(right))
    differences = np.asarray([left[item] - right[item] for item in common], dtype=float)
    rng = np.random.default_rng(seed)
    if differences.size:
        indices = rng.integers(0, differences.size, size=(20000, differences.size))
        bootstrap = np.mean(differences[indices], axis=1)
        ci = np.quantile(bootstrap, [0.025, 0.975])
        sd = float(np.std(differences, ddof=1)) if differences.size > 1 else float("nan")
        effect = float(np.mean(differences) / sd) if sd > 0 else float("nan")
    else:
        ci = [float("nan"), float("nan")]
        effect = float("nan")
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(differences)) if differences.size else float("nan"),
        "paired_bootstrap_95_ci": [float(ci[0]), float(ci[1])],
        "paired_effect_dz": effect,
    }


def main() -> None:
    root = ROOT / "outputs" / "stage2_belief_voei_v1"
    belief_rows = _read_csv(root / "processed" / "belief_per_seed.csv")
    voei_rows = _read_csv(root / "processed" / "voei_per_seed.csv")
    validation_unc = _seed_average(belief_rows, "validation", "uncertainty_twin", "rmse_j")
    validation_last = _seed_average(belief_rows, "validation", "last_value", "rmse_j")
    rmse_stats = _paired_stats(validation_unc, validation_last, 20260718)
    validation_coverage = [
        float(row["coverage"])
        for row in belief_rows
        if row["split"] == "validation" and row["method"] == "uncertainty_twin"
    ]
    coverage = float(np.mean(validation_coverage))
    coverage_error = abs(coverage - 0.95)

    comparisons = {}
    for split in ("calibration", "validation"):
        for metric in ("spearman", "ndcg_at_k"):
            full = _seed_average(voei_rows, split, "full_voei", metric)
            for baseline in ("age", "uncertainty"):
                base = _seed_average(voei_rows, split, baseline, metric)
                comparisons[f"{split}_{metric}_full_minus_{baseline}"] = _paired_stats(
                    full, base, 20260718 + len(comparisons)
                )

    manifests = list(root.glob("raw/*/seed=*/report_interval=*/manifest.json"))
    manifest_values = [json.loads(path.read_text()) for path in manifests]
    observed_seeds = {int(item["seed"]) for item in manifest_values}
    held_out = {int(x) for x in (ROOT / "seeds" / "test_held_out.txt").read_text().split()}
    expected = {
        "calibration": {int(x) for x in (ROOT / "seeds" / "calibration.txt").read_text().split()},
        "validation": {int(x) for x in (ROOT / "seeds" / "validation.txt").read_text().split()},
    }
    observed_by_phase = {
        phase: {int(item["seed"]) for item in manifest_values if item["phase"] == phase}
        for phase in expected
    }
    ndcg_evaluable = [
        float(row["ndcg_evaluable_slot_fraction"])
        for row in voei_rows
        if row["split"] == "validation" and row["method"] == "full_voei"
    ]
    directional = all(
        value["mean_difference_left_minus_right"] > 0.0
        for key, value in comparisons.items()
        if "full_minus" in key
    )
    checks = {
        "calibration_seed_registry_exact": observed_by_phase["calibration"] == expected["calibration"],
        "validation_seed_registry_exact": observed_by_phase["validation"] == expected["validation"],
        "held_out_not_seen": observed_seeds.isdisjoint(held_out),
        "expected_manifest_count": len(manifests) == 20 * 4,
        "belief_rmse_direction": rmse_stats["mean_difference_left_minus_right"] < 0.0,
        "interval_coverage_error_at_most_0_05": coverage_error <= 0.05,
        "voei_direction_positive_calibration_and_validation": directional,
        "voei_labels_evaluable": float(np.mean(ndcg_evaluable)) >= 0.50,
    }
    write_json(
        root / "stage2_gate_audit.json",
        {
            "stage": 2,
            "status": "pass" if all(checks.values()) else "fail",
            "checks": checks,
            "validation_uncertainty_vs_last_value_rmse": rmse_stats,
            "validation_uncertainty_coverage": coverage,
            "validation_uncertainty_coverage_error": coverage_error,
            "voei_paired_diagnostics": comparisons,
            "mean_validation_ndcg_evaluable_slot_fraction": float(np.mean(ndcg_evaluable)),
            "held_out_test_used": False,
            "interpretation": "Developmental calibration/validation gate; not a held-out paper claim.",
        },
    )
    if not all(checks.values()):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
