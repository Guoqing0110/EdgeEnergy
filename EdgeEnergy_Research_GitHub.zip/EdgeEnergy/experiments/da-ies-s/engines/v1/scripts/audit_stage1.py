#!/usr/bin/env python3
"""Audit completeness, pairing, conservation, and seed-boundary compliance."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _seeds(path: Path) -> set[int]:
    return {int(x) for x in path.read_text().split()}


def audit(raw_root: Path) -> dict:
    development = _seeds(ROOT / "seeds" / "development.txt")
    held_out = _seeds(ROOT / "seeds" / "test_held_out.txt")
    trace_hashes: dict[int, set[str]] = {}
    methods_by_seed: dict[int, set[str]] = {}
    max_conservation_residual = 0.0
    total_energy_shortfall = 0.0
    online_boundary_ok = True
    slot_files = sorted(raw_root.glob("seed=*/method=*/slots.jsonl"))
    observed_seeds: set[int] = set()
    record_count = 0
    for path in slot_files:
        for line in path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            seed = int(row["seed"])
            observed_seeds.add(seed)
            methods_by_seed.setdefault(seed, set()).add(row["method"])
            record_count += 1
            residuals = row["executor_ledger"]["conservation_residual_j"]
            max_conservation_residual = max(
                max_conservation_residual, max(abs(float(x)) for x in residuals)
            )
            total_energy_shortfall += float(row["reporting_execution"]["energy_shortfall_j"])
            total_energy_shortfall += float(row["wet_execution"]["shortfall_j"])
            online_keys = set(row["online_information_set"])
            online_boundary_ok = online_boundary_ok and not bool(
                online_keys
                & {"energy_before_j", "energy_after_j", "harvest_actual_j", "hidden_load_j"}
            )
        summary = json.loads((path.parent / "summary.json").read_text(encoding="utf-8"))
        trace_hashes.setdefault(int(summary["seed"]), set()).add(summary["trace_hash"])

    expected_methods = {"fixed_periodic", "age_selective"}
    test_log_path = ROOT / "outputs" / "logs" / "stage1_unit_tests.json"
    test_log = json.loads(test_log_path.read_text()) if test_log_path.exists() else {}
    checks = {
        "unit_tests": test_log.get("successful") is True and test_log.get("tests_run", 0) >= 14,
        "only_development_seeds": observed_seeds == development,
        "no_held_out_seed_seen": observed_seeds.isdisjoint(held_out),
        "two_methods_per_seed": all(
            methods_by_seed.get(seed, set()) == expected_methods for seed in development
        ),
        "matched_trace_hash_per_seed": all(
            len(trace_hashes.get(seed, set())) == 1 for seed in development
        ),
        "slot_record_count": record_count == 5 * 2 * 48,
        "energy_conservation": max_conservation_residual <= 1e-8,
        "no_physical_energy_shortfall": total_energy_shortfall <= 1e-12,
        "online_log_boundary": online_boundary_ok,
    }
    return {
        "stage": 1,
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "observed_development_seeds": sorted(observed_seeds),
        "record_count": record_count,
        "max_abs_energy_conservation_residual_j": max_conservation_residual,
        "total_physical_energy_shortfall_j": total_energy_shortfall,
        "note": "Engineering gate only; no method-performance inference is authorized.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--raw", type=Path, default=ROOT / "outputs" / "raw" / "stage1_minimal_v1"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "outputs" / "logs" / "stage1_minimal_v1_gate.json",
    )
    args = parser.parse_args()
    result = audit(args.raw)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    if result["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
