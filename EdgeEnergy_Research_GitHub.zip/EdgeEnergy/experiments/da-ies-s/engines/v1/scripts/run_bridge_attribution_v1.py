#!/usr/bin/env python3
"""Fresh-seed post-hoc bridge attribution for the DA-IES-S package.

This script does NOT alter or rerun the frozen Stage-6 held-out comparison.
It uses a new disjoint seed registry to diagnose which package changes account
for the B4 -> DA-IES-S service shift. The chain is deliberately incremental:

B4 (2x2, interval guard, age-direct)
  -> Wide-Age (4x4, interval guard, age-direct)
  -> Wide-RCPG-Age (4x4, RCPG, age-direct)
  -> Wide-RCPG-Hybrid-Direct (4x4, RCPG, hybrid score, direct only)
  -> DA-IES-S (4x4, RCPG, hybrid score, direct + EETOR)

The experiment is attribution evidence, not a new confirmatory superiority test.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5_1 import BASELINE, external_config, load_configs, method_config
from src.digital_twin.calibration import calibration_from_dict
from src.environment.trace import generate_trace
from src.logging.provenance import canonical_hash, deterministic_records_hash, write_json
from src.scheduler.stage4 import (
    BRIDGE_WIDE_AGE,
    BRIDGE_WIDE_RCPG_AGE,
    BRIDGE_WIDE_RCPG_HYBRID_DIRECT,
    DA_IES_S_METHOD,
    method_spec,
)
from src.stage4_simulation import run_stage4_method

METHODS = (
    BASELINE,
    BRIDGE_WIDE_AGE,
    BRIDGE_WIDE_RCPG_AGE,
    BRIDGE_WIDE_RCPG_HYBRID_DIRECT,
    DA_IES_S_METHOD,
)
METHOD_LABELS = {
    BASELINE: "B4",
    BRIDGE_WIDE_AGE: "Wide-Age",
    BRIDGE_WIDE_RCPG_AGE: "Wide-RCPG-Age",
    BRIDGE_WIDE_RCPG_HYBRID_DIRECT: "Wide-RCPG-Hybrid-Direct",
    DA_IES_S_METHOD: "DA-IES-S",
}
CONTRASTS = (
    (BRIDGE_WIDE_AGE, BASELINE, "breadth: Wide-Age - B4"),
    (BRIDGE_WIDE_RCPG_AGE, BRIDGE_WIDE_AGE, "guard: Wide-RCPG-Age - Wide-Age"),
    (BRIDGE_WIDE_RCPG_HYBRID_DIRECT, BRIDGE_WIDE_RCPG_AGE, "ranking: Hybrid-Direct - RCPG-Age"),
    (DA_IES_S_METHOD, BRIDGE_WIDE_RCPG_HYBRID_DIRECT, "return: DA-IES-S - Hybrid-Direct"),
    (DA_IES_S_METHOD, BASELINE, "package: DA-IES-S - B4"),
)
PRIMARY_METRICS = (
    "cumulative_unmet_visible_demand_j",
    "all_service_met_slot_fraction",
    "node_service_continuity_fraction",
    "average_reporting_debit_j_per_slot",
    "average_wet_gross_debit_j_per_slot",
    "payer_reserve_violation_rate",
)


def _load() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    stage51, stage4, stage5 = load_configs(ROOT / "configs" / "stage5_1.yaml")
    selection = json.loads((ROOT / "outputs" / "stage5_1_da_ies_s_v1" / "calibration_selection.json").read_text())
    calib_payload = json.loads((ROOT / "outputs" / "stage2_belief_voei_v2" / "calibration_parameters_v2.json").read_text())
    return stage51, stage4, stage5, selection, calib_payload


def _config_for(method: str, condition: str) -> dict[str, Any]:
    stage51, stage4, stage5, selection, _ = _load()
    base = external_config(stage51, stage4, stage5, condition, "validation")
    base["simulation"]["slots"] = 480
    if method == BASELINE:
        return copy.deepcopy(base)
    # Wide-Age changes candidate breadth only. Belief-sample count is set to 8
    # for configuration parity but is not read by age-direct ranking.
    if method == BRIDGE_WIDE_AGE:
        cfg = copy.deepcopy(base)
        cfg["voei"]["belief_samples"] = 8
        cfg["voei"]["receiver_candidate_count"] = 4
        cfg["voei"]["donor_candidate_count"] = 4
        return cfg
    # All remaining methods share the frozen proposed override and selected RCPG.
    selected = str(selection["selected_grid_id"])
    cfg = method_config(base, stage51, DA_IES_S_METHOD, selected)
    if method not in {BRIDGE_WIDE_RCPG_AGE, BRIDGE_WIDE_RCPG_HYBRID_DIRECT, DA_IES_S_METHOD}:
        raise ValueError(method)
    return cfg


def _physical_hash(records: tuple[dict[str, Any], ...]) -> str:
    digest = hashlib.sha256()
    for row in records:
        payload = {
            "executor_ledger": row["executor_ledger"],
            "outcomes": row["outcomes"],
            "energy_after_j": row["offline_evaluation"]["energy_after_j"],
            "report_action": {
                "state_subset": row["decision"]["action"]["state_subset"],
                "return_mode": row["decision"]["action"]["return_mode"],
            },
            "wet_action": {
                "receiver": row["decision"]["action"]["receiver"],
                "donor": row["decision"]["action"]["donor"],
                "wet_path": row["decision"]["action"]["wet_path"],
                "amount_j": row["decision"]["action"]["amount_j"],
            },
        }
        digest.update(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode())
        digest.update(b"\n")
    return digest.hexdigest()


def _run_one(task: tuple[str, int, str]) -> dict[str, Any]:
    condition, seed, method = task
    _, _, _, _, calib_payload = _load()
    calibration = calibration_from_dict(calib_payload["calibration"])
    cfg = _config_for(method, condition)
    trace = generate_trace(cfg, seed)
    result = run_stage4_method(cfg, trace, method, f"bridge-v1:{condition}", calibration)
    max_residual = 0.0
    online_errors = 0
    guard_errors = 0
    return_counts: dict[str, int] = {}
    opportunity_nonempty = 0
    direct_nonempty = 0
    nonnull_wet = 0
    for row in result.records:
        residual = row["executor_ledger"]["conservation_residual_j"]
        max_residual = max(max_residual, max(abs(float(x)) for x in residual))
        online = json.dumps(row["online_information"], sort_keys=True).lower()
        if any(tok in online for tok in ("harvest_actual", "hidden_service", "energy_before")):
            online_errors += 1
        _, wet_rule, _ = method_spec(method)
        if wet_rule == "queue_safe":
            guard = row["decision"].get("risk_guard")
            if guard is None or guard.get("passed") is not True:
                guard_errors += 1
        action = row["decision"]["action"]
        mode = str(action["return_mode"])
        return_counts[mode] = return_counts.get(mode, 0) + 1
        if action["amount_j"] > 0:
            nonnull_wet += 1
        if mode == "opportunity" and action["state_subset"]:
            opportunity_nonempty += 1
        if mode == "independent" and action["state_subset"]:
            direct_nonempty += 1
    return {
        "condition": condition,
        "seed": seed,
        "method": method,
        "method_label": METHOD_LABELS[method],
        "trace_hash": result.trace_hash,
        "deterministic_records_hash": deterministic_records_hash(result.records),
        "physical_outcome_hash": _physical_hash(result.records),
        "maximum_conservation_residual_j": max_residual,
        "online_boundary_errors": online_errors,
        "selected_guard_errors": guard_errors,
        "return_mode_counts_json": json.dumps(return_counts, sort_keys=True),
        "opportunity_nonempty_slots": opportunity_nonempty,
        "direct_nonempty_slots": direct_nonempty,
        "nonnull_wet_slots": nonnull_wet,
        "runtime_seconds": result.runtime_seconds,
        "config_hash": canonical_hash(cfg),
        **result.summary,
    }


def _bootstrap(d: np.ndarray, resamples: int, seed: int) -> tuple[float, float, float]:
    d = np.asarray(d, dtype=float)
    mean = float(np.mean(d))
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, d.size, size=(resamples, d.size))
    boot = np.mean(d[idx], axis=1)
    lo, hi = np.quantile(boot, [0.025, 0.975])
    return mean, float(lo), float(hi)


def _analyze(df: pd.DataFrame, out: Path, resamples: int = 20000) -> None:
    out.mkdir(parents=True, exist_ok=True)
    # Integrity: each condition-seed must share one exogenous trace across all methods.
    trace_counts = df.groupby(["condition", "seed"])["trace_hash"].nunique()
    integrity = {
        "cells": int(trace_counts.size),
        "all_cells_have_one_trace_hash": bool((trace_counts == 1).all()),
        "maximum_conservation_residual_j": float(df["maximum_conservation_residual_j"].max()),
        "online_boundary_errors": int(df["online_boundary_errors"].sum()),
        "selected_guard_errors": int(df["selected_guard_errors"].sum()),
        "expected_rows": int(15 * 7 * len(METHODS)),
        "observed_rows": int(len(df)),
    }
    # Exact C vs P physical identity count.
    wide = df.pivot_table(index=["condition", "seed"], columns="method", values="physical_outcome_hash", aggfunc="first")
    c = BRIDGE_WIDE_RCPG_HYBRID_DIRECT
    p = DA_IES_S_METHOD
    exact = (wide[c] == wide[p])
    integrity["hybrid_direct_vs_daies_exact_physical_cells"] = int(exact.sum())
    integrity["hybrid_direct_vs_daies_total_cells"] = int(exact.size)
    write_json(out / "bridge_integrity_audit.json", integrity)

    # Method summaries, first across conditions within seed, then seeds.
    seed_mean = df.groupby(["seed", "method"], as_index=False)[list(PRIMARY_METRICS) + ["runtime_seconds", "opportunity_nonempty_slots", "direct_nonempty_slots"]].mean()
    seed_mean.to_csv(out / "seed_condition_averaged_metrics.csv", index=False)
    method_summary = seed_mean.groupby("method")[list(PRIMARY_METRICS) + ["runtime_seconds", "opportunity_nonempty_slots", "direct_nonempty_slots"]].agg(["mean", "std"])
    method_summary.to_csv(out / "method_summary.csv")

    # Condition-method raw means.
    cond = df.groupby(["condition", "method"], as_index=False)[list(PRIMARY_METRICS)].mean()
    cond.to_csv(out / "condition_method_summary.csv", index=False)

    # Paired incremental contrasts. Positive/negative signs remain proposed-minus-reference.
    rows = []
    pivots = {metric: seed_mean.pivot(index="seed", columns="method", values=metric) for metric in PRIMARY_METRICS}
    for ci, (left, right, label) in enumerate(CONTRASTS):
        for mi, metric in enumerate(PRIMARY_METRICS):
            d = (pivots[metric][left] - pivots[metric][right]).to_numpy(float)
            mean, lo, hi = _bootstrap(d, resamples, 2026082600 + ci * 100 + mi)
            rows.append({
                "contrast": label,
                "method_left": left,
                "method_right": right,
                "metric": metric,
                "mean_difference_left_minus_right": mean,
                "ci95_low": lo,
                "ci95_high": hi,
                "paired_seeds": len(d),
            })
    contrast_df = pd.DataFrame(rows)
    contrast_df.to_csv(out / "paired_bridge_contrasts.csv", index=False)

    # Fraction of package difference reached by each bridge point; descriptive only.
    frac_rows = []
    for metric in ("cumulative_unmet_visible_demand_j", "all_service_met_slot_fraction"):
        pv = pivots[metric]
        means = pv.mean(axis=0)
        package = float(means[DA_IES_S_METHOD] - means[BASELINE])
        for method in (BRIDGE_WIDE_AGE, BRIDGE_WIDE_RCPG_AGE, BRIDGE_WIDE_RCPG_HYBRID_DIRECT):
            bridge = float(means[method] - means[BASELINE])
            frac_rows.append({
                "metric": metric,
                "bridge_method": method,
                "bridge_minus_b4": bridge,
                "daies_minus_b4": package,
                "fraction_of_package_difference_reached": (bridge / package if abs(package) > 1e-12 else np.nan),
                "interpretation": "descriptive operating-point fraction; not additive causal attribution",
            })
    pd.DataFrame(frac_rows).to_csv(out / "package_difference_fraction.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--resamples", type=int, default=20000)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs" / "bridge_attribution_v1")
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 8:
        raise ValueError("workers must be in [1,8]")
    stage51, _, _, _, _ = _load()
    conditions = list(stage51["stage5_1"]["validation_conditions"])
    seeds = [int(x) for x in (ROOT / "seeds" / "bridge_attribution_v1.txt").read_text().split()]
    if len(seeds) != 15 or len(set(seeds)) != 15:
        raise RuntimeError("bridge seed registry must contain 15 unique seeds")
    other = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != "bridge_attribution_v1.txt":
            other.update(int(x) for x in path.read_text().split())
    if set(seeds) & other:
        raise RuntimeError("bridge seeds overlap a prior registry")

    tasks = [(condition, seed, method) for condition in conditions for seed in seeds for method in METHODS]
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": "bridge-attribution-v1",
        "status": "pre-run-frozen",
        "purpose": "post-hoc fresh-seed attribution; does not modify frozen Stage 6 claims",
        "methods": list(METHODS),
        "method_labels": METHOD_LABELS,
        "conditions": conditions,
        "seeds": seeds,
        "slots": 480,
        "expected_runs": len(tasks),
        "bootstrap_resamples": args.resamples,
        "selected_risk_grid": json.loads((ROOT / "outputs" / "stage5_1_da_ies_s_v1" / "calibration_selection.json").read_text())["selected_grid_id"],
    }
    write_json(args.output / "bridge_prerun_manifest.json", manifest)

    results = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futs = {pool.submit(_run_one, task): task for task in tasks}
        for i, fut in enumerate(as_completed(futs), 1):
            task = futs[fut]
            try:
                results.append(fut.result())
            except Exception as exc:
                raise RuntimeError(f"bridge task failed {task}: {exc}") from exc
            if i % 25 == 0 or i == len(tasks):
                print(f"completed {i}/{len(tasks)}", flush=True)
    df = pd.DataFrame(results).sort_values(["condition", "seed", "method"])
    df.to_csv(args.output / "all_bridge_runs.csv", index=False)
    _analyze(df, args.output, args.resamples)
    manifest["status"] = "completed"
    manifest["observed_runs"] = len(df)
    write_json(args.output / "bridge_final_manifest.json", manifest)
    print(args.output)


if __name__ == "__main__":
    main()
