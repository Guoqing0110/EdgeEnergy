#!/usr/bin/env python3
"""Execute the pre-registered DA-IES-S development or calibration grid."""

from __future__ import annotations

import argparse
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_stage5_1.py"


def _seeds(phase: str) -> list[int]:
    name = "da_ies_s_development.txt" if phase == "development" else "da_ies_s_calibration.txt"
    return [int(value) for value in (ROOT / "seeds" / name).read_text().split()]


def build_tasks(phase: str, limit_seeds: int | None) -> list[tuple[str, int, str]]:
    config = yaml.safe_load((ROOT / "configs" / "stage5_1.yaml").read_text())
    seeds = _seeds(phase)
    if limit_seeds is not None:
        if phase != "development":
            raise RuntimeError("seed limiting is development-only")
        seeds = seeds[:limit_seeds]
    return [
        (condition, seed, grid)
        for condition in config["stage5_1"]["tuning_conditions"]
        for seed in seeds
        for grid in config["risk_grid"]
    ]


def _run(phase: str, task: tuple[str, int, str]) -> tuple[str, int, str]:
    condition, seed, grid = task
    command = [
        sys.executable,
        str(RUNNER),
        "--phase",
        phase,
        "--condition",
        condition,
        "--seed",
        str(seed),
        "--method",
        "p_da_ies_s",
        "--grid-id",
        grid,
    ]
    completed = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    if completed.returncode != 0:
        raise RuntimeError(f"Stage 5.1 {phase} task failed {task}:\n{completed.stdout}")
    return task


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("development", "calibration"), required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--limit-seeds", type=int)
    args = parser.parse_args()
    if args.workers < 1 or args.workers > 4:
        raise RuntimeError("workers must be in [1,4]")
    tasks = build_tasks(args.phase, args.limit_seeds)
    count = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(_run, args.phase, task) for task in tasks]
        for future in as_completed(futures):
            condition, seed, grid = future.result()
            count += 1
            print(
                f"completed {count}/{len(tasks)} {condition}/seed={seed}/{grid}",
                flush=True,
            )


if __name__ == "__main__":
    main()
