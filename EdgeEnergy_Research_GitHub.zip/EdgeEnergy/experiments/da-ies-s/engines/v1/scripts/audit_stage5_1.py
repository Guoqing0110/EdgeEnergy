#!/usr/bin/env python3
"""Audit the frozen DA-IES-S baseline-superiority gate."""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


BASELINE = "b4_queue_belief_age_direct"
PROPOSED = "p_da_ies_s"


def main() -> None:
    output = ROOT / "outputs" / "stage5_1_da_ies_s_v1"
    config = yaml.safe_load((ROOT / "configs" / "stage5_1.yaml").read_text())
    gate = config["gate"]
    freeze = json.loads((output / "stage5_1_freeze_manifest.json").read_text())
    selection = json.loads((output / "calibration_selection.json").read_text())
    pooled = json.loads((output / "processed" / "pooled_paired_comparisons.json").read_text())
    cells = json.loads((output / "processed" / "cell_paired_comparisons.json").read_text())
    summaries = [
        json.loads(path.read_text())
        for path in sorted(
            output.glob("raw/da_ies_s_validation/grid=*/condition=*/seed=*/method=*/summary.json")
        )
    ]
    manifests = [
        json.loads(path.read_text())
        for path in sorted(
            output.glob("raw/da_ies_s_validation/grid=*/condition=*/seed=*/method=*/manifest.json")
        )
    ]
    slot_paths = sorted(
        output.glob("raw/da_ies_s_validation/grid=*/condition=*/seed=*/method=*/slots.jsonl")
    )
    expected_runs = int(freeze["expected_method_runs"])
    expected_rows = int(freeze["expected_slot_rows"])
    slot_rows = 0
    maximum_conservation = 0.0
    online_errors = 0
    selected_guard_errors = 0
    for path in slot_paths:
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                slot_rows += 1
                residual = row["executor_ledger"]["conservation_residual_j"]
                maximum_conservation = max(
                    maximum_conservation, max(abs(float(value)) for value in residual)
                )
                online = json.dumps(row["online_information"]).lower()
                if any(token in online for token in ("harvest_actual", "hidden_service", "energy_before")):
                    online_errors += 1
                if row["method"] == PROPOSED:
                    guard_record = row["decision"].get("risk_guard")
                    if guard_record is None or guard_record.get("passed") is not True:
                        selected_guard_errors += 1
    hash_keys = (
        "code_hash",
        "stage5_1_config_hash",
        "stage4_base_config_hash",
        "stage5_factor_config_hash",
        "belief_calibration_hash",
        "seed_hash",
        "risk_selection_hash",
    )
    hashes_match = all(
        all(item.get(key) == freeze.get(key) for key in hash_keys)
        for item in manifests
    )
    trace_methods: dict[tuple[str, int], set[str]] = defaultdict(set)
    trace_hashes: dict[tuple[str, int], set[str]] = defaultdict(set)
    for row in summaries:
        key = (str(row["condition"]), int(row["seed"]))
        trace_methods[key].add(str(row["method"]))
        trace_hashes[key].add(str(row["trace_hash"]))
    traces_match = all(
        methods == {BASELINE, PROPOSED} and len(trace_hashes[key]) == 1
        for key, methods in trace_methods.items()
    )
    report_limit = float(config["stage4"]["report_average_budget_j_per_slot"]) if "stage4" in config else None
    # Stage 5.1 inherits physical caps from Stage 4; use the loaded base directly.
    stage4 = yaml.safe_load((ROOT / config["experiment"]["stage4_base_config"]).read_text())
    report_limit = float(stage4["stage4"]["report_average_budget_j_per_slot"]) + float(
        gate["maximum_average_report_budget_tolerance_j"]
    )
    wet_limit = float(stage4["stage4"]["wet_average_budget_j_per_slot"]) + float(
        gate["maximum_average_wet_budget_tolerance_j"]
    )
    budget_ok = all(
        float(row["average_reporting_debit_j_per_slot"]) <= report_limit
        and float(row["average_wet_gross_debit_j_per_slot"]) <= wet_limit
        for row in summaries
    )
    lower_unmet_cells = sum(
        item["cumulative_unmet_visible_demand_j"][
            "mean_difference_proposed_minus_baseline"
        ] < 0.0
        for item in cells.values()
    )
    higher_continuity_cells = sum(
        item["all_service_met_slot_fraction"][
            "mean_difference_proposed_minus_baseline"
        ] > 0.0
        for item in cells.values()
    )
    safe_cells = sum(
        float(item["proposed_pooled_payer_reserve_violation_rate"])
        <= float(gate["maximum_payer_reserve_violation_rate_each_cell"])
        for item in cells.values()
    )
    reporting_ok = all(
        item["average_reporting_debit_j_per_slot"]["paired_bootstrap_95_ci"][1]
        <= float(gate["maximum_reporting_noninferiority_margin_j_per_slot"])
        for item in cells.values()
    )
    runtime_ratio = (
        sum(float(row["runtime_seconds"]) for row in summaries if row["method"] == PROPOSED)
        / sum(float(row["runtime_seconds"]) for row in summaries if row["method"] == BASELINE)
    )
    checks = {
        "calibration_selected_feasible_grid": selection.get("status") == "selected",
        "validation_structure_complete": len(summaries) == expected_runs
        and len(manifests) == expected_runs
        and len(slot_paths) == expected_runs
        and slot_rows == expected_rows,
        "freeze_hashes_match": hashes_match,
        "matched_exogenous_traces": traces_match,
        "causal_online_boundary_and_selected_guard": online_errors == 0
        and selected_guard_errors == 0,
        "energy_conservation": maximum_conservation
        <= float(gate["maximum_conservation_residual_j"]),
        "report_and_wet_budgets": budget_ok,
        "pooled_unmet_superiority": pooled["cumulative_unmet_visible_demand_j"][
            "paired_bootstrap_95_ci"
        ][1]
        < 0.0,
        "pooled_continuity_superiority": pooled["all_service_met_slot_fraction"][
            "paired_bootstrap_95_ci"
        ][0]
        > 0.0,
        "minimum_cells_lower_unmet": lower_unmet_cells
        >= int(gate["minimum_cells_with_lower_mean_unmet"]),
        "minimum_cells_higher_continuity": higher_continuity_cells
        >= int(gate["minimum_cells_with_higher_mean_continuity"]),
        "payer_reserve_limit_each_cell": safe_cells == len(cells),
        "reporting_energy_noninferiority_each_cell": reporting_ok,
        "runtime_ratio_within_envelope": runtime_ratio
        <= float(gate["maximum_runtime_ratio_to_baseline"]),
    }
    passed = bool(all(checks.values()))
    result = {
        "schema_version": "stage5.1-gate-audit-v1",
        "stage": "5.1-da-ies-s-baseline-focused-v1",
        "status": "pass" if passed else "fail",
        "stage5_1_completed": True,
        "stage5_1_gate_passed": passed,
        "stage6_authorized": passed,
        "checks": checks,
        "selected_grid_id": selection["selected_grid_id"],
        "selected_parameters": selection["selected_parameters"],
        "pooled_comparisons": pooled,
        "cell_comparisons": cells,
        "counts": {
            "lower_unmet_cells": lower_unmet_cells,
            "higher_continuity_cells": higher_continuity_cells,
            "safe_cells": safe_cells,
            "total_cells": len(cells),
        },
        "runtime_ratio_proposed_to_baseline": runtime_ratio,
        "accounting": {
            "summary_files": len(summaries),
            "slot_rows": slot_rows,
            "expected_slot_rows": expected_rows,
            "maximum_conservation_residual_j": maximum_conservation,
            "online_errors": online_errors,
            "selected_guard_errors": selected_guard_errors,
        },
        "held_out_test_used": False,
        "claim_release": (
            "DA-IES-S outperforms B4 on the frozen synthetic robustness validation while satisfying the payer-reserve criterion."
            if passed
            else "baseline-superiority claim remains locked"
        ),
    }
    write_json(output / "stage5_1_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
