#!/usr/bin/env python3
"""Final held-out claim audit for DA-IES-S versus B4."""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import write_json  # noqa: E402


BASELINE = "b4_queue_belief_age_direct"
PROPOSED = "p_da_ies_s"


def main() -> None:
    output = ROOT / "outputs" / "stage6_held_out_v1"
    config = yaml.safe_load((ROOT / "configs" / "stage6.yaml").read_text())
    gate = config["gate"]
    freeze = json.loads((output / "stage6_freeze_manifest.json").read_text())
    pooled = json.loads((output / "processed" / "pooled_paired_comparisons.json").read_text())
    cells = json.loads((output / "processed" / "cell_paired_comparisons.json").read_text())
    summaries = [
        json.loads(path.read_text())
        for path in sorted(output.glob("raw/condition=*/seed=*/method=*/summary.json"))
    ]
    manifests = [
        json.loads(path.read_text())
        for path in sorted(output.glob("raw/condition=*/seed=*/method=*/manifest.json"))
    ]
    slot_paths = sorted(output.glob("raw/condition=*/seed=*/method=*/slots.jsonl"))
    expected_runs = int(freeze["expected_method_runs"])
    expected_rows = int(freeze["expected_slot_rows"])
    slot_rows = 0
    max_conservation = 0.0
    online_errors = 0
    guard_errors = 0
    for path in slot_paths:
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                slot_rows += 1
                max_conservation = max(
                    max_conservation,
                    max(abs(float(x)) for x in row["executor_ledger"]["conservation_residual_j"]),
                )
                online = json.dumps(row["online_information"]).lower()
                if any(token in online for token in ("harvest_actual", "hidden_service", "energy_before")):
                    online_errors += 1
                if row["method"] == PROPOSED:
                    guard = row["decision"].get("risk_guard")
                    if guard is None or guard.get("passed") is not True:
                        guard_errors += 1
    hash_keys = (
        "code_hash",
        "stage6_config_hash",
        "stage5_1_config_hash",
        "stage4_base_config_hash",
        "stage5_factor_config_hash",
        "risk_selection_hash",
        "stage5_1_authorization_hash",
        "held_out_seed_hash",
    )
    hashes_match = all(
        all(item.get(key) == freeze.get(key) for key in hash_keys)
        for item in manifests
    )
    traces: dict[tuple[str, int], set[str]] = defaultdict(set)
    methods: dict[tuple[str, int], set[str]] = defaultdict(set)
    for row in summaries:
        key = (str(row["condition"]), int(row["seed"]))
        traces[key].add(str(row["trace_hash"]))
        methods[key].add(str(row["method"]))
    matched = all(
        len(traces[key]) == 1 and values == {BASELINE, PROPOSED}
        for key, values in methods.items()
    )
    stage51 = yaml.safe_load((ROOT / config["experiment"]["stage5_1_config"]).read_text())
    stage4 = yaml.safe_load((ROOT / stage51["experiment"]["stage4_base_config"]).read_text())
    report_limit = float(stage4["stage4"]["report_average_budget_j_per_slot"]) + float(
        gate["maximum_average_report_budget_tolerance_j"]
    )
    wet_limit = float(stage4["stage4"]["wet_average_budget_j_per_slot"]) + float(
        gate["maximum_average_wet_budget_tolerance_j"]
    )
    budgets = all(
        float(row["average_reporting_debit_j_per_slot"]) <= report_limit
        and float(row["average_wet_gross_debit_j_per_slot"]) <= wet_limit
        for row in summaries
    )
    lower_unmet = sum(
        x["cumulative_unmet_visible_demand_j"]["mean_difference_proposed_minus_baseline"] < 0
        for x in cells.values()
    )
    higher_cont = sum(
        x["all_service_met_slot_fraction"]["mean_difference_proposed_minus_baseline"] > 0
        for x in cells.values()
    )
    safe = sum(
        float(x["proposed_pooled_payer_reserve_violation_rate"])
        <= float(gate["maximum_payer_reserve_violation_rate_each_cell"])
        for x in cells.values()
    )
    reporting = all(
        x["average_reporting_debit_j_per_slot"]["paired_bootstrap_95_ci"][1]
        <= float(gate["maximum_reporting_noninferiority_margin_j_per_slot"])
        for x in cells.values()
    )
    runtime_ratio = (
        sum(float(x["runtime_seconds"]) for x in summaries if x["method"] == PROPOSED)
        / sum(float(x["runtime_seconds"]) for x in summaries if x["method"] == BASELINE)
    )
    checks = {
        "held_out_structure_complete": len(summaries) == expected_runs
        and len(manifests) == expected_runs
        and len(slot_paths) == expected_runs
        and slot_rows == expected_rows,
        "freeze_hashes_match": hashes_match,
        "matched_exogenous_traces": matched,
        "causal_online_boundary_and_selected_guard": online_errors == 0 and guard_errors == 0,
        "energy_conservation": max_conservation <= float(gate["maximum_conservation_residual_j"]),
        "report_and_wet_budgets": budgets,
        "held_out_pooled_unmet_superiority": pooled["cumulative_unmet_visible_demand_j"]["paired_bootstrap_95_ci"][1] < 0,
        "held_out_pooled_continuity_superiority": pooled["all_service_met_slot_fraction"]["paired_bootstrap_95_ci"][0] > 0,
        "minimum_cells_lower_unmet": lower_unmet >= int(gate["minimum_cells_with_lower_mean_unmet"]),
        "minimum_cells_higher_continuity": higher_cont >= int(gate["minimum_cells_with_higher_mean_continuity"]),
        "payer_reserve_limit_each_cell": safe == len(cells),
        "reporting_energy_noninferiority_each_cell": reporting,
        "runtime_ratio_within_envelope": runtime_ratio <= float(gate["maximum_runtime_ratio_to_baseline"]),
    }
    passed = bool(all(checks.values()))
    result = {
        "schema_version": "stage6-gate-audit-v1",
        "stage": "6-final-held-out-confirmation-v1",
        "status": "pass" if passed else "fail",
        "stage6_completed": True,
        "stage6_gate_passed": passed,
        "final_claim_authorized": passed,
        "checks": checks,
        "pooled_comparisons": pooled,
        "cell_comparisons": cells,
        "counts": {
            "lower_unmet_cells": lower_unmet,
            "higher_continuity_cells": higher_cont,
            "safe_cells": safe,
            "total_cells": len(cells),
        },
        "runtime_ratio_proposed_to_baseline": runtime_ratio,
        "accounting": {
            "summary_files": len(summaries),
            "slot_rows": slot_rows,
            "expected_slot_rows": expected_rows,
            "maximum_conservation_residual_j": max_conservation,
            "online_errors": online_errors,
            "selected_guard_errors": guard_errors,
        },
        "held_out_test_used": True,
        "claim_release": (
            "Across the frozen held-out synthetic robustness regimes, DA-IES-S outperforms B4 in unmet demand and continuity while satisfying the payer-reserve criterion and preserving reporting efficiency."
            if passed
            else "final baseline-superiority claim remains locked"
        ),
    }
    write_json(output / "stage6_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
