#!/usr/bin/env python3
"""Run v2 tests, calibration, freeze, validation, aggregation, and gate."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    commands = [
        [sys.executable, str(ROOT / "scripts" / "run_tests.py")],
        [
            sys.executable,
            str(ROOT / "scripts" / "run_stage2_v2.py"),
            "--phase",
            "calibration_v2",
        ],
        [sys.executable, str(ROOT / "scripts" / "freeze_stage2_v2.py")],
        [
            sys.executable,
            str(ROOT / "scripts" / "run_stage2_v2.py"),
            "--phase",
            "validation_v2",
        ],
        [sys.executable, str(ROOT / "scripts" / "aggregate_stage2_v2.py")],
        [sys.executable, str(ROOT / "scripts" / "audit_stage2_v2.py")],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
