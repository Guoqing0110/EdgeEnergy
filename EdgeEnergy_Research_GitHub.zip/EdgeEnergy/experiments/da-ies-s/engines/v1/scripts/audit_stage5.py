#!/usr/bin/env python3
"""Apply Stage 5 engineering, robustness and scalability gates."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage5 import family_conditions, family_methods  # noqa: E402
from src.logging.provenance import canonical_hash, write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def _csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    output = ROOT / "outputs" / "stage5_robustness_scalability_v1"
    config = yaml.safe_load((ROOT / "configs" / "stage5.yaml").read_text())
    stage4 = yaml.safe_load(
        (ROOT / config["experiment"]["stage4_base_config"]).read_text()
    )
    gate = config["gate"]
    freeze = json.loads((output / "stage5_freeze_manifest.json").read_text())
    comparisons = json.loads(
        (output / "processed" / "robustness_paired_comparisons.json").read_text()
    )
    exponents = json.loads(
        (output / "processed" / "scalability_exponents.json").read_text()
    )
    summaries = _csv(output / "processed" / "all_method_runs.csv")
    manifests = list(
        output.glob("raw/stage5_validation/*/*/seed=*/method=*/manifest.json")
    )
    manifest_values = [json.loads(path.read_text()) for path in manifests]
    slot_paths = sorted(
        output.glob("raw/stage5_validation/*/*/seed=*/method=*/slots.jsonl")
    )
    trace_manifests = list(
        output.glob("raw/stage5_validation/*/*/seed=*/trace_manifest.json")
    )
    expected_seed_list = _seeds(ROOT / "seeds" / "stage5_validation.txt")
    expected_seeds = set(expected_seed_list)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != "stage5_validation.txt":
            forbidden.update(_seeds(path))

    observed_all = {int(item["seed"]) for item in manifest_values}
    observed_robustness = {
        int(item["seed"]) for item in manifest_values if item["family"] == "robustness"
    }
    expected_small = set(
        expected_seed_list[: int(config["stage5"]["scalability_seed_count"])]
    )
    observed_scalability = {
        int(item["seed"]) for item in manifest_values if item["family"] == "scalability"
    }
    observed_complexity = {
        int(item["seed"]) for item in manifest_values if item["family"] == "complexity"
    }
    hash_fields = (
        "code_hash",
        "stage5_config_hash",
        "stage4_base_config_hash",
        "calibration_hash",
        "stage4_authorization_hash",
        "validation_seed_hash",
    )
    hashes_match = all(
        all(item[field] == freeze[field] for field in hash_fields)
        for item in manifest_values
    )
    trace_hashes: dict[tuple[str, str, int], set[str]] = {}
    manifest_counts: dict[tuple[str, str, int], int] = {}
    for item in manifest_values:
        key = (str(item["family"]), str(item["condition"]), int(item["seed"]))
        trace_hashes.setdefault(key, set()).add(str(item["trace_hash"]))
        manifest_counts[key] = manifest_counts.get(key, 0) + 1
    trace_hash_errors = sum(len(values) != 1 for values in trace_hashes.values())

    maximum_conservation = 0.0
    slot_rows = 0
    online_key_errors = 0
    forbidden_online = {
        "hidden_service_j",
        "harvest_actual_j",
        "energy_before_j",
        "energy_after_j",
    }
    for path in slot_paths:
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                slot_rows += 1
                residual = row["executor_ledger"]["conservation_residual_j"]
                maximum_conservation = max(
                    maximum_conservation, max(abs(float(value)) for value in residual)
                )
                online_key_errors += len(
                    forbidden_online.intersection(row["online_information"])
                )

    expected_runs = int(freeze["expected_method_runs"])
    expected_rows = int(freeze["expected_slot_rows"])
    expected_slots = int(config["stage5"]["slots"])
    expected_units = 0
    unit_method_counts: dict[tuple[str, str], int] = {}
    for family in ("robustness", "scalability", "complexity"):
        seed_count = len(expected_seeds) if family == "robustness" else len(expected_small)
        expected_units += len(family_conditions(config, family)) * seed_count
        for condition in family_conditions(config, family):
            unit_method_counts[(family, condition)] = len(family_methods(config, family))
    structure_ok = (
        len(manifests) == expected_runs
        and len(slot_paths) == expected_runs
        and len(trace_manifests) == expected_units
        and slot_rows == expected_rows
        and all(int(item["slot_rows"]) == expected_slots for item in manifest_values)
        and all(
            count == unit_method_counts[(family, condition)]
            for (family, condition, _), count in manifest_counts.items()
        )
    )

    report_limit = float(stage4["stage4"]["report_average_budget_j_per_slot"]) + float(
        gate["maximum_average_report_budget_tolerance_j"]
    )
    wet_limit = float(stage4["stage4"]["wet_average_budget_j_per_slot"]) + float(
        gate["maximum_average_wet_budget_tolerance_j"]
    )
    report_budget_ok = all(
        float(row["average_reporting_debit_j_per_slot"]) <= report_limit
        for row in summaries
    )
    wet_budget_ok = all(
        float(row["average_wet_gross_debit_j_per_slot"]) <= wet_limit
        for row in summaries
    )
    test_log = json.loads((ROOT / "outputs" / "logs" / "stage1_unit_tests.json").read_text())

    baseline = comparisons["baseline"]
    favorable_cells = sum(
        cell["b7_minus_b0_unmet"]["mean_difference_left_minus_right"] < 0.0
        and cell["b7_minus_b0_continuity"]["mean_difference_left_minus_right"] > 0.0
        for cell in comparisons.values()
    )
    reporting_cells = sum(
        cell["b7_minus_b4_reporting"]["paired_bootstrap_95_ci"][1] < 0.0
        for cell in comparisons.values()
    )
    continuity_cells = sum(
        cell["b7_minus_b4_continuity"]["paired_bootstrap_95_ci"][0]
        > -float(gate["maximum_b7_continuity_noninferiority_margin"])
        for cell in comparisons.values()
    )
    reserve_cells = sum(
        float(cell["b7_payer_reserve_violation_rate_mean"])
        <= float(gate["maximum_b7_payer_reserve_violation_rate"])
        for cell in comparisons.values()
    )
    proposed = str(config["stage5"]["proposed_method"])
    n96_expected = len(expected_small) * len(config["stage5"]["scalability_methods"])
    n96_observed = sum(
        row["family"] == "scalability" and int(row["node_count"]) == 96
        for row in summaries
    )
    checks = {
        "stage5_seed_registry_exact_and_disjoint": observed_all == expected_seeds
        and observed_robustness == expected_seeds
        and observed_scalability == expected_small
        and observed_complexity == expected_small
        and expected_seeds.isdisjoint(forbidden),
        "manifest_trace_and_slot_rows_complete": structure_ok,
        "freeze_hashes_match": hashes_match
        and freeze["validation_seed_hash"] == canonical_hash(expected_seed_list),
        "matched_policy_independent_trace_hashes": trace_hash_errors == 0,
        "unit_and_no_leakage_tests": test_log.get("successful") is True
        and int(test_log.get("tests_run", 0)) >= 40
        and online_key_errors == 0,
        "energy_conservation": maximum_conservation
        <= float(gate["maximum_conservation_residual_j"]),
        "average_report_budgets_respected": report_budget_ok,
        "average_wet_budgets_respected": wet_budget_ok,
        "baseline_b7_vs_b0_unmet_ci_upper_negative": baseline[
            "b7_minus_b0_unmet"
        ]["paired_bootstrap_95_ci"][1]
        < 0.0,
        "baseline_b7_vs_b0_continuity_ci_lower_positive": baseline[
            "b7_minus_b0_continuity"
        ]["paired_bootstrap_95_ci"][0]
        > 0.0,
        "favorable_service_direction_in_minimum_cells": favorable_cells
        >= int(gate["minimum_robustness_cells_with_favorable_service_direction"]),
        "b7_reporting_lower_than_b4_in_all_cells": reporting_cells
        == len(comparisons),
        "b7_continuity_noninferior_to_b4_in_minimum_cells": continuity_cells
        >= int(gate["minimum_robustness_cells_continuity_noninferior_to_b4"]),
        "b7_payer_reserve_rate_within_limit_in_all_cells": reserve_cells
        == len(comparisons),
        "all_n96_runs_completed": n96_observed == n96_expected,
        "b7_runtime_scaling_within_envelope": float(
            exponents[proposed]["runtime_loglog_exponent"]
        )
        <= float(gate["maximum_runtime_loglog_exponent"]),
        "b7_process_peak_rss_scaling_within_envelope": float(
            exponents[proposed]["process_peak_rss_loglog_exponent"]
        )
        <= float(gate["maximum_process_peak_rss_loglog_exponent"]),
    }
    passed = bool(all(checks.values()))
    result = {
        "stage": "5-robustness-scalability-v1",
        "status": "pass" if passed else "fail",
        "stage5_completed": True,
        "stage5_gate_passed": passed,
        "stage6_authorized": passed,
        "checks": checks,
        "robustness_gate_counts": {
            "total_cells": len(comparisons),
            "favorable_service_direction_cells": favorable_cells,
            "reporting_superiority_cells": reporting_cells,
            "continuity_noninferiority_cells": continuity_cells,
            "reserve_limit_cells": reserve_cells,
        },
        "robustness_comparisons": comparisons,
        "scalability_exponents": exponents,
        "accounting": {
            "manifest_files": len(manifests),
            "trace_manifest_files": len(trace_manifests),
            "slot_files": len(slot_paths),
            "slot_rows": slot_rows,
            "expected_slot_rows": expected_rows,
            "maximum_conservation_residual_j": maximum_conservation,
            "online_key_errors": online_key_errors,
            "trace_hash_errors": trace_hash_errors,
            "report_budget_limit_j_per_slot": report_limit,
            "wet_budget_limit_j_per_slot": wet_limit,
        },
        "held_out_test_used": False,
        "memory_scope": "resource.getrusage process peak RSS; includes Python/native",
        "lyapunov_claim_made": False,
    }
    write_json(output / "stage5_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
