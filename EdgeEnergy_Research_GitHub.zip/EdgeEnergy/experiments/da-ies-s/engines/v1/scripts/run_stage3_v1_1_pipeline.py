#!/usr/bin/env python3
"""One-shot Stage 3 v1.1 freeze, run, aggregate and audit pipeline."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "stage3_v1_1.yaml"
OUTPUT = ROOT / "outputs" / "stage3_selective_eetor_v1_1"


def main() -> None:
    commands = [
        [sys.executable, str(ROOT / "scripts" / "run_tests.py")],
        [
            sys.executable,
            str(ROOT / "scripts" / "freeze_stage3.py"),
            "--config",
            str(CONFIG),
            "--output",
            str(OUTPUT),
            "--protocol",
            str(ROOT / "STAGE3_V1_1_PROTOCOL.md"),
        ],
        [
            sys.executable,
            str(ROOT / "scripts" / "run_stage3.py"),
            "--config",
            str(CONFIG),
            "--output",
            str(OUTPUT),
        ],
        [
            sys.executable,
            str(ROOT / "scripts" / "aggregate_stage3.py"),
            "--output",
            str(OUTPUT),
            "--seed-split",
            "stage3_validation_v1_1",
            "--bootstrap-seed",
            "20260727",
        ],
        [
            sys.executable,
            str(ROOT / "scripts" / "audit_stage3.py"),
            "--config",
            str(CONFIG),
            "--output",
            str(OUTPUT),
        ],
    ]
    for command in commands:
        subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
