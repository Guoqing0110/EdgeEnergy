#!/usr/bin/env python3
"""Aggregate belief and VoEI rows at seed/trajectory level."""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.digital_twin.calibration import age_bucket  # noqa: E402
from src.metrics.ranking import binary_auc, ndcg_at_k, spearman, top_k_precision  # noqa: E402


def _read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise RuntimeError(f"no rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _belief_metrics(rows: list[dict]) -> dict:
    error = np.asarray([row["error_j_offline_only"] for row in rows], dtype=float)
    coverage = np.asarray([row["interval_covered_offline_only"] for row in rows], dtype=float)
    widths = np.asarray([row["interval_width_j"] for row in rows], dtype=float)
    return {
        "observations": len(rows),
        "mae_j": float(np.mean(np.abs(error))),
        "rmse_j": float(np.sqrt(np.mean(error**2))),
        "median_abs_error_j": float(np.median(np.abs(error))),
        "underestimation_rate": float(np.mean(error < 0.0)),
        "overestimation_rate": float(np.mean(error > 0.0)),
        "coverage": float(np.mean(coverage)),
        "mean_interval_width_j": float(np.mean(widths)),
    }


def aggregate_belief(raw_root: Path, processed_root: Path, config: dict) -> None:
    seed_groups: dict[tuple, list[dict]] = defaultdict(list)
    role_groups: dict[tuple, list[dict]] = defaultdict(list)
    age_groups: dict[tuple, list[dict]] = defaultdict(list)
    for path in sorted(raw_root.glob("*/seed=*/report_interval=*/belief_rows.jsonl")):
        split = path.parts[-4]
        rows = _read_jsonl(path)
        for row in rows:
            base = (split, int(row["seed"]), int(row["report_interval"]), row["method"])
            seed_groups[base].append(row)
            role_groups[base + (row["role"],)].append(row)
            bucket = age_bucket(int(row["age"]), config["belief"]["age_bucket_edges"])
            age_groups[base + (bucket,)].append(row)

    seed_rows = []
    for (split, seed, interval, method), rows in sorted(seed_groups.items()):
        metrics = _belief_metrics(rows)
        metrics["calibration_error"] = abs(
            metrics["coverage"] - float(config["belief"]["nominal_coverage"])
        )
        seed_rows.append(
            {"split": split, "seed": seed, "report_interval": interval, "method": method, **metrics}
        )
    role_rows = [
        {
            "split": key[0],
            "seed": key[1],
            "report_interval": key[2],
            "method": key[3],
            "role": key[4],
            **_belief_metrics(rows),
        }
        for key, rows in sorted(role_groups.items())
    ]
    age_rows = [
        {
            "split": key[0],
            "seed": key[1],
            "report_interval": key[2],
            "method": key[3],
            "age_bucket": key[4],
            **_belief_metrics(rows),
        }
        for key, rows in sorted(age_groups.items())
    ]
    _write_csv(processed_root / "belief_per_seed.csv", seed_rows)
    _write_csv(processed_root / "belief_role_per_seed.csv", role_rows)
    _write_csv(processed_root / "belief_age_per_seed.csv", age_rows)


def aggregate_voei(raw_root: Path, processed_root: Path, config: dict) -> None:
    output: list[dict] = []
    score_fields = {
        "age": "age_score",
        "uncertainty": "uncertainty_score",
        "urgency": "urgency_score",
        "random": "random_score",
        "full_voei": "full_voei_score",
    }
    k = int(config["voei"]["top_k"])
    for path in sorted(raw_root.glob("*/seed=*/report_interval=*/voei_rows.jsonl")):
        split = path.parts[-4]
        rows = _read_jsonl(path)
        if not rows:
            continue
        labels = np.asarray([row["offline_true_value"] for row in rows], dtype=float)
        outcomes = np.asarray([row["offline_action_changed"] for row in rows], dtype=bool)
        slots = sorted({int(row["slot"]) for row in rows})
        for method, field in score_fields.items():
            scores = np.asarray([row[field] for row in rows], dtype=float)
            ndcgs: list[float] = []
            precisions: list[float] = []
            for slot in slots:
                indices = [idx for idx, row in enumerate(rows) if int(row["slot"]) == slot]
                ndcg = ndcg_at_k(scores[indices], labels[indices], k)
                if math.isfinite(ndcg):
                    ndcgs.append(ndcg)
                precisions.append(top_k_precision(scores[indices], labels[indices], k))
            output.append(
                {
                    "split": split,
                    "seed": int(rows[0]["seed"]),
                    "report_interval": int(rows[0]["report_interval"]),
                    "method": method,
                    "node_slot_labels": len(rows),
                    "positive_label_fraction": float(np.mean(labels > 0.0)),
                    "action_change_fraction": float(np.mean(outcomes)),
                    "spearman": spearman(scores, labels),
                    "ndcg_at_k": float(np.mean(ndcgs)) if ndcgs else float("nan"),
                    "ndcg_evaluable_slot_fraction": len(ndcgs) / len(slots),
                    "top_k_precision": float(np.mean(precisions)),
                    "action_change_auc": binary_auc(scores, outcomes),
                    "mean_candidate_count": float(
                        np.mean([row["candidate_count"] for row in rows])
                    ),
                }
            )
    _write_csv(processed_root / "voei_per_seed.csv", output)


def main() -> None:
    config = yaml.safe_load((ROOT / "configs" / "stage2.yaml").read_text())
    experiment_root = ROOT / "outputs" / "stage2_belief_voei_v1"
    processed = experiment_root / "processed"
    aggregate_belief(experiment_root / "raw", processed, config)
    aggregate_voei(experiment_root / "raw", processed, config)


if __name__ == "__main__":
    main()
