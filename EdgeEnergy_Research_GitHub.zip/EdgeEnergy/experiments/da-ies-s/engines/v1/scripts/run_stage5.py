#!/usr/bin/env python3
"""Run frozen Stage 5 robustness, scalability and complexity trajectories."""

from __future__ import annotations

import argparse
import copy
import gc
import json
import math
import resource
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage4 import _deep_update, scenario_config  # noqa: E402
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
    write_jsonl,
)
from src.scheduler.stage4 import METHODS  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def load_configs(stage5_path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    stage5 = yaml.safe_load(stage5_path.read_text())
    stage4_path = ROOT / stage5["experiment"]["stage4_base_config"]
    stage4 = yaml.safe_load(stage4_path.read_text())
    return stage5, stage4


def family_conditions(stage5: dict[str, Any], family: str) -> list[str]:
    if family == "robustness":
        return list(stage5["robustness"]["conditions"])
    if family == "scalability":
        return [f"n{int(value)}" for value in stage5["scalability"]["node_counts"]]
    if family == "complexity":
        return list(stage5["complexity"]["conditions"])
    raise ValueError(f"unknown Stage 5 family: {family}")


def family_methods(stage5: dict[str, Any], family: str) -> list[str]:
    if family == "robustness":
        return list(stage5["stage5"]["robustness_methods"])
    if family == "scalability":
        return list(stage5["stage5"]["scalability_methods"])
    if family == "complexity":
        return [str(stage5["stage5"]["complexity_method"])]
    raise ValueError(f"unknown Stage 5 family: {family}")


def _density_scaled_area(stage5: dict[str, Any], node_count: int) -> list[float]:
    section = stage5["scalability"]
    reference = int(section["reference_node_count"])
    scale = math.sqrt(float(node_count) / reference)
    return [float(value) * scale for value in section["reference_area_m"]]


def factor_config(
    stage5: dict[str, Any], stage4: dict[str, Any], family: str, condition: str
) -> dict[str, Any]:
    section = stage5[family]
    config = scenario_config(stage4, str(section["base_stage4_scenario"]))
    config["simulation"]["slots"] = int(stage5["stage5"]["slots"])
    if family == "robustness":
        if condition not in section["conditions"]:
            raise ValueError("unknown Stage 5 robustness condition")
        _deep_update(config, copy.deepcopy(section["conditions"][condition]))
    elif family == "scalability":
        if not condition.startswith("n"):
            raise ValueError("invalid Stage 5 scalability condition")
        node_count = int(condition[1:])
        if node_count not in [int(value) for value in section["node_counts"]]:
            raise ValueError("unknown Stage 5 node count")
        config["simulation"]["node_count"] = node_count
        config["simulation"]["area_m"] = _density_scaled_area(stage5, node_count)
    elif family == "complexity":
        if condition not in section["conditions"]:
            raise ValueError("unknown Stage 5 complexity condition")
        node_count = int(section["node_count"])
        config["simulation"]["node_count"] = node_count
        config["simulation"]["area_m"] = _density_scaled_area(stage5, node_count)
        values = section["conditions"][condition]
        config["voei"]["belief_samples"] = int(values["belief_samples"])
        config["voei"]["receiver_candidate_count"] = int(values["candidate_count"])
        config["voei"]["donor_candidate_count"] = int(values["candidate_count"])
    else:
        raise ValueError(f"unknown Stage 5 family: {family}")
    return config


def stage5_hashes(
    stage5: dict[str, Any], stage4: dict[str, Any], seed_path: Path
) -> dict[str, str]:
    authorization = json.loads(
        (ROOT / stage5["experiment"]["stage4_authorization"]).read_text()
    )
    calibration = json.loads(
        (ROOT / stage5["experiment"]["calibration_source"]).read_text()
    )
    return {
        "code_hash": code_hash(ROOT),
        "stage5_config_hash": canonical_hash(stage5),
        "stage4_base_config_hash": canonical_hash(stage4),
        "calibration_hash": canonical_hash(calibration["calibration"]),
        "stage4_authorization_hash": canonical_hash(authorization),
        "validation_seed_hash": canonical_hash(_seeds(seed_path)),
    }


def _completed(method_root: Path, hashes: dict[str, str], slots: int) -> bool:
    manifest_path = method_root / "manifest.json"
    summary_path = method_root / "summary.json"
    slot_path = method_root / "slots.jsonl"
    if not (manifest_path.exists() and summary_path.exists() and slot_path.exists()):
        return False
    try:
        manifest = json.loads(manifest_path.read_text())
        summary = json.loads(summary_path.read_text())
        if manifest.get("status") != "completed" or int(manifest["slot_rows"]) != slots:
            return False
        if int(summary["slots"]) != slots:
            return False
        if any(manifest.get(key) != value for key, value in hashes.items()):
            return False
        with slot_path.open(encoding="utf-8") as handle:
            return sum(1 for _ in handle) == slots
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return False


def run(
    config_path: Path,
    output: Path,
    phase: str,
    family_filter: str | None,
    condition_filter: str | None,
    seed_filter: int | None,
    method_filter: str | None,
    limit_seeds: int | None,
    skip_completed: bool,
) -> None:
    stage5, stage4 = load_configs(config_path)
    if phase not in stage5["experiment"]["allowed_seed_splits"]:
        raise RuntimeError("Stage 5 phase is not authorized by config")
    seed_path = ROOT / "seeds" / f"{phase}.txt"
    all_seeds = _seeds(seed_path)
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != seed_path.name:
            forbidden.update(_seeds(path))
    if len(all_seeds) != len(set(all_seeds)) or not set(all_seeds).isdisjoint(forbidden):
        raise RuntimeError("Stage 5 seed registry is duplicated or overlapping")
    if phase == "stage5_validation" and len(all_seeds) != int(
        stage5["stage5"]["validation_seed_count"]
    ):
        raise RuntimeError("Stage 5 validation registry has wrong seed count")
    if limit_seeds is not None:
        if phase != "development":
            raise RuntimeError("seed limiting is development-only")
        all_seeds = all_seeds[: int(limit_seeds)]
    if seed_filter is not None:
        if seed_filter not in all_seeds:
            raise RuntimeError("seed filter is outside active Stage 5 registry")
        all_seeds = [seed_filter]

    authorization = json.loads(
        (ROOT / stage5["experiment"]["stage4_authorization"]).read_text()
    )
    if authorization.get("stage5_authorized") is not True:
        raise RuntimeError("Stage 4 does not authorize Stage 5")
    calibration_payload = json.loads(
        (ROOT / stage5["experiment"]["calibration_source"]).read_text()
    )
    calibration = calibration_from_dict(calibration_payload["calibration"])
    hashes = stage5_hashes(stage5, stage4, seed_path)
    if phase == "stage5_validation":
        freeze = json.loads((output / "stage5_freeze_manifest.json").read_text())
        for key, value in hashes.items():
            if freeze.get(key) != value:
                raise RuntimeError(f"Stage 5 {key} differs from pre-run freeze")

    families = [family_filter] if family_filter else ["robustness", "scalability", "complexity"]
    for family in families:
        if family not in {"robustness", "scalability", "complexity"}:
            raise RuntimeError("unknown Stage 5 family filter")
        seeds = list(all_seeds)
        if family == "scalability":
            seeds = seeds[: int(stage5["stage5"]["scalability_seed_count"])]
        if family == "complexity":
            seeds = seeds[: int(stage5["stage5"]["complexity_seed_count"])]
        conditions = family_conditions(stage5, family)
        if condition_filter is not None:
            if condition_filter not in conditions:
                raise RuntimeError("condition filter is outside selected Stage 5 family")
            conditions = [condition_filter]
        methods = family_methods(stage5, family)
        if any(method not in METHODS for method in methods):
            raise RuntimeError("Stage 5 method is outside Stage 4 registry")
        if method_filter is not None:
            if method_filter not in methods:
                raise RuntimeError("method filter is outside selected Stage 5 family")
            methods = [method_filter]

        for condition in conditions:
            config = factor_config(stage5, stage4, family, condition)
            for seed in seeds:
                trace = generate_trace(config, seed)
                unit_root = output / "raw" / phase / family / condition / f"seed={seed}"
                trace.save(unit_root / "trace.npz")
                write_json(
                    unit_root / "trace_manifest.json",
                    {
                        "schema_version": "stage5-trace-v1",
                        "phase": phase,
                        "family": family,
                        "condition": condition,
                        "seed": seed,
                        "node_count": trace.node_count,
                        "trace_hash": trace.content_hash(),
                        "policy_independent": True,
                        "methods": methods,
                        **hashes,
                        "held_out_test_used": False,
                    },
                )
                for method in methods:
                    method_root = unit_root / f"method={method}"
                    if skip_completed and _completed(
                        method_root, hashes, int(config["simulation"]["slots"])
                    ):
                        continue
                    result = run_stage4_method(
                        config, trace, method, f"stage5:{family}:{condition}", calibration
                    )
                    process_peak_rss_bytes = int(
                        resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
                    )
                    write_jsonl(method_root / "slots.jsonl", result.records)
                    summary = {
                        "schema_version": "stage5-summary-v1",
                        "phase": phase,
                        "family": family,
                        "condition": condition,
                        "seed": seed,
                        "method": method,
                        "node_count": trace.node_count,
                        "area_m": list(map(float, config["simulation"]["area_m"])),
                        "belief_samples": int(config["voei"]["belief_samples"]),
                        "receiver_candidate_count": int(
                            config["voei"]["receiver_candidate_count"]
                        ),
                        "donor_candidate_count": int(
                            config["voei"]["donor_candidate_count"]
                        ),
                        "trace_hash": result.trace_hash,
                        "deterministic_records_hash": deterministic_records_hash(
                            result.records
                        ),
                        "runtime_seconds": result.runtime_seconds,
                        "process_peak_rss_bytes": process_peak_rss_bytes,
                        "memory_scope": "resource.getrusage process peak RSS; includes Python/native",
                        **hashes,
                        **result.summary,
                    }
                    write_json(method_root / "summary.json", summary)
                    write_json(
                        method_root / "manifest.json",
                        {
                            "schema_version": "stage5-method-manifest-v1",
                            "phase": phase,
                            "family": family,
                            "condition": condition,
                            "seed": seed,
                            "method": method,
                            "node_count": trace.node_count,
                            "slot_rows": len(result.records),
                            "trace_hash": result.trace_hash,
                            **hashes,
                            "online_truth_separation": "online_information vs offline_truth_only",
                            "status": "completed",
                        },
                    )
                    del result
                    gc.collect()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage5.yaml")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage5_robustness_scalability_v1"
    )
    parser.add_argument("--phase", choices=["development", "stage5_validation"], required=True)
    parser.add_argument("--family", choices=["robustness", "scalability", "complexity"])
    parser.add_argument("--condition")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--method")
    parser.add_argument("--limit-seeds", type=int)
    parser.add_argument("--skip-completed", action="store_true")
    args = parser.parse_args()
    run(
        args.config,
        args.output,
        args.phase,
        args.family,
        args.condition,
        args.seed,
        args.method,
        args.limit_seeds,
        args.skip_completed,
    )


if __name__ == "__main__":
    main()
