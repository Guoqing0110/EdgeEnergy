#!/usr/bin/env python3
"""Apply the frozen Stage 3 crossover gate at the seed/trajectory level."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, write_json  # noqa: E402


def _csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="utf-8").split()]


def _paired(left: dict[int, float], right: dict[int, float], seed: int) -> dict:
    common = sorted(set(left) & set(right))
    difference = np.asarray([left[item] - right[item] for item in common], dtype=float)
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(difference), size=(20000, len(difference)))
    means = np.mean(difference[draws], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    sd = float(np.std(difference, ddof=1))
    return {
        "paired_seeds": len(common),
        "mean_difference_left_minus_right": float(np.mean(difference)),
        "paired_bootstrap_95_ci": [float(low), float(high)],
        "paired_effect_dz": float(np.mean(difference) / sd)
        if sd > 0.0
        else float("nan"),
    }


def _region_seed_values(
    rows: list[dict], method: str, metric: str, predicate
) -> dict[int, float]:
    values: dict[int, list[float]] = defaultdict(list)
    for row in rows:
        if row["method"] == method and predicate(row):
            value = float(row[metric])
            if math.isfinite(value):
                values[int(row["seed"])].append(value)
    return {seed: float(np.mean(items)) for seed, items in values.items() if items}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage3.yaml")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage3_selective_eetor_v1"
    )
    args = parser.parse_args()
    config = yaml.safe_load(args.config.read_text())
    gate = config["gate"]
    output = args.output
    seed_split = str(config["experiment"]["allowed_seed_split"])
    freeze = json.loads((output / "stage3_freeze_manifest.json").read_text())
    accounting = json.loads((output / "stage3_accounting_audit.json").read_text())
    rows = _csv(output / "processed" / "per_seed_factor.csv")
    paired_cells = _csv(output / "processed" / "paired_crossover_cells.csv")
    manifests = list(output.glob(f"raw/{seed_split}/*/seed=*/manifest.json"))
    manifest_values = [json.loads(path.read_text()) for path in manifests]
    expected_seed_path = ROOT / "seeds" / f"{seed_split}.txt"
    expected_seeds_list = _seeds(expected_seed_path)
    expected_seeds = set(expected_seeds_list)
    observed_seeds = {int(item["seed"]) for item in manifest_values}
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path.name != expected_seed_path.name:
            forbidden.update(_seeds(path))
    hashes_match = all(
        item["code_hash"] == freeze["code_hash"]
        and item["config_hash"] == freeze["config_hash"]
        and item["calibration_hash"] == freeze["calibration_hash"]
        and item["validation_seed_hash"] == freeze["validation_seed_hash"]
        and item["stage2_authorization_hash"] == freeze["stage2_authorization_hash"]
        for item in manifest_values
    )
    seed_hash_match = freeze["validation_seed_hash"] == canonical_hash(
        expected_seeds_list
    )
    expected_per_manifest = (
        int(config["simulation"]["slots"])
        // int(config["stage3"]["source_stride_slots"])
        * len(config["stage3"]["path_lengths_hops"])
        * len(config["stage3"]["field_payload_bytes"])
        * len(config["stage3"]["link_success_probabilities"])
        * len(config["stage3"]["report_energy_budgets_j"])
        * len(config["stage3"]["methods"])
    )
    manifest_counts_correct = all(
        int(item["method_row_count"]) == expected_per_manifest
        and int(item["source_event_count"])
        == int(config["simulation"]["slots"])
        // int(config["stage3"]["source_stride_slots"])
        for item in manifest_values
    )

    constrained = lambda row: (
        float(row["report_budget_j"])
        <= float(gate["constrained_budget_max_j"]) + 1e-15
        and int(float(row["path_length_hops"]))
        >= int(gate["constrained_path_min_hops"])
    )
    reliable_short = lambda row: (
        math.isclose(float(row["report_budget_j"]), 0.50)
        and int(float(row["path_length_hops"]))
        <= int(gate["reliable_short_path_max_hops"])
        and float(row["link_success_probability"])
        >= float(gate["reliable_link_min_probability"])
        and int(float(row["field_payload_bytes"]))
        <= int(gate["reliable_payload_max_bytes"])
    )
    stressed = lambda row: (
        math.isclose(float(row["report_budget_j"]), 0.50)
        and int(float(row["path_length_hops"]))
        >= int(gate["stressed_path_min_hops"])
        and float(row["link_success_probability"])
        <= float(gate["stressed_link_max_probability"])
        and int(float(row["field_payload_bytes"]))
        >= int(gate["stressed_payload_min_bytes"])
    )

    selective_comparison = _paired(
        _region_seed_values(
            rows,
            "full_voei_selective_eetor",
            "ratio_information_value_per_sensor_joule",
            constrained,
        ),
        _region_seed_values(
            rows,
            "collect_all_eetor",
            "ratio_information_value_per_sensor_joule",
            constrained,
        ),
        20260724,
    )
    collect_comparison = _paired(
        _region_seed_values(
            rows,
            "collect_all_eetor",
            "mean_offline_delivered_counterfactual_value",
            reliable_short,
        ),
        _region_seed_values(
            rows,
            "full_voei_selective_eetor",
            "mean_offline_delivered_counterfactual_value",
            reliable_short,
        ),
        20260725,
    )
    independent_comparison = _paired(
        _region_seed_values(
            rows,
            "independent_periodic_direct",
            "mean_offline_delivered_counterfactual_value",
            stressed,
        ),
        _region_seed_values(
            rows,
            "collect_all_eetor",
            "mean_offline_delivered_counterfactual_value",
            stressed,
        ),
        20260726,
    )

    positive_cell_counts = {
        "full_efficiency_ci_positive": sum(
            row["comparison"] == "full_minus_collect_efficiency"
            and float(row["paired_bootstrap_95_ci_low"]) > 0.0
            for row in paired_cells
        ),
        "collect_raw_value_mean_positive": sum(
            row["comparison"] == "collect_minus_full_raw_value"
            and float(row["mean_difference"]) > 0.0
            for row in paired_cells
        ),
        "independent_raw_value_mean_positive": sum(
            row["comparison"] == "independent_minus_collect_raw_value"
            and float(row["mean_difference"]) > 0.0
            for row in paired_cells
        ),
    }
    test_log = json.loads((ROOT / "outputs" / "logs" / "stage1_unit_tests.json").read_text())
    method_counts = list(accounting["method_row_counts"].values())
    checks = {
        "validation_seed_registry_exact": observed_seeds == expected_seeds
        and len(expected_seeds) == int(gate["expected_validation_seeds"]),
        "stage3_seeds_disjoint": expected_seeds.isdisjoint(forbidden),
        "manifest_count_and_rows_complete": len(manifests)
        == len(expected_seeds) * len(config["scenarios"])
        and manifest_counts_correct
        and int(accounting["raw_method_rows"])
        == int(freeze["expected_method_rows"]),
        "freeze_hashes_match": hashes_match and seed_hash_match,
        "unit_and_no_leakage_tests": test_log.get("successful") is True
        and int(test_log.get("tests_run", 0)) >= 27,
        "budget_accounting_exact": float(accounting["max_budget_residual_j"])
        <= float(gate["maximum_budget_residual_j"]),
        "payer_accounting_exact": max(
            float(accounting["max_actual_payer_accounting_residual_j"]),
            float(accounting["max_planned_payer_accounting_residual_j"]),
        )
        <= float(gate["maximum_accounting_residual_j"]),
        "no_execution_shortfall": float(accounting["max_energy_shortfall_j"]) == 0.0,
        "matched_factor_events": int(accounting["factor_event_structure_errors"]) == 0
        and int(accounting["row_structure_errors"]) == 0
        and len(set(method_counts)) == 1,
        "selective_constrained_efficiency_ci_positive": selective_comparison[
            "paired_seeds"
        ]
        == int(gate["expected_validation_seeds"])
        and selective_comparison["paired_bootstrap_95_ci"][0] > 0.0,
    }
    collect_positive = (
        collect_comparison["paired_seeds"] == int(gate["expected_validation_seeds"])
        and collect_comparison["mean_difference_left_minus_right"] > 0.0
    )
    independent_positive = (
        independent_comparison["paired_seeds"] == int(gate["expected_validation_seeds"])
        and independent_comparison["mean_difference_left_minus_right"] > 0.0
    )
    if gate.get("require_collect_all_or_independent_advantage_region", False):
        checks["collect_all_or_independent_advantage_region"] = bool(
            collect_positive or independent_positive
        )
    else:
        checks["collect_all_reliable_raw_value_direction_positive"] = collect_positive
        checks["independent_stressed_raw_value_direction_positive"] = independent_positive
    passed = bool(all(checks.values()))
    result = {
        "stage": str(config["experiment"]["id"]),
        "status": "pass" if passed else "fail",
        "stage3_completed": passed,
        "stage4_authorized": passed,
        "checks": checks,
        "counterexample_branch_directions": {
            "reliable_short_collect_all_positive": collect_positive,
            "stressed_independent_positive": independent_positive,
        },
        "primary_region_comparisons": {
            "constrained_full_minus_collect_efficiency": selective_comparison,
            "reliable_short_collect_minus_full_raw_value": collect_comparison,
            "stressed_independent_minus_collect_raw_value": independent_comparison,
        },
        "exploratory_crossover_cell_counts": positive_cell_counts,
        "accounting": accounting,
        "held_out_test_used": False,
        "failed_stage2_v2_ambiguity_classifier_used": False,
    }
    write_json(output / "stage3_gate_audit.json", result)
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
