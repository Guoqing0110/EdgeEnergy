#!/usr/bin/env python3
"""Aggregate Stage 2 v2.1 without modifying the preserved v2 outputs."""

from __future__ import annotations

import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.aggregate_stage2_v2 import aggregate_belief, aggregate_voei  # noqa: E402


def main() -> None:
    config = yaml.safe_load(
        (ROOT / "configs" / "stage2_v2_1.yaml").read_text(encoding="utf-8")
    )
    output = ROOT / "outputs" / "stage2_belief_voei_v2_1"
    processed = output / "processed"
    aggregate_belief(output / "raw", processed, config)
    aggregate_voei(output / "raw", processed, config)


if __name__ == "__main__":
    main()
