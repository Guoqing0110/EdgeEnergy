#!/usr/bin/env python3
"""Run the frozen, budget-matched selective-EETOR crossover experiment."""

from __future__ import annotations

import argparse
import copy
import json
import sys
from collections import defaultdict
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage2_v2 import (  # noqa: E402
    augment_intervals,
    build_voei_rows_v2,
    generate_benchmark,
    generate_trace,
    replay_beliefs_v2,
    scenario_config,
)
from src.communication_model.model import estimate_plan_cost, execute_communication  # noqa: E402
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.energy_model.model import PhysicalState, SlotEnergyLedger  # noqa: E402
from src.logging.provenance import canonical_hash, code_hash, write_json, write_jsonl  # noqa: E402
from src.reporting.eetor import (  # noqa: E402
    build_subset_catalog,
    chain_positions,
    expected_delivery,
    select_subset,
)


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="utf-8").split()]


def _source_events(voei_rows: list[dict], stride: int) -> list[list[dict]]:
    grouped: dict[int, list[dict]] = defaultdict(list)
    for row in voei_rows:
        if int(row["slot"]) % stride == 0:
            grouped[int(row["slot"])].append(row)
    return [sorted(grouped[slot], key=lambda row: int(row["node"])) for slot in sorted(grouped)]


def _per_node_actual(ledger: SlotEnergyLedger) -> dict[int, float]:
    if not ledger.executed_debits:
        return {}
    vector = np.sum(np.stack(list(ledger.executed_debits.values())), axis=0)
    return {int(node): float(value) for node, value in enumerate(vector) if value > 0.0}


def _category_totals(ledger: SlotEnergyLedger) -> dict[str, float]:
    return {
        category: float(np.sum(vector))
        for category, vector in sorted(ledger.executed_debits.items())
    }


def _mapped(mapping: dict[int, float], original_nodes: np.ndarray) -> dict[int, float]:
    return {
        int(original_nodes[int(position)]): float(value)
        for position, value in sorted(mapping.items())
        if int(position) < len(original_nodes)
    }


def run(
    config_path: Path,
    output: Path,
    scenario_filter: str | None = None,
    seed_filter: int | None = None,
) -> None:
    base = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    stage3 = base["stage3"]
    seed_split = str(base["experiment"]["allowed_seed_split"])
    seed_path = ROOT / "seeds" / f"{seed_split}.txt"
    seeds = _seeds(seed_path)
    forbidden: set[int] = set()
    for path in sorted((ROOT / "seeds").glob("*.txt")):
        if path.name != seed_path.name:
            forbidden.update(_seeds(path))
    expected_seed_count = int(base["gate"]["expected_validation_seeds"])
    if (
        len(seeds) != expected_seed_count
        or len(set(seeds)) != expected_seed_count
        or not set(seeds).isdisjoint(forbidden)
    ):
        raise RuntimeError("invalid or overlapping Stage 3 seed registry")

    authorization_path = ROOT / base["experiment"]["stage2_authorization"]
    authorization = json.loads(authorization_path.read_text(encoding="utf-8"))
    if authorization.get("stage3_authorized") is not True:
        raise RuntimeError("Stage 2 has not authorized Stage 3")
    calibration_path = ROOT / base["experiment"]["calibration_source"]
    calibration_payload = json.loads(calibration_path.read_text(encoding="utf-8"))
    calibration = calibration_from_dict(calibration_payload["calibration"])
    freeze = json.loads(
        (output / "stage3_freeze_manifest.json").read_text(encoding="utf-8")
    )
    expected_hashes = {
        "code_hash": code_hash(ROOT),
        "config_hash": canonical_hash(base),
        "calibration_hash": canonical_hash(calibration_payload["calibration"]),
        "validation_seed_hash": canonical_hash(seeds),
        "stage2_authorization_hash": canonical_hash(authorization),
    }
    for field, expected in expected_hashes.items():
        if freeze.get(field) != expected:
            raise RuntimeError(f"Stage 3 {field} differs from pre-run freeze")

    interval = int(base["reporting"]["intervals_slots"][0])
    methods = list(stage3["methods"])
    source_stride = int(stage3["source_stride_slots"])
    scenario_codes = {"nominal_sparse": 3701, "decision_boundary": 3702}
    catalog_cache: dict[tuple[int, int], tuple[Any, Any]] = {}

    scenarios = list(base["scenarios"])
    if scenario_filter is not None:
        if scenario_filter not in scenarios:
            raise RuntimeError(f"unknown Stage 3 scenario filter: {scenario_filter}")
        scenarios = [scenario_filter]
    selected_seeds = seeds
    if seed_filter is not None:
        if seed_filter not in seeds:
            raise RuntimeError("Stage 3 seed filter is outside the frozen registry")
        selected_seeds = [seed_filter]

    for scenario in scenarios:
        config = scenario_config(base, scenario)
        scenario_code = scenario_codes[scenario]
        for seed in selected_seeds:
            trace = generate_trace(config, seed)
            benchmark = generate_benchmark(config, trace, interval)
            belief_rows = replay_beliefs_v2(config, benchmark, scenario)
            augment_intervals(
                belief_rows, calibration, float(config["energy"]["capacity_j"])
            )
            voei_rows = build_voei_rows_v2(
                config, trace, scenario, interval, belief_rows
            )
            events = _source_events(voei_rows, source_stride)
            seed_root = output / "raw" / seed_split / scenario / f"seed={seed}"
            trace.save(seed_root / "trace.npz")
            online_source: list[dict[str, Any]] = []
            offline_source: list[dict[str, Any]] = []
            experiment_rows: list[dict[str, Any]] = []

            for event_rows in events:
                slot = int(event_rows[0]["slot"])
                source_event_id = f"{scenario}:seed={seed}:slot={slot}"
                online_source.append(
                    {
                        "source_event_id": source_event_id,
                        "scenario": scenario,
                        "seed": seed,
                        "slot": slot,
                        "nodes": [
                            {
                                "node": int(row["node"]),
                                "age_score": float(row["age_score"]),
                                "uncertainty_score": float(row["uncertainty_score"]),
                                "full_voei_score": float(row["full_voei_score"]),
                                "full_uncertainty_component": float(
                                    row["full_uncertainty_component"]
                                ),
                                "full_sensitivity_component": float(
                                    row["full_sensitivity_component"]
                                ),
                                "full_consequence_component": float(
                                    row["full_consequence_component"]
                                ),
                            }
                            for row in event_rows
                        ],
                    }
                )
                offline_source.append(
                    {
                        "source_event_id": source_event_id,
                        "offline_only": True,
                        "nodes": [
                            {
                                "node": int(row["node"]),
                                "counterfactual_value": float(row["offline_true_value"]),
                                "action_changed": bool(row["offline_action_changed"]),
                            }
                            for row in event_rows
                        ],
                    }
                )
                by_node = {int(row["node"]): row for row in event_rows}
                permutation_rng = np.random.default_rng(
                    np.random.SeedSequence([seed, scenario_code, slot, 30103])
                )
                permutation = permutation_rng.permutation(int(base["simulation"]["node_count"]))

                for length_value in stage3["path_lengths_hops"]:
                    length = int(length_value)
                    original_nodes = permutation[:length]
                    age_scores = np.asarray(
                        [by_node[int(node)]["age_score"] for node in original_nodes],
                        dtype=float,
                    )
                    voei_scores = np.asarray(
                        [by_node[int(node)]["full_voei_score"] for node in original_nodes],
                        dtype=float,
                    )
                    true_values = np.asarray(
                        [by_node[int(node)]["offline_true_value"] for node in original_nodes],
                        dtype=float,
                    )
                    random_rng = np.random.default_rng(
                        np.random.SeedSequence([seed, scenario_code, slot, length, 90217])
                    )
                    random_scores = random_rng.random(length)
                    positions = chain_positions(
                        length, float(stage3["hop_distance_m"])
                    )
                    uniform_rng = np.random.default_rng(
                        np.random.SeedSequence([seed, scenario_code, slot, length, 77191])
                    )
                    success_uniform = uniform_rng.random((length + 1, length + 1))
                    innovation_id = canonical_hash(
                        {
                            "seed": seed,
                            "scenario": scenario,
                            "slot": slot,
                            "length": length,
                            "uniform": success_uniform.tolist(),
                        }
                    )
                    permutation_id = canonical_hash(original_nodes.tolist())

                    for payload_value in stage3["field_payload_bytes"]:
                        payload = int(payload_value)
                        comm_config = copy.deepcopy(config["communication"])
                        comm_config["state_field_bytes"] = payload
                        catalog_key = (length, payload)
                        if catalog_key not in catalog_cache:
                            catalog_cache[catalog_key] = (
                                build_subset_catalog(
                                    length, "opportunity", positions, comm_config
                                ),
                                build_subset_catalog(
                                    length, "independent", positions, comm_config
                                ),
                            )
                        opportunity_catalog, independent_catalog = catalog_cache[
                            catalog_key
                        ]
                        for budget_value in stage3["report_energy_budgets_j"]:
                            budget = float(budget_value)
                            decisions: dict[str, tuple[Any, Any]] = {}
                            for method in methods:
                                catalog = (
                                    independent_catalog
                                    if method == "independent_periodic_direct"
                                    else opportunity_catalog
                                )
                                decision = select_subset(
                                    method=method,
                                    catalog=catalog,
                                    budget_j=budget,
                                    age_scores=age_scores,
                                    voei_scores=voei_scores,
                                    random_scores=random_scores,
                                    periodic_offset=slot // source_stride,
                                )
                                decisions[method] = (catalog, decision)

                            for success_value in stage3["link_success_probabilities"]:
                                link_success = float(success_value)
                                success_probability = np.full(
                                    (length + 1, length + 1), link_success, dtype=float
                                )
                                for method in methods:
                                    started = perf_counter()
                                    catalog, decision = decisions[method]
                                    plan = catalog.plans[decision.mask]
                                    planned = estimate_plan_cost(
                                        plan, positions, length, comm_config
                                    )
                                    if planned.total_sensor_debit_j > budget + 1e-12:
                                        raise AssertionError("selected plan violates report budget")
                                    state = PhysicalState.from_initial(
                                        np.full(
                                            length,
                                            float(stage3["battery_for_reporting_j"]),
                                        ),
                                        float(stage3["battery_capacity_for_reporting_j"]),
                                    )
                                    ledger = SlotEnergyLedger(state)
                                    execution = execute_communication(
                                        plan,
                                        ledger,
                                        positions,
                                        length,
                                        success_probability,
                                        success_uniform,
                                        comm_config,
                                    )
                                    ledger.assert_conservation()
                                    actual_payer = _per_node_actual(ledger)
                                    actual_total = float(sum(actual_payer.values()))
                                    categories = _category_totals(ledger)
                                    selected = np.asarray(decision.selected_nodes, dtype=int)
                                    delivered = np.asarray(execution.delivered_fields, dtype=int)
                                    attempted = np.asarray(execution.attempted_fields, dtype=int)
                                    selected_true = (
                                        float(np.sum(true_values[selected]))
                                        if selected.size
                                        else 0.0
                                    )
                                    delivered_true = (
                                        float(np.sum(true_values[delivered]))
                                        if delivered.size
                                        else 0.0
                                    )
                                    available_true = float(np.sum(true_values))
                                    expected_packets, expected_fields = expected_delivery(
                                        plan, link_success
                                    )
                                    factor_event_id = canonical_hash(
                                        {
                                            "source": source_event_id,
                                            "length": length,
                                            "payload": payload,
                                            "budget": budget,
                                            "success": link_success,
                                        }
                                    )
                                    experiment_rows.append(
                                        {
                                            "schema_version": "stage3-row-v1",
                                            "source_event_id": source_event_id,
                                            "factor_event_id": factor_event_id,
                                            "link_innovation_id": innovation_id,
                                            "path_permutation_id": permutation_id,
                                            "scenario": scenario,
                                            "seed": seed,
                                            "slot": slot,
                                            "method": method,
                                            "return_mode": catalog.mode,
                                            "path_length_hops": length,
                                            "field_payload_bytes": payload,
                                            "link_success_probability": link_success,
                                            "report_budget_j": budget,
                                            "eligible_original_nodes": [
                                                int(node) for node in original_nodes
                                            ],
                                            "selected_path_nodes": [
                                                int(node) for node in decision.selected_nodes
                                            ],
                                            "selected_original_nodes": [
                                                int(original_nodes[node])
                                                for node in decision.selected_nodes
                                            ],
                                            "delivered_path_nodes": [
                                                int(node) for node in execution.delivered_fields
                                            ],
                                            "delivered_original_nodes": [
                                                int(original_nodes[node])
                                                for node in execution.delivered_fields
                                            ],
                                            "selection_reason": decision.reason,
                                            "selection_utility_online": decision.utility,
                                            "selected_fields": int(selected.size),
                                            "attempted_fields": int(attempted.size),
                                            "delivered_fields": int(delivered.size),
                                            "measurement_loss_fields": int(
                                                selected.size - delivered.size
                                            ),
                                            "planned_sensor_debit_j": planned.total_sensor_debit_j,
                                            "planned_payer_debit_j": _mapped(
                                                planned.per_node_debit_j, original_nodes
                                            ),
                                            "actual_sensor_debit_j": actual_total,
                                            "actual_payer_debit_j": _mapped(
                                                actual_payer, original_nodes
                                            ),
                                            "actual_debit_by_category_j": categories,
                                            "budget_residual_j": max(
                                                0.0,
                                                planned.total_sensor_debit_j - budget,
                                            ),
                                            "accounting_residual_j": actual_total
                                            - float(sum(actual_payer.values())),
                                            "planned_bytes_over_hops": planned.bytes_over_hops,
                                            "actual_bytes_over_hops": execution.bytes_over_hops,
                                            "packets_attempted": execution.packets_attempted,
                                            "packets_delivered": execution.packets_delivered,
                                            "planned_hops": planned.hop_count,
                                            "actual_hops_attempted": execution.hops_attempted,
                                            "planned_latency_ms": planned.hop_count
                                            * float(comm_config["hop_latency_ms"]),
                                            "actual_latency_ms": execution.latency_ms,
                                            "expected_delivered_packets": expected_packets,
                                            "expected_delivered_fields": expected_fields,
                                            "expected_selected_field_delivery_probability": (
                                                expected_fields / selected.size
                                                if selected.size
                                                else 0.0
                                            ),
                                            "actual_selected_field_delivery_fraction": (
                                                delivered.size / selected.size
                                                if selected.size
                                                else 0.0
                                            ),
                                            "energy_shortfall_j": execution.energy_shortfall_j,
                                            "offline_selected_counterfactual_value": selected_true,
                                            "offline_delivered_counterfactual_value": delivered_true,
                                            "offline_available_counterfactual_value": available_true,
                                            "offline_residual_counterfactual_value": available_true
                                            - delivered_true,
                                            "offline_information_value_per_sensor_joule": (
                                                delivered_true / actual_total
                                                if actual_total > 0.0
                                                else 0.0
                                            ),
                                            "runtime_ms": (perf_counter() - started) * 1000.0,
                                        }
                                    )

            write_jsonl(seed_root / "source_online.jsonl", online_source)
            write_jsonl(seed_root / "source_offline_labels.jsonl", offline_source)
            write_jsonl(seed_root / "method_rows.jsonl", experiment_rows)
            write_json(
                seed_root / "manifest.json",
                {
                    "schema_version": str(
                        base["experiment"].get("manifest_schema", "stage3-manifest-v1")
                    ),
                    "phase": seed_split,
                    "scenario": scenario,
                    "seed": seed,
                    "trace_hash": trace.content_hash(),
                    **expected_hashes,
                    "source_event_count": len(events),
                    "online_source_row_count": len(online_source),
                    "offline_source_row_count": len(offline_source),
                    "method_row_count": len(experiment_rows),
                    "truth_fields": "source_offline_labels and offline_* evaluator columns only",
                    "retry_count": int(config["communication"]["retry_count"]),
                },
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs" / "stage3.yaml"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "outputs" / "stage3_selective_eetor_v1",
    )
    parser.add_argument("--scenario", choices=["nominal_sparse", "decision_boundary"])
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    run(args.config, args.output, args.scenario, args.seed)


if __name__ == "__main__":
    main()
