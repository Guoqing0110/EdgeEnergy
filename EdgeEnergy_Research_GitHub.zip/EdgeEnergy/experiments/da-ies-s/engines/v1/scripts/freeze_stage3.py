#!/usr/bin/env python3
"""Freeze Stage 3 code, factors, calibration, and new validation seeds."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, code_hash, write_json  # noqa: E402


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text(encoding="utf-8").split()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage3.yaml")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage3_selective_eetor_v1"
    )
    parser.add_argument("--protocol", type=Path, default=ROOT / "STAGE3_PROTOCOL.md")
    args = parser.parse_args()
    output = args.output
    config_path = args.config
    protocol_path = args.protocol
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    seed_split = str(config["experiment"]["allowed_seed_split"])
    seed_path = ROOT / "seeds" / f"{seed_split}.txt"
    authorization_path = ROOT / config["experiment"]["stage2_authorization"]
    calibration_path = ROOT / config["experiment"]["calibration_source"]
    for path in (protocol_path, seed_path, authorization_path, calibration_path):
        if not path.exists():
            raise RuntimeError(f"missing Stage 3 freeze input: {path}")
    authorization = json.loads(authorization_path.read_text(encoding="utf-8"))
    if authorization.get("stage3_authorized") is not True:
        raise RuntimeError("Stage 2 audit does not authorize Stage 3")
    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    seeds = _seeds(seed_path)
    if len(seeds) != 15 or len(set(seeds)) != 15:
        raise RuntimeError("Stage 3 needs exactly 15 unique validation seeds")
    factors = config["stage3"]
    expected_rows = (
        len(seeds)
        * len(config["scenarios"])
        * (int(config["simulation"]["slots"]) // int(factors["source_stride_slots"]))
        * len(factors["path_lengths_hops"])
        * len(factors["field_payload_bytes"])
        * len(factors["link_success_probabilities"])
        * len(factors["report_energy_budgets_j"])
        * len(factors["methods"])
    )
    write_json(
        output / "stage3_freeze_manifest.json",
        {
            "schema_version": str(
                config["experiment"].get("freeze_schema", "stage3-freeze-v1")
            ),
            "code_hash": code_hash(ROOT),
            "config_hash": canonical_hash(config),
            "calibration_hash": canonical_hash(calibration["calibration"]),
            "validation_seed_hash": canonical_hash(seeds),
            "stage2_authorization_hash": canonical_hash(authorization),
            "stage2_authorization_file": config["experiment"]["stage2_authorization"],
            "calibration_source": config["experiment"]["calibration_source"],
            "validation_seed_file": str(seed_path.relative_to(ROOT)),
            "protocol_file": str(protocol_path.relative_to(ROOT)),
            "expected_method_rows": expected_rows,
            "held_out_test_used": False,
            "frozen_parameters": [
                "controlled chain and direct-return topology",
                "path, payload, loss, and budget factor grid",
                "TX/RX/measurement/processing accounting",
                "block-fading innovations and zero retries",
                "six baseline/proposed subset policies",
                "exact subset enumeration and tie breaking",
                "three pre-registered crossover regions",
                "paired-seed bootstrap protocol",
            ],
        },
    )


if __name__ == "__main__":
    main()
