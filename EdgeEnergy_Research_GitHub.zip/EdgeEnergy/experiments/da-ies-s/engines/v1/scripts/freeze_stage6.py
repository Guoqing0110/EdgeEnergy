#!/usr/bin/env python3
"""Freeze the final 30-seed Stage 6 held-out confirmation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage6 import load_all, stage6_hashes  # noqa: E402
from src.logging.provenance import write_json  # noqa: E402


def main() -> None:
    config_path = ROOT / "configs" / "stage6.yaml"
    stage6, stage51, stage4, stage5, selection = load_all(config_path)
    authorization = json.loads(
        (ROOT / stage6["experiment"]["stage5_1_authorization"]).read_text()
    )
    if authorization.get("stage6_authorized") is not True:
        raise RuntimeError("Stage 5.1 did not authorize held-out execution")
    seed_path = ROOT / stage6["experiment"]["held_out_seed_file"]
    seeds = [int(value) for value in seed_path.read_text().split()]
    expected = int(stage6["stage6"]["held_out_seed_count"])
    if len(seeds) != expected or len(set(seeds)) != expected:
        raise RuntimeError("invalid held-out seed registry")
    other: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path != seed_path:
            other.update(int(value) for value in path.read_text().split())
    if set(seeds) & other:
        raise RuntimeError("held-out seeds overlap another registry")
    conditions = list(stage6["stage6"]["conditions"])
    runs = expected * len(conditions) * 2
    output = ROOT / "outputs" / "stage6_held_out_v1"
    write_json(
        output / "stage6_freeze_manifest.json",
        {
            "schema_version": "stage6-freeze-v1",
            **stage6_hashes(stage6, stage51, stage4, stage5, selection),
            "selected_grid_id": selection["selected_grid_id"],
            "selected_parameters": selection["selected_parameters"],
            "held_out_seed_file": "seeds/test_held_out.txt",
            "protocol_file": "STAGE6_PROTOCOL.md",
            "expected_method_runs": runs,
            "expected_slot_rows": runs * int(stage6["stage6"]["slots"]),
            "held_out_test_used_before_freeze": False,
        },
    )


if __name__ == "__main__":
    main()
