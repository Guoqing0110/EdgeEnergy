#!/usr/bin/env python3
"""Run DA-IES-S calibration or frozen baseline-focused validation units."""

from __future__ import annotations

import argparse
import copy
import json
import resource
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_stage4 import _deep_update  # noqa: E402
from scripts.run_stage5 import factor_config as stage5_factor_config  # noqa: E402
from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.trace import generate_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
    write_jsonl,
)
from src.scheduler.stage4 import DA_IES_S_METHOD  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402


BASELINE = "b4_queue_belief_age_direct"
PHASES = {
    "development": "da_ies_s_development",
    "calibration": "da_ies_s_calibration",
    "validation": "da_ies_s_validation",
}


def _seeds(path: Path) -> list[int]:
    return [int(value) for value in path.read_text().split()]


def load_configs(path: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    stage51 = yaml.safe_load(path.read_text())
    stage4 = yaml.safe_load((ROOT / stage51["experiment"]["stage4_base_config"]).read_text())
    stage5 = yaml.safe_load((ROOT / stage51["experiment"]["stage5_factor_source"]).read_text())
    return stage51, stage4, stage5


def external_config(
    stage51: dict[str, Any],
    stage4: dict[str, Any],
    stage5: dict[str, Any],
    condition: str,
    phase: str,
) -> dict[str, Any]:
    if condition not in stage51["stage5_1"][
        "validation_conditions" if phase == "validation" else "tuning_conditions"
    ]:
        raise ValueError("condition is outside the active Stage 5.1 family")
    config = stage5_factor_config(stage5, stage4, "robustness", condition)
    config["simulation"]["slots"] = int(
        stage51["stage5_1"][
            "development_slots" if phase == "development" else "slots"
        ]
    )
    return config


def method_config(
    base: dict[str, Any],
    stage51: dict[str, Any],
    method: str,
    grid_id: str,
) -> dict[str, Any]:
    config = copy.deepcopy(base)
    if method == BASELINE:
        if grid_id != "baseline":
            raise ValueError("B4 must use grid_id=baseline")
        return config
    if method != DA_IES_S_METHOD:
        raise ValueError("unsupported Stage 5.1 method")
    if grid_id not in stage51["risk_grid"]:
        raise ValueError("unknown RCPG grid id")
    _deep_update(config, copy.deepcopy(stage51["proposed_overrides"]))
    _deep_update(
        config["da_ies_s"]["risk_guard"],
        copy.deepcopy(stage51["risk_grid"][grid_id]),
    )
    return config


def hashes(
    stage51: dict[str, Any],
    stage4: dict[str, Any],
    stage5: dict[str, Any],
    seed_path: Path,
    selection: dict[str, Any] | None,
) -> dict[str, str]:
    calibration = json.loads(
        (ROOT / stage51["experiment"]["calibration_source"]).read_text()
    )
    values = {
        "code_hash": code_hash(ROOT),
        "stage5_1_config_hash": canonical_hash(stage51),
        "stage4_base_config_hash": canonical_hash(stage4),
        "stage5_factor_config_hash": canonical_hash(stage5),
        "belief_calibration_hash": canonical_hash(calibration["calibration"]),
        "seed_hash": canonical_hash(_seeds(seed_path)),
    }
    if selection is not None:
        values["risk_selection_hash"] = canonical_hash(selection)
    return values


def run_one(
    config_path: Path,
    output: Path,
    phase: str,
    condition: str,
    seed: int,
    method: str,
    grid_id: str,
) -> None:
    if phase not in PHASES:
        raise RuntimeError("unknown Stage 5.1 phase")
    stage51, stage4, stage5 = load_configs(config_path)
    split = PHASES[phase]
    if split not in stage51["experiment"]["allowed_seed_splits"]:
        raise RuntimeError("seed split is not authorized")
    seed_path = ROOT / "seeds" / f"{split}.txt"
    active = _seeds(seed_path)
    if seed not in active:
        raise RuntimeError("seed is outside the active Stage 5.1 registry")
    forbidden: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        if path != seed_path:
            forbidden.update(_seeds(path))
    if set(active) & forbidden:
        raise RuntimeError("Stage 5.1 seed overlap detected")

    selection = None
    if phase == "validation":
        selection_path = output / "calibration_selection.json"
        freeze_path = output / "stage5_1_freeze_manifest.json"
        if not selection_path.exists() or not freeze_path.exists():
            raise RuntimeError("validation requires calibration selection and freeze")
        selection = json.loads(selection_path.read_text())
        selected = str(selection["selected_grid_id"])
        if method == DA_IES_S_METHOD and grid_id != selected:
            raise RuntimeError("validation grid differs from calibrated selection")
        frozen = json.loads(freeze_path.read_text())
        current = hashes(stage51, stage4, stage5, seed_path, selection)
        if any(frozen.get(key) != value for key, value in current.items()):
            raise RuntimeError("Stage 5.1 validation inputs differ from freeze")

    base = external_config(stage51, stage4, stage5, condition, phase)
    config = method_config(base, stage51, method, grid_id)
    trace = generate_trace(config, seed)
    calibration_payload = json.loads(
        (ROOT / stage51["experiment"]["calibration_source"]).read_text()
    )
    calibration = calibration_from_dict(calibration_payload["calibration"])
    result = run_stage4_method(
        config, trace, method, f"stage5.1:{phase}:{condition}", calibration
    )
    current_hashes = hashes(stage51, stage4, stage5, seed_path, selection)
    unit = (
        output
        / "raw"
        / split
        / f"grid={grid_id}"
        / f"condition={condition}"
        / f"seed={seed}"
        / f"method={method}"
    )
    write_jsonl(unit / "slots.jsonl", result.records)
    summary = {
        "schema_version": "stage5.1-summary-v1",
        "phase": phase,
        "seed_split": split,
        "condition": condition,
        "seed": seed,
        "method": method,
        "risk_grid_id": grid_id,
        "trace_hash": result.trace_hash,
        "deterministic_records_hash": deterministic_records_hash(result.records),
        "runtime_seconds": result.runtime_seconds,
        "process_peak_rss_bytes": int(
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        ),
        "slot_rows": len(result.records),
        **current_hashes,
        **result.summary,
    }
    write_json(unit / "summary.json", summary)
    write_json(
        unit / "manifest.json",
        {
            "schema_version": "stage5.1-method-manifest-v1",
            "status": "completed",
            "phase": phase,
            "condition": condition,
            "seed": seed,
            "method": method,
            "risk_grid_id": grid_id,
            "slot_rows": len(result.records),
            "trace_hash": result.trace_hash,
            "held_out_test_used": False,
            **current_hashes,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "stage5_1.yaml")
    parser.add_argument(
        "--output", type=Path, default=ROOT / "outputs" / "stage5_1_da_ies_s_v1"
    )
    parser.add_argument("--phase", choices=tuple(PHASES), required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--method", choices=(BASELINE, DA_IES_S_METHOD), required=True)
    parser.add_argument("--grid-id", required=True)
    args = parser.parse_args()
    run_one(
        args.config,
        args.output,
        args.phase,
        args.condition,
        args.seed,
        args.method,
        args.grid_id,
    )


if __name__ == "__main__":
    main()
