#!/usr/bin/env python3
"""Audit the independent E6 v1 seed, trace, raw-record and checksum invariants."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_e6_matched_independent_v1 import (  # noqa: E402
    DEFAULT_OUTPUT,
    load_spec,
    seed_rows,
    verify_freeze,
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit(output: Path) -> dict[str, object]:
    freeze = verify_freeze(ROOT / "configs" / "e6_matched_independent_v1.yaml", output)
    spec = load_spec()
    with (output / "trajectory_index.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    conditions = set(spec["formal_run"]["conditions"])
    methods = set(spec["formal_run"]["methods"])
    seeds = {row["seed_value"] for row in seed_rows(spec)}
    expected = int(spec["formal_run"]["expected_trajectories"])
    expected_slots = int(spec["formal_run"]["slots"])
    cells: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    raw_hash_errors = []
    slot_errors = []
    max_residual = 0.0
    observed_slots = 0
    for row in rows:
        condition = row["condition"]
        seed = int(row["seed"])
        cells[(condition, seed)].append(row)
        path = ROOT / row["raw_relative_path"]
        if not path.is_file() or _sha256(path) != row["raw_sha256"]:
            raw_hash_errors.append(row["trajectory_id"])
            continue
        count = 0
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                record = json.loads(line)
                count += 1
                max_residual = max(
                    max_residual,
                    max(abs(float(value)) for value in record["executor_ledger"]["conservation_residual_j"]),
                )
        observed_slots += count
        if count != expected_slots:
            slot_errors.append({"trajectory_id": row["trajectory_id"], "slot_rows": count})
    cell_method_errors = []
    trace_hash_errors = []
    config_hash_errors = []
    for cell, group in sorted(cells.items()):
        observed_methods = {row["method"] for row in group}
        if observed_methods != methods or len(group) != len(methods):
            cell_method_errors.append({"condition": cell[0], "seed": cell[1], "methods": sorted(observed_methods)})
        if len({row["trace_hash"] for row in group}) != 1:
            trace_hash_errors.append({"condition": cell[0], "seed": cell[1]})
        if len({row["config_hash"] for row in group}) != 1:
            config_hash_errors.append({"condition": cell[0], "seed": cell[1]})
    retained: set[int] = set()
    for path in (ROOT / "seeds").glob("*.txt"):
        retained.update(int(value) for value in path.read_text().split())
    duplicate_ids = [item for item, count in Counter(row["trajectory_id"] for row in rows).items() if count != 1]
    checks = {
        "freeze_hashes_match": True,
        "trajectory_count_exact": len(rows) == expected,
        "trajectory_ids_unique": not duplicate_ids,
        "condition_set_exact": {row["condition"] for row in rows} == conditions,
        "seed_set_exact": {int(row["seed"]) for row in rows} == seeds,
        "method_set_exact": {row["method"] for row in rows} == methods,
        "condition_seed_cell_count_exact": len(cells) == len(conditions) * len(seeds),
        "seven_methods_per_cell": not cell_method_errors,
        "one_trace_hash_per_cell": not trace_hash_errors,
        "one_config_hash_per_cell": not config_hash_errors,
        "raw_sha256_all_match": not raw_hash_errors,
        "slot_rows_all_exact": not slot_errors,
        "formal_seeds_disjoint_from_retained": seeds.isdisjoint(retained),
        "conservation_residual_within_tolerance": max_residual <= float(spec["integrity"]["maximum_conservation_residual_j"]),
    }
    result = {
        "schema_version": "e6-independent-integrity-audit-v1",
        "scientific_status": "independently_reconstructed_not_original_r3",
        "passed": all(checks.values()),
        "checks": checks,
        "expected_trajectories": expected,
        "observed_trajectories": len(rows),
        "expected_slot_rows": int(freeze["expected_slot_rows"]),
        "observed_slot_rows": observed_slots,
        "condition_seed_cells": len(cells),
        "maximum_conservation_residual_j": max_residual,
        "errors": {
            "duplicate_trajectory_ids": duplicate_ids,
            "cell_method_errors": cell_method_errors,
            "trace_hash_errors": trace_hash_errors,
            "config_hash_errors": config_hash_errors,
            "raw_hash_errors": raw_hash_errors,
            "slot_errors": slot_errors,
        },
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "e6_integrity_audit.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["passed"]:
        raise SystemExit(1)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    audit(args.output.resolve())


if __name__ == "__main__":
    main()
