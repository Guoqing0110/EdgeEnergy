#!/usr/bin/env python3
"""Recompute E6 v1 tables and paired intervals from compressed raw trajectories."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_e6_matched_independent_v1 import DEFAULT_OUTPUT, load_spec  # noqa: E402


METRICS = (
    "cumulative_unmet_visible_demand_j",
    "node_service_continuity_fraction",
    "average_reporting_debit_j_per_slot",
    "payer_reserve_violation_rate",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_index(output: Path) -> list[dict[str, str]]:
    with (output / "trajectory_index.csv").open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _raw_metrics(row: dict[str, str]) -> dict[str, object]:
    path = ROOT / row["raw_relative_path"]
    if _sha256(path) != row["raw_sha256"]:
        raise RuntimeError(f"raw SHA-256 mismatch: {path}")
    unmet = 0.0
    continuity: list[float] = []
    report = 0.0
    reserve_events = 0
    payer_checks = 0
    slots = 0
    max_residual = 0.0
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            record = json.loads(line)
            slots += 1
            unmet += float(record["outcomes"]["unmet_visible_demand_j"])
            continuity.append(float(record["outcomes"]["node_service_met_fraction"]))
            report += float(record["outcomes"]["reporting_sensor_debit_j"])
            reserve_events += int(record["outcomes"]["payer_reserve_violation_count"])
            payer_checks += int(record["outcomes"]["payer_count"])
            max_residual = max(
                max_residual,
                max(abs(float(value)) for value in record["executor_ledger"]["conservation_residual_j"]),
            )
    if slots == 0:
        raise RuntimeError(f"empty raw trajectory: {path}")
    return {
        "trajectory_id": row["trajectory_id"],
        "condition": row["condition"],
        "seed_id": row["seed_id"],
        "seed": int(row["seed"]),
        "method": row["method"],
        "slot_rows": slots,
        "trace_hash": row["trace_hash"],
        "cumulative_unmet_visible_demand_j": unmet,
        "node_service_continuity_fraction": float(np.mean(continuity)),
        "average_reporting_debit_j_per_slot": report / slots,
        "payer_reserve_violation_rate": reserve_events / payer_checks if payer_checks else 0.0,
        "maximum_conservation_residual_j": max_residual,
    }


def _bootstrap(values: np.ndarray, resamples: int, seed: int) -> tuple[float, float, float]:
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(resamples, values.size))
    means = np.mean(values[indices], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(np.mean(values)), float(low), float(high)


def aggregate(output: Path) -> None:
    spec = load_spec()
    index = _read_index(output)
    expected = int(spec["formal_run"]["expected_trajectories"])
    if len(index) != expected:
        raise RuntimeError(f"expected {expected} indexed trajectories, found {len(index)}")
    rows = [_raw_metrics(row) for row in index]
    frame = pd.DataFrame(rows)
    processed = output / "processed"
    processed.mkdir(parents=True, exist_ok=True)
    frame.to_csv(processed / "trajectory_metrics_from_raw.csv", index=False)

    condition = frame.groupby(["condition", "method"], as_index=False)[list(METRICS)].mean()
    condition.to_csv(processed / "condition_method_summary.csv", index=False)
    seed_mean = frame.groupby(["seed_id", "seed", "method"], as_index=False)[list(METRICS)].mean()
    seed_mean.to_csv(processed / "seed_condition_averaged_metrics.csv", index=False)

    labels = {
        "e6_age_direct": "Age direct",
        "e6_uncertainty_direct": "Uncertainty direct",
        "e6_full_voei_direct": "Full-VoEI direct",
        "e6_hybrid_direct": "Hybrid direct",
        "e6_age_uncertainty_direct": "Age-of-uncertainty adaptation",
        "e6_usefulness_direct": "Usefulness adaptation",
        "e6_da_ies_s": "DA-IES-S",
    }
    summary_rows = []
    for method in spec["formal_run"]["methods"]:
        values = seed_mean[seed_mean["method"] == method]
        cond_values = condition[condition["method"] == method]
        summary_rows.append(
            {
                "method": method,
                "policy": labels[method],
                "unmet_kj": values["cumulative_unmet_visible_demand_j"].mean() / 1000.0,
                "node_continuity": values["node_service_continuity_fraction"].mean(),
                "report_mj_per_slot": values["average_reporting_debit_j_per_slot"].mean() * 1000.0,
                "max_condition_mean_reserve_percent": cond_values["payer_reserve_violation_rate"].max() * 100.0,
            }
        )
    pd.DataFrame(summary_rows).to_csv(processed / "table_5_6_independent_reconstruction.csv", index=False)

    pivots = {
        metric: seed_mean.pivot(index="seed", columns="method", values=metric)
        for metric in (
            "cumulative_unmet_visible_demand_j",
            "node_service_continuity_fraction",
        )
    }
    contrast_rows = []
    proposed = "e6_da_ies_s"
    resamples = int(spec["formal_run"]["bootstrap_resamples"])
    for method_index, method in enumerate(spec["formal_run"]["methods"]):
        if method == proposed:
            continue
        for metric_index, (metric, pivot) in enumerate(pivots.items()):
            differences = (pivot[proposed] - pivot[method]).to_numpy(float)
            mean, low, high = _bootstrap(
                differences,
                resamples,
                2026111900 + method_index * 10 + metric_index,
            )
            contrast_rows.append(
                {
                    "contrast": f"DA-IES-S minus {labels[method]}",
                    "metric": metric,
                    "mean_difference": mean,
                    "ci95_low": low,
                    "ci95_high": high,
                    "paired_seeds": len(differences),
                }
            )
    pd.DataFrame(contrast_rows).to_csv(processed / "paired_seed_bootstrap_contrasts.csv", index=False)
    report = {
        "schema_version": "e6-independent-aggregation-v1",
        "scientific_status": "independently_reconstructed_not_original_r3",
        "trajectories": len(frame),
        "slot_rows": int(frame["slot_rows"].sum()),
        "condition_seed_cells": int(frame.groupby(["condition", "seed"]).ngroups),
        "maximum_conservation_residual_j": float(frame["maximum_conservation_residual_j"].max()),
        "outputs": [
            "trajectory_metrics_from_raw.csv",
            "condition_method_summary.csv",
            "seed_condition_averaged_metrics.csv",
            "table_5_6_independent_reconstruction.csv",
            "paired_seed_bootstrap_contrasts.csv",
        ],
    }
    (processed / "aggregation_report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    aggregate(args.output.resolve())


if __name__ == "__main__":
    main()
