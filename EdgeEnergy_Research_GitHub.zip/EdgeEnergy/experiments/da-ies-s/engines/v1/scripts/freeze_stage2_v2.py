#!/usr/bin/env python3
"""Freeze Stage 2 v2 calibration and code before one-shot validation."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.logging.provenance import canonical_hash, code_hash, write_json  # noqa: E402


def main() -> None:
    output = ROOT / "outputs" / "stage2_belief_voei_v2"
    calibration_path = output / "calibration_parameters_v2.json"
    if not calibration_path.exists():
        raise RuntimeError("v2 calibration output does not exist")
    config = yaml.safe_load((ROOT / "configs" / "stage2_v2.yaml").read_text())
    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    write_json(
        output / "stage2_v2_freeze_manifest.json",
        {
            "schema_version": "stage2-v2-freeze-v1",
            "parent_v1_status": "failed_and_retained",
            "code_hash": code_hash(ROOT),
            "config_hash": canonical_hash(config),
            "calibration_hash": canonical_hash(calibration["calibration"]),
            "calibration_seed_file": "seeds/calibration_v2.txt",
            "validation_seed_file": "seeds/validation_v2.txt",
            "held_out_test_used": False,
            "frozen_parameters": [
                "hidden-load mean forecast",
                "process and measurement variance",
                "role-age conformal multipliers",
                "scenario reserve and initial-energy ranges",
                "ambiguity threshold and gate bounds",
                "VoEI objective and amount levels",
                "belief sample count and candidate pruning",
                "evaluation stride and primary ranking metrics",
            ],
        },
    )


if __name__ == "__main__":
    main()
