#!/usr/bin/env python3
"""Aggregate Stage 1 summaries at the seed trajectory level."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def aggregate(raw_root: Path, output_file: Path) -> list[dict]:
    rows = []
    for path in sorted(raw_root.glob("seed=*/method=*/summary.json")):
        rows.append(json.loads(path.read_text(encoding="utf-8")))
    if not rows:
        raise RuntimeError(f"no Stage 1 summaries found below {raw_root}")
    output_file.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row})
    with output_file.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--raw", type=Path, default=ROOT / "outputs" / "raw" / "stage1_minimal_v1"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "outputs" / "processed" / "stage1_minimal_v1" / "per_seed.csv",
    )
    args = parser.parse_args()
    aggregate(args.raw, args.output)


if __name__ == "__main__":
    main()
