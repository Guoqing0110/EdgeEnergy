#!/usr/bin/env python3
"""Aggregate final 30-seed held-out DA-IES-S comparisons."""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.aggregate_stage5_1 import METRICS, paired, write_csv  # noqa: E402
from src.logging.provenance import write_json  # noqa: E402


BASELINE = "b4_queue_belief_age_direct"
PROPOSED = "p_da_ies_s"


def main() -> None:
    output = ROOT / "outputs" / "stage6_held_out_v1"
    processed = output / "processed"
    config = yaml.safe_load((ROOT / "configs" / "stage6.yaml").read_text())
    rows = [
        json.loads(path.read_text())
        for path in sorted(output.glob("raw/condition=*/seed=*/method=*/summary.json"))
    ]
    expected = int(config["stage6"]["held_out_seed_count"]) * len(
        config["stage6"]["conditions"]
    ) * 2
    if len(rows) != expected:
        raise RuntimeError(f"expected {expected} Stage 6 summaries, observed {len(rows)}")
    write_csv(processed / "all_held_out_runs.csv", rows)
    lookup = {
        (str(row["condition"]), int(row["seed"]), str(row["method"])): row
        for row in rows
    }
    draws = int(config["stage6"]["bootstrap_resamples"])
    cells = {}
    summary_rows = []
    for index, condition in enumerate(config["stage6"]["conditions"]):
        cell = {}
        for metric_index, metric in enumerate(METRICS):
            proposed = {
                seed: float(row[metric])
                for (name, seed, method), row in lookup.items()
                if name == condition and method == PROPOSED
            }
            baseline = {
                seed: float(row[metric])
                for (name, seed, method), row in lookup.items()
                if name == condition and method == BASELINE
            }
            cell[metric] = paired(
                proposed, baseline, 20261001 + index * 100 + metric_index, draws
            )
        proposed_rows = [
            row for row in rows if row["condition"] == condition and row["method"] == PROPOSED
        ]
        violations = sum(int(row["payer_reserve_violations"]) for row in proposed_rows)
        checks = sum(int(row["payer_checks"]) for row in proposed_rows)
        cell["proposed_pooled_payer_reserve_violation_rate"] = (
            violations / checks if checks else 0.0
        )
        cells[condition] = cell
        for method in (BASELINE, PROPOSED):
            members = [
                row for row in rows if row["condition"] == condition and row["method"] == method
            ]
            item = {"condition": condition, "method": method, "runs": len(members)}
            for metric in METRICS:
                values = np.asarray([float(row[metric]) for row in members], dtype=float)
                item[f"mean_{metric}"] = float(np.mean(values))
                item[f"sd_{metric}"] = float(np.std(values, ddof=1))
            summary_rows.append(item)
    write_json(processed / "cell_paired_comparisons.json", cells)
    write_csv(processed / "condition_method_summary.csv", summary_rows)

    pooled_by_seed: dict[int, dict[str, dict[str, list[float]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(list))
    )
    for row in rows:
        for metric in METRICS:
            pooled_by_seed[int(row["seed"])][str(row["method"])][metric].append(
                float(row[metric])
            )
    pooled = {}
    for metric_index, metric in enumerate(METRICS):
        proposed = {
            seed: float(np.mean(values[PROPOSED][metric]))
            for seed, values in pooled_by_seed.items()
        }
        baseline = {
            seed: float(np.mean(values[BASELINE][metric]))
            for seed, values in pooled_by_seed.items()
        }
        pooled[metric] = paired(
            proposed, baseline, 20261101 + metric_index, draws
        )
    write_json(processed / "pooled_paired_comparisons.json", pooled)


if __name__ == "__main__":
    main()
