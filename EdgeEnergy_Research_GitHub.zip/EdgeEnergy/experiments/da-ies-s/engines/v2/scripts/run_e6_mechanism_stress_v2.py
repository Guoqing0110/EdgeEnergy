#!/usr/bin/env python3
"""Develop, validate, freeze and run the prospectively registered E6 v2 study."""

from __future__ import annotations

import argparse
import copy
import csv
import gzip
import hashlib
import io
import json
import os
import resource
import sys
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.digital_twin.calibration import calibration_from_dict  # noqa: E402
from src.environment.e6_v2_trace import generate_e6_v2_trace  # noqa: E402
from src.logging.provenance import (  # noqa: E402
    canonical_hash,
    code_hash,
    deterministic_records_hash,
    write_json,
)
from src.scheduler.stage4 import E6_METHODS, method_spec  # noqa: E402
from src.stage4_simulation import run_stage4_method  # noqa: E402

DEFAULT_CONFIG = ROOT / "configs" / "e6_mechanism_stress_v2.yaml"
DEFAULT_OUTPUT = ROOT / "outputs" / "e6_mechanism_stress_v2"
SCIENTIFIC_STATUS = (
    "prospectively_registered_mechanism_stress_extension_not_original_r3"
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _deep_update(target: dict[str, Any], override: dict[str, Any]) -> None:
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_update(target[key], value)
        else:
            target[key] = copy.deepcopy(value)


def load_spec(path: Path = DEFAULT_CONFIG) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def seed_rows(spec: dict[str, Any], split: str | None = None) -> list[dict[str, Any]]:
    path = ROOT / spec["experiment"]["seed_registry"]
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    parsed = [
        {
            "seed_id": row["seed_id"],
            "seed_value": int(row["seed_value"]),
            "generation_counter": int(row["generation_counter"]),
            "split": row["split"],
        }
        for row in rows
    ]
    return [row for row in parsed if split is None or row["split"] == split]


def validate_registry(spec: dict[str, Any]) -> None:
    rows = seed_rows(spec)
    values = [row["seed_value"] for row in rows]
    if len(values) != len(set(values)) or any(value <= 0 for value in values):
        raise RuntimeError("v2 seed registry is invalid")
    for split in ("development", "validation", "held_out"):
        expected = int(spec["phases"][split]["seed_count"])
        if len(seed_rows(spec, split)) != expected:
            raise RuntimeError(f"wrong seed count for {split}")
    retained: set[int] = set()
    active_path = (ROOT / spec["experiment"]["seed_registry"]).resolve()
    for path in (ROOT / "seeds").glob("*.txt"):
        for token in path.read_text(encoding="utf-8").replace(",", " ").split():
            if token.isdigit():
                retained.add(int(token))
    for path in (ROOT / "seeds").glob("*.csv"):
        if path.resolve() == active_path:
            continue
        with path.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                value = row.get("seed_value", "")
                if value.isdigit():
                    retained.add(int(value))
    if set(values) & retained:
        raise RuntimeError("v2 registry overlaps a retained seed partition")


def selected_grid(output: Path) -> str:
    path = output / "development_selection.json"
    if not path.exists():
        raise RuntimeError("development_selection.json is required")
    return str(json.loads(path.read_text(encoding="utf-8"))["selected_grid_id"])


def formal_config(
    condition: str,
    phase: str,
    grid_id: str,
    path: Path = DEFAULT_CONFIG,
) -> dict[str, Any]:
    spec = load_spec(path)
    if phase not in spec["phases"]:
        raise ValueError(f"unknown phase: {phase}")
    if condition not in spec["phases"][phase]["conditions"]:
        raise ValueError(f"condition {condition} is not registered for {phase}")
    if grid_id not in spec["development_grid"]:
        raise ValueError(f"unknown development grid: {grid_id}")
    config = copy.deepcopy(spec["base"])
    _deep_update(config, spec["conditions"][condition])
    _deep_update(config, spec["development_grid"][grid_id])
    config["simulation"]["slots"] = int(spec["phases"][phase]["slots"])
    return config


def input_hashes(config_path: Path, output: Path) -> dict[str, str]:
    spec = load_spec(config_path)
    calibration = json.loads(
        (ROOT / spec["experiment"]["calibration_source"]).read_text(encoding="utf-8")
    )
    values = {
        "code_hash": code_hash(ROOT),
        "v2_config_hash": canonical_hash(spec),
        "belief_calibration_hash": canonical_hash(calibration["calibration"]),
        "seed_registry_hash": canonical_hash(seed_rows(spec)),
    }
    selection = output / "development_selection.json"
    validation = output / "validation_gate.json"
    if selection.exists():
        values["development_selection_hash"] = canonical_hash(
            json.loads(selection.read_text(encoding="utf-8"))
        )
    if validation.exists():
        values["validation_gate_hash"] = canonical_hash(
            json.loads(validation.read_text(encoding="utf-8"))
        )
    return values


def _write_gzip_jsonl(path: Path, records: tuple[dict[str, Any], ...]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with io.TextIOWrapper(compressed, encoding="utf-8", newline="\n") as text:
                for record in records:
                    text.write(
                        json.dumps(
                            record,
                            sort_keys=True,
                            separators=(",", ":"),
                            ensure_ascii=False,
                        )
                    )
                    text.write("\n")
    temporary.replace(path)


def _unit_root(
    output: Path,
    phase: str,
    grid_id: str,
    condition: str,
    seed_id: str,
    method: str,
) -> Path:
    if phase == "development":
        return output / phase / grid_id / "raw" / condition / seed_id / method
    return output / phase / "raw" / condition / seed_id / method


def _run_one(
    task: tuple[str, str, int, str, str, str, str, str]
) -> dict[str, Any]:
    phase, condition, seed, seed_id, method, grid_id, config_name, output_name = task
    config_path = Path(config_name)
    output = Path(output_name)
    spec = load_spec(config_path)
    config = formal_config(condition, phase, grid_id, config_path)
    calibration_payload = json.loads(
        (ROOT / spec["experiment"]["calibration_source"]).read_text(encoding="utf-8")
    )
    calibration = calibration_from_dict(calibration_payload["calibration"])
    trace = generate_e6_v2_trace(config, seed, condition)
    result = run_stage4_method(
        config,
        trace,
        method,
        f"e6-v2:{phase}:{condition}:{grid_id}",
        calibration,
    )
    records = tuple(
        {key: value for key, value in record.items() if key != "runtime_ms"}
        for record in result.records
    )
    unit = _unit_root(output, phase, grid_id, condition, seed_id, method)
    raw_path = unit / "slots.jsonl.gz"
    _write_gzip_jsonl(raw_path, records)
    maximum_residual = max(
        abs(float(value))
        for record in records
        for value in record["executor_ledger"]["conservation_residual_j"]
    )
    opportunity_slots = sum(
        record["decision"]["action"]["return_mode"] == "opportunity"
        for record in records
    )
    direct_slots = sum(
        record["decision"]["action"]["return_mode"] == "independent"
        for record in records
    )
    delivered_fields = sum(
        int(record["outcomes"]["report_delivered_fields"]) for record in records
    )
    summary = {
        "schema_version": "e6-mechanism-stress-trajectory-summary-v2",
        "scientific_status": SCIENTIFIC_STATUS,
        "trajectory_id": f"{phase}__{condition}__{seed_id}__{method}__{grid_id}",
        "phase": phase,
        "condition": condition,
        "seed_id": seed_id,
        "seed": seed,
        "method": method,
        "grid_id": grid_id,
        "method_spec": list(method_spec(method)),
        "slot_rows": len(records),
        "trace_hash": result.trace_hash,
        "deterministic_records_hash": deterministic_records_hash(records),
        "raw_relative_path": str(raw_path.relative_to(ROOT)),
        "raw_sha256": _sha256(raw_path),
        "config_hash": canonical_hash(config),
        "maximum_conservation_residual_j": maximum_residual,
        "runtime_seconds": result.runtime_seconds,
        "process_peak_rss_bytes": int(
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        ),
        "opportunity_return_slot_fraction": opportunity_slots / len(records),
        "independent_return_slot_fraction": direct_slots / len(records),
        "delivered_report_fields_per_slot": delivered_fields / len(records),
        **result.summary,
    }
    write_json(unit / "summary.json", summary)
    return summary


def _tasks(
    config_path: Path,
    output: Path,
    phase: str,
    grid_ids: list[str],
    condition_filter: str | None = None,
    seed_filter: int | None = None,
    method_filter: str | None = None,
) -> list[tuple[str, str, int, str, str, str, str, str]]:
    spec = load_spec(config_path)
    rows = seed_rows(spec, phase)
    return [
        (
            phase,
            condition,
            row["seed_value"],
            row["seed_id"],
            method,
            grid_id,
            str(config_path.resolve()),
            str(output.resolve()),
        )
        for grid_id in grid_ids
        for condition in spec["phases"][phase]["conditions"]
        for row in rows
        for method in spec["phases"][phase]["methods"]
        if (condition_filter is None or condition == condition_filter)
        and (seed_filter is None or row["seed_value"] == seed_filter)
        and (method_filter is None or method == method_filter)
    ]


def _write_index(output: Path, phase: str) -> int:
    root = output / phase
    rows = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted(root.rglob("summary.json"))
    ]
    fields = [
        "trajectory_id",
        "phase",
        "condition",
        "seed_id",
        "seed",
        "method",
        "grid_id",
        "slot_rows",
        "trace_hash",
        "config_hash",
        "deterministic_records_hash",
        "raw_relative_path",
        "raw_sha256",
        "maximum_conservation_residual_j",
        "runtime_seconds",
        "cumulative_unmet_visible_demand_j",
        "total_visible_demand_j",
        "node_service_continuity_fraction",
        "average_reporting_debit_j_per_slot",
        "payer_reserve_violation_rate",
        "post_belief_rmse_j",
        "opportunity_return_slot_fraction",
        "independent_return_slot_fraction",
        "delivered_report_fields_per_slot",
    ]
    root.mkdir(parents=True, exist_ok=True)
    temporary = root / "trajectory_index.csv.tmp"
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row[field] for field in fields})
    temporary.replace(root / "trajectory_index.csv")
    return len(rows)


def run_phase(
    config_path: Path,
    output: Path,
    phase: str,
    workers: int,
    condition: str | None,
    seed: int | None,
    method: str | None,
) -> None:
    spec = load_spec(config_path)
    validate_registry(spec)
    if phase == "development":
        grid_ids = list(spec["development_grid"])
    else:
        grid_ids = [selected_grid(output)]
    if phase == "validation" and not (output / "development_selection.json").exists():
        raise RuntimeError("validation requires a frozen development selection")
    if phase == "held_out":
        verify_freeze(config_path, output)
    tasks = _tasks(
        config_path,
        output,
        phase,
        grid_ids,
        condition_filter=condition,
        seed_filter=seed,
        method_filter=method,
    )
    if not tasks:
        raise RuntimeError("no task matches the requested filters")
    completed = 0
    if workers <= 1:
        for task in tasks:
            _run_one(task)
            completed += 1
            print(f"completed {completed}/{len(tasks)}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(_run_one, task) for task in tasks]
            for future in as_completed(futures):
                future.result()
                completed += 1
                print(f"completed {completed}/{len(tasks)}", flush=True)
    print(f"trajectory index rows: {_write_index(output, phase)}")


def _phase_summaries(output: Path, phase: str) -> list[dict[str, Any]]:
    return [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted((output / phase).rglob("summary.json"))
    ]


def select_development(config_path: Path, output: Path) -> Path:
    spec = load_spec(config_path)
    rows = _phase_summaries(output, "development")
    expected = (
        len(spec["development_grid"])
        * len(spec["phases"]["development"]["conditions"])
        * int(spec["phases"]["development"]["seed_count"])
        * len(spec["phases"]["development"]["methods"])
    )
    if len(rows) != expected:
        raise RuntimeError(f"development requires {expected} summaries, found {len(rows)}")
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["grid_id"], row["condition"], row["method"])].append(row)
    cap = float(spec["selection_rule"]["maximum_condition_mean_reserve_violation_rate"])
    degradation_cap = float(
        spec["selection_rule"]["maximum_mean_unmet_degradation_fraction_vs_hybrid"]
    )
    grid_rows = []
    for grid_id in spec["development_grid"]:
        eligible = True
        cells = []
        da_unmet_values = []
        da_report_values = []
        for condition in spec["phases"]["development"]["conditions"]:
            hybrid = grouped[(grid_id, condition, "e6_hybrid_direct")]
            proposed = grouped[(grid_id, condition, "e6_da_ies_s")]
            hybrid_unmet = float(
                np.mean([item["cumulative_unmet_visible_demand_j"] for item in hybrid])
            )
            da_unmet = float(
                np.mean([item["cumulative_unmet_visible_demand_j"] for item in proposed])
            )
            da_report = float(
                np.mean([item["average_reporting_debit_j_per_slot"] for item in proposed])
            )
            da_reserve = float(
                np.mean([item["payer_reserve_violation_rate"] for item in proposed])
            )
            degradation = (da_unmet - hybrid_unmet) / max(1e-12, hybrid_unmet)
            cell_eligible = da_reserve <= cap and degradation <= degradation_cap
            eligible = eligible and cell_eligible
            da_unmet_values.append(da_unmet)
            da_report_values.append(da_report)
            cells.append(
                {
                    "condition": condition,
                    "eligible": cell_eligible,
                    "da_ies_s_unmet_j": da_unmet,
                    "hybrid_unmet_j": hybrid_unmet,
                    "unmet_degradation_fraction": degradation,
                    "da_ies_s_report_j_per_slot": da_report,
                    "da_ies_s_reserve_violation_rate": da_reserve,
                    "da_ies_s_opportunity_slot_fraction": float(
                        np.mean(
                            [
                                item["opportunity_return_slot_fraction"]
                                for item in proposed
                            ]
                        )
                    ),
                }
            )
        grid_rows.append(
            {
                "grid_id": grid_id,
                "eligible_all_conditions": eligible,
                "mean_da_ies_s_unmet_j": float(np.mean(da_unmet_values)),
                "mean_da_ies_s_reporting_j_per_slot": float(
                    np.mean(da_report_values)
                ),
                "cells": cells,
            }
        )
    candidates = [row for row in grid_rows if row["eligible_all_conditions"]]
    if not candidates:
        raise RuntimeError("no development grid satisfies the pre-registered eligibility rule")
    selected = min(
        candidates,
        key=lambda row: (
            row["mean_da_ies_s_unmet_j"],
            row["mean_da_ies_s_reporting_j_per_slot"],
            row["grid_id"],
        ),
    )
    result = {
        "schema_version": "e6-v2-development-selection-v1",
        "scientific_status": SCIENTIFIC_STATUS,
        "formal_results_seen_before_selection": False,
        "selection_rule": spec["selection_rule"],
        "selected_grid_id": selected["grid_id"],
        "selected_overrides": spec["development_grid"][selected["grid_id"]],
        "grid_results": grid_rows,
    }
    path = output / "development_selection.json"
    write_json(path, result)
    print(json.dumps(result, indent=2, sort_keys=True))
    return path


def validate_selection(config_path: Path, output: Path) -> Path:
    spec = load_spec(config_path)
    rows = _phase_summaries(output, "validation")
    expected = (
        len(spec["phases"]["validation"]["conditions"])
        * int(spec["phases"]["validation"]["seed_count"])
        * len(spec["phases"]["validation"]["methods"])
    )
    if len(rows) != expected:
        raise RuntimeError(f"validation requires {expected} summaries, found {len(rows)}")
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["condition"], row["method"])].append(row)
    cap = float(spec["selection_rule"]["maximum_condition_mean_reserve_violation_rate"])
    degradation_cap = float(
        spec["selection_rule"]["maximum_mean_unmet_degradation_fraction_vs_hybrid"]
    )
    cells = []
    for condition in spec["phases"]["validation"]["conditions"]:
        hybrid = grouped[(condition, "e6_hybrid_direct")]
        proposed = grouped[(condition, "e6_da_ies_s")]
        hybrid_unmet = float(
            np.mean([item["cumulative_unmet_visible_demand_j"] for item in hybrid])
        )
        da_unmet = float(
            np.mean([item["cumulative_unmet_visible_demand_j"] for item in proposed])
        )
        reserve = float(
            np.mean([item["payer_reserve_violation_rate"] for item in proposed])
        )
        opportunity = float(
            np.mean([item["opportunity_return_slot_fraction"] for item in proposed])
        )
        degradation = (da_unmet - hybrid_unmet) / max(1e-12, hybrid_unmet)
        cells.append(
            {
                "condition": condition,
                "reserve_pass": reserve <= cap,
                "service_noninferiority_pass": degradation <= degradation_cap,
                "mechanism_activated": opportunity > 0.0,
                "da_ies_s_unmet_j": da_unmet,
                "hybrid_unmet_j": hybrid_unmet,
                "unmet_degradation_fraction": degradation,
                "da_ies_s_reserve_violation_rate": reserve,
                "da_ies_s_opportunity_slot_fraction": opportunity,
            }
        )
    checks = {
        "reserve_cap_all_conditions": all(cell["reserve_pass"] for cell in cells),
        "service_noninferiority_all_conditions": all(
            cell["service_noninferiority_pass"] for cell in cells
        ),
        "mechanism_activated_in_at_least_two_conditions": sum(
            cell["mechanism_activated"] for cell in cells
        )
        >= 2,
    }
    result = {
        "schema_version": "e6-v2-validation-gate-v1",
        "scientific_status": SCIENTIFIC_STATUS,
        "selected_grid_id": selected_grid(output),
        "formal_authorized": all(checks.values()),
        "checks": checks,
        "cells": cells,
    }
    path = output / "validation_gate.json"
    write_json(path, result)
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["formal_authorized"]:
        raise SystemExit(1)
    return path


def freeze(config_path: Path, output: Path) -> Path:
    spec = load_spec(config_path)
    validate_registry(spec)
    validation_path = output / "validation_gate.json"
    if not validation_path.exists():
        raise RuntimeError("validation_gate.json is required before freeze")
    validation = json.loads(validation_path.read_text(encoding="utf-8"))
    if validation.get("formal_authorized") is not True:
        raise RuntimeError("validation did not authorize held-out execution")
    raw = output / "held_out" / "raw"
    if raw.exists() and any(raw.rglob("slots.jsonl.gz")):
        raise RuntimeError("refusing to freeze after held-out raw output exists")
    held = spec["phases"]["held_out"]
    if tuple(held["methods"]) != E6_METHODS:
        raise RuntimeError("held-out method order differs from E6 registry")
    expected = (
        len(held["conditions"])
        * int(held["seed_count"])
        * len(held["methods"])
    )
    if expected != int(held["expected_trajectories"]):
        raise RuntimeError("held-out trajectory count is inconsistent")
    manifest = {
        "schema_version": "e6-v2-held-out-prerun-freeze-v1",
        "scientific_status": SCIENTIFIC_STATUS,
        **input_hashes(config_path, output),
        "selected_grid_id": selected_grid(output),
        "conditions": held["conditions"],
        "methods": held["methods"],
        "held_out_seed_rows": seed_rows(spec, "held_out"),
        "expected_trajectories": expected,
        "expected_slot_rows": int(held["expected_slot_rows"]),
        "formal_results_seen_before_freeze": False,
    }
    path = output / "e6_v2_prerun_manifest.json"
    write_json(path, manifest)
    print(path)
    return path


def verify_freeze(config_path: Path, output: Path) -> dict[str, Any]:
    path = output / "e6_v2_prerun_manifest.json"
    if not path.exists():
        raise RuntimeError("held-out run requires e6_v2_prerun_manifest.json")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    current = input_hashes(config_path, output)
    mismatches = [key for key, value in current.items() if manifest.get(key) != value]
    if mismatches:
        raise RuntimeError("frozen v2 inputs changed: " + ", ".join(mismatches))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command",
        choices=(
            "development",
            "select",
            "validation",
            "validate",
            "freeze",
            "held-out",
            "status",
        ),
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    parser.add_argument("--condition")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--method", choices=E6_METHODS)
    args = parser.parse_args()
    config_path = args.config.resolve()
    output = args.output.resolve()
    if args.command in {"development", "validation", "held-out"}:
        phase = "held_out" if args.command == "held-out" else args.command
        run_phase(
            config_path,
            output,
            phase,
            args.workers,
            args.condition,
            args.seed,
            args.method,
        )
    elif args.command == "select":
        select_development(config_path, output)
    elif args.command == "validate":
        validate_selection(config_path, output)
    elif args.command == "freeze":
        freeze(config_path, output)
    else:
        manifest = verify_freeze(config_path, output)
        print(
            json.dumps(
                {
                    "freeze_verified": True,
                    "indexed_held_out_trajectories": _write_index(
                        output, "held_out"
                    ),
                    "expected_trajectories": manifest["expected_trajectories"],
                },
                indent=2,
            )
        )


if __name__ == "__main__":
    main()

