#!/usr/bin/env python3
"""Audit the frozen E6 v2 held-out seed, trace, raw and accounting invariants."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_e6_mechanism_stress_v2 import (  # noqa: E402
    DEFAULT_CONFIG,
    DEFAULT_OUTPUT,
    load_spec,
    seed_rows,
    verify_freeze,
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit(output: Path) -> dict[str, object]:
    freeze = verify_freeze(DEFAULT_CONFIG, output)
    spec = load_spec(DEFAULT_CONFIG)
    held = spec["phases"]["held_out"]
    index_path = output / "held_out" / "trajectory_index.csv"
    with index_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    conditions = set(held["conditions"])
    methods = set(held["methods"])
    held_seeds = {row["seed_value"] for row in seed_rows(spec, "held_out")}
    nonformal = {
        row["seed_value"]
        for split in ("development", "validation")
        for row in seed_rows(spec, split)
    }
    expected = int(held["expected_trajectories"])
    expected_slots = int(held["slots"])
    cells: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    raw_hash_errors = []
    slot_errors = []
    record_identity_errors = []
    max_residual = 0.0
    observed_slots = 0
    for row in rows:
        condition = row["condition"]
        seed = int(row["seed"])
        cells[(condition, seed)].append(row)
        path = ROOT / row["raw_relative_path"]
        if not path.is_file() or _sha256(path) != row["raw_sha256"]:
            raw_hash_errors.append(row["trajectory_id"])
            continue
        count = 0
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                record = json.loads(line)
                count += 1
                if (
                    record["seed"] != seed
                    or record["method"] != row["method"]
                    or record["scenario"]
                    != f"e6-v2:held_out:{condition}:{row['grid_id']}"
                ):
                    record_identity_errors.append(row["trajectory_id"])
                    break
                max_residual = max(
                    max_residual,
                    max(
                        abs(float(value))
                        for value in record["executor_ledger"][
                            "conservation_residual_j"
                        ]
                    ),
                )
        observed_slots += count
        if count != expected_slots:
            slot_errors.append(
                {"trajectory_id": row["trajectory_id"], "slot_rows": count}
            )
    method_errors = []
    trace_errors = []
    config_errors = []
    for (condition, seed), group in sorted(cells.items()):
        if {row["method"] for row in group} != methods or len(group) != len(methods):
            method_errors.append({"condition": condition, "seed": seed})
        if len({row["trace_hash"] for row in group}) != 1:
            trace_errors.append({"condition": condition, "seed": seed})
        if len({row["config_hash"] for row in group}) != 1:
            config_errors.append({"condition": condition, "seed": seed})
    duplicate_ids = [
        value
        for value, count in Counter(row["trajectory_id"] for row in rows).items()
        if count != 1
    ]
    checks = {
        "freeze_hashes_match": True,
        "trajectory_count_exact": len(rows) == expected,
        "trajectory_ids_unique": not duplicate_ids,
        "condition_set_exact": {row["condition"] for row in rows} == conditions,
        "held_out_seed_set_exact": {int(row["seed"]) for row in rows}
        == held_seeds,
        "held_out_seeds_disjoint_from_development_validation": held_seeds.isdisjoint(
            nonformal
        ),
        "method_set_exact": {row["method"] for row in rows} == methods,
        "condition_seed_cell_count_exact": len(cells)
        == len(conditions) * len(held_seeds),
        "seven_methods_per_cell": not method_errors,
        "one_trace_hash_per_cell": not trace_errors,
        "one_config_hash_per_cell": not config_errors,
        "raw_sha256_all_match": not raw_hash_errors,
        "slot_rows_all_exact": not slot_errors,
        "record_identity_exact": not record_identity_errors,
        "conservation_residual_within_tolerance": max_residual
        <= float(spec["integrity"]["maximum_conservation_residual_j"]),
    }
    result = {
        "schema_version": "e6-v2-held-out-integrity-audit-v1",
        "scientific_status": spec["experiment"]["status"],
        "passed": all(checks.values()),
        "checks": checks,
        "expected_trajectories": expected,
        "observed_trajectories": len(rows),
        "expected_slot_rows": int(freeze["expected_slot_rows"]),
        "observed_slot_rows": observed_slots,
        "condition_seed_cells": len(cells),
        "maximum_conservation_residual_j": max_residual,
        "errors": {
            "duplicate_trajectory_ids": duplicate_ids,
            "cell_method_errors": method_errors,
            "trace_hash_errors": trace_errors,
            "config_hash_errors": config_errors,
            "raw_hash_errors": raw_hash_errors,
            "slot_errors": slot_errors,
            "record_identity_errors": sorted(set(record_identity_errors)),
        },
    }
    path = output / "held_out" / "e6_v2_integrity_audit.json"
    path.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["passed"]:
        raise SystemExit(1)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    audit(args.output.resolve())


if __name__ == "__main__":
    main()

