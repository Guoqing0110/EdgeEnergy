#!/usr/bin/env python3
"""Recompute E6 v2 tables and registered paired intervals from held-out raw data."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_e6_mechanism_stress_v2 import (  # noqa: E402
    DEFAULT_CONFIG,
    DEFAULT_OUTPUT,
    load_spec,
)

METRICS = (
    "cumulative_unmet_visible_demand_j",
    "unmet_fraction",
    "node_service_continuity_fraction",
    "average_reporting_debit_j_per_slot",
    "payer_reserve_violation_rate",
    "post_belief_rmse_j",
    "opportunity_return_slot_fraction",
    "delivered_report_fields_per_slot",
)

LABELS = {
    "e6_age_direct": "Age direct",
    "e6_uncertainty_direct": "Uncertainty direct",
    "e6_full_voei_direct": "Full-VoEI direct",
    "e6_hybrid_direct": "Hybrid direct",
    "e6_age_uncertainty_direct": "Age-of-uncertainty adaptation",
    "e6_usefulness_direct": "Usefulness adaptation",
    "e6_da_ies_s": "DA-IES-S",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_index(output: Path) -> list[dict[str, str]]:
    path = output / "held_out" / "trajectory_index.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _raw_metrics(row: dict[str, str]) -> dict[str, object]:
    path = ROOT / row["raw_relative_path"]
    if _sha256(path) != row["raw_sha256"]:
        raise RuntimeError(f"raw SHA-256 mismatch: {path}")
    unmet = 0.0
    demand = 0.0
    continuity = []
    report = 0.0
    reserve_events = 0
    payer_checks = 0
    squared_errors = []
    opportunity = 0
    delivered = 0
    slots = 0
    max_residual = 0.0
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            record = json.loads(line)
            slots += 1
            unmet += float(record["outcomes"]["unmet_visible_demand_j"])
            demand += float(record["outcomes"]["visible_demand_j"])
            continuity.append(
                float(record["outcomes"]["node_service_met_fraction"])
            )
            report += float(record["outcomes"]["reporting_sensor_debit_j"])
            reserve_events += int(
                record["outcomes"]["payer_reserve_violation_count"]
            )
            payer_checks += int(record["outcomes"]["payer_count"])
            squared_errors.extend(
                float(value) ** 2
                for value in record["offline_evaluation"]["belief_error_j"]
            )
            opportunity += (
                record["decision"]["action"]["return_mode"] == "opportunity"
            )
            delivered += int(record["outcomes"]["report_delivered_fields"])
            max_residual = max(
                max_residual,
                max(
                    abs(float(value))
                    for value in record["executor_ledger"]["conservation_residual_j"]
                ),
            )
    if slots == 0:
        raise RuntimeError(f"empty raw trajectory: {path}")
    return {
        "trajectory_id": row["trajectory_id"],
        "condition": row["condition"],
        "seed_id": row["seed_id"],
        "seed": int(row["seed"]),
        "method": row["method"],
        "slot_rows": slots,
        "trace_hash": row["trace_hash"],
        "cumulative_unmet_visible_demand_j": unmet,
        "total_visible_demand_j": demand,
        "unmet_fraction": unmet / demand if demand else 0.0,
        "node_service_continuity_fraction": float(np.mean(continuity)),
        "average_reporting_debit_j_per_slot": report / slots,
        "payer_reserve_violation_rate": reserve_events / payer_checks
        if payer_checks
        else 0.0,
        "post_belief_rmse_j": float(np.sqrt(np.mean(squared_errors))),
        "opportunity_return_slot_fraction": opportunity / slots,
        "delivered_report_fields_per_slot": delivered / slots,
        "maximum_conservation_residual_j": max_residual,
    }


def _bootstrap(
    values: np.ndarray, resamples: int, seed: int
) -> tuple[float, float, float]:
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(resamples, values.size))
    means = np.mean(values[indices], axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(np.mean(values)), float(low), float(high)


def aggregate(output: Path) -> dict[str, object]:
    spec = load_spec(DEFAULT_CONFIG)
    held = spec["phases"]["held_out"]
    index = _read_index(output)
    expected = int(held["expected_trajectories"])
    if len(index) != expected:
        raise RuntimeError(f"expected {expected} indexed trajectories, found {len(index)}")
    frame = pd.DataFrame([_raw_metrics(row) for row in index])
    processed = output / "held_out" / "processed"
    processed.mkdir(parents=True, exist_ok=True)
    frame.to_csv(processed / "trajectory_metrics_from_raw.csv", index=False)

    condition = frame.groupby(["condition", "method"], as_index=False)[
        list(METRICS)
    ].mean()
    condition.to_csv(processed / "condition_method_summary.csv", index=False)
    seed_mean = frame.groupby(["seed_id", "seed", "method"], as_index=False)[
        list(METRICS)
    ].mean()
    seed_mean.to_csv(processed / "seed_condition_averaged_metrics.csv", index=False)

    table_rows = []
    for method in held["methods"]:
        values = seed_mean[seed_mean["method"] == method]
        cond_values = condition[condition["method"] == method]
        table_rows.append(
            {
                "method": method,
                "policy": LABELS[method],
                "unmet_kj": values["cumulative_unmet_visible_demand_j"].mean()
                / 1000.0,
                "unmet_fraction_percent": values["unmet_fraction"].mean() * 100.0,
                "node_continuity": values[
                    "node_service_continuity_fraction"
                ].mean(),
                "report_mj_per_slot": values[
                    "average_reporting_debit_j_per_slot"
                ].mean()
                * 1000.0,
                "max_condition_mean_reserve_percent": cond_values[
                    "payer_reserve_violation_rate"
                ].max()
                * 100.0,
                "belief_rmse_j": values["post_belief_rmse_j"].mean(),
                "opportunity_slot_percent": values[
                    "opportunity_return_slot_fraction"
                ].mean()
                * 100.0,
            }
        )
    table = pd.DataFrame(table_rows)
    table.to_csv(processed / "table_e6_v2_mechanism_stress.csv", index=False)

    resamples = int(spec["confirmatory_hypotheses"]["bootstrap_resamples"])
    proposed = "e6_da_ies_s"
    contrasts = []
    for method_index, method in enumerate(held["methods"]):
        if method == proposed:
            continue
        for metric_index, metric in enumerate(METRICS):
            pivot = seed_mean.pivot(index="seed", columns="method", values=metric)
            differences = (pivot[proposed] - pivot[method]).to_numpy(float)
            mean, low, high = _bootstrap(
                differences,
                resamples,
                2026111900 + method_index * 100 + metric_index,
            )
            contrasts.append(
                {
                    "contrast": f"DA-IES-S minus {LABELS[method]}",
                    "comparator": method,
                    "metric": metric,
                    "mean_difference": mean,
                    "ci95_low": low,
                    "ci95_high": high,
                    "paired_seeds": len(differences),
                }
            )
    contrasts_frame = pd.DataFrame(contrasts)
    contrasts_frame.to_csv(
        processed / "paired_seed_bootstrap_contrasts.csv", index=False
    )

    condition_contrasts = []
    for condition_name in held["conditions"]:
        subset = frame[frame["condition"] == condition_name]
        for method_index, method in enumerate(held["methods"]):
            if method == proposed:
                continue
            for metric_index, metric in enumerate(
                ("unmet_fraction", "average_reporting_debit_j_per_slot")
            ):
                pivot = subset.pivot(index="seed", columns="method", values=metric)
                differences = (pivot[proposed] - pivot[method]).to_numpy(float)
                mean, low, high = _bootstrap(
                    differences,
                    resamples,
                    2026112900
                    + held["conditions"].index(condition_name) * 100
                    + method_index * 10
                    + metric_index,
                )
                condition_contrasts.append(
                    {
                        "condition": condition_name,
                        "comparator": method,
                        "metric": metric,
                        "mean_difference": mean,
                        "ci95_low": low,
                        "ci95_high": high,
                    }
                )
    pd.DataFrame(condition_contrasts).to_csv(
        processed / "condition_paired_contrasts.csv", index=False
    )

    def contrast(metric: str, comparator: str) -> dict[str, float]:
        row = contrasts_frame[
            (contrasts_frame["metric"] == metric)
            & (contrasts_frame["comparator"] == comparator)
        ].iloc[0]
        return {
            "mean": float(row["mean_difference"]),
            "ci95_low": float(row["ci95_low"]),
            "ci95_high": float(row["ci95_high"]),
        }

    margin = float(
        spec["confirmatory_hypotheses"][
            "service_noninferiority_margin_fraction_of_visible_demand"
        ]
    )
    hybrid_report = contrast(
        "average_reporting_debit_j_per_slot", "e6_hybrid_direct"
    )
    hybrid_unmet_fraction = contrast("unmet_fraction", "e6_hybrid_direct")
    proposed_condition = condition[condition["method"] == proposed]
    primary_checks = {
        "reporting_ci_upper_below_zero_vs_hybrid": hybrid_report["ci95_high"]
        < 0.0,
        "service_noninferiority_vs_hybrid": hybrid_unmet_fraction["ci95_high"]
        <= margin,
        "reserve_risk_at_most_0_03_each_condition": bool(
            (
                proposed_condition["payer_reserve_violation_rate"] <= 0.03 + 1e-12
            ).all()
        ),
        "opportunity_return_observed": bool(
            (proposed_condition["opportunity_return_slot_fraction"] > 0.0).any()
        ),
    }
    hypothesis = {
        "schema_version": "e6-v2-confirmatory-hypothesis-report-v1",
        "primary_passed": all(primary_checks.values()),
        "primary_checks": primary_checks,
        "hybrid_reporting_contrast_j_per_slot": hybrid_report,
        "hybrid_unmet_fraction_contrast": hybrid_unmet_fraction,
        "service_noninferiority_margin_fraction": margin,
        "age_unmet_contrast_j": contrast(
            "cumulative_unmet_visible_demand_j", "e6_age_direct"
        ),
        "full_voei_unmet_contrast_j": contrast(
            "cumulative_unmet_visible_demand_j", "e6_full_voei_direct"
        ),
        "usefulness_unmet_contrast_j": contrast(
            "cumulative_unmet_visible_demand_j", "e6_usefulness_direct"
        ),
        "usefulness_max_condition_reserve_rate": float(
            condition[condition["method"] == "e6_usefulness_direct"][
                "payer_reserve_violation_rate"
            ].max()
        ),
    }
    (processed / "confirmatory_hypothesis_report.json").write_text(
        json.dumps(hypothesis, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    report = {
        "schema_version": "e6-v2-held-out-aggregation-v1",
        "scientific_status": spec["experiment"]["status"],
        "trajectories": len(frame),
        "slot_rows": int(frame["slot_rows"].sum()),
        "condition_seed_cells": int(frame.groupby(["condition", "seed"]).ngroups),
        "maximum_conservation_residual_j": float(
            frame["maximum_conservation_residual_j"].max()
        ),
        "primary_hypotheses_passed": hypothesis["primary_passed"],
        "outputs": [
            "trajectory_metrics_from_raw.csv",
            "condition_method_summary.csv",
            "seed_condition_averaged_metrics.csv",
            "table_e6_v2_mechanism_stress.csv",
            "paired_seed_bootstrap_contrasts.csv",
            "condition_paired_contrasts.csv",
            "confirmatory_hypothesis_report.json",
        ],
    }
    (processed / "aggregation_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"aggregation": report, "hypotheses": hypothesis}, indent=2))
    return {"aggregation": report, "hypotheses": hypothesis}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    aggregate(args.output.resolve())


if __name__ == "__main__":
    main()

