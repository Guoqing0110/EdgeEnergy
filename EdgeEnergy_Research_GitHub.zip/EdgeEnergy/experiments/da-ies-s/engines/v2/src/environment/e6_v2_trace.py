"""Policy-independent structured multi-hop traces for the E6 v2 extension."""

from __future__ import annotations

from typing import Any

import numpy as np

from src.environment.trace import ExogenousTrace, generate_trace


def _pairwise_distances(points: np.ndarray) -> np.ndarray:
    delta = points[:, None, :] - points[None, :, :]
    return np.sqrt(np.sum(delta * delta, axis=-1))


def generate_e6_v2_trace(
    config: dict[str, Any], seed: int, condition: str
) -> ExogenousTrace:
    """Generate a registered corridor trace shared by every compared method.

    The stochastic arrays originate from the common trace generator.  This
    function replaces only the topology and applies condition-declared,
    policy-independent energy/load/link transformations.
    """

    base = generate_trace(config, seed)
    trace_cfg = config["e6_v2_trace"]
    rows = int(trace_cfg["rows"])
    columns = int(trace_cfg["columns"])
    if rows * columns != base.node_count:
        raise ValueError("e6_v2_trace rows*columns must equal node_count")

    rng_position, rng_energy = [
        np.random.default_rng(child)
        for child in np.random.SeedSequence([int(seed), 62002]).spawn(2)
    ]
    positions = np.zeros((base.node_count, 2), dtype=float)
    for row in range(rows):
        for column in range(columns):
            node = row * columns + column
            positions[node] = (
                float(trace_cfg["x_origin_m"])
                + column * float(trace_cfg["x_spacing_m"]),
                float(trace_cfg["y_origin_m"])
                + row * float(trace_cfg["y_spacing_m"]),
            )
    positions += rng_position.uniform(
        -float(trace_cfg["position_jitter_m"]),
        float(trace_cfg["position_jitter_m"]),
        size=positions.shape,
    )
    sink_position = np.asarray(
        [0.0, float(trace_cfg["y_origin_m"]) + float(trace_cfg["y_spacing_m"])],
        dtype=float,
    )
    all_positions = np.vstack([positions, sink_position])
    comm_dist = _pairwise_distances(all_positions)
    wet_dist = _pairwise_distances(positions)
    comm_range = float(config["communication"]["range_m"])
    wet_range = float(config["wet"]["range_m"])
    comm_adjacency = (comm_dist <= comm_range) & (comm_dist > 0.0)
    wet_adjacency = (wet_dist <= wet_range) & (wet_dist > 0.0)

    capacity = float(config["energy"]["capacity_j"])
    column_index = np.tile(np.arange(columns, dtype=float), rows)
    distance_fraction = column_index / max(1.0, columns - 1.0)
    initial_fraction = (
        float(trace_cfg["near_initial_fraction"])
        + distance_fraction
        * (
            float(trace_cfg["far_initial_fraction"])
            - float(trace_cfg["near_initial_fraction"])
        )
        + rng_energy.uniform(
            -float(trace_cfg["initial_jitter_fraction"]),
            float(trace_cfg["initial_jitter_fraction"]),
            base.node_count,
        )
    )
    relay_columns = {int(value) for value in trace_cfg["relay_columns"]}
    relay_mask = np.asarray(
        [int(column) in relay_columns for column in column_index], dtype=bool
    )
    initial_fraction[relay_mask] *= float(trace_cfg["relay_initial_multiplier"])
    initial_energy = capacity * np.clip(initial_fraction, 0.18, 0.62)

    far_load = 1.0 + distance_fraction * (
        float(trace_cfg["far_load_multiplier"]) - 1.0
    )
    visible_load = base.visible_load * far_load[None, :]
    hidden_load = base.hidden_load * far_load[None, :]
    hidden_load[:, relay_mask] *= float(trace_cfg["relay_hidden_load_multiplier"])

    far_harvest = 1.0 + distance_fraction * (
        float(trace_cfg["far_harvest_multiplier"]) - 1.0
    )
    harvest_expected = base.harvest_expected * far_harvest[None, :]
    harvest_actual = base.harvest_actual * far_harvest[None, :]
    harvest_expected[:, relay_mask] *= float(trace_cfg["relay_harvest_multiplier"])
    harvest_actual[:, relay_mask] *= float(trace_cfg["relay_harvest_multiplier"])

    normalized = np.clip(comm_dist / comm_range, 0.0, 1.0)
    p_hi = float(config["communication"]["max_link_success"])
    p_lo = float(config["communication"]["min_link_success"])
    probability = p_hi - (p_hi - p_lo) * normalized
    probability[~comm_adjacency] = 0.0
    np.fill_diagonal(probability, 1.0)
    if bool(trace_cfg.get("apply_bottleneck_loss", False)):
        multiplier = float(trace_cfg["bottleneck_edge_success_multiplier"])
        sensor_columns = np.concatenate([column_index, np.asarray([-1.0])])
        for sender in range(base.node_count + 1):
            for receiver in range(base.node_count + 1):
                if not comm_adjacency[sender, receiver]:
                    continue
                pair = {int(sensor_columns[sender]), int(sensor_columns[receiver])}
                if pair == {2, 3}:
                    probability[sender, receiver] *= multiplier
    probability = np.clip(probability, 0.0, 1.0)

    return ExogenousTrace(
        seed=int(seed),
        positions=positions,
        sink_position=sink_position,
        initial_energy=initial_energy,
        harvest_expected=harvest_expected,
        harvest_actual=harvest_actual,
        visible_load=visible_load,
        hidden_load=hidden_load,
        measurement_noise=base.measurement_noise,
        comm_adjacency=comm_adjacency,
        wet_adjacency=wet_adjacency,
        comm_success_probability=probability,
        comm_success_uniform=base.comm_success_uniform,
    )

