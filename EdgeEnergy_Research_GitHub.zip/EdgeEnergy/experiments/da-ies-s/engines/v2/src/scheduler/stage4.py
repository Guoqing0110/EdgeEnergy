"""Belief-causal Stage 4 queue-aware energy/report co-scheduler.

This module contains no physical state type and accepts no hidden load, future
harvest, future link state or offline truth argument. The full-state method is
constructed by the executor as an explicitly labelled ideal reference snapshot.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Any

import numpy as np

from src.communication_model.model import (
    CommunicationPlan,
    PlannedCommunicationCost,
    empty_plan,
    estimate_plan_cost,
)
from src.energy_model.model import wet_efficiency
from src.guard.reserve import assess_candidate
from src.guard.risk_calibrated import assess_risk_calibrated_candidate
from src.information_value.voei import (
    DecisionAction,
    DecisionBelief,
    build_candidate_actions,
    full_decision_aware_voei,
)
from src.reporting.planner import build_communication_plan
from src.scheduler.types import Action, OnlineSnapshot, null_action


@dataclass(frozen=True)
class Stage4Queues:
    service_j: tuple[float, ...]
    report_j: float
    wet_j: float
    donor_j: tuple[float, ...]


@dataclass(frozen=True)
class Stage4Decision:
    action: Action
    report_plan: CommunicationPlan
    planned_report: PlannedCommunicationCost
    planned_wet_debits_j: dict[int, float]
    wet_objective: float
    wet_candidate_count: int
    guard_rejected_wet_candidates: int
    information_scores: tuple[float, ...]
    report_strategy: str
    report_due: bool


METHODS = (
    "b0_no_wet_periodic_direct",
    "b1_last_value_greedy_periodic_direct",
    "b2_deterministic_greedy_periodic_direct",
    "b3_uncertainty_greedy_uncertainty_direct",
    "b4_queue_belief_age_direct",
    "b5_queue_belief_full_voei_direct",
    "b6_queue_belief_collect_all_eetor",
    "b7_queue_belief_full_voei_eetor",
    "b8_full_state_queue_oracle",
)

DA_IES_S_METHOD = "p_da_ies_s"

# Independently reconstructed E6 matched-policy controls.  These identifiers
# were not present in the recovered July runner; they are explicit v1
# implementations of the policy definitions frozen in the R6 manuscript.
E6_AGE_DIRECT = "e6_age_direct"
E6_UNCERTAINTY_DIRECT = "e6_uncertainty_direct"
E6_FULL_VOEI_DIRECT = "e6_full_voei_direct"
E6_HYBRID_DIRECT = "e6_hybrid_direct"
E6_AGE_UNCERTAINTY_DIRECT = "e6_age_uncertainty_direct"
E6_USEFULNESS_DIRECT = "e6_usefulness_direct"
E6_DA_IES_S = "e6_da_ies_s"
E6_METHODS = (
    E6_AGE_DIRECT,
    E6_UNCERTAINTY_DIRECT,
    E6_FULL_VOEI_DIRECT,
    E6_HYBRID_DIRECT,
    E6_AGE_UNCERTAINTY_DIRECT,
    E6_USEFULNESS_DIRECT,
    E6_DA_IES_S,
)

# Post-hoc fresh-seed bridge controls for attribution only. These are kept out
# of the frozen Stage 6 comparison and do not alter any released result.
BRIDGE_WIDE_AGE = "x_wide_age_direct"
BRIDGE_WIDE_RCPG_AGE = "x_wide_rcpg_age_direct"
BRIDGE_WIDE_RCPG_HYBRID_DIRECT = "x_wide_rcpg_hybrid_direct"


def method_spec(method: str) -> tuple[str, str, str]:
    """Return estimator, WET rule and report strategy."""

    table = {
        "b0_no_wet_periodic_direct": ("last_value", "none", "periodic_direct"),
        "b1_last_value_greedy_periodic_direct": (
            "last_value",
            "greedy",
            "periodic_direct",
        ),
        "b2_deterministic_greedy_periodic_direct": (
            "deterministic_twin",
            "greedy",
            "periodic_direct",
        ),
        "b3_uncertainty_greedy_uncertainty_direct": (
            "uncertainty_twin",
            "greedy",
            "uncertainty_direct",
        ),
        "b4_queue_belief_age_direct": ("uncertainty_twin", "queue", "age_direct"),
        "b5_queue_belief_full_voei_direct": (
            "uncertainty_twin",
            "queue",
            "full_voei_direct",
        ),
        "b6_queue_belief_collect_all_eetor": (
            "uncertainty_twin",
            "queue",
            "collect_all_eetor",
        ),
        "b7_queue_belief_full_voei_eetor": (
            "uncertainty_twin",
            "queue",
            "full_voei_eetor",
        ),
        "b8_full_state_queue_oracle": ("full_state_oracle", "queue", "none"),
        BRIDGE_WIDE_AGE: ("uncertainty_twin", "queue", "age_direct"),
        BRIDGE_WIDE_RCPG_AGE: ("uncertainty_twin", "queue_safe", "age_direct_rcpg"),
        BRIDGE_WIDE_RCPG_HYBRID_DIRECT: (
            "uncertainty_twin", "queue_safe", "adaptive_hybrid_direct"
        ),
        DA_IES_S_METHOD: ("uncertainty_twin", "queue_safe", "adaptive_hybrid"),
        E6_AGE_DIRECT: ("uncertainty_twin", "queue_safe", "age_direct_rcpg"),
        E6_UNCERTAINTY_DIRECT: (
            "uncertainty_twin", "queue_safe", "uncertainty_direct_rcpg"
        ),
        E6_FULL_VOEI_DIRECT: (
            "uncertainty_twin", "queue_safe", "full_voei_direct_rcpg"
        ),
        E6_HYBRID_DIRECT: (
            "uncertainty_twin", "queue_safe", "adaptive_hybrid_direct"
        ),
        E6_AGE_UNCERTAINTY_DIRECT: (
            "uncertainty_twin", "queue_safe", "age_uncertainty_direct_rcpg"
        ),
        E6_USEFULNESS_DIRECT: (
            "uncertainty_twin", "queue_safe", "usefulness_direct_rcpg"
        ),
        E6_DA_IES_S: ("uncertainty_twin", "queue_safe", "adaptive_hybrid"),
    }
    if method not in table:
        raise ValueError(f"unsupported Stage 4 method: {method}")
    return table[method]


def snapshot_to_decision_belief(
    snapshot: OnlineSnapshot, capacity_j: float
) -> DecisionBelief:
    return DecisionBelief(
        mean_j=np.asarray([node.mean_j for node in snapshot.nodes], dtype=float),
        std_j=np.sqrt(
            np.asarray([max(0.0, node.variance_j2) for node in snapshot.nodes], dtype=float)
        ),
        lower_j=np.asarray([node.lower_j for node in snapshot.nodes], dtype=float),
        age=np.asarray([node.age for node in snapshot.nodes], dtype=int),
        capacity_j=float(capacity_j),
        reserve_j=float(snapshot.reserve_j),
        positions=np.asarray(snapshot.positions, dtype=float),
        wet_adjacency=snapshot.wet_adjacency,
    )


def wet_debits(
    action: DecisionAction, positions: np.ndarray, wet_config: dict[str, Any]
) -> tuple[dict[int, float], float]:
    if action.amount_j <= 0.0 or len(action.path) < 2:
        return {}, 0.0
    amount = float(action.amount_j)
    gross: dict[int, float] = {}
    for sender, receiver in zip(action.path[:-1], action.path[1:]):
        gross[sender] = gross.get(sender, 0.0) + amount
        distance = float(np.linalg.norm(positions[sender] - positions[receiver]))
        amount *= wet_efficiency(distance, wet_config)
    return gross, amount


def _as_action(action: DecisionAction) -> Action:
    if action.amount_j <= 0.0 or action.donor is None or action.receiver is None:
        return null_action()
    return Action(
        receiver=action.receiver,
        donor=action.donor,
        wet_path=action.path,
        amount_j=action.amount_j,
        state_subset=(),
        return_mode="none",
    )


def _wet_choice(
    snapshot: OnlineSnapshot,
    current_visible_demand_j: np.ndarray,
    queues: Stage4Queues,
    wet_rule: str,
    config: dict[str, Any],
) -> tuple[DecisionAction, float, int, int, tuple[DecisionAction, ...]]:
    belief = snapshot_to_decision_belief(snapshot, float(config["energy"]["capacity_j"]))
    candidates = build_candidate_actions(belief, config)
    if wet_rule == "none":
        return candidates[0], 0.0, len(candidates), 0, candidates

    scale = float(config["stage4"]["wet_amount_scale_j"])
    capacity = float(config["energy"]["capacity_j"])
    target = capacity * float(config["stage4"]["energy_target_fraction"])
    horizon_scale = max(
        1.0,
        float(config["energy"]["visible_load_mean_j"])
        * float(config["simulation"]["slots"]),
    )
    q_service = np.asarray(queues.service_j, dtype=float) / horizon_scale
    q_donor = np.asarray(queues.donor_j, dtype=float) / max(
        1.0,
        float(config["stage4"]["donor_average_budget_j_per_slot"])
        * float(config["simulation"]["slots"]),
    )
    q_wet = float(queues.wet_j) / max(
        1.0,
        float(config["stage4"]["wet_average_budget_j_per_slot"])
        * float(config["simulation"]["slots"]),
    )
    margin = float(config["belief"]["guard_margin_j"])
    positions = np.asarray(snapshot.positions, dtype=float)
    scored: list[tuple[Any, tuple, DecisionAction]] = [
        (0.0, candidates[0].key(), candidates[0])
    ]
    rejected = 0
    for candidate in candidates[1:]:
        gross, delivered = wet_debits(candidate, positions, config["wet"])
        gross_total = float(sum(gross.values()))
        if (
            float(queues.wet_j) + gross_total
            > float(config["stage4"]["wet_queue_cap_j"]) + 1e-12
        ):
            rejected += 1
            continue
        if any(
            float(queues.donor_j[node]) + float(debit)
            > float(config["stage4"]["donor_queue_cap_j"]) + 1e-12
            for node, debit in gross.items()
        ):
            rejected += 1
            continue
        action = _as_action(candidate)
        predicted = {
            payer: debit + float(current_visible_demand_j[payer])
            for payer, debit in gross.items()
        }
        if wet_rule == "queue_safe":
            risk_decision = assess_risk_calibrated_candidate(
                snapshot, action, predicted, config["da_ies_s"]["risk_guard"]
            )
            guard_passed = risk_decision.passed
        else:
            risk_decision = None
            guard_passed = assess_candidate(snapshot, action, predicted, margin).passed
        if not guard_passed:
            rejected += 1
            continue
        assert candidate.receiver is not None
        energy_need = max(0.0, target - belief.mean_j[candidate.receiver]) / capacity
        service_need = (
            q_service[candidate.receiver]
            if wet_rule in {"queue", "queue_safe"}
            else 0.0
        )
        receiver_gain = (
            1.0
            + float(config["stage4"]["energy_deficit_weight"]) * energy_need
            + float(config["stage4"]["service_queue_weight"]) * service_need
        ) * delivered / scale
        donor_pressure = sum(q_donor[node] * debit for node, debit in gross.items()) / scale
        loss = max(0.0, gross_total - delivered) / scale
        objective = (
            -receiver_gain
            + float(config["stage4"]["gross_wet_weight"]) * gross_total / scale
            + float(config["stage4"]["wet_loss_weight"]) * loss
        )
        if wet_rule in {"queue", "queue_safe"}:
            objective += (
                float(config["stage4"]["donor_queue_weight"]) * donor_pressure
                + float(config["stage4"]["wet_queue_weight"])
                * q_wet
                * gross_total
                / scale
            )
        if wet_rule == "queue_safe":
            # DA-IES-S exactly minimizes the frozen net-service objective
            # inside the RCPG-feasible set, then prefers greater safety slack.
            assert risk_decision is not None
            minimum_slack = min(
                item.post_action_lower_j - item.reserve_j
                for item in risk_decision.assessments
            )
            safe_key = (
                float(objective),
                -float(minimum_slack),
                float(gross_total),
                float(donor_pressure),
                candidate.key(),
            )
            scored.append((safe_key, candidate.key(), candidate))
        else:
            scored.append((float(objective), candidate.key(), candidate))
    if wet_rule == "queue_safe":
        # Replace the historical scalar null key with a compatible net-service key.
        converted = []
        for value, key, candidate in scored:
            if isinstance(value, tuple):
                converted.append((value, key, candidate))
            else:
                converted.append(((0.0, 0.0, 0.0, 0.0, key), key, candidate))
        selected_key, _, selected = min(converted, key=lambda item: item[0])
        objective = float(selected_key[0])
    else:
        objective, _, selected = min(scored, key=lambda item: (item[0], item[1]))
    return selected, float(objective), len(candidates), rejected, candidates


def _information_scores(
    strategy: str,
    snapshot: OnlineSnapshot,
    candidates: tuple[DecisionAction, ...],
    config: dict[str, Any],
    rng_seed: int,
) -> np.ndarray:
    nodes = len(snapshot.nodes)
    if strategy == "none" or strategy == "collect_all_eetor":
        return np.zeros(nodes, dtype=float)
    if strategy == "periodic_direct":
        offset = (snapshot.slot // int(config["stage4"]["report_interval_slots"]))
        scores = np.zeros(nodes, dtype=float)
        for rank in range(nodes):
            scores[(offset + rank) % nodes] = float(nodes - rank)
        return scores
    if strategy in {"age_direct", "age_direct_rcpg"}:
        return np.asarray([node.age for node in snapshot.nodes], dtype=float)
    if strategy in {"uncertainty_direct", "uncertainty_direct_rcpg"}:
        return np.sqrt(
            np.asarray([max(0.0, node.variance_j2) for node in snapshot.nodes], dtype=float)
        )
    if strategy == "age_uncertainty_direct_rcpg":
        ages = np.asarray([node.age for node in snapshot.nodes], dtype=float)
        uncertainty = np.sqrt(
            np.asarray(
                [max(0.0, node.variance_j2) for node in snapshot.nodes], dtype=float
            )
        )
        return ages * uncertainty
    if strategy == "usefulness_direct_rcpg":
        ages = np.asarray([node.age for node in snapshot.nodes], dtype=float)
        means = np.asarray([node.mean_j for node in snapshot.nodes], dtype=float)
        target = (
            float(config["voei"]["service_target_fraction"])
            * float(config["energy"]["capacity_j"])
        )
        urgency = np.maximum(target - means, 0.0)
        return urgency * ages
    if strategy in {
        "full_voei_direct",
        "full_voei_direct_rcpg",
        "full_voei_eetor",
        "adaptive_hybrid",
        "adaptive_hybrid_direct",
    }:
        belief = snapshot_to_decision_belief(
            snapshot, float(config["energy"]["capacity_j"])
        )
        scores = np.zeros(nodes, dtype=float)
        selected_nodes = list(range(nodes))
        if strategy in {"adaptive_hybrid", "adaptive_hybrid_direct"}:
            ages = np.asarray([node.age for node in snapshot.nodes], dtype=float)
            uncertainty = np.sqrt(
                np.asarray(
                    [max(0.0, node.variance_j2) for node in snapshot.nodes],
                    dtype=float,
                )
            )
            base = ages / max(1.0, float(np.max(ages)))
            base += float(config["da_ies_s"]["information"]["uncertainty_weight"]) * (
                uncertainty / max(1.0, float(np.max(uncertainty)))
            )
            shortlist = min(
                nodes, int(config["da_ies_s"]["information"]["voei_shortlist_nodes"])
            )
            selected_nodes = sorted(
                range(nodes), key=lambda node: (-base[node], node)
            )[:shortlist]
        for node in selected_nodes:
            rng = np.random.default_rng(
                np.random.SeedSequence([int(rng_seed), snapshot.slot, node, 44091])
            )
            scores[node] = full_decision_aware_voei(
                belief, node, candidates, config, rng
            ).value
        if strategy in {"adaptive_hybrid", "adaptive_hybrid_direct"}:
            ages = np.asarray([node.age for node in snapshot.nodes], dtype=float)
            uncertainty = np.sqrt(
                np.asarray(
                    [max(0.0, node.variance_j2) for node in snapshot.nodes],
                    dtype=float,
                )
            )
            age_score = ages / max(1.0, float(np.max(ages)))
            uncertainty_score = uncertainty / max(1.0, float(np.max(uncertainty)))
            voei_score = scores / max(1e-12, float(np.max(scores)))
            info = config["da_ies_s"]["information"]
            scores = (
                float(info["age_weight"]) * age_score
                + float(info["uncertainty_weight"]) * uncertainty_score
                + float(info["voei_weight"]) * voei_score
            )
        refresh_age = int(config["stage4"]["full_voei_refresh_age_slots"])
        refresh_floor = float(config["stage4"]["full_voei_refresh_floor_score"])
        for node, view in enumerate(snapshot.nodes):
            if view.age >= refresh_age:
                scores[node] = max(
                    scores[node],
                    refresh_floor * (1.0 + (view.age - refresh_age) / refresh_age),
                )
        return scores
    raise ValueError(f"unknown Stage 4 report strategy: {strategy}")


def _candidate_subsets(
    eligible: tuple[int, ...], maximum_fields: int, collect_all: bool
) -> tuple[tuple[int, ...], ...]:
    if collect_all:
        return ((), tuple(sorted(eligible)))
    subsets: list[tuple[int, ...]] = [()]
    for size in range(1, min(maximum_fields, len(eligible)) + 1):
        subsets.extend(tuple(values) for values in combinations(sorted(eligible), size))
    return tuple(subsets)


def _report_choice(
    snapshot: OnlineSnapshot,
    wet_action: DecisionAction,
    wet_gross: dict[int, float],
    current_visible_demand_j: np.ndarray,
    queues: Stage4Queues,
    strategy: str,
    scores: np.ndarray,
    config: dict[str, Any],
) -> tuple[Action, CommunicationPlan, PlannedCommunicationCost]:
    base_action = _as_action(wet_action)
    all_positions = np.vstack(
        [np.asarray(snapshot.positions, dtype=float), np.asarray(snapshot.sink_position)]
    )
    empty_cost = estimate_plan_cost(
        empty_plan(), all_positions, snapshot.sink_id, config["communication"]
    )
    if strategy == "none":
        return base_action, empty_plan(), empty_cost

    if strategy == "adaptive_hybrid_direct":
        mode_catalog: list[tuple[tuple[int, ...], str, bool]] = [
            (tuple(node.node_id for node in snapshot.nodes), "independent", False)
        ]
    elif strategy == "adaptive_hybrid":
        mode_catalog = [
            (tuple(node.node_id for node in snapshot.nodes), "independent", False)
        ]
        if len(wet_action.path) >= 2:
            mode_catalog.append(
                (tuple(int(node) for node in wet_action.path), "opportunity", False)
            )
    elif strategy.endswith("eetor"):
        if len(wet_action.path) < 2:
            return base_action, empty_plan(), empty_cost
        mode_catalog = [
            (tuple(int(node) for node in wet_action.path), "opportunity", strategy == "collect_all_eetor")
        ]
    else:
        mode_catalog = [
            (tuple(node.node_id for node in snapshot.nodes), "independent", False)
        ]
    budget = float(config["stage4"]["instantaneous_report_budget_j"])
    report_scale = max(1e-12, budget)
    z_scale = max(
        1e-12,
        float(config["stage4"]["report_average_budget_j_per_slot"])
        * float(config["simulation"]["slots"]),
    )
    z_norm = float(queues.report_j) / z_scale
    max_score = max(1e-12, float(np.max(scores)) if scores.size else 0.0)
    margin = float(config["belief"]["guard_margin_j"])
    options: list[
        tuple[float, float, tuple[Any, ...], Action, CommunicationPlan, PlannedCommunicationCost]
    ] = []
    for eligible, mode, collect_all in mode_catalog:
        subsets = _candidate_subsets(
            eligible, int(config["stage4"]["maximum_report_fields"]), collect_all
        )
        for subset in subsets:
            action = Action(
                receiver=base_action.receiver,
                donor=base_action.donor,
                wet_path=base_action.wet_path,
                amount_j=base_action.amount_j,
                state_subset=tuple(sorted(subset)),
                return_mode=mode if subset else "none",
            )
            plan = build_communication_plan(action, snapshot)
            planned = estimate_plan_cost(
                plan, all_positions, snapshot.sink_id, config["communication"]
            )
            delivered_nodes = {
                node for packet in plan.packets for node in packet.selected_nodes
            }
            if subset and len(delivered_nodes) != len(subset):
                continue
            if planned.total_sensor_debit_j > budget + 1e-12:
                continue
            payers = set(wet_gross) | set(planned.per_node_debit_j)
            predicted = {
                node: float(wet_gross.get(node, 0.0))
                + float(planned.per_node_debit_j.get(node, 0.0))
                + float(current_visible_demand_j[node])
                for node in payers
            }
            if strategy in {
                "adaptive_hybrid",
                "adaptive_hybrid_direct",
                "age_direct_rcpg",
                "uncertainty_direct_rcpg",
                "full_voei_direct_rcpg",
                "age_uncertainty_direct_rcpg",
                "usefulness_direct_rcpg",
            }:
                guard_passed = assess_risk_calibrated_candidate(
                    snapshot, action, predicted, config["da_ies_s"]["risk_guard"]
                ).passed
            else:
                guard_passed = assess_candidate(
                    snapshot, action, predicted, margin
                ).passed
            if not guard_passed:
                continue
            utility = float(sum(scores[node] for node in subset)) / max_score
            if collect_all and subset:
                utility = float(len(subset))
            penalty = (
                float(config["stage4"]["report_queue_weight"])
                * z_norm
                * planned.total_sensor_debit_j
                / report_scale
            )
            # v2 can activate a pre-registered physical report-energy term.
            # The default is zero, preserving all earlier experiments.  The
            # same term applies to every reporting strategy; opportunity
            # return gains only when its audited packet plan is truly cheaper.
            physical_energy_penalty = (
                float(config["stage4"].get("report_energy_weight", 0.0))
                * planned.total_sensor_debit_j
                / report_scale
            )
            objective = -utility + penalty + physical_energy_penalty
            options.append(
                (
                    objective,
                    planned.total_sensor_debit_j,
                    (mode, *tuple(sorted(subset))),
                    action,
                    plan,
                    planned,
                )
            )
    if not options:
        return base_action, empty_plan(), empty_cost
    if strategy in {
        "full_voei_direct",
        "full_voei_direct_rcpg",
        "full_voei_eetor",
        "adaptive_hybrid",
        "adaptive_hybrid_direct",
    } and np.all(scores <= 0.0):
        return base_action, empty_plan(), empty_cost
    _, _, _, action, plan, planned = min(
        options, key=lambda item: (item[0], item[1], item[2])
    )
    return action, plan, planned


def choose_action(
    method: str,
    snapshot: OnlineSnapshot,
    current_visible_demand_j: tuple[float, ...],
    queues: Stage4Queues,
    config: dict[str, Any],
    rng_seed: int,
) -> Stage4Decision:
    """Choose a Stage 4 action from slot-start online information only."""

    _, wet_rule, strategy = method_spec(method)
    demand = np.asarray(current_visible_demand_j, dtype=float)
    selected_wet, wet_objective, candidate_count, rejected, candidates = _wet_choice(
        snapshot, demand, queues, wet_rule, config
    )
    due = snapshot.slot % int(config["stage4"]["report_interval_slots"]) == 0
    scores = (
        _information_scores(strategy, snapshot, candidates, config, rng_seed)
        if due
        else np.zeros(len(snapshot.nodes), dtype=float)
    )
    gross, _ = wet_debits(
        selected_wet, np.asarray(snapshot.positions), config["wet"]
    )
    if due:
        action, report_plan, planned_report = _report_choice(
            snapshot,
            selected_wet,
            gross,
            demand,
            queues,
            strategy,
            scores,
            config,
        )
    else:
        action = _as_action(selected_wet)
        report_plan = empty_plan()
        all_positions = np.vstack(
            [np.asarray(snapshot.positions), np.asarray(snapshot.sink_position)]
        )
        planned_report = estimate_plan_cost(
            report_plan, all_positions, snapshot.sink_id, config["communication"]
        )
    return Stage4Decision(
        action=action,
        report_plan=report_plan,
        planned_report=planned_report,
        planned_wet_debits_j=gross,
        wet_objective=wet_objective,
        wet_candidate_count=candidate_count,
        guard_rejected_wet_candidates=rejected,
        information_scores=tuple(float(value) for value in scores),
        report_strategy=strategy,
        report_due=due,
    )
