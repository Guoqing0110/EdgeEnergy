#!/usr/bin/env python3
"""Chapter 5: rerun two registered trajectories and independently rebuild two tables."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
EXPERIMENT = {
    'v1': ('e6_matched_independent_v1', 'run'),
    'v2': ('e6_mechanism_stress_v2', 'held-out'),
}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def launch(args, cwd, log):
    result = subprocess.run([sys.executable, '-B', *args], cwd=cwd,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log.write_text(result.stdout, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'{args[0]} exited with {result.returncode}. See {log}:\n{result.stdout[-1800:]}')

def run(tag, target, item):
    experiment, mode = EXPERIMENT[tag]
    # The original drivers use a path relative to their source tree. Isolate their writes.
    engine = target / 'work'
    shutil.copytree(HERE / 'engines' / tag, engine)
    control = engine / 'outputs' / experiment
    require(not list(control.rglob('slots.jsonl.gz')), 'engine template contains a precomputed trajectory')
    clock = time.monotonic()
    launch([str(Path('scripts')/f'run_{experiment}.py'), mode, '--workers', '1',
            '--condition', item['condition'], '--seed', str(item['seed']), '--method', item['method']],
           engine, target/'driver.log')
    raw = list(control.rglob('slots.jsonl.gz'))
    require(len(raw)==1, f'expected exactly one new raw trajectory; got {len(raw)}')
    summary = json.loads((raw[0].parent/'summary.json').read_text(encoding='utf-8'))
    for k in ['seed','seed_id','condition','method','trace_hash','slot_rows']:
        require(summary[k] == item[k], f'{tag}: identity mismatch in {k}')
    n = 0
    decoded_hash = hashlib.sha256()
    with gzip.open(raw[0],'rb') as f:
        for line in f:
            decoded_hash.update(line)
            n += 1
    require(n == item['slot_rows'], f'{tag}: slot count mismatch')
    require(decoded_hash.hexdigest() == item['uncompressed_sha256'], f'{tag}: raw JSONL content differs')
    for k, expected in item['metrics'].items():
        require(math.isclose(summary[k], expected, rel_tol=1e-10, abs_tol=1e-9),
                f'{tag}: {k}, expected {expected}, got {summary[k]}')
    if 'opportunity_slots' in item:
        require(round(n*summary['opportunity_return_slot_fraction'])==item['opportunity_slots'],
                'number of opportunity-return decisions differs')
    compressed = hashlib.sha256(raw[0].read_bytes()).hexdigest()
    report = {'seed':item['seed'],'condition':item['condition'],'method':item['method'],'slots':n,
              'raw_sha256':compressed,'matches_archived_gzip':compressed==item['raw_sha256'],
              'raw_jsonl_sha256':decoded_hash.hexdigest(),
              'metrics':{k:summary[k] for k in item['metrics']},
              'max_conservation_residual_j':summary['maximum_conservation_residual_j'],
              'fresh_simulation_seconds':round(time.monotonic()-clock,3),
              'raw_output':raw[0].relative_to(target).as_posix()}
    if 'opportunity_slots' in item: report['opportunity_slots']=round(n*summary['opportunity_return_slot_fraction'])
    if not report['matches_archived_gzip']:
        print(f'{tag}: gzip wrapper differs; the complete decompressed JSONL stream is byte-identical.')
    return report

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True,
                        help='New or empty run directory outside the package; relative paths resolve from the caller')
    opts=parser.parse_args()
    target=opts.output.expanduser().resolve()
    if target==HERE or HERE in target.parents:parser.error('output must be outside this study source directory')
    if target.exists() and (not target.is_dir() or any(target.iterdir())):parser.error('output is not an empty directory')
    target.mkdir(parents=True,exist_ok=True)
    expected=json.loads((HERE/'expected.json').read_text(encoding='utf-8')); report={}
    for tag in EXPERIMENT:
        (target/tag).mkdir()
        report[tag]=run(tag,target/tag,expected[tag])
        print(f"{tag}: {report[tag]['slots']} freshly simulated slots; stream and metrics match.")
    launch([str(HERE/'tables'/'check_tables.py')], target, target/'matched-policy-tables.txt')
    print((target/'matched-policy-tables.txt').read_text(encoding='utf-8'),end='')
    report['tables']={'trajectories':{'v1':735,'v2':1176},'fields_checked':56,
                      'source':'supplied per-trajectory metrics and pairing indices'}
    (target/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('PASS: Chapter 5 scheduling simulations and two seven-policy tables.')
if __name__=='__main__':main()
