# Decision-Aware Information–Energy Scheduling with Safeguarded Payer Reserves (DA-IES-S)

When a scheduler requests a state report, some node must pay for it. The two experiments here compare seven reporting and return policies under the same action catalogue, reserve rule and external inputs. The first uses a 12-node reference network. The second asks whether a report can hitch a ride on a returning packet in an 18-node corridor.

## Run two trajectories

From this directory on 64-bit Linux, run:

```sh
python -m pip install -r requirements-demo.txt
python -B demo.py --output /path/to/new/results
```

Use a new or empty directory outside this study directory. The tested environment is CPython 3.12.14, NumPy 2.3.5 and PyYAML 6.0.3, with zlib 1.3.2. The original drivers use the POSIX `resource` module. After installation the demo runs offline on a CPU. It copies each engine into its own working directory and leaves the input files intact.

| Output | Short paths (v1) | Multihop corridor (v2) |
|---|---:|---:|
| DA-IES-S seed | 2559208254 | 1177016155 |
| Condition; duration | baseline; 480 slots | bottleneck_loss; 720 slots |
| Node service continuity (fraction) | 0.920138889 | 0.613966049 |
| Cumulative unmet visible demand (J) | 38,054.658608 | 398,505.307533 |
| Reporting debit (J/slot) | 0.008501617268 | 0.003244314199 |
| Payer reserve violation rate (fraction) | 0.005464481 | 0 |

Open `results.json` for each trajectory's identity, metrics and output path. The corridor trajectory selects opportunity return twice. The per-slot JSONL records, engine summaries and logs are in the same results directory. The demo compares the uncompressed trajectory SHA-256 against `expected.json` and checks the metrics (relative tolerance 1e-10, absolute tolerance 1e-9). It also reports the gzip checksum: different compression libraries can encode the same JSONL differently. See [full-sweep instructions](../../docs/USER_GUIDE.md#full-sweeps-for-the-two-networks) to run more than the two examples.

## Recalculate the matched comparisons

```sh
python -B tables/check_tables.py
```

This standard-library command reads the archived trajectory summaries; the demo above also runs it and saves `matched-policy-tables.txt`. For thesis Table 5.6 it uses 15 seeds × seven conditions × seven policies (735 trajectories); for the appendix corridor table it uses 24 held-out seeds with the same design (1,176 trajectories). The reference-network comparison is an independent reconstruction. The earlier July experiment survives as a separate aggregate table; its original seed mapping and trajectories were not recovered.

The checker confirms that the seven policies in each seed–condition cell faced the same external trace. It averages conditions within each seed for service and cost, and takes the largest condition-mean payer reserve event rate for the reserve column. Across the two tables it checks all 56 entries (relative tolerance 5e-13; absolute tolerance 1e-10). Node continuity is printed as a percentage. For the separate complete-controller (420 trajectories) and incremental (525 trajectories) experiments, see [Chapter 5 table data](../thesis-tables/README.md).

The policy implementation is in `engines/<version>/src/scheduler/stage4.py`; `src/stage4_simulation.py` executes the decision cycle. Each engine has its own `scripts/run_e6_*.py` driver, configuration, seed registry and calibrated settings. The files supplied under `engines/<version>/outputs/` are inputs to the formal runs, including the corridor's configuration selected before held-out testing. `tables/v1/` and `tables/v2/` hold the corresponding numerical summaries. [Archive identifiers](archive-origins.csv) and [licence terms](../../legal/LICENSE_SCOPE.md) identify the sources.
