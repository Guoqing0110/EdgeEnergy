#!/usr/bin/env python3
"""Check the two matched-policy tables from retained per-trajectory metrics."""
import argparse, csv, hashlib, math
from collections import defaultdict
from pathlib import Path
from statistics import fmean
BASE=Path(__file__).resolve().parent
def records(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def need(condition,reason):
    if not condition: raise ValueError(reason)
def run(tag,nseed,nslots):
    d=BASE/tag; R=records(d/'trajectory_metrics_from_raw.csv'); table=records(next(d.glob('table*.csv')))
    methods={r['method'] for r in table};cells=defaultdict(dict);cond=set()
    registry=records(next(d.glob('e6*.csv')))
    seeds={r['seed_id']:int(r['seed_value']) for r in registry if r.get('split','held_out')=='held_out'}
    need(len(methods)==7 and len(seeds)==len(set(seeds.values()))==nseed,'unexpected registry or methods')
    for r in R:
        c,s,m=r['condition'],r['seed_id'],r['method']
        need(m in methods and s in seeds and int(r['seed'])==seeds[s] and int(r['slot_rows'])==nslots,'identity/slot mismatch')
        need(m not in cells[c,s],'duplicate trajectory')
        cells[c,s][m]=r;cond.add(c)
    need(len(cond)==7 and len(cells)==7*nseed and len(R)==49*nseed,'incomplete design')
    for rec in cells.values():
        need(set(rec)==methods and len({r['trace_hash'] for r in rec.values()})==1,'unmatched policies')
    print(tag, '         Policy        Unmet(kJ)    Node(%)   Report(mJ/slot)  Max reserve(%)')
    for t in table:
        m=t['method']
        def meanbyseed(metric):
            return fmean(fmean(float(cells[c,s][m][metric]) for c in sorted(cond)) for s in sorted(seeds))
        risk=max(fmean(float(cells[c,s][m]['payer_reserve_violation_rate']) for s in sorted(seeds)) for c in cond)
        a=(meanbyseed('cumulative_unmet_visible_demand_j')/1000, 100*meanbyseed('node_service_continuity_fraction'), 1000*meanbyseed('average_reporting_debit_j_per_slot'), 100*risk)
        b=(float(t['unmet_kj']),100*float(t['node_continuity']),float(t['report_mj_per_slot']),float(t['max_condition_mean_reserve_percent']))
        need(all(math.isclose(p,q,rel_tol=5e-13,abs_tol=1e-10) for p,q in zip(a,b)),'table mismatch '+m)
        print(f'{m:26}'+''.join(f'{v:13.4f}' for v in a))
    print(f'{len(R)} trajectories, {len(cells)} matched cells, {len(R)*nslots:,} slot records represented. Table verified.')
def validate_archives(folder):
    for row in records(BASE/'archive_register.csv'):
        p=folder/row['filename'];need(p.is_file(),f'Archive not present: {p}');h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
        need(p.stat().st_size==int(row['bytes']) and h.hexdigest()==row['sha256'],'checksum mismatch: '+p.name)
        print('SHA-256 OK:',p.name)
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archives',type=Path,help='also verify the eleven original ZIP archives supplied in this directory')
    opt=ap.parse_args();run('v1',15,480);run('v2',24,720)
    if opt.archives: validate_archives(opt.archives)
