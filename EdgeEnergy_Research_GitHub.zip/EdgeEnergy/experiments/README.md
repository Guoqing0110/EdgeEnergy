# Research experiments

The studies follow three decisions in an energy-constrained sensor network: how many donors should assist a receiver, which status reports are worth obtaining before a transfer, and when extra sensing can still capture an event.

| Study | Source and experiment design |
|---|---|
| [Dynamic-K](dynamic-k/README.md) · Chapter 4 | The 25-node nominal experiment applies fixed and adaptive donor limits to the same five schedulers. |
| [Decision-aware information and energy scheduling (DA-IES-S)](da-ies-s/README.md) · Chapter 5 | Separate reference-network and corridor engines evaluate how report selection, feasible transfers and reserve protection affect unmet demand. |
| [Sentinel-assisted adaptive sampling](adaptive-sampling-monitoring/README.md) · Chapter 6, Stage I | Four policies share the same local anomaly events. The simulation and the hardware-session replay provide different views of sensing decisions. |
| [DF-ReAlert at moving fronts](adaptive-sampling-monitoring/stage-ii/README.md) · Chapter 6, Stage II | Sensor revisit policies are paired within a time window. A separate detector and sentinel-placement control tests how the design transfers across mechanisms. |

Start with the [quick start](../docs/QUICKSTART.md) for a runnable example. The [results guide](RESULTS.md) gives representative values; [source and data provenance](PROVENANCE.md) identifies the materials behind them. The [table data](thesis-tables/README.md) support additional Chapter 5 and 6 comparisons, and the [hardware records](../hil/README.md) support the Chapter 4 and 5 radio experiments.
