import os
import json
import copy
import random
import argparse
import numpy as np
from datetime import datetime
from contextlib import redirect_stdout
from src.wsn_et import Network, EnergySimulation, schedulers

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT_ROOT = os.path.join(ROOT, "artifacts", "table2_reproduction")
os.makedirs(OUT_ROOT, exist_ok=True)

network_config = {
    "num_nodes": 25,
    "low_threshold": 0.1,
    "high_threshold": 0.9,
    "node_initial_energy": 40000,
    "max_hops": 3,
    "random_seed": 129,
    "distribution_mode": "uniform",
    "network_area": {"width": 10.0, "height": 10.0},
    "min_distance": 0.5
}

TIME_STEPS = 10080
FIXED_SEED = 42
WEIGHT_CONFIG = {
    "w_b": 0.2,
    "w_d": 0.5,
    "w_l": 0.2
}

TABLE2_TARGET = {
    "NoTransfer": {"avg_std": 400000.0, "final_min": 0.0, "eff": 0.0, "loss": 0.0},
    "Average_static_k1": {"avg_std": 5163.0, "final_min": 964.6, "eff": 57.8, "loss": 316089.0},
    "Average_dynamic_k": {"avg_std": 1658.6, "final_min": 9275.8, "eff": 57.2, "loss": 449565.0},
    "Baseline_static_k1": {"avg_std": 4285.1, "final_min": 3470.2, "eff": 50.0, "loss": 380399.0},
    "Baseline_dynamic_k": {"avg_std": 1586.7, "final_min": 6922.4, "eff": 50.3, "loss": 525237.0},
    "Lyapunov_static_k1": {"avg_std": 2316.4, "final_min": 24760.3, "eff": 59.4, "loss": 290090.0},
    "Lyapunov_dynamic_k": {"avg_std": 1243.4, "final_min": 16478.8, "eff": 58.2, "loss": 433534.0},
    "Prediction_static_k1": {"avg_std": 4285.1, "final_min": 5907.3, "eff": 50.0, "loss": 380399.0},
    "Prediction_dynamic_k": {"avg_std": 1594.4, "final_min": 7035.63, "eff": 49.6, "loss": 528086.0},
    "PowerControl_static_k1": {"avg_std": 5046.8, "final_min": 249.46, "eff": 47.4, "loss": 347884.0},
    "PowerControl_dynamic_k": {"avg_std": 1434.8, "final_min": 56.9, "eff": 47.4, "loss": 492092.0}
}


def build_base():
    random.seed(FIXED_SEED)
    np.random.seed(FIXED_SEED)
    return Network(num_nodes=network_config["num_nodes"], network_config=network_config)


def mk_scheduler(name):
    if name == "Average":
        return None
    if name == "Baseline":
        return schedulers.BaselineHeuristic(K=3, max_hops=network_config["max_hops"])
    if name == "Lyapunov":
        return schedulers.LyapunovScheduler(V=0.5, K=2, max_hops=network_config["max_hops"])
    if name == "Prediction":
        return schedulers.PredictionScheduler(alpha=0.6, horizon_min=60, K=3, max_hops=network_config["max_hops"])
    if name == "PowerControl":
        return schedulers.PowerControlScheduler(target_eta=0.25, K=3, max_hops=network_config["max_hops"])
    raise ValueError(name)


class ExtremeEventScheduler(object):
    def __init__(self, base_scheduler, victim_node_ids, shock_t, depletion_ratio, surge_start, surge_end, mobility_speed_scale):
        self.base_scheduler = base_scheduler
        self.victim_node_ids = set(victim_node_ids)
        self.shock_t = int(shock_t)
        self.depletion_ratio = float(depletion_ratio)
        self.surge_start = int(surge_start)
        self.surge_end = int(surge_end)
        self.mobility_speed_scale = float(mobility_speed_scale)
        self._shock_applied = False
        self._surge_applied = False
        self._speed_backup = {}
        if hasattr(base_scheduler, "K"):
            self.K = base_scheduler.K

    def _apply_events(self, network, t):
        if (not self._shock_applied) and t >= self.shock_t:
            for n in network.nodes:
                if n.node_id in self.victim_node_ids:
                    n.current_energy = max(0.0, n.current_energy * self.depletion_ratio)
            self._shock_applied = True

        if (not self._surge_applied) and t >= self.surge_start:
            for n in network.nodes:
                if getattr(n, "is_mobile", False):
                    params = getattr(n, "mobility_params", None)
                    if not isinstance(params, dict):
                        continue
                    old_speed = params.get("speed", 0.01)
                    self._speed_backup[n.node_id] = old_speed
                    params["speed"] = old_speed * self.mobility_speed_scale
            self._surge_applied = True

        if self._surge_applied and t >= self.surge_end and self._speed_backup:
            for n in network.nodes:
                if n.node_id in self._speed_backup:
                    params = getattr(n, "mobility_params", None)
                    if isinstance(params, dict):
                        params["speed"] = self._speed_backup[n.node_id]
            self._speed_backup = {}

    def plan(self, network, t):
        self._apply_events(network, t)
        if hasattr(self.base_scheduler, "K") and hasattr(self, "K"):
            self.base_scheduler.K = self.K
        return self.base_scheduler.plan(network, t)

    def post_step(self, network, t, feedback):
        if hasattr(self.base_scheduler, "post_step"):
            return self.base_scheduler.post_step(network, t, feedback)
        return None


def run_case(base_network, case_name, scheduler_name=None, mode=None, no_transfer=False):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(OUT_ROOT, f"{ts}_{case_name}")
    os.makedirs(run_dir, exist_ok=True)

    net = copy.deepcopy(base_network)
    sched = None if scheduler_name is None else mk_scheduler(scheduler_name)
    sim = EnergySimulation(net, TIME_STEPS, scheduler=sched)
    sim.w_b = float(WEIGHT_CONFIG["w_b"])
    sim.w_d = float(WEIGHT_CONFIG["w_d"])
    sim.w_l = float(WEIGHT_CONFIG["w_l"])

    if mode == "static_k1":
        sim.K = 1
        sim._adapt_K = lambda stats: None
    elif mode == "dynamic_k":
        sim.K = 1

    if no_transfer:
        def no_exec(plans):
            return None
        net.execute_energy_transfer = no_exec

    with open(os.path.join(run_dir, "console_output.log"), "w", encoding="utf-8") as logf:
        with redirect_stdout(logf):
            sim.simulate()

    total_sent = sum(sum(node.transferred_history) for node in net.nodes)
    total_received = sum(sum(node.received_history) for node in net.nodes)
    avg_std = float(np.mean(sim.energy_Standards) if sim.energy_Standards else 0.0)
    final_min = float(min(node.current_energy for node in net.nodes))
    eff = float(total_received / total_sent * 100) if total_sent > 0 else 0.0
    loss = float(total_sent - total_received)

    out = {
        "case": case_name,
        "avg_std": avg_std,
        "final_min": final_min,
        "eff": eff,
        "loss": loss,
        "run_dir": run_dir
    }
    with open(os.path.join(run_dir, "summary_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    return out


def _collect_metrics(net, sim, shock_t):
    total_sent = sum(sum(node.transferred_history) for node in net.nodes)
    total_received = sum(sum(node.received_history) for node in net.nodes)
    avg_std = float(np.mean(sim.energy_Standards) if sim.energy_Standards else 0.0)
    final_min = float(min(node.current_energy for node in net.nodes))
    eff = float(total_received / total_sent * 100) if total_sent > 0 else 0.0
    loss = float(total_sent - total_received)
    dead_nodes = int(sum(1 for node in net.nodes if node.current_energy <= 0.0))

    min_energy_series = []
    for step_result in sim.results:
        if not step_result:
            continue
        min_energy_series.append(min(x["current_energy"] for x in step_result))

    if min_energy_series:
        post_end = min(len(min_energy_series), shock_t + 1440)
        post_slice = min_energy_series[shock_t:post_end]
        post_shock_min_24h = float(min(post_slice)) if post_slice else float(min_energy_series[-1])
        post_shock_mean_24h = float(np.mean(post_slice)) if post_slice else float(min_energy_series[-1])
    else:
        post_shock_min_24h = final_min
        post_shock_mean_24h = final_min

    return {
        "avg_std": avg_std,
        "final_min": final_min,
        "eff": eff,
        "loss": loss,
        "dead_nodes": dead_nodes,
        "post_shock_min_24h": post_shock_min_24h,
        "post_shock_mean_24h": post_shock_mean_24h
    }


def run_extreme_experiment(time_steps):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_root = os.path.join(OUT_ROOT, f"{ts}_extreme_case_ablation")
    os.makedirs(run_root, exist_ok=True)

    base = build_base()
    victim_ids = [n.node_id for n in base.nodes if not getattr(n, "has_solar", True)][:5]
    shock_t = 2880
    surge_start = 2880
    surge_end = 4320

    def run_one(mode):
        net = copy.deepcopy(base)
        base_sched = mk_scheduler("Baseline")
        wrapped_sched = ExtremeEventScheduler(
            base_scheduler=base_sched,
            victim_node_ids=victim_ids,
            shock_t=shock_t,
            depletion_ratio=0.08,
            surge_start=surge_start,
            surge_end=surge_end,
            mobility_speed_scale=8.0
        )
        sim = EnergySimulation(net, time_steps, scheduler=wrapped_sched)
        sim.w_b = float(WEIGHT_CONFIG["w_b"])
        sim.w_d = float(WEIGHT_CONFIG["w_d"])
        sim.w_l = float(WEIGHT_CONFIG["w_l"])
        sim.K = 1
        if mode == "static_k1":
            sim._adapt_K = lambda stats: None
        run_dir = os.path.join(run_root, mode)
        os.makedirs(run_dir, exist_ok=True)
        with open(os.path.join(run_dir, "console_output.log"), "w", encoding="utf-8") as logf:
            with redirect_stdout(logf):
                sim.simulate()
        metrics = _collect_metrics(net, sim, shock_t)
        metrics["mode"] = mode
        metrics["run_dir"] = run_dir
        with open(os.path.join(run_dir, "summary_metrics.json"), "w", encoding="utf-8") as f:
            json.dump(metrics, f, ensure_ascii=False, indent=2)
        return metrics

    static_r = run_one("static_k1")
    dynamic_r = run_one("dynamic_k")
    compare = {
        "scenario": {
            "time_steps": time_steps,
            "scheduler": "BaselineHeuristic",
            "weight_config": WEIGHT_CONFIG,
            "victim_node_ids": victim_ids,
            "shock_t": shock_t,
            "depletion_ratio": 0.08,
            "mobility_surge": {"start": surge_start, "end": surge_end, "speed_scale": 8.0}
        },
        "static_k1": static_r,
        "dynamic_k": dynamic_r,
        "delta_dynamic_minus_static": {
            "avg_std": dynamic_r["avg_std"] - static_r["avg_std"],
            "final_min": dynamic_r["final_min"] - static_r["final_min"],
            "eff": dynamic_r["eff"] - static_r["eff"],
            "loss": dynamic_r["loss"] - static_r["loss"],
            "dead_nodes": dynamic_r["dead_nodes"] - static_r["dead_nodes"],
            "post_shock_min_24h": dynamic_r["post_shock_min_24h"] - static_r["post_shock_min_24h"],
            "post_shock_mean_24h": dynamic_r["post_shock_mean_24h"] - static_r["post_shock_mean_24h"]
        }
    }
    out_file = os.path.join(run_root, "extreme_case_compare.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(compare, f, ensure_ascii=False, indent=2)
    print(json.dumps(compare, ensure_ascii=False, indent=2))
    return compare


def compare_to_target(result):
    target = TABLE2_TARGET.get(result["case"])
    if target is None:
        return {"case": result["case"], "note": "no target"}
    return {
        "case": result["case"],
        "avg_std_diff": result["avg_std"] - target["avg_std"],
        "final_min_diff": result["final_min"] - target["final_min"],
        "eff_diff": result["eff"] - target["eff"],
        "loss_diff": result["loss"] - target["loss"]
    }


def main():
    base = build_base()
    plan = [
        ("NoTransfer", None, None, True),
        ("Average_static_k1", "Average", "static_k1", False),
        ("Average_dynamic_k", "Average", "dynamic_k", False),
        ("Baseline_static_k1", "Baseline", "static_k1", False),
        ("Baseline_dynamic_k", "Baseline", "dynamic_k", False),
        ("Lyapunov_static_k1", "Lyapunov", "static_k1", False),
        ("Lyapunov_dynamic_k", "Lyapunov", "dynamic_k", False),
        ("Prediction_static_k1", "Prediction", "static_k1", False),
        ("Prediction_dynamic_k", "Prediction", "dynamic_k", False),
        ("PowerControl_static_k1", "PowerControl", "static_k1", False),
        ("PowerControl_dynamic_k", "PowerControl", "dynamic_k", False)
    ]

    all_results = []
    all_cmp = []
    for case, sched_name, mode, no_transfer in plan:
        r = run_case(base, case, scheduler_name=sched_name, mode=mode, no_transfer=no_transfer)
        c = compare_to_target(r)
        all_results.append(r)
        all_cmp.append(c)
        print(json.dumps(r, ensure_ascii=False))
        print(json.dumps(c, ensure_ascii=False))

    with open(os.path.join(OUT_ROOT, "table2_reproduce_results.json"), "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    with open(os.path.join(OUT_ROOT, "table2_reproduce_compare.json"), "w", encoding="utf-8") as f:
        json.dump(all_cmp, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--extreme", action="store_true")
    parser.add_argument("--time_steps", type=int, default=5760)
    args = parser.parse_args()
    if args.extreme:
        run_extreme_experiment(args.time_steps)
    else:
        main()
