import math
import random
import numpy as np
from .sensor_node import SensorNode
from .adcr_link_layer import ADCRLinkLayerVirtual
from .opportunistic_routing import opportunistic_routing
from .energy_management import balance_energy
from .eeor import eeor_find_path

class Network:
    def __init__(self, num_nodes, network_config, **kwargs):
        self.num_nodes = num_nodes
        self.nodes = []
        self.network_config = network_config

        self.low_threshold = network_config.get('low_threshold', 0.25)
        self.high_threshold = network_config.get('high_threshold', 0.75)
        self.node_initial_energy = network_config.get('node_initial_energy', 10000)
        self.max_hops = network_config.get('max_hops', 3)
        
        self.distribution_mode = network_config.get('distribution_mode', 'uniform')

        self.create_nodes()

        try:
            self.adcr_link = ADCRLinkLayerVirtual(
                self,
                round_period=60,
                plan_paths=True,
                consume_energy=True,
                max_hops=self.max_hops,
                output_dir=self.network_config.get("output_dir", "date927")
            )
        except Exception as e:
            print("[ADCR-Link-Virtual] init failed:", e)
            self.adcr_link = None

    def create_nodes(self):
        """

        """
        if self.distribution_mode == "uniform":
            self._create_uniform_nodes()
        elif self.distribution_mode == "random":
            self._create_random_nodes()
        else:
            print(f"Unknown distribution mode: {self.distribution_mode}, falling back to uniform distribution")
            self._create_uniform_nodes()

    def _create_uniform_nodes(self):
        """
        Create nodes in an approximate square layout using equilateral triangle grid pattern.
        Randomly assign 40% of nodes to be without solar energy harvesting capability.
        """
        import random
        seed = self.network_config.get("random_seed", 42)
        random.seed(seed)
        np.random.seed(seed)

        horizontal_spacing = 1.0
        vertical_spacing = np.sqrt(3) / 2 * horizontal_spacing

        cols = int(np.ceil(np.sqrt(self.num_nodes)))
        rows = int(np.ceil(self.num_nodes / cols))

        all_node_ids = list(range(self.num_nodes))
        num_without_solar = int(0.4 * self.num_nodes)
        no_solar_nodes = set(random.sample(all_node_ids, num_without_solar))

        num_mobile = int(0.1 * self.num_nodes)
        mobile_nodes = set(random.sample(list(no_solar_nodes), num_mobile))

        node_id = 0
        for row in range(rows):
            for col in range(cols):
                if node_id >= self.num_nodes:
                    break

                x = col * horizontal_spacing
                if row % 2 == 1:
                    x += horizontal_spacing / 2
                y = row * vertical_spacing

                has_solar = node_id not in no_solar_nodes

                is_mobile = node_id in mobile_nodes

                mobility_pattern = "circle" if is_mobile else None
                mobility_params = {
                    "radius": 1.0,
                    "speed": 0.01,
                    "center": [x, y]
                } if is_mobile else {}

                node = SensorNode(
                    node_id=node_id,
                    initial_energy=self.node_initial_energy,
                    low_threshold=self.low_threshold,
                    high_threshold=self.high_threshold,
                    position=[x, y],
                    has_solar=has_solar,
                    is_mobile=is_mobile,
                    mobility_pattern=mobility_pattern,
                    mobility_params=mobility_params,
                    **{k: v for k, v in self.network_config.items() if k not in ['low_threshold', 'high_threshold']}
                )

                self.nodes.append(node)
                node_id += 1

    def _create_random_nodes(self):
        """

        """
        import random
        import math
        
        seed = self.network_config.get("random_seed", 42)
        random.seed(seed)
        np.random.seed(seed)
        
        area = self.network_config.get("network_area", {"width": 10.0, "height": 10.0})
        width = area["width"]
        height = area["height"]
        min_dist = self.network_config.get("min_distance", 0.5)
        
        positions = []
        attempts = 0
        max_attempts = self.num_nodes * 100
        
        print(f"Generating {self.num_nodes} randomly distributed nodes...")
        
        while len(positions) < self.num_nodes and attempts < max_attempts:
            x = random.uniform(0, width)
            y = random.uniform(0, height)
            
            valid_position = True
            for existing_pos in positions:
                if math.sqrt((x - existing_pos[0])**2 + (y - existing_pos[1])**2) < min_dist:
                    valid_position = False
                    break
            
            if valid_position:
                positions.append([x, y])
            
            attempts += 1
        
        if len(positions) < self.num_nodes:
            print(f"Warning: failed to place all nodes with minimum distance {min_dist}; relaxing the distance requirement to {min_dist/2}")
            min_dist = min_dist / 2
            
            while len(positions) < self.num_nodes and attempts < max_attempts * 2:
                x = random.uniform(0, width)
                y = random.uniform(0, height)
                
                valid_position = True
                for existing_pos in positions:
                    if math.sqrt((x - existing_pos[0])**2 + (y - existing_pos[1])**2) < min_dist:
                        valid_position = False
                        break
                
                if valid_position:
                    positions.append([x, y])
                
                attempts += 1
        
        if len(positions) < self.num_nodes:
            print(f"Warning: generating the remaining nodes without a distance constraint.")
            while len(positions) < self.num_nodes:
                x = random.uniform(0, width)
                y = random.uniform(0, height)
                positions.append([x, y])
        
        print(f"Successfully generated {len(positions)} node positions")
        
        self._assign_node_properties(positions)
    
    def _assign_node_properties(self, positions):
        """

        """
        import random
        
        all_node_ids = list(range(self.num_nodes))
        num_without_solar = int(0.4 * self.num_nodes)
        no_solar_nodes = set(random.sample(all_node_ids, num_without_solar))
        
        num_mobile = int(0.1 * self.num_nodes)
        mobile_nodes = set(random.sample(list(no_solar_nodes), num_mobile))
        
        for node_id in range(self.num_nodes):
            x, y = positions[node_id]
            
            has_solar = node_id not in no_solar_nodes
            is_mobile = node_id in mobile_nodes
            
            mobility_pattern = "circle" if is_mobile else None
            mobility_params = {
                "radius": 1.0,
                "speed": 0.01,
                "center": [x, y]
            } if is_mobile else {}
            
            node = SensorNode(
                node_id=node_id,
                initial_energy=self.node_initial_energy,
                low_threshold=self.low_threshold,
                high_threshold=self.high_threshold,
                position=[x, y],
                has_solar=has_solar,
                is_mobile=is_mobile,
                mobility_pattern=mobility_pattern,
                mobility_params=mobility_params,
                **{k: v for k, v in self.network_config.items() if k not in ['low_threshold', 'high_threshold']}
            )
            
            self.nodes.append(node)

    # def create_nodes(self):
    #     """
    #     Create nodes in an approximate square layout using equilateral triangle grid pattern.
    #     Force nodes without solar to form a compact cluster near a chosen center.
    #     """
    #     import random
    #     horizontal_spacing = 1.0
    #     vertical_spacing = np.sqrt(3) / 2 * horizontal_spacing
    
    #     cols = int(np.ceil(np.sqrt(self.num_nodes)))
    #     rows = int(np.ceil(self.num_nodes / cols))
    
    #     positions = []
    #     node_id = 0
    #     for row in range(rows):
    #         for col in range(cols):
    #             if node_id >= self.num_nodes:
    #                 break
    #             x = col * horizontal_spacing
    #             if row % 2 == 1:
    #                 x += horizontal_spacing / 2.0
    #             y = row * vertical_spacing
    #             positions.append([x, y])
    #             node_id += 1
    #     positions = np.array(positions)  # (N, 2)
    
    #     all_node_ids = list(range(self.num_nodes))
    #     num_without_solar = int(0.4 * self.num_nodes)
    
    #     center_idx = random.choice(all_node_ids)
    #     center = positions[center_idx]
    
    
    #     diffs = positions - center
    #     selected = order[:num_without_solar]
    #     no_solar_nodes = set(int(i) for i in selected)
    
    #     num_mobile = int(0.1 * self.num_nodes)
    #     mobile_pool = list(no_solar_nodes)
    #     mobile_nodes = set(random.sample(mobile_pool, min(num_mobile, len(mobile_pool))))
    
    #     self.nodes = []
    #     for node_id in range(self.num_nodes):
    #         x, y = positions[node_id]
    #         has_solar = node_id not in no_solar_nodes
    #         is_mobile = node_id in mobile_nodes
    
    #         mobility_pattern = "circle" if is_mobile else None
    #         mobility_params = {
    #             "radius": 1.0,
    #             "speed": 0.01,
    #             "center": [float(x), float(y)]
    #         } if is_mobile else {}
    
    #         node = SensorNode(
    #             node_id=node_id,
    #             initial_energy=self.node_initial_energy,
    #             low_threshold=self.low_threshold,
    #             high_threshold=self.high_threshold,
    #             position=[float(x), float(y)],
    #             has_solar=has_solar,
    #             is_mobile=is_mobile,
    #             mobility_pattern=mobility_pattern,
    #             mobility_params=mobility_params,
    #             **{k: v for k, v in self.network_config.items() if k not in ['low_threshold', 'high_threshold']}
    #         )
    #         self.nodes.append(node)

    # def run_routing1(self, t):
    #     """
    #     Each below-average node (prioritized from lowest energy) requests energy from a unique donor:
    #     - Donor must have energy > average
    #     - Among available donors, choose the one with highest energy and shortest distance
    #     - Donor can only be assigned to one receiver
    #     """
    #     routing_plans = []
    #
    #     average_energy = np.mean([node.current_energy for node in self.nodes])
    #
    #     low_energy_nodes = sorted(
    #         [node for node in self.nodes if node.current_energy < average_energy],
    #         key=lambda n: n.current_energy
    #     )
    #
    #     for receiver in low_energy_nodes:
    #         candidate_nodes = [
    #             node for node in self.nodes
    #             if node != receiver and node.current_energy > average_energy and node not in used_donors
    #         ]
    #
    #         if not candidate_nodes:
    #
    #         max_energy = max(n.current_energy for n in candidate_nodes)
    #         max_energy_nodes = [n for n in candidate_nodes if n.current_energy == max_energy]
    #
    #         closest_donor = min(max_energy_nodes, key=lambda node: receiver.distance_to(node))
    #         distance = receiver.distance_to(closest_donor)
    #
    #         used_donors.add(closest_donor)
    #
    #         if distance <= math.sqrt(3):
    #             path = [closest_donor, receiver]
    #         else:
    #             path = opportunistic_routing(self.nodes, closest_donor, receiver, max_hops=self.max_hops, t=t)
    #             if path is None:
    #                 print(f"[Routing Failed] {closest_donor.node_id} → {receiver.node_id}")
    #                 continue
    #
    #         routing_plans.append({
    #             "receiver": receiver,
    #             "donor": closest_donor,
    #             "path": path,
    #             "distance": distance
    #         })
    #
    #     return routing_plans
    #
    # def run_routing2(self, t):
    #     """
    #     Each below-average node (prioritized by largest energy deficit) requests energy from up to three unique donors:
    #     - Donors must have energy > average
    #     - Among available donors, choose those with highest energy and shortest distance
    #     - Each donor can only be assigned to one receiver
    #     - Each receiver can have up to three donors
    #
    #     Args:
    #         t: Current time step
    #     Returns:
    #         List of routing plans, each containing receiver, donor, path, and distance
    #     """
    #     routing_plans = []
    #     used_donors = set()  # Track donors assigned to any receiver
    #     receiver_donor_count = {node: 0 for node in self.nodes}  # Track number of donors per receiver
    #
    #     # Calculate average energy
    #     average_energy = np.mean([node.current_energy for node in self.nodes])
    #
    #     # Sort nodes by largest energy deficit (average_energy - current_energy)
    #     low_energy_nodes = sorted(
    #         [node for node in self.nodes if node.current_energy < average_energy],
    #         key=lambda n: average_energy - n.current_energy,
    #         reverse=True
    #     )
    #
    #     for receiver in low_energy_nodes:
    #         # Skip if receiver already has 3 donors
    #         if receiver_donor_count[receiver] >= 3:
    #             continue
    #
    #         # Select up to 3 donors for this receiver
    #         candidate_nodes = [
    #             node for node in self.nodes
    #             if node != receiver and node.current_energy > average_energy and node not in used_donors
    #         ]
    #
    #         # If no candidates, move to next receiver
    #         if not candidate_nodes:
    #             continue
    #
    #         # Sort candidates by energy (descending) and distance (ascending)
    #         sorted_candidates = sorted(
    #             candidate_nodes,
    #             key=lambda n: (-n.current_energy, receiver.distance_to(n))
    #         )
    #
    #         # Select up to 3 donors or as many as available
    #         selected_donors = sorted_candidates[:3 - receiver_donor_count[receiver]]
    #
    #         for donor in selected_donors:
    #             distance = receiver.distance_to(donor)
    #
    #             # Mark donor as used
    #             used_donors.add(donor)
    #             receiver_donor_count[receiver] += 1
    #
    #             # Plan path
    #             if distance <= math.sqrt(3):
    #                 path = [donor, receiver]
    #             else:
    #                 path = opportunistic_routing(self.nodes, donor, receiver, max_hops=self.max_hops, t=t)
    #                 if path is None:
    #                     print(f"[Routing Failed] {donor.node_id} → {receiver.node_id}")
    #                     continue
    #
    #             routing_plans.append({
    #                 "receiver": receiver,
    #                 "donor": donor,
    #                 "path": path,
    #                 "distance": distance
    #             })
    #
    #     return routing_plans

    def run_routing(self, t, max_donors_per_receiver=3):
        """
        Each below-average node (prioritized by largest energy deficit) requests energy from up to N unique donors:
        - Donors must have energy > average
        - Among available donors, choose those with highest energy and shortest distance
        - Each donor can only be assigned to one receiver
        - Each receiver can have up to `max_donors_per_receiver` donors
        """
        alive_nodes = [n for n in self.nodes if not getattr(n, 'is_dead', False)]
        routing_plans = []
        used_donors = set()  # Track donors assigned to any receiver
        receiver_donor_count = {node: 0 for node in alive_nodes}  # Track number of donors per receiver

        # Calculate average energy
        if not alive_nodes:
            return []
        average_energy = np.mean([node.current_energy for node in alive_nodes])

        # Sort nodes by largest energy deficit (average_energy - current_energy)
        low_energy_nodes = sorted(
            [node for node in alive_nodes if node.current_energy < average_energy],
            key=lambda n: average_energy - n.current_energy,
            reverse=True
        )

        for receiver in low_energy_nodes:
            if receiver_donor_count[receiver] >= max_donors_per_receiver:
                continue

            candidate_nodes = [
                node for node in alive_nodes
                if node is not receiver and node.current_energy > average_energy and node not in used_donors
            ]
            if not candidate_nodes:
                continue

            sorted_candidates = sorted(
                candidate_nodes,
                key=lambda n: (-n.current_energy, receiver.distance_to(n))
            )

            quota = max_donors_per_receiver - receiver_donor_count[receiver]
            for donor in sorted_candidates:
                if quota <= 0:
                    break

                distance = receiver.distance_to(donor)

                if distance <= math.sqrt(3):
                    path = [donor, receiver]
                else:
                    path = opportunistic_routing(alive_nodes, donor, receiver, max_hops=self.max_hops, t=t)
                    # path = eeor_find_path(self.nodes, donor, receiver, max_hops=self.max_hops)
                    if path is None:
                        print(f"[Routing Failed] {donor.node_id} → {receiver.node_id}")
                        continue

                used_donors.add(donor)
                receiver_donor_count[receiver] += 1
                quota -= 1

                routing_plans.append({
                    "receiver": receiver,
                    "donor": donor,
                    "path": path,
                    "distance": distance
                })

        return routing_plans

    def execute_energy_transfer(self, plans):
        """
        Execute energy transfers based on the routing plans returned by run_routing().
        Updates donor and receiver energies and histories.
        """
        for plan in plans:
            donor = plan["donor"]
            receiver = plan["receiver"]
            path = plan["path"]
            distance = plan["distance"]

            energy_sent = donor.E_char

            if getattr(donor, 'is_dead', False) or getattr(receiver, 'is_dead', False):
                continue

            if distance <= math.sqrt(3):
                eta = donor.energy_transfer_efficiency(receiver)
                energy_received = energy_sent * eta

                donor.current_energy -= donor.energy_consumption(receiver, transfer_WET=True)
                if donor.current_energy < 0:
                    donor.current_energy = 0
                    donor.is_dead = True
                    continue
                receiver.current_energy += energy_received

                donor.transferred_history.append(energy_sent)
                receiver.received_history.append(energy_received)

                print(f"[Direct WET] {donor.node_id} → {receiver.node_id}, η={eta:.2f}, +{energy_received:.2f}J")
            
            else:
                energy_left = energy_sent
                donor.transferred_history.append(energy_sent)

                for i in range(len(path) - 1):
                    sender = path[i]
                    receiver_i = path[i + 1]

                    if getattr(sender, 'is_dead', False) or getattr(receiver_i, 'is_dead', False):
                        break

                    eta = sender.energy_transfer_efficiency(receiver_i)

                    energy_delivered = energy_left * eta

                    transfer_WET = (i == 0)
                    sender.current_energy -= sender.energy_consumption(receiver_i, transfer_WET=transfer_WET)
                    if sender.current_energy < 0:
                        sender.current_energy = 0
                        sender.is_dead = True
                        break

                    receiver_i.current_energy += energy_delivered
                    receiver_i.received_history.append(energy_delivered)

                    print(
                        f"  [Hop {i + 1}] {sender.node_id} → {receiver_i.node_id}, d={sender.distance_to(receiver_i):.2f}m, η={eta:.3f}, +{energy_delivered:.2f}J")

                    energy_left = energy_delivered

    def update_network_energy(self, t):
        """Update the energy of all nodes considering only harvesting and decay."""
        for node in self.nodes:
            if getattr(node, 'is_dead', False):
                continue
            node.update_position(t)
            E_gen, E_decay = node.update_energy(t)
            self.display_energy_update(node, E_gen, E_decay)

    def balance_network_energy(self):
        """Balance the energy in the network to ensure no node exceeds its energy thresholds."""
        balance_energy(self.nodes)

    def display_routing(self, path):
        """Display the optimal path found by the routing algorithm."""
        print("Optimal routing path:")
        for node in path:
            print(f"Node {node.node_id} -> ", end="")
        print("End of path")

    def display_energy_update(self, node, E_gen, E_con):
        print(f"Node {node.node_id} energy updated:")
        print(f"  Energy generated (solar): {E_gen:.2f} J")
        print(f"  Energy decayed (battery loss): {E_con:.2f} J")
        print(f"  Current energy: {node.current_energy:.2f} J")

    def simulate_network(self, time_steps):
        """Simulate the network for a given number of time steps."""
        for t in range(time_steps):
            print(f"\n--- Time step {t + 1} ---")
            self.run_routing(t)  # Pass t as a parameter
            self.update_network_energy(t)  # Pass t as a parameter
            self.balance_network_energy()
