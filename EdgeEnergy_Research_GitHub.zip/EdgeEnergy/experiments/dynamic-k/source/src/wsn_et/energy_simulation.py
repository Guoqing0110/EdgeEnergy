
import csv
import random
# Headless packaging: unused turtle.pd import removed (no numerical change).
from datetime import datetime, timedelta
import numpy as np
from datetime import datetime, timedelta

from .sensor_node import SensorNode
from .receiver_info_link import ReceiverInfoLinkVirtual
from .lookahead import pick_k_via_lookahead
from .energy_management import balance_energy
try:
    from .schedulers import PowerControlScheduler
except Exception:
    PowerControlScheduler = None

class EnergySimulation:
    def __init__(self, network, time_steps,scheduler=None):
        """
        Initialize the energy simulation for the network.

        :param network: The network object that contains nodes and their parameters.
        :param time_steps: Total number of time steps to simulate.
        """
        self.network = network
        self.time_steps = time_steps
        self.results = []  # To store the simulation results (energy, transfer, etc.)
        self.scheduler = scheduler
        self.plans_by_time = {}

        try:
            self.receiver_info = ReceiverInfoLinkVirtual(network, max_hops=getattr(network, 'max_hops', 5), output_dir=network.network_config.get('output_dir', 'date927'))
        except Exception:
            self.receiver_info = None

        self.K = 1
        self.K_max = 24
        self.last_reward = None
        self.last_direction = +1
        self.hysteresis = 0.2
        self.w_b = 0.2
        self.w_d = 0.5
        self.w_l = 0.2

        self.K_history = []
        self.K_timestamps = []
        self.K_stats = []

        self.energy_averages = []
        self.energy_Standards = []
        self.time_steps = time_steps

        self.cand = []


        self.use_lookahead = False
        self.lookahead_max_step = 3
        self.lookahead_flat_step = 2


        self._adaptk_logged_header = False
        self._adaptk_last_t = None

    # def _reward(self, stats):
    #     return (self.w_b * (stats["pre_std"] - stats["post_std"])
    #             + self.w_d * stats["delivered_total"]
    #             - self.w_l * stats["total_loss"])

    def _reward(self, stats):
        """Compute the normalized reward value."""

        improve = stats["pre_std"] - stats["post_std"]
        delivered = stats["delivered_total"]
        loss = stats["total_loss"]

        if not hasattr(self, 'max_improve'):
            self.max_improve = max(abs(improve), 1e-9)
            self.max_delivered = max(delivered, 1e-9)
            self.max_loss = max(loss, 1e-9)
        else:
            self.max_improve = max(self.max_improve, abs(improve))
            self.max_delivered = max(self.max_delivered, delivered)
            self.max_loss = max(self.max_loss, loss)

        norm_improve = improve / self.max_improve
        norm_delivered = delivered / self.max_delivered
        norm_loss = loss / self.max_loss

        return  (
                self.w_b * norm_improve +
                self.w_d * norm_delivered -
                self.w_l * norm_loss
        )

    # def _adapt_K(self, stats):
    #     cur_reward = self._reward(stats)
    #     if self.last_reward is None:
    #         self.last_reward = cur_reward
    #         return
    #     improve = (cur_reward - self.last_reward) / (abs(self.last_reward) + 1e-9)
    #     if improve > self.hysteresis:
    #         new_K = self.K + self.last_direction
    #     elif improve < -self.hysteresis:
    #         self.last_direction *= -1
    #         new_K = self.K + self.last_direction
    #     else:
    #         new_K = self.K
    #     self.K = max(1, min(self.K_max, new_K))
    #     self.last_reward = cur_reward

    def _adapt_K(self, stats):
        old_K = self.K
        cur_reward = self._reward(stats)
        prev_reward = self.last_reward
        prev_dir = self.last_direction
        prev_K = self.K
        if prev_reward is None:
            self.last_reward = cur_reward
            return


        improve = cur_reward - prev_reward
        # improve = (cur_reward - prev_reward) / (abs(prev_reward) + 1e-9)

        # denom = max(abs(prev_reward), 1)
        # improve = (cur_reward - prev_reward) / denom
        #

        # step = 2 if abs(improve) > 0.4 else 1
        step = 1

        if self.use_lookahead:
            try:
                new_K, _ = pick_k_via_lookahead(
                    self.network, self.scheduler,
                    getattr(self, "_adaptk_last_t", 0),
                    self.K, self.last_direction, improve, self.hysteresis, self.K_max,
                    horizon_minutes=60, reward_fn=self._reward,
                    max_step=self.lookahead_max_step, flat_step=self.lookahead_flat_step
                )
            except Exception:
                if improve > self.hysteresis:
                    new_K = self.K + self.last_direction * step
                elif improve < -self.hysteresis:
                    self.last_direction *= -1
                    new_K = self.K + self.last_direction * step
                else:
                    new_K = self.K
        else:
            if improve > self.hysteresis:
                new_K = self.K + self.last_direction * step
            elif improve < -self.hysteresis:
                self.last_direction *= -1
                new_K = self.K + self.last_direction * step
            else:
                new_K = self.K


        self.K = max(1, min(self.K_max, new_K))


        dir_new = self.last_direction
        self.last_reward = cur_reward

        # try:
        #     log_path = "data/adaptK_log.txt"
        #     if not hasattr(self, "_adaptk_logged_header"):
        #         self._adaptk_logged_header = False
        #     if not self._adaptk_logged_header:
        #         with open(log_path, "w", encoding="utf-8") as f:
        #             f.write("timestep,pre_std,post_std,delivered,loss,reward_prev,reward_cur,improve,dir_prev,dir_new,K_old,K_new\n")
        #         self._adaptk_logged_header = True
        #     t_val = getattr(self, "_adaptk_last_t", None)
        #     with open(log_path, "a", encoding="utf-8") as f:
        #         f.write("{t},{p:.6f},{q:.6f},{d:.6f},{l:.6f},{rp:.6f},{rc:.6f},{im:.6f},{dirp},{dirn},{ko},{kn}\n".format(
        #             t=(-1 if t_val is None else t_val),
        #             p=stats["pre_std"], q=stats["post_std"], d=stats["delivered_total"], l=stats["total_loss"],
        #             rp=prev_reward, rc=cur_reward, im=improve, dirp=prev_dir, dirn=dir_new,
        #             ko=prev_K, kn=self.K
        #         ))
        # except Exception:
        #     pass

        self.K_stats.append({
            'old_K': old_K,
            'new_K': self.K,
            'improve': improve,
            'reward': cur_reward,
            'pre_std': stats["pre_std"],
            'post_std': stats["post_std"],
            'delivered': stats["delivered_total"],
            'loss': stats["total_loss"]
        })

    def print_statistics(self):
        """Print average variance over time and total loss energy at the end of the run."""
        avg_variance = np.mean(self.energy_Standards) if self.energy_Standards else 0
        print(f"\nAverage variance over all sampled time points: {avg_variance:.4f}")

        total_sent_energy = sum(sum(node.transferred_history) for node in self.network.nodes)

        total_received_energy = sum(sum(node.received_history) for node in self.network.nodes)

        total_loss_energy = total_sent_energy - total_received_energy

        print(f"Total loss energy: {total_loss_energy:.4f} Joules")
        print(f"Total sent energy: {total_sent_energy:.4f} Joules")
        print(f"Total received energy: {total_received_energy:.4f} Joules")
        print(f"Energy transfer efficiency: {(total_received_energy / total_sent_energy * 100 if total_sent_energy > 0 else 0):.2f}%")

        return {
            'avg_variance': avg_variance,
            'total_loss_energy': total_loss_energy,
            'total_sent_energy': total_sent_energy,
            'total_received_energy': total_received_energy
        }

    def _compute_step_stats(self, plans, pre_energies, pre_received_total):
        post_energies = np.array([n.current_energy for n in self.network.nodes], dtype=float)
        pre_std = float(np.std(pre_energies))
        post_std = float(np.std(post_energies))

        sent_total = sum(p["donor"].E_char for p in plans)
        post_received_total = sum(sum(n.received_history) for n in self.network.nodes)
        delivered_total = max(0.0, post_received_total - pre_received_total)
        total_loss = max(0.0, sent_total - delivered_total)

        return {
            "pre_std": pre_std,
            "post_std": post_std,
            "delivered_total": delivered_total,
            "total_loss": total_loss
        }

    def simulate(self):
        start_time = datetime(2023, 1, 2)
        """Run the energy simulation for the specified number of time steps."""
        start_time = datetime(2023, 1, 2)
        for t in range(self.time_steps):
            print("\n--- Time step {} ---".format(t + 1))

            self.network.update_network_energy(t)

            # if hasattr(self.network, "adcr_link") and (self.network.adcr_link is not None):
            #     self.network.adcr_link.step(t)

            if t % 60 == 0:
                current_time = start_time + timedelta(minutes=t)
                pre_energies = np.array([n.current_energy for n in self.network.nodes], dtype=float)
                pre_received_total = sum(sum(n.received_history) for n in self.network.nodes)

                node_energies = [node.current_energy for node in self.network.nodes]
                energy_avg = np.mean(node_energies)
                energy_std = np.std(node_energies)

                self.energy_averages.append(energy_avg)
                self.energy_Standards.append(energy_std)

                if self.scheduler is not None:
                    if hasattr(self.scheduler, "K"):
                        try:
                            self.scheduler.K = self.K
                            # self.scheduler.K = 1
                        except Exception:
                            pass

                    result = self.scheduler.plan(self.network, t)
                    if isinstance(result, tuple):
                        plans, cand = result
                    else:
                        plans = result
                        cand = []

                    if (PowerControlScheduler is not None) and isinstance(self.scheduler, PowerControlScheduler):
                        self.scheduler.execute_plans(self.network, plans)
                    else:
                        self.network.execute_energy_transfer(plans)
                else:
                    plans = self.network.run_routing(t, max_donors_per_receiver=self.K)
                    self.network.execute_energy_transfer(plans)

                # try:
                #     if self.receiver_info is not None:
                #         receivers = []
                #         for p in plans:
                #             d = p.get("donor")
                #             r = p.get("receiver")
                #             path = p.get("path") or []
                #             if r is not None:
                #                 final_receiver = path[-1] if len(path) > 0 else r
                #                 receivers.append(final_receiver)
                #         if receivers:
                #             uniq_receivers = list({id(x): x for x in receivers}.values())
                #             self.receiver_info.report_receivers_to_virtual(
                #                 uniq_receivers,
                #                 participants=None,
                #                 include_idle=False
                #             )
                # except Exception:
                #     pass

                stats = self._compute_step_stats(plans, pre_energies, pre_received_total)

                try:
                    node_energies = {node.node_id: node.current_energy for node in self.network.nodes}
                    self.plans_by_time[t] = {
                        "plans": plans,
                        "candidates": cand,
                        "node_energies": node_energies
                    }
                except Exception:
                    pass

                print("K={} pre_std={:.4f} post_std={:.4f} delivered={:.2f} loss={:.2f}".format(
                    self.K, stats['pre_std'], stats['post_std'], stats['delivered_total'], stats['total_loss']
                ))

                self._adaptk_last_t = t
                self._adapt_K(stats)

                self.K_history.append(self.K)
                self.K_timestamps.append(current_time)


                # self.plot_energy_stats()

            self.record_energy_status()
        self.plot_K_history()
        self.print_statistics()

    def plot_K_history(self, mdates=None):
        """Plot K values over time."""
        from matplotlib import pyplot as plt
        import matplotlib.dates as mdates
        from matplotlib.dates import DateFormatter
        if not self.K_history:
            print("No K-history data is available for plotting.")
            return

        plt.figure(figsize=(12, 6))
        plt.plot(self.K_timestamps, self.K_history, marker='o', linestyle='-')

        plt.title('Dynamic K Values Over Time')
        plt.xlabel('Time')
        plt.ylabel('K Value')

        try:
            date_formatter = DateFormatter('%a %H:%M')
            plt.gca().xaxis.set_major_formatter(date_formatter)
            plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=1))
            plt.gcf().autofmt_xdate()
        except Exception as e:
            print(f"Date formatting failed: {e}. Using the default formatter instead.")

        plt.grid(True, linestyle='--', alpha=0.7)

        plt.tight_layout()
        plt.savefig('date927/K_value_over_time.png')
        plt.show()

        self.create_K_table()

    def create_K_table(self):
        """Create tabular K-history data."""
        import pandas as pd
        df = pd.DataFrame({
            'Time': [t.strftime('%Y-%m-%d %H:%M') for t in self.K_timestamps],
            'Day': [t.strftime('%A') for t in self.K_timestamps],
            'Hour': [t.hour for t in self.K_timestamps],
            'K_Value': self.K_history
        })

        daily_stats = df.groupby('Day')['K_Value'].agg(['mean', 'min', 'max', 'std']).round(2)

        df.to_csv('date927/K_value_history.csv', index=False)
        daily_stats.to_csv('date927/K_value_daily_stats.csv')

        print("Saved K-history records and summary statistics to CSV files.")
        print("\nDaily K-value summary:")
        print(daily_stats)

    def record_energy_status(self):
        """Record the current energy state for later analysis."""
        pass

        self.plot_K_history()
        self.print_statistics()



    def plot_K_history(self, mdates=None):
        import plotly.graph_objects as go
        if not self.K_history:
            print("No K-history data is available for plotting.")
            return

        x_vals = [i * 60 for i in range(len(self.K_history))]

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=x_vals, y=self.K_history, mode='lines+markers', name='K',
            hovertemplate='Time: %{x} min<br>K: %{y}<extra></extra>'
        ))

        fig.update_layout(
            title='Dynamic K Values Over Time',
            xaxis_title='Time (minutes)',
            yaxis_title='K Value',
            template='plotly_white',
            hovermode='closest'
        )

        # fig.write_image('K_value_over_time.png', width=1000, height=600, scale=2)
        fig.show()

        self.create_K_table()

    def create_K_table(self):
        """Create tabular K-history data."""
        import pandas as pd
        df = pd.DataFrame({
            'Time': [t.strftime('%Y-%m-%d %H:%M') for t in self.K_timestamps],
            'Day': [t.strftime('%A') for t in self.K_timestamps],
            'Hour': [t.hour for t in self.K_timestamps],
            'K_Value': self.K_history
        })

        daily_stats = df.groupby('Day')['K_Value'].agg(['mean', 'min', 'max', 'std']).round(2)

        df.to_csv('date927/K_value_history.csv', index=False)
        daily_stats.to_csv('date927/K_value_daily_stats.csv')

        print("Saved K-history records and summary statistics to CSV files.")
        print("\nDaily K-value summary:")
        print(daily_stats)

    def record_energy_status(self):
        """Record the energy status of all nodes in the network."""
        energy_data = []
        for node in self.network.nodes:
            energy_data.append({
                "node_id": node.node_id,
                "current_energy": node.current_energy,
                "received_energy": sum(node.received_history),  # Sum of all received energy
                "transferred_energy": sum(node.transferred_history),  # Sum of all transferred energy
                "energy_history": node.energy_history[-1] if node.energy_history else None
            })
        self.results.append(energy_data)

    def save_results(self, filename="data/results.csv"):
        """Save the simulation results to a CSV file."""
        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            # Write header
            writer.writerow(["Time Step", "Node ID", "Current Energy", "Received Energy", "Transferred Energy", "Energy History"])
            for t, step_result in enumerate(self.results):
                for node_data in step_result:
                    writer.writerow([t + 1, node_data["node_id"], node_data["current_energy"],
                                     node_data["received_energy"], node_data["transferred_energy"],
                                     node_data["energy_history"]])

        print(f"Results saved to {filename}")

    def display_results(self):
        """Display the simulation results."""
        print("\n--- Energy Simulation Results ---")
        for t, step_result in enumerate(self.results):
            print(f"\nTime step {t + 1}:")
            for node_data in step_result:
                print(f"Node {node_data['node_id']} - Current Energy: {node_data['current_energy']:.2f} Joules")
                print(f"  Received Energy: {node_data['received_energy']:.2f} Joules")
                print(f"  Transferred Energy: {node_data['transferred_energy']:.2f} Joules")
                if node_data['energy_history']:
                    print(f"  Energy History: {node_data['energy_history']}")

    def save_results(self, filename="simulation_results.csv"):
        """Save the simulation results to a CSV file."""
        import csv
        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            # Write header
            writer.writerow(
                ["Time Step", "Node ID", "Current Energy", "Received Energy", "Transferred Energy", "Energy History"])
            for t, step_result in enumerate(self.results):
                for node_data in step_result:
                    writer.writerow([t + 1, node_data["node_id"], node_data["current_energy"],
                                     node_data["received_energy"], node_data["transferred_energy"],
                                     node_data["energy_history"]])

    def plot_results(self):
        """Plot the results of the energy simulation."""
        import matplotlib.pyplot as plt
        time_steps = list(range(1, self.time_steps + 1))

        # Extract energy data for plotting
        node_ids = [node.node_id for node in self.network.nodes]
        energy_data = {node_id: [] for node_id in node_ids}

        for step_result in self.results:
            for node_data in step_result:
                energy_data[node_data["node_id"]].append(node_data["current_energy"])

        # Plot energy data for each node
        plt.figure(figsize=(10, 6))
        for node_id, energy_values in energy_data.items():
            plt.plot(time_steps, energy_values, label=f"Node {node_id}")

        plt.title("Energy Consumption Over Time")
        plt.xlabel("Time Step")
        plt.ylabel("Energy (Joules)")
        plt.legend(loc="upper right", bbox_to_anchor=(1.15, 1))
        plt.grid(True)
        plt.show()

    def plot_energy_stats(self):
        """Plot average energy and variance every 60 time steps."""
        from matplotlib import pyplot as plt
        plt.figure(figsize=(12, 6))

        plt.subplot(2, 1, 1)
        plt.plot(range(0, len(self.energy_averages) * 60, 60), self.energy_averages, marker='o', color='b')
        plt.title("Average Node Energy Every 60 Time Units")
        plt.xlabel("Time (minutes)")
        plt.ylabel("Average Energy (Joules)")
        plt.grid(True)

        plt.subplot(2, 1, 2)
        plt.plot(range(0, len(self.energy_Standards) * 60, 60), self.energy_Standards, marker='o', color='r')
        plt.title("Variance of Node Energy Every 60 Time Units")
        plt.xlabel("Time (minutes)")
        plt.ylabel("Energy Variance (Joules^2)")
        plt.grid(True)

        plt.tight_layout()
        plt.show()
