# --- EEOR minimal reproducible implementation ---

import math
import heapq
from collections import defaultdict


def _neighbor_range():
    return math.sqrt(3)

def _build_neighbors(nodes):
    nmap = {n.node_id: [] for n in nodes}
    ndict = {n.node_id: n for n in nodes}
    R = _neighbor_range()
    for i, ni in enumerate(nodes):
        for j, nj in enumerate(nodes):
            if i == j: continue
            d = ni.distance_to(nj)
            if d <= R:
                nmap[ni.node_id].append((nj.node_id, d))
    return nmap, ndict

def _build_neighbors_adaptive(nodes, target_neighbors=6):
    """Adaptive neighbor discovery that adjusts communication range to reach a target neighbor count."""
    nmap = {n.node_id: [] for n in nodes}
    ndict = {n.node_id: n for n in nodes}
    
    for ni in nodes:
        distances = []
        for nj in nodes:
            if ni != nj:
                d = ni.distance_to(nj)
                distances.append((d, nj))
        
        distances.sort(key=lambda x: x[0])
        
        if len(distances) >= target_neighbors:
            R = distances[target_neighbors-1][0] * 1.1
        else:
            R = distances[-1][0] if distances else math.sqrt(3)
        
        # original_R = math.sqrt(3)
        
        for d, nj in distances:
            if d <= R:
                nmap[ni.node_id].append((nj.node_id, d))
    
    return nmap, ndict

def _link_error_prob(d, k=0.05, gamma=2.0):
    return min(0.95, k * (d ** gamma))

def _min_tx_power(d, base=1.0, tau=2.0):
    return base * (d ** tau)

def _expected_cost_given_fwd(u_id, Fwd_ids, C, neighbor_map, node_dict):
    """


    """
    if not Fwd_ids:
        return float('inf'), 0.0, 1.0

    prod = 1.0
    w_u = 0.0
    max_d = 0.0

    for v_id in Fwd_ids:
        d = None
        for nid, dist in neighbor_map[u_id]:
            if nid == v_id:
                d = dist
                break
        if d is None:
            return float('inf'), 0.0, 1.0
        e_uv = _link_error_prob(d)
        prod *= e_uv
        if d > max_d: max_d = d

    alpha = prod
    rho = 1.0 - alpha
    if rho <= 1e-12:
        return float('inf'), rho, alpha

    w_u = _min_tx_power(max_d)

    beta = 0.0
    prefix_fail = 1.0
    for i, v_id in enumerate(Fwd_ids):
        # e(u, v)
        d_uv = None
        for nid, dist in neighbor_map[u_id]:
            if nid == v_id:
                d_uv = dist
                break
        e_uv = _link_error_prob(d_uv)
        success = (1.0 - e_uv)
        beta += prefix_fail * success * C.get(v_id, float('inf'))
        prefix_fail *= e_uv

    C_h = w_u / rho
    C_f = beta / rho
    return (C_h + C_f), rho, alpha

def _select_forwarder_prefix(u_id, neighbors_ids, C, neighbor_map):
    ordered = sorted(neighbors_ids, key=lambda vid: C.get(vid, float('inf')))
    best_cost = float('inf')
    best_fwd = []
    trial_fwd = []

    for vid in ordered:
        trial_fwd.append(vid)
        cost, _, _ = _expected_cost_given_fwd(u_id, trial_fwd, C, neighbor_map, None)
        if cost < best_cost:
            best_cost = cost
            best_fwd = list(trial_fwd)
        else:
            break
    return best_cost, best_fwd

def eeor_compute_costs(nodes, target_node_id, max_iter=20):
    neighbor_map, node_dict = _build_neighbors(nodes)
    V = [n.node_id for n in nodes]

    C = {vid: float('inf') for vid in V}
    FWD = {vid: [] for vid in V}
    C[target_node_id] = 0.0

    for _ in range(max_iter):
        updated = False
        for u_id in V:
            if u_id == target_node_id:
                FWD[u_id] = []
                continue
            neigh_ids = [nid for (nid, _) in neighbor_map[u_id]]
            if not neigh_ids:
                continue
            new_cost, new_fwd = _select_forwarder_prefix(u_id, neigh_ids, C, neighbor_map)
            if new_cost < C[u_id] - 1e-12:
                C[u_id] = new_cost
                FWD[u_id] = new_fwd
                updated = True
        if not updated:
            break
    return C, FWD

def eeor_compute_costs_adaptive(nodes, target_node_id, max_iter=20, target_neighbors=6):
    """Compute EEOR cost with adaptive neighbor discovery enabled."""
    neighbor_map, node_dict = _build_neighbors_adaptive(nodes, target_neighbors)
    V = [n.node_id for n in nodes]

    C = {vid: float('inf') for vid in V}
    FWD = {vid: [] for vid in V}
    C[target_node_id] = 0.0

    for _ in range(max_iter):
        updated = False
        for u_id in V:
            if u_id == target_node_id:
                FWD[u_id] = []
                continue
            neigh_ids = [nid for (nid, _) in neighbor_map[u_id]]
            if not neigh_ids:
                continue
            new_cost, new_fwd = _select_forwarder_prefix(u_id, neigh_ids, C, neighbor_map)
            if new_cost < C[u_id] - 1e-12:
                C[u_id] = new_cost
                FWD[u_id] = new_fwd
                updated = True
        if not updated:
            break
    return C, FWD

def eeor_find_path(nodes, source_node, dest_node, max_hops=5):
    C, FWD = eeor_compute_costs(nodes, dest_node.node_id)

    path = [source_node]
    cur = source_node.node_id
    hops = 0

    while cur != dest_node.node_id and hops < max_hops:
        fwd = FWD.get(cur, [])
        if not fwd:
            break
        nxt = fwd[0]
        if nxt == cur or any(n.node_id == nxt for n in path):
            break
        path.append(next(n for n in nodes if n.node_id == nxt))
        cur = nxt
        hops += 1

    if path[-1].node_id != dest_node.node_id:
        return None
    return path

def eeor_find_path_adaptive(nodes, source_node, dest_node, max_hops=5, target_neighbors=6):
    """Find EEOR paths with adaptive neighbor discovery enabled."""
    C, FWD = eeor_compute_costs_adaptive(nodes, dest_node.node_id, target_neighbors=target_neighbors)

    path = [source_node]
    cur = source_node.node_id
    hops = 0

    while cur != dest_node.node_id and hops < max_hops:
        fwd = FWD.get(cur, [])
        if not fwd:
            break
        nxt = fwd[0]
        if nxt == cur or any(n.node_id == nxt for n in path):
            break
        path.append(next(n for n in nodes if n.node_id == nxt))
        cur = nxt
        hops += 1

    if path[-1].node_id != dest_node.node_id:
        return None
    return path
