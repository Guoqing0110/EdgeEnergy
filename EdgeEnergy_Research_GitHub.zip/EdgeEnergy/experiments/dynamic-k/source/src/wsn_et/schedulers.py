# schedulers.py

from __future__ import print_function
import math
import random
import numpy as np

try:
    # from .eeor import eeor_find_path, eeor_find_path_adaptive
    # from .opportunistic_routing import opportunistic_routing
    from .eeor import eeor_find_path, eeor_find_path_adaptive
    from .opportunistic_routing import opportunistic_routing
except Exception:
    from .eeor import eeor_find_path, eeor_find_path_adaptive
    from .opportunistic_routing import opportunistic_routing


class BaseScheduler(object):
    def __init__(self, K=2, max_hops=5):
        self.K = K
        self.max_hops = max_hops

    def plan(self, network, t):
        """Return a list of routing or energy-transfer plans."""
        raise NotImplementedError

    def post_step(self, network, t, feedback):
        """Optionally update internal state after one transfer step."""
        pass


class BaselineHeuristic(BaseScheduler):
    def plan(self, network, t):
        nodes = network.nodes
        plans = []
        used = set()

        avgE = float(np.mean([n.current_energy for n in nodes]))
        lows = sorted([n for n in nodes if n.current_energy < avgE],
                      key=lambda x: (avgE - x.current_energy), reverse=True)

        for r in lows:
            cand = [n for n in nodes if (n is not r) and (n.current_energy > avgE) and (n not in used)]
            if not cand:
                continue
            cand.sort(key=lambda d: (-d.current_energy, r.distance_to(d)))
            quota = self.K
            for d in cand:
                if quota <= 0:
                    break
                dist = r.distance_to(d)
                if dist <= math.sqrt(3):
                    path = [d, r]
                else:
                    path = eeor_find_path(nodes, d, r, max_hops=self.max_hops)
                    if path is None:
                        continue
                plans.append({"receiver": r, "donor": d, "path": path, "distance": dist})
                used.add(d)
                quota -= 1
        return plans


class LyapunovScheduler(BaseScheduler):
    def __init__(self, V=0.5, K=1, max_hops=5):
        BaseScheduler.__init__(self, K, max_hops)
        self.V = float(V)

    def _path_eta(self, path):
        eta = 1.0
        for i in range(len(path) - 1):
            eta *= path[i].energy_transfer_efficiency(path[i + 1])
        if eta < 1e-6:
            eta = 1e-6
        if eta > 1.0:
            eta = 1.0
        return eta

    def plan(self, network, t):
        nodes = network.nodes
        E = np.array([n.current_energy for n in nodes], dtype=float)
        E_bar = float(E.mean())
        Q = dict((n, max(0.0, E_bar - n.current_energy)) for n in nodes)

        receivers = sorted([n for n in nodes if Q[n] > 0], key=lambda x: Q[x], reverse=True)
        donors = [n for n in nodes if n.current_energy > E_bar]
        used = set()
        plans = []
        all_candidates = []

        for r in receivers:
            cand = []
            for d in donors:
                if d in used or d is r:
                    continue
                dist = r.distance_to(d)
                if dist <= math.sqrt(3):
                    path = [d, r]
                    eta = d.energy_transfer_efficiency(r)
                else:
                    path = eeor_find_path_adaptive(nodes, d, r, max_hops=self.max_hops)
                    # path = eeor_find_path(nodes, d, r, max_hops=self.max_hops)
                    if path is None:
                        continue
                    eta = self._path_eta(path)
                if eta < 0.1:
                    continue
                    
                E_char = getattr(d, "E_char", 300.0)
                delivered = E_char * eta
                loss = max(0.0, E_char - delivered)
                Q_normalized = Q[r] / E_bar
                score = eta * (Q_normalized + self.V) - self.V
                # score = Q[r] * delivered - self.V * loss
                cand.append((score, d, r, path, dist, delivered, loss))
            if not cand:
                continue
            cand.sort(key=lambda x: x[0], reverse=True)
            all_candidates.extend(cand)
            quota = self.K
            for sc, d, rr, path, dist, delivered, loss in cand:
                if quota <= 0:
                    break
                plans.append({
                    "receiver": rr, 
                    "donor": d, 
                    "path": path, 
                    "distance": dist,
                    "delivered": delivered,
                    "loss": loss
                })
                used.add(d)
                quota -= 1
        return plans, all_candidates


class ClusterScheduler(BaseScheduler):
    def __init__(self, round_period=360, K=2, max_hops=5, p_ch=0.05):
        BaseScheduler.__init__(self, K, max_hops)
        self.round_period = int(round_period)
        self.p_ch = float(p_ch)
        self.cluster_of = {}  # node_id -> ch_id
        self.ch_set = set()

    def _recluster(self, nodes, t):
        self.ch_set.clear()
        meanE = float(np.mean([x.current_energy for x in nodes]))
        for n in nodes:
            prob = self.p_ch * (n.current_energy / (1.0 + meanE))
            if random.random() < prob:
                self.ch_set.add(n.node_id)
        if not self.ch_set:
            top = max(nodes, key=lambda x: x.current_energy)
            self.ch_set.add(top.node_id)

        self.cluster_of.clear()
        id2node = dict((n.node_id, n) for n in nodes)
        ch_nodes = [id2node[i] for i in self.ch_set]
        for n in nodes:
            best = min(ch_nodes, key=lambda ch: n.distance_to(ch))
            self.cluster_of[n.node_id] = best.node_id

    def plan(self, network, t):
        nodes = network.nodes
        if (t % self.round_period == 0) or (not self.cluster_of):
            self._recluster(nodes, t)

        id2node = dict((n.node_id, n) for n in nodes)
        clusters = {}
        for n in nodes:
            ch_id = self.cluster_of[n.node_id]
            clusters.setdefault(ch_id, []).append(n)

        plans = []
        for ch_id, members in clusters.items():
            ch = id2node[ch_id]
            avgE = float(np.mean([m.current_energy for m in members]))
            lows = sorted([m for m in members if m.current_energy < avgE],
                          key=lambda x: avgE - x.current_energy, reverse=True)
            highs = [m for m in members if m.current_energy > avgE]

            if ch in highs:
                for r in lows:
                    if r is ch:
                        continue
                    dist = r.distance_to(ch)
                    if dist <= math.sqrt(3):
                        path = [ch, r]
                    else:
                        path = eeor_find_path(nodes, ch, r, max_hops=self.max_hops)
                        if path is None:
                            continue
                    plans.append({"receiver": r, "donor": ch, "path": path, "distance": dist})
            else:
                highs_sorted = sorted(highs, key=lambda x: (-x.current_energy, ch.distance_to(x)))
                quota = self.K
                for d in highs_sorted:
                    if quota <= 0:
                        break
                    dist = ch.distance_to(d)
                    if dist <= math.sqrt(3):
                        path = [d, ch]
                    else:
                        path = eeor_find_path(nodes, d, ch, max_hops=self.max_hops)
                        if path is None:
                            continue
                    plans.append({"receiver": ch, "donor": d, "path": path, "distance": dist})
                    quota -= 1
        return plans


class PredictionScheduler(BaseScheduler):
    def __init__(self, alpha=0.6, horizon_min=60, K=2, max_hops=5):
        BaseScheduler.__init__(self, K, max_hops)
        self.alpha = float(alpha)
        self.horizon = int(horizon_min)
        self.prev_harv = {}

    def _predict_harvest(self, node, t):
        obs = node.energy_harvest(t)
        last = self.prev_harv.get(node.node_id, obs)
        est = self.alpha * obs + (1.0 - self.alpha) * last
        self.prev_harv[node.node_id] = est
        return est * (self.horizon / 60.0)

    def plan(self, network, t):
        nodes = network.nodes
        avgE = float(np.mean([n.current_energy for n in nodes]))
        pred_surplus = dict((n, (n.current_energy + self._predict_harvest(n, t))) for n in nodes)

        receivers = sorted([n for n in nodes if n.current_energy < avgE],
                           key=lambda n: (avgE - n.current_energy), reverse=True)
        plans = []
        used = set()

        for r in receivers:
            cand = [n for n in nodes if (n is not r) and (pred_surplus[n] > avgE) and (n not in used)]
            if not cand:
                continue
            cand.sort(key=lambda d: (-pred_surplus[d], r.distance_to(d)))
            quota = self.K
            for d in cand:
                if quota <= 0:
                    break
                dist = r.distance_to(d)
                if dist <= math.sqrt(3):
                    path = [d, r]
                else:
                    path = eeor_find_path(nodes, d, r, max_hops=self.max_hops)
                    if path is None:
                        continue
                plans.append({"receiver": r, "donor": d, "path": path, "distance": dist})
                used.add(d)
                quota -= 1
        return plans


class PowerControlScheduler(BaseScheduler):
    def __init__(self, target_eta=0.25, K=2, max_hops=5):
        BaseScheduler.__init__(self, K, max_hops)
        self.target_eta = float(target_eta)

    def _path_eta(self, path):
        eta = 1.0
        for i in range(len(path) - 1):
            eta *= path[i].energy_transfer_efficiency(path[i + 1])
        if eta < 1e-6:
            eta = 1e-6
        if eta > 1.0:
            eta = 1.0
        return eta

    def plan(self, network, t):
        nodes = network.nodes
        avgE = float(np.mean([n.current_energy for n in nodes]))
        receivers = sorted([n for n in nodes if n.current_energy < avgE],
                           key=lambda n: (avgE - n.current_energy), reverse=True)
        plans = []
        used = set()

        for r in receivers:
            cand = [n for n in nodes if (n is not r) and (n.current_energy > avgE) and (n not in used)]
            cand.sort(key=lambda d: (-d.current_energy, r.distance_to(d)))
            quota = self.K
            for d in cand:
                if quota <= 0:
                    break
                dist = r.distance_to(d)
                if dist <= math.sqrt(3):
                    path = [d, r]
                else:
                    path = eeor_find_path(nodes, d, r, max_hops=self.max_hops)
                    if path is None:
                        continue
                eta = self._path_eta(path)
                E_char = getattr(d, "E_char", 300.0)
                scale = min(1.0, self.target_eta / eta)
                energy_sent = max(0.0, E_char * scale)
                plans.append({
                    "receiver": r, "donor": d, "path": path, "distance": dist,
                    "energy_sent": energy_sent
                })
                used.add(d)
                quota -= 1
        return plans

    @staticmethod
    def execute_plans(network, plans):
        """Execute plans using per-plan energy values without changing the network default executor."""
        for plan in plans:
            d = plan["donor"]; r = plan["receiver"]; path = plan["path"]; dist = plan["distance"]
            energy_sent = float(plan.get("energy_sent", getattr(d, "E_char", 300.0)))

            if dist <= math.sqrt(3):
                eta = d.energy_transfer_efficiency(r)
                energy_received = energy_sent * eta
                d.current_energy -= d.energy_consumption(r, transfer_WET=True)
                r.current_energy += energy_received
                d.transferred_history.append(energy_sent)
                r.received_history.append(energy_received)
            else:
                energy_left = energy_sent
                d.transferred_history.append(energy_sent)
                for i in range(len(path) - 1):
                    s = path[i]; rr = path[i + 1]
                    eta = s.energy_transfer_efficiency(rr)
                    delivered = energy_left * eta
                    transfer_WET = (i == 0)
                    s.current_energy -= s.energy_consumption(rr, transfer_WET=transfer_WET)
                    rr.current_energy += delivered
                    rr.received_history.append(delivered)
                    energy_left = delivered
