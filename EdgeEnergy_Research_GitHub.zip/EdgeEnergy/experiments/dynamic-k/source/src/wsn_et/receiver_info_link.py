from __future__ import annotations
import os
import math
from typing import List, Dict, Tuple

try:
    from .opportunistic_routing import opportunistic_routing
except Exception:
    opportunistic_routing = None


class ReceiverInfoLinkVirtual(object):
    """





    """

    def __init__(self, network,
                 max_hops: int = 5,
                 output_dir: str = "date927",
                 consume_energy: bool = True,
                 r_virtual_neighbor: float = math.sqrt(3.0)):
        self.net = network
        self.max_hops = int(max_hops)
        self.output_dir = output_dir
        self.consume_energy = bool(consume_energy)
        self.r_virtual_neighbor = float(r_virtual_neighbor)

        self.virtual_center: Tuple[float, float] = (0.0, 0.0)
        self.last_paths: Dict[int, List] = {}          # r_id -> [SensorNode,...]
        self.last_comms: List[Dict] = []

        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except Exception:
            pass


    def _geo_center(self) -> Tuple[float, float]:
        nodes = self.net.nodes
        if not nodes:
            return (0.0, 0.0)
        xs = [n.position[0] for n in nodes]
        ys = [n.position[1] for n in nodes]
        return (sum(xs) / float(len(xs)), sum(ys) / float(len(ys)))

    @staticmethod
    def _dist_xy(a: Tuple[float, float], b: Tuple[float, float]) -> float:
        dx = a[0] - b[0]
        dy = a[1] - b[1]
        return (dx * dx + dy * dy) ** 0.5

    def _energy_consume_one_hop(self, u, v, B_scale: float = 1.0):
        """Account for one-hop communication energy between real nodes, with optional hop-wise bit scaling."""
        Bu_old = getattr(u, 'B', 1000000)
        Bv_old = getattr(v, 'B', 1000000)
        try:
            u.B = Bu_old * max(1.0, float(B_scale))
            v.B = Bv_old * max(1.0, float(B_scale))
            Eu = u.energy_consumption(target_node=v, transfer_WET=False)
            Ev = v.energy_consumption(target_node=u, transfer_WET=False)
        finally:
            u.B = Bu_old
            v.B = Bv_old
        u.current_energy = max(0.0, u.current_energy - Eu)
        v.current_energy = max(0.0, v.current_energy - Ev)
        return Eu, Ev


    def report_receivers_to_virtual(self, receivers: List, participants: List = None, include_idle: bool = False) -> None:
        """




        """
        if not receivers:
            self.last_paths = {}
            self.last_comms = []
            return

        self.virtual_center = self._geo_center()
        cx, cy = self.virtual_center
        nodes = self.net.nodes
        if not nodes:
            return
        anchor = min(nodes, key=lambda n: self._dist_xy(n.position, (cx, cy)))

        target_nodes = set(receivers)
        if include_idle and participants is not None:
            part_set = set(participants)
            for n in nodes:
                if n not in part_set:
                    target_nodes.add(n)

        paths = {}
        comms = []

        for r in target_nodes:
            if r is anchor:
                paths[r.node_id] = [r]
                if self.consume_energy:
                    d = self._dist_xy(r.position, (cx, cy))
                    B = r.B; E_elec = r.E_elec; eps = r.epsilon_amp; tau = r.tau
                    E_tx_virtual = E_elec * B + eps * B * (d ** tau)
                    E_rx_virtual = E_elec * B
                    E_com = 0.5 * (E_tx_virtual + E_rx_virtual) + 0.1
                    r.current_energy = max(0.0, r.current_energy - E_com)
                    comms.append({"hop": (r.node_id, "VIRTUAL"), "E_tx_only": E_com})
                continue

            d_r_vc = self._dist_xy(r.position, (cx, cy))
            if d_r_vc <= self.r_virtual_neighbor:
                paths[r.node_id] = [r]
                if self.consume_energy:
                    B = r.B; E_elec = r.E_elec; eps = r.epsilon_amp; tau = r.tau
                    E_tx_virtual = E_elec * B + eps * B * (d_r_vc ** tau)
                    E_rx_virtual = E_elec * B
                    E_com = 0.5 * (E_tx_virtual + E_rx_virtual) + 0.1
                    r.current_energy = max(0.0, r.current_energy - E_com)
                    comms.append({"hop": (r.node_id, "VIRTUAL"), "E_tx_only": E_com})
                continue

            path = None
            if opportunistic_routing is not None:
                path = opportunistic_routing(nodes, r, anchor, max_hops=self.max_hops, t=0)
            paths[r.node_id] = path if path is not None else []

            if self.consume_energy and path:
                for i in range(len(path) - 1):
                    u = path[i]; v = path[i + 1]
                    Eu, Ev = self._energy_consume_one_hop(u, v, B_scale=(i + 1))
                    comms.append({"hop": (u.node_id, v.node_id), "E_tx": Eu, "E_rx": Ev, "B_scale": (i + 1)})

                last_real = path[-1]
                d = self._dist_xy(last_real.position, (cx, cy))
                B0 = last_real.B; E_elec = last_real.E_elec; eps = last_real.epsilon_amp; tau = last_real.tau
                B_eff = B0 * (len(path) + 1)
                E_tx_virtual = E_elec * B_eff + eps * B_eff * (d ** tau)
                E_rx_virtual = E_elec * B_eff
                E_com = 0.5 * (E_tx_virtual + E_rx_virtual) + 0.1
                last_real.current_energy = max(0.0, last_real.current_energy - E_com)
                comms.append({"hop": (last_real.node_id, "VIRTUAL"), "E_tx_only": E_com, "B_scale": (len(path) + 1)})

        self.last_paths = paths
        self.last_comms = comms


    def plot_last_reports(self, title: str = "Receiver reports to virtual center"):
        try:
            import plotly.graph_objects as go
        except Exception:
            print("[ReceiverInfoLink] Plotly not available.")
            return

        nodes = self.net.nodes
        if not nodes:
            return

        cx, cy = self.virtual_center
        ids = [n.node_id for n in nodes]
        xs = [n.position[0] for n in nodes]
        ys = [n.position[1] for n in nodes]

        id2node = {n.node_id: n for n in nodes}
        ch_ids = list(self.last_paths.keys())
        ch_nodes = [id2node[i] for i in ch_ids if i in id2node]

        cluster_of = {}
        if ch_nodes:
            for n in nodes:
                best = min(ch_nodes, key=lambda ch: self._dist_xy(n.position, ch.position))
                cluster_of[n.node_id] = best.node_id
        else:
            cluster_of = {n.node_id: -1 for n in nodes}

        palette = [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b',
            '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]
        ch_list = sorted(set(cluster_of.values()))
        color_map = {cid: palette[i % len(palette)] for i, cid in enumerate(ch_list) if cid != -1}
        node_colors = [color_map.get(cluster_of.get(nid, -1), '#888888') for nid in ids]

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=xs, y=ys, mode='markers+text', name='Nodes (by cluster)',
                                 marker=dict(color=node_colors, size=7),
                                 text=[str(i) for i in ids[:100]], textposition='bottom right'))

        fig.add_trace(go.Scatter(x=[cx], y=[cy], mode='markers', name='Virtual Center',
                                 marker=dict(color='#1f77b4', size=12, symbol='x')))

        if ch_nodes:
            fig.add_trace(go.Scatter(
                x=[n.position[0] for n in ch_nodes],
                y=[n.position[1] for n in ch_nodes],
                mode='markers', name='Cluster Heads',
                marker=dict(color='red', size=10, symbol='diamond')
            ))

        for nid, chid in cluster_of.items():
            if chid == -1 or nid == chid:
                continue
            a = id2node[nid].position
            b = id2node[chid].position
            fig.add_trace(go.Scatter(x=[a[0], b[0]], y=[a[1], b[1]], mode='lines',
                                     line=dict(width=1, color='rgba(0,0,0,0.15)'),
                                     showlegend=False, hoverinfo='skip'))

        for rid, path in self.last_paths.items():
            if not path or len(path) == 1:
                rnode = next((n for n in nodes if n.node_id == rid), None)
                if rnode is None:
                    continue
                fig.add_trace(go.Scatter(x=[rnode.position[0], cx], y=[rnode.position[1], cy],
                                         mode='lines', line=dict(width=2, color='rgba(31,119,180,0.6)'),
                                         showlegend=False))
                continue
            xs_p = [n.position[0] for n in path]
            ys_p = [n.position[1] for n in path]
            fig.add_trace(go.Scatter(x=xs_p, y=ys_p, mode='lines+markers',
                                     line=dict(width=2, color='rgba(31,119,180,0.6)'),
                                     marker=dict(size=6), showlegend=False))
            last = path[-1].position
            fig.add_trace(go.Scatter(x=[last[0], cx], y=[last[1], cy], mode='lines',
                                     line=dict(width=2, dash='dot', color='rgba(31,119,180,0.6)'),
                                     showlegend=False))

        fig.update_layout(title=title, xaxis_title='X (m)', yaxis_title='Y (m)', template='plotly_white',
                          xaxis=dict(scaleanchor='y', scaleratio=1))
        out_png = os.path.join(self.output_dir, 'receiver_info_paths.png')
        try:
            fig.write_image(out_png, width=900, height=700, scale=3)
        except Exception as e:
            print("[ReceiverInfoLink] save image failed:", e)
        fig.show()


