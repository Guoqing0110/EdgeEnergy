"""Run the original 25-node nominal Dynamic-K simulation and compare it with the documented results."""
import argparse,csv,json,math,os,shutil,subprocess,sys,tempfile
from pathlib import Path
here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();out=a.output.resolve()
if out.exists() and (not out.is_dir() or any(out.iterdir())):ap.error('use an empty output directory or a new path')
out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='edgeenergy_dk_') as tmp:
 w=Path(tmp);shutil.copytree(here/'source',w/'source')
 env=dict(os.environ,MPLBACKEND='Agg',MPLCONFIGDIR=str(w/'mpl-cache'),PYTHONDONTWRITEBYTECODE='1')
 with (out/'driver.log').open('w',encoding='utf-8') as log:
  subprocess.run([sys.executable,'-B',str(here/'run_headless.py'),str(w/'source'),str(w/'runs')],env=env,cwd=w,stdout=log,stderr=subprocess.STDOUT,check=True)
 rows=json.loads((w/'runs/table2_reproduce_results.json').read_text(encoding='utf-8'))
 results={rec['case']:{k:rec[k] for k in ('avg_std','final_min','eff','loss')} for rec in rows}
 if len(results)!=11: raise ValueError('unexpected number of cases')
with (here/'expected/nominal_results.csv').open(encoding='utf-8-sig') as f:ref=list(csv.DictReader(f))
if len(ref)!=44:raise ValueError('expected 44 metrics')
for row in ref:
 val=results[row['case']][row['reported_metric']]; old=float(row['rerun_unrounded'])
 if not math.isclose(val,old,rel_tol=0.,abs_tol=1e-8):raise ValueError(f"numerical mismatch: {row['case']} {row['reported_metric']}: {val} vs {old}")
if sum(x['scope']=='active-transfer' and x['matches_at_print_precision']=='True' for x in ref)!=40:raise ValueError('expected 40 active-transfer tabulated comparisons')
f=out/'nominal_results.csv'
with f.open('w',encoding='utf-8',newline='') as s:
 w=csv.writer(s);w.writerow(['case','avg_std_J','final_min_J','eff_percent','loss_J']);w.writerows([key,*val.values()] for key,val in results.items())
report={'status':'PASS','cases':len(results),'metrics_checked':len(ref),'absolute_tolerance':1e-8,'active_transfer_metrics_matching_chapter_print_precision':40,'Average_static_dispersion_J':results['Average_static_k1']['avg_std'],'Average_dynamic_dispersion_J':results['Average_dynamic_k']['avg_std'],'no_transfer_simulated_dispersion_J':results['NoTransfer']['avg_std'],'no_transfer_historical_dispersion_J':400000.0}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
