# Dynamic-K: donor concurrency in a 25-node network

How much does changing the number of donors help balance node energy, and what does that cost in transfer losses? This experiment compares a fixed limit of one donor with Dynamic-K under five schedulers: Average, Baseline, Lyapunov, Prediction and Power Control.

From the repository root, run:

```sh
python -B experiments/run_demos.py --only dynamic-k --output ../results-dynamic-k
```

Use a new or empty directory outside the repository. The tested setup is CPython 3.12 with NumPy 2.3.5; the simulation runs offline without a display. Open `dynamic-k/nominal_results.csv` in the results directory for the eleven cases, and `dynamic-k/result.json` for the numerical comparisons.

**Conditions.** The 25 nodes occupy a 10 × 10 m area. The simulation uses 10,080 one-minute steps (seven model days), initial model energy of 40,000 J and a three-hop limit. The network configuration seed is 129 and the driver seed is 42. Following the no-transfer case, each scheduler runs once with fixed K = 1 and once with K adjusted in response to realised reward. The separate prospective-search experiment is outside this nominal comparison.

**Reading the results.** Across the five schedulers, adaptive concurrency reduces mean dispersion by 64.4% and increases mean network-accounted transfer loss by 43.5%. For Average scheduling alone, dispersion falls from 5,163.021599 J to 1,658.645858 J. The four measures for each policy are energy dispersion, final minimum node energy, transfer efficiency and transfer loss. For transfer accounting, receipts are summed across nodes, including intermediate relays. The ten active-transfer rows reproduce all 40 printed entries in thesis Tables 4.3 and 4.4, after converting joules to kilojoules where appropriate. The auxiliary **no-transfer** row gives dispersion of **22,928.8767 J** under the supplied conditions; the historical reference is **400,000 J**. This row is separate from the five scheduler contrasts.

The numerical comparison uses `expected/nominal_results.csv` (absolute tolerance 1e-8); `driver.log` retains the original driver's printout. `source/run_table2_reproduction.py` defines the cases; `source/src/wsn_et/` contains the simulation, network, energy and scheduler implementations. Use the command above to run the driver without its graphical dependencies. Compared with the thesis source archive `S1-dynamicK-main.zip`, the distributed code removes an unused Turtle import and loads Matplotlib only in the plotting functions.

G. Lu and B. Butler, [Dynamic-K adaptation framework for energy transfer coordination in wireless sensor networks](https://doi.org/10.1016/j.adhoc.2026.104346), *Ad Hoc Networks*.
