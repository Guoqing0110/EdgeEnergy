"""Run the original numerical driver in an isolated temporary source tree.
Only graphical display and its console output are disabled. No algorithm or seed is replaced.
"""
from pathlib import Path
import sys,os,types,builtins
source,out=map(lambda x:Path(x).resolve(),sys.argv[1:]);out.mkdir(parents=True)
sys.path.insert(0,str(source));os.chdir(out)
sys.modules['src.wsn_et.plotter']=types.ModuleType('src.wsn_et.plotter') # optional GUI, not called
import run_table2_reproduction as driver
driver.EnergySimulation.plot_K_history=lambda self: None
def quiet_console(path,*args,**kwargs):
 return builtins.open(os.devnull if str(path).endswith('console_output.log') else path,*args,**kwargs)
driver.open=quiet_console;driver.OUT_ROOT=str(out)
driver.main()
