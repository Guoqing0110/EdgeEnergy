from pathlib import Path
import argparse,csv,json
from collections import defaultdict
from p9_algorithms import NODES
from p9_engine import P9Engine

def readcsv(p):
    if not p.exists() or p.stat().st_size==0:
        return []
    with p.open("r",encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))

def b(v):
    return str(v).strip().lower() in {"1","true","yes"}

def close(a,bv,tol=1e-8):
    try:return abs(float(a)-float(bv))<=tol
    except:return str(a)==str(bv)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--run-dir",required=True)
    a=ap.parse_args()

    root=Path(a.run_dir);raw=root/"raw";derived=root/"derived"
    sampling=readcsv(raw/"sampling_actions.csv")
    kf_online=readcsv(raw/"kf_state.csv")
    state_online=readcsv(raw/"alert_state.csv")
    admitted=readcsv(raw/"admitted_measurements.csv")
    wakes=readcsv(raw/"wake_ack_map.csv")

    by_measure=defaultdict(dict)
    for r in admitted:
        by_measure[int(r["step_id"])][r["node_id"]]=float(r["value"])

    samp_by={(int(r["step_id"]),r["node_id"]):r for r in sampling}
    kf_by={(int(r["step_id"]),r["node_id"]):r for r in kf_online}
    state_by={(int(r["step_id"]),r["node_id"]):r for r in state_online}

    wake_by_step=defaultdict(dict)
    for r in wakes:
        wake_by_step[int(r["step_id"])][r["alert_id"]]=[
            x for x in r.get("acked_targets","").split(";") if x
        ]

    eng=P9Engine()
    dec_checks=[];kf_checks=[];state_checks=[]

    for step in range(60):
        vals={n:by_measure[step][n] for n in NODES}
        rows=eng.warmup_step(step,vals)
        for rr in rows:
            o=samp_by[(step,rr["node_id"])]
            dec_checks.append({
                "requested_match":b(o["requested"]) is True,
                "reason_match":o["reason"]=="WARMUP_FULL"
            })

    eng.finish_warmup()

    max_step=max(k[0] for k in samp_by)
    for step in range(60,max_step+1):
        preds,decisions,srows=eng.begin_step(step)
        vals={}
        for n in NODES:
            requested,_=decisions[n]
            vals[n]=by_measure[step].get(n) if requested else None

        krows,_,new=eng.apply_measurements(
            step,preds,decisions,srows,vals
        )
        _,states=eng.apply_wake_acks_and_finalize(
            step,new,wake_by_step.get(step,{})
        )

        for rr in srows:
            o=samp_by[(step,rr["node_id"])]
            dec_checks.append({
                "requested_match":b(o["requested"])==rr["requested"],
                "reason_match":o["reason"]==rr["reason"]
            })

        for rr in krows:
            o=kf_by[(step,rr["node_id"])]
            numeric=all(close(o[k],rr[k]) for k in [
                "x_pred_0","x_pred_1","P_pred_00","P_pred_01",
                "P_pred_10","P_pred_11","sigma_y2","S",
                "x_post_0","x_post_1","P_post_00","P_post_01",
                "P_post_10","P_post_11"
            ])
            kf_checks.append({
                "numeric_match":numeric,
                "update_kind_match":o["update_kind"]==rr["update_kind"]
            })

        for rr in states:
            o=state_by[(step,rr["node_id"])]
            state_checks.append({
                "state_match":o["state_after"]==rr["state_after"],
                "alert_id_match":o["alert_id"]==rr["alert_id"]
            })

    d_ok=all(x["requested_match"] and x["reason_match"] for x in dec_checks)
    k_ok=all(x["numeric_match"] and x["update_kind_match"] for x in kf_checks)
    s_ok=all(x["state_match"] and x["alert_id_match"] for x in state_checks)

    report={
        "decision_rows":len(dec_checks),
        "kf_rows":len(kf_checks),
        "state_rows":len(state_checks),
        "decision_match_100pct":d_ok,
        "kf_match_100pct":k_ok,
        "state_transition_match_100pct":s_ok,
        "match_rate":1.0 if d_ok and k_ok and s_ok else 0.0,
        "status":"PASS" if d_ok and k_ok and s_ok else "FAIL"
    }
    derived.mkdir(exist_ok=True)
    (derived/"snapshot_replay_report.json").write_text(
        json.dumps(report,indent=2),encoding="utf-8"
    )
    print(json.dumps(report,indent=2))
    return 0 if report["status"]=="PASS" else 2

if __name__=="__main__":
    raise SystemExit(main())
