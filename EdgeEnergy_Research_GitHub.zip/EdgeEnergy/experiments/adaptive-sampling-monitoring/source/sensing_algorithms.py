from __future__ import annotations
from dataclasses import dataclass, field
from collections import deque
import math, statistics

NODES=[f"N{i:02d}" for i in range(1,11)]
SENTINELS={"N02","N09"}
GC={
"N01":["N02","N06"],"N02":["N01","N03","N07"],"N03":["N02","N04","N08"],
"N04":["N03","N05","N09"],"N05":["N04","N10"],"N06":["N01","N07"],
"N07":["N02","N06","N08"],"N08":["N03","N07","N09"],
"N09":["N04","N08","N10"],"N10":["N05","N09"]}

def median(xs): return statistics.median(xs) if xs else 0.0
def mad(xs):
    if not xs:return 0.0
    m=median(xs);return median([abs(x-m) for x in xs])
def mm(A,B):
    return [[A[0][0]*B[0][0]+A[0][1]*B[1][0],A[0][0]*B[0][1]+A[0][1]*B[1][1]],
            [A[1][0]*B[0][0]+A[1][1]*B[1][0],A[1][0]*B[0][1]+A[1][1]*B[1][1]]]
def tr(A):return [[A[0][0],A[1][0]],[A[0][1],A[1][1]]]

@dataclass
class KFNode:
    node_id:str
    R:float=0.04;q:float=0.0008
    x:list=field(default_factory=lambda:[20.0,0.0])
    P:list=field(default_factory=lambda:[[0.04,0.0],[0.0,0.01]])
    gamma:float=0.0;last_sample_step:int=-1
    r_hist:deque=field(default_factory=lambda:deque(maxlen=8))
    bg:deque=field(default_factory=lambda:deque(maxlen=64))
    bg_freeze_until:int=-1
    alert_state:str="SPARSE";alert_id:str="";alert_sign:int=0
    verify_start:int=-1;confirm_start:int=-1
    verify_same_sign_count:int=0;recovery_count:int=0;rearm_count:int=0
    broadcasted:bool=False

    def Q(self):return [[0.25*self.q,0.5*self.q],[0.5*self.q,self.q]]
    def predP(self,P):
        F=[[1.,1.],[0.,1.]];A=mm(mm(F,P),tr(F));Q=self.Q()
        return [[A[0][0]+Q[0][0],A[0][1]+Q[0][1]],[A[1][0]+Q[1][0],A[1][1]+Q[1][1]]]
    def predict(self):
        xp=[self.x[0]+self.x[1],self.x[1]];Pp=self.predP(self.P);S=Pp[0][0]+self.R
        return {"x_pred":xp,"P_pred":Pp,"S":S,"sigma_y2":S}
    def update(self,y,p):
        xp,Pp,S=p["x_pred"],p["P_pred"],p["S"];inn=y-xp[0]
        k0,k1=Pp[0][0]/S,Pp[1][0]/S
        self.x=[xp[0]+k0*inn,xp[1]+k1*inn]
        A=[[1-k0,0],[-k1,1]];J=mm(mm(A,Pp),tr(A))
        self.P=[[J[0][0]+k0*k0*self.R,J[0][1]+k0*k1*self.R],
                [J[1][0]+k1*k0*self.R,J[1][1]+k1*k1*self.R]]
        return inn,inn/math.sqrt(max(S,1e-12))
    def no_update(self,p):self.x=p["x_pred"];self.P=p["P_pred"]

    def initialize(self,vals):
        first=vals[:10];diff=[first[i]-first[i-1] for i in range(1,10)]
        residual=[v-median(vals) for v in vals]
        self.R=max((1.4826*mad(residual))**2,0.04);self.q=.02*self.R
        self.x=[median(first),median(diff)];self.P=[[self.R,0],[0,.25*self.R]]
        for y in vals:self.update(y,self.predict())
        P=[r[:] for r in self.P];Ss=[]
        for _ in range(8):
            P=self.predP(P);Ss.append(P[0][0]+self.R)
        self.gamma=(Ss[2]+Ss[3])/2;self.last_sample_step=59

    def glr(self,r):
        self.r_hist.append(r);v=list(self.r_hist);bp=bm=0.;terms=[]
        for w in range(1,min(8,len(v))+1):
            s=sum(v[-w:]);gp=max(0.,s)**2/(2*w);gm=max(0.,-s)**2/(2*w)
            bp=max(bp,gp);bm=max(bm,gm);terms.append((w,gp,gm))
        G=max(bp,bm);sign=1 if bp>=bm else -1
        if len(self.bg)>=16:
            med=median(self.bg);m=mad(self.bg);sig=max(1.4826*m,.25);rel=max(3.4,med+3*sig)
        else:med=m=sig=rel=None
        at=G>=6.;rt=rel is not None and G>=rel
        return {"G_plus":bp,"G_minus":bm,"G":G,"sign":sign,"lambda_rel":rel,
                "median_bg":med,"MAD_bg":m,"sigma_bg":sig,"trigger":at or rt,
                "branch":"BOTH" if at and rt else ("ABS" if at else ("REL" if rt else "NONE"))}

class P9Core:
    def __init__(self):self.nodes={n:KFNode(n) for n in NODES};self.seq=0
    def initialize(self,warm):
        for n in NODES:self.nodes[n].initialize(warm[n])
    def active_alert_near(self,n):
        return any(self.nodes[x].alert_state in {"VERIFY","CONFIRMED","RECOVERY_EXIT","SPARSE_REARM"} for x in {n,*GC[n]})
    def decide(self,n,step,p):
        x=self.nodes[n];age=step-x.last_sample_step
        if n in SENTINELS:return True,"SENTINEL"
        if x.alert_state in {"VERIFY","CONFIRMED"}:return True,"ALERT_STATE"
        if p["sigma_y2"]>x.gamma:return True,"UNCERTAINTY"
        if age>=8:return True,"HEARTBEAT_8"
        return False,"SPARSE_SKIP"
    def alert_id(self,n,step):
        self.seq+=1;return f"P9A-{n}-{step:04d}-{self.seq:04d}"
