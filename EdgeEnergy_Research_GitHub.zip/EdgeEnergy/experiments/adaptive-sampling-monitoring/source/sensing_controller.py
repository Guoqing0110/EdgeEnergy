from __future__ import annotations
import json
from p9_algorithms import P9Core,NODES,SENTINELS,GC

class P9Engine:
    def __init__(self):
        self.core=P9Core()
        self.initialized=False
        self.alerts=[]
        self.warm={n:[] for n in NODES}

    def warmup_step(self,step,measurements):
        rows=[]
        for n in NODES:
            y=measurements.get(n)
            rows.append({
                "step_id":step,"node_id":n,"role":"SENTINEL" if n in SENTINELS else "NORMAL",
                "state_before":"WARMUP","sigma_y2":"","gamma":"","sample_age":"",
                "reason":"WARMUP_FULL","requested":True,
                "acquired":y is not None,"delivered_by_deadline":y is not None
            })
            if y is not None:self.warm[n].append(float(y))
        return rows

    def finish_warmup(self):
        missing={n:len(v) for n,v in self.warm.items() if len(v)<10}
        if missing:raise RuntimeError(f"insufficient warmup samples: {missing}")
        self.core.initialize(self.warm);self.initialized=True

    def begin_step(self,step):
        preds={};decisions={};sampling=[]
        for n in NODES:
            node=self.core.nodes[n]
            p=node.predict();preds[n]=p
            req,reason=self.core.decide(n,step,p);decisions[n]=(req,reason)
            sampling.append({
                "step_id":step,"node_id":n,"role":"SENTINEL" if n in SENTINELS else "NORMAL",
                "state_before":node.alert_state,"sigma_y2":p["sigma_y2"],"gamma":node.gamma,
                "sample_age":step-node.last_sample_step,"reason":reason,
                "requested":req,"acquired":False,"delivered_by_deadline":False
            })
        return preds,decisions,sampling

    def apply_measurements(self,step,preds,decisions,sampling,measurements):
        kf=[];glr=[];new_alerts=[]
        by_node={r["node_id"]:r for r in sampling}
        for n in NODES:
            node=self.core.nodes[n];p=preds[n];req,_=decisions[n]
            y=measurements.get(n) if req else None
            row=by_node[n]
            row["acquired"]=y is not None
            row["delivered_by_deadline"]=y is not None
            if y is not None:
                node.last_sample_step=step
                inn,rr=node.update(float(y),p)
                g=node.glr(rr)
                glr.append({
                    "step_id":step,"node_id":n,"r":rr,"w":"1..8",
                    "G_plus":g["G_plus"],"G_minus":g["G_minus"],"G":g["G"],
                    "median_bg":g["median_bg"],"MAD_bg":g["MAD_bg"],"sigma_bg":g["sigma_bg"],
                    "lambda_rel":g["lambda_rel"],"lambda_abs":6.0,
                    "branch":g["branch"],"trigger":g["trigger"]
                })
                if node.alert_state=="SPARSE" and g["trigger"]:
                    aid=self.core.alert_id(n,step)
                    node.alert_state="CONFIRMED";node.alert_id=aid;node.alert_sign=g["sign"]
                    node.confirm_start=step;node.broadcasted=True
                    item={"alert_id":aid,"source":n,"trigger_step":step,"sign":g["sign"],
                          "broadcast_round":1,"clear_step":"","clear_reason":""}
                    self.alerts.append(item);new_alerts.append(item)
                elif node.alert_state=="VERIFY":
                    if g["trigger"] or (g["sign"]==node.alert_sign and abs(rr)>=1.5):
                        node.verify_same_sign_count+=1
                    if g["trigger"] or node.verify_same_sign_count>=2:
                        node.alert_state="CONFIRMED";node.confirm_start=step
                elif node.alert_state=="CONFIRMED":
                    if step-node.confirm_start>=5 and g["G"]<3.4 and abs(rr)<1.0:
                        node.recovery_count+=1
                    else:
                        node.recovery_count=0
                    if node.recovery_count>=3:
                        node.alert_state="SPARSE_REARM";node.rearm_count=0;node.bg_freeze_until=step+8
                elif node.alert_state=="SPARSE_REARM":
                    node.rearm_count=node.rearm_count+1 if g["G"]<3.4 else 0
                    if node.rearm_count>=4:
                        old=node.alert_id;node.alert_state="SPARSE";node.alert_id="";node.broadcasted=False
                        for a in self.alerts:
                            if a["alert_id"]==old and a["clear_step"]=="":
                                a["clear_step"]=step;a["clear_reason"]="REARM_COMPLETE"
                if node.alert_state=="SPARSE" and step>node.bg_freeze_until and not self.core.active_alert_near(n) and not g["trigger"]:
                    node.bg.append(g["G"])
                kind="MEASUREMENT"
            else:
                node.no_update(p);inn="";kind="PREDICT_ONLY"
            kf.append({
                "step_id":step,"node_id":n,
                "x_pred_0":p["x_pred"][0],"x_pred_1":p["x_pred"][1],
                "P_pred_00":p["P_pred"][0][0],"P_pred_01":p["P_pred"][0][1],
                "P_pred_10":p["P_pred"][1][0],"P_pred_11":p["P_pred"][1][1],
                "sigma_y2":p["sigma_y2"],"innovation":inn,"S":p["S"],
                "x_post_0":node.x[0],"x_post_1":node.x[1],
                "P_post_00":node.P[0][0],"P_post_01":node.P[0][1],
                "P_post_10":node.P[1][0],"P_post_11":node.P[1][1],
                "update_kind":kind
            })
        return kf,glr,new_alerts

    def apply_wake_acks_and_finalize(self,step,new_alerts,acked_by_alert):
        transitions=[]
        for alert in new_alerts:
            src=alert["source"];aid=alert["alert_id"]
            acked=set(acked_by_alert.get(aid,[]))
            for target in GC[src]:
                node=self.core.nodes[target]
                if target in acked and node.alert_state=="SPARSE":
                    node.alert_state="VERIFY";node.alert_id=aid;node.alert_sign=alert["sign"]
                    node.verify_start=step;node.verify_same_sign_count=0
                    transitions.append({"step_id":step,"node_id":target,"alert_id":aid,
                                        "event":"ALERT_WAKE_ACK","state_after":"VERIFY"})
        # VERIFY timeout.
        for n in NODES:
            node=self.core.nodes[n]
            if node.alert_state=="VERIFY" and step-node.verify_start>=5:
                old=node.alert_id
                node.alert_state="SPARSE";node.alert_id="";node.verify_same_sign_count=0
                transitions.append({"step_id":step,"node_id":n,"alert_id":old,
                                    "event":"VERIFY_TIMEOUT","state_after":"SPARSE"})
        state_rows=[]
        for n in NODES:
            node=self.core.nodes[n]
            state_rows.append({
                "step_id":step,"node_id":n,"alert_id":node.alert_id,
                "event":"STEP_COMMIT",
                "predicate_values":json.dumps({
                    "verify_count":node.verify_same_sign_count,
                    "recovery_count":node.recovery_count,
                    "rearm_count":node.rearm_count
                },sort_keys=True),
                "state_after":node.alert_state
            })
        return transitions,state_rows

    def digest_state(self):
        obj={}
        for n,node in self.core.nodes.items():
            obj[n]={
                "x":node.x,"P":node.P,"gamma":node.gamma,"last_sample_step":node.last_sample_step,
                "r_hist":list(node.r_hist),"bg":list(node.bg),"bg_freeze_until":node.bg_freeze_until,
                "alert_state":node.alert_state,"alert_id":node.alert_id,"alert_sign":node.alert_sign,
                "verify_start":node.verify_start,"confirm_start":node.confirm_start,
                "verify_same_sign_count":node.verify_same_sign_count,
                "recovery_count":node.recovery_count,"rearm_count":node.rearm_count
            }
        return obj
