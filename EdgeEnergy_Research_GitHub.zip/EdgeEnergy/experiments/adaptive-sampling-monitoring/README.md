# Adaptive Sampling for Spatiotemporal Anomaly Monitoring in Wireless Sensor Networks

Chapter 6 asks when a network should spend another observation on a possible anomaly. Stage I uses sentinels to wake nearby nodes after a local detection; [Stage II](stage-ii/README.md) revisits sites where an earlier check was negative as the anomaly front advances. A separate ten-node session tests how the sensing controller responds to device acknowledgements.

From the repository root, run the **Stage I simulation and ten-node replay** together:

```sh
python -B experiments/run_demos.py --only adaptive-sampling-monitoring --output ../results-adaptive-sampling-monitoring
```

**Stage I — local detection (Table 6.3).** The four policies share ten injected events, a measured temperature background (54 nodes × 465 time slots) and a directed radio graph with 429 edges. The [simulation entry point](task10/run.py) starts from the aligned temperatures before event injection and runs the original sensing, wake-up and accounting routines. The seven metrics for each policy reproduce all 28 table cells. The Oracle samples 19,597 of 25,110 node-slots (0.780). Under `adaptive-sampling-monitoring/task10/` in the output directory, `table_6_3.csv` contains the comparison and `runs/` contains the simulated histories.

**Ten-node hardware replay.** The host controller replays admitted samples and recorded wake acknowledgements from ten devices over 110 two-second steps. All nodes are observed for the first 60 steps. The stimulus was virtual; the acknowledgements came from the devices in the original session. Running the replay requires no hardware. The output `adaptive-sampling-monitoring/hardware_replay.json` compares 1,100 decisions, 500 filter records and 500 node-state records with the captured outputs. The study-wide `result.json` is in the same directory. See [the event fields](projection.json) to trace the inputs and outputs to the session.

For the propagation experiments, use the [Stage II instructions](stage-ii/README.md); the command above does not run them.
