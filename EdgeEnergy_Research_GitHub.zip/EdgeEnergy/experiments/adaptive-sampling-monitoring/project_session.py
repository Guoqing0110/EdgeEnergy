"""Extract five replay tables from a LAB01 session into a new directory and verify them against the distributed sample."""
import argparse,csv,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
spec=json.loads((root/'projection.json').read_text(encoding='utf-8'))
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('archived_raw_directory',type=Path)
p.add_argument('new_projection_directory',type=Path)
a=p.parse_args();src=a.archived_raw_directory.resolve();dest=a.new_projection_directory.resolve()
if dest==root or root in dest.parents or dest==src or src in dest.parents:p.error('choose a new working directory outside the package and original data')
dest.mkdir(parents=True,exist_ok=False)
for file in spec:
 original=src/file['original_name']
 if hashlib.sha256(original.read_bytes()).hexdigest()!=file['original_sha256']:raise ValueError(f'Original source hash differs: {file["original_name"]}')
 target=dest/file['sample_file'];target.parent.mkdir(exist_ok=True,parents=True)
 with original.open(encoding='utf-8-sig',newline='') as r,target.open('w',encoding='utf-8',newline='') as w:
  writer=csv.DictWriter(w,file['fields'],extrasaction='ignore',lineterminator='\n');writer.writeheader();writer.writerows(csv.DictReader(r))
 if hashlib.sha256(target.read_bytes()).hexdigest()!=file['sample_sha256']:raise ValueError(f'Projection differs: {target.name}')
 print(f'{target.relative_to(dest)}: {file["rows"]} rows; projected file matches.')
