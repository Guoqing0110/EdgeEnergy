"""Run a four-policy sensing simulation and an independent ten-node host replay."""
import argparse,json,shutil,subprocess,sys,tempfile
from pathlib import Path
loc=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();out=a.output.resolve()
if out.exists() and (not out.is_dir() or any(out.iterdir())):ap.error('use a new or empty output directory')
out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='edgeenergy_sense_') as tmp:
 session=Path(tmp); raw=session/'raw';raw.mkdir()
 for d in (loc/'input',loc/'expected/online'):
  for p in sorted(d.glob('*.csv')):shutil.copyfile(p,raw/p.name)
 # The archived modules import each other by their original Python names.
 # Stage those dependencies beside the replay script without modifying the research code.
 for public, module in (('sensing_algorithms.py', 'p9_algorithms.py'),
                        ('sensing_controller.py', 'p9_engine.py'),
                        ('host_replay.py', 'host_replay.py')):
  shutil.copyfile(loc/'source'/public, session/module)
 subprocess.run([sys.executable,'-B',str(session/'host_replay.py'),'--run-dir',str(session)],cwd=session,check=True)
 rep=json.loads((session/'derived/snapshot_replay_report.json').read_text())
expected=json.loads((loc/'expected/original_replay_summary.json').read_text())
if rep!=expected or rep['status']!='PASS' or [rep[k] for k in ('decision_rows','kf_rows','state_rows')]!=[1100,500,500]:raise ValueError('replay mismatches')
(out/'hardware_replay.json').write_text(json.dumps(rep,indent=2)+'\n',encoding='utf-8')
subprocess.run([sys.executable,'-B',str(loc/'task10/run.py'),'--output',str(out/'task10')],check=True)
sim=json.loads((out/'task10/result.json').read_text())
combined={'status':'PASS','task10_simulation':sim,'hardware_session_replay':rep}
(out/'result.json').write_text(json.dumps(combined,indent=2)+'\n',encoding='utf-8')
print(json.dumps(combined,indent=2))
