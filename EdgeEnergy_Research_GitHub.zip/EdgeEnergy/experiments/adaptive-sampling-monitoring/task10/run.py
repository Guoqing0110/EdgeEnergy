#!/usr/bin/env python3
"""Simulate Chapter 6 Stage I from the archived aligned sensing inputs."""
import argparse
import csv
import json
import math
import os
import sys
import time
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
METRICS = dict(EDR='event_detection_rate', ODD='onset_detection_delay_mean_steps',
               coverage='alert_coverage_l', AWSR='anomaly_window_sampling_ratio',
               GSR='global_sampling_rate', RMSE_a='rmse_anomaly_window', energy_proxy='energy_proxy_total')

def compare(condition, message):
    if not condition:
        raise ValueError(message)

def read_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def run(out):
    start = time.perf_counter()
    out.mkdir(parents=True, exist_ok=True)
    compare(not any(out.iterdir()), 'Use a fresh, empty output directory.')
    os.environ['MPLBACKEND'] = 'Agg'
    sys.path.insert(0, str(ROOT/'source'))
    import src.run_conclusion_experiments as driver
    import src.run_multinode_baseline as model
    from src.models import SimulationEnvironment
    ip = ROOT/'input'
    bg = pd.read_csv(ip/'aligned_temperatures.csv.gz', float_precision='round_trip', parse_dates=['time'])
    data = {int(i): panel[['time','aligned_temperature']].set_index('time').rename(columns={'aligned_temperature':'temperature'})
            for i, panel in bg.groupby('node_id', sort=True)}
    pos = {int(row['node_id']):dict(x=float(row['x']),y=float(row['y'])) for row in read_rows(ip/'positions.csv')}
    graph = {i:[] for i in pos}
    for row in read_rows(ip/'communication_edges.csv'):
        graph[int(row['src'])].append(int(row['dst']))
    ix = data[1].index
    compare(sorted(data)==sorted(pos) and len(pos)==54 and len(ix)==465 and
            all(p.index.equals(ix) and not p.temperature.isna().any() for p in data.values()),
            'Aligned input does not match the archived grid.')
    compare(sum(map(len, graph.values()))==429, 'Directed graph edge count differs.')
    def panel_at_original_grid(df, node_ids, start_time, end_time, dt_sec):
        compare(sorted(node_ids)==sorted(data) and pd.date_range(start_time, end_time, freq=f'{dt_sec}s').equals(ix),
                'Requested time grid does not match the recorded experimental window.')
        return data, ix
    def original_graph(self,threshold,directed=True,model='threshold_cut',random_seed=None):
        compare((threshold,directed,model)==(.3,True,'threshold_cut'), 'This graph represents only the original threshold setting.')
        self.communication_adjacency={i:sorted(v) for i,v in graph.items()}
        return self.communication_adjacency
    # Replace only the raw-data/timing and graph loading steps; the archived original
    # four policy definitions, stimulus generation, sampling rules and scoring run as written.
    model._load_experiment_inputs=lambda:(None,pos)
    model.prepare_multinode_data=panel_at_original_grid
    model.load_connectivity_weights=lambda path,node_ids:{}
    SimulationEnvironment.build_communication_topology=original_graph
    study=out/'runs';study.mkdir()
    driver.run_task10_main_effectiveness(str(study),repeats=1,seed_base=1)
    # Post-run validation only. No historical controls, samples or events drive the simulator.
    actual={r['method']:r for r in read_rows(study/'task10_main_effectiveness/task10_main_raw_runs.csv')}
    truth={r['method']:r for r in read_rows(ROOT/'expected/seed_1_metrics.csv')}
    display={r['method']:r for r in read_rows(ROOT/'expected/table_6_3.csv')}
    compare(len(actual)==4 and set(actual)==set(truth)==set(display), 'Incomplete method pairing.')
    expected_events=pd.read_csv(ROOT/'expected/events.csv'); compare(len(expected_events)==10,'Expected ten event definitions.')
    comparisons=[]
    for name, r in actual.items():
        compare(int(r['seed'])==1,'Incorrect seed.')
        fresh=pd.read_csv(Path(r['output_dir'])/'spatial_anomaly_config.csv')
        compare(fresh.equals(expected_events), 'Regenerated events do not match: '+name)
        for short, field in METRICS.items():
            x=float(r[field]); expected=float(truth[name][field]); text=display[name][short]
            precision=len(text.partition('.')[2])
            compare(math.isclose(x,expected,rel_tol=1e-10,abs_tol=1e-10) and format(x,f'.{precision}f')==text,
                    f'{name}: {field} differs from its run or thesis value.')
            comparisons.append(dict(method=name,measure=short,simulated=x,archived=expected,thesis=text))
    with (out/'table_6_3.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
    oracle=Path(actual['Oracle-local wake-up']['output_dir'])
    counts={int(r['node_id']):(int(r['steps']),int(r['sampled_count'])) for r in read_rows(oracle/'node_metrics.csv')}
    expected={int(r['node_id']):(int(r['steps']),int(r['sampled_count'])) for r in read_rows(ROOT/'expected/oracle_node_counts.csv')}
    histories={int(p.stem.split('_')[-1]):(len(t),int(t['sampled'].sum())) for p in sorted((oracle/'node_histories').glob('node_*.csv')) for t in [pd.read_csv(p,usecols=['sampled'])]}
    n=sum(v[1] for v in counts.values());den=sum(v[0] for v in counts.values());ledger=read_rows(oracle/'task6_energy_proxy.csv')[0]
    compare(counts==expected==histories and n==int(ledger['total_sampled_count'])==19597 and den==25110, 'Oracle counts differ.')
    full,pure,sent=[actual[k] for k in ('Full sampling','Pure KF sparse','Sentinel-assisted KF')]
    gain=float(sent[METRICS['AWSR']])-float(pure[METRICS['AWSR']])
    saving=100*(1-float(sent[METRICS['energy_proxy']])/float(full[METRICS['energy_proxy']]))
    compare(format(gain,'.3f')=='0.494' and format(saving,'.1f')=='24.1', 'Sampling or cost contrast mismatch.')
    report=dict(status='PASS',seed=1,physical_nodes_in_background=54,steps=465,step_seconds=31,directed_edges=429,
                policies_rerun=4,events_per_policy=10,metrics_checked_against_archive=len(comparisons),
                thesis_table_6_3_cells_matching=len(comparisons),oracle_sampled_node_steps=n,possible_node_steps=den,
                oracle_global_sampling_rate=n/den,oracle_cost_mJ=float(ledger['total_energy_mj']),
                sentinel_minus_pure_KF_AWSR=gain,sentinel_cost_saving_relative_to_full_percent=saving,
                sentinel_mean_onset_delay_steps=float(sent[METRICS['ODD']]),pure_KF_mean_onset_delay_steps=float(pure[METRICS['ODD']]),
                elapsed_seconds=round(time.perf_counter()-start,3))
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    run(parser.parse_args().output.resolve())
