import numpy as np

import src.config as config


def calc_rmse(estimated, truth):
    estimated = np.asarray(estimated, dtype=float)
    truth = np.asarray(truth, dtype=float)
    mask = ~np.isnan(estimated) & ~np.isnan(truth)
    if not np.any(mask):
        return np.nan
    return float(np.sqrt(np.mean((estimated[mask] - truth[mask]) ** 2)))


def calc_masked_rmse(estimated, truth, mask):
    estimated = np.asarray(estimated, dtype=float)
    truth = np.asarray(truth, dtype=float)
    mask = np.asarray(mask, dtype=bool)
    valid_mask = mask & ~np.isnan(estimated) & ~np.isnan(truth)
    if not np.any(valid_mask):
        return np.nan
    return float(np.sqrt(np.mean((estimated[valid_mask] - truth[valid_mask]) ** 2)))


def compute_reconstruction_rmse_metrics(estimated, truth, anomaly_mask=None):
    metrics = {
        "rmse_global": calc_rmse(estimated, truth),
        "rmse_anomaly_window": np.nan,
    }
    if anomaly_mask is not None:
        metrics["rmse_anomaly_window"] = calc_masked_rmse(estimated, truth, anomaly_mask)
    return metrics


def compute_energy_proxy_metrics(sample_count, tx_peer_count=0, rx_peer_count=0):
    sample_count = int(sample_count)
    tx_peer_count = int(tx_peer_count)
    rx_peer_count = int(rx_peer_count)
    sensing_energy_per_sample_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.SENSING_ACTIVE_CURRENT_MA) / 1000.0 * float(config.SENSING_DURATION_SEC) * 1000.0
    tx_energy_per_peer_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
    rx_energy_per_peer_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
    sensing_energy_mj = float(sample_count) * sensing_energy_per_sample_mj
    tx_energy_mj = float(tx_peer_count) * tx_energy_per_peer_mj
    rx_energy_mj = float(rx_peer_count) * rx_energy_per_peer_mj
    communication_energy_mj = tx_energy_mj + rx_energy_mj
    total_energy_mj = sensing_energy_mj + communication_energy_mj
    return {
        "sensing_energy_per_sample_mj": sensing_energy_per_sample_mj,
        "communication_tx_energy_per_peer_mj": tx_energy_per_peer_mj,
        "communication_rx_energy_per_peer_mj": rx_energy_per_peer_mj,
        "sensing_energy_mj": sensing_energy_mj,
        "communication_tx_energy_mj": tx_energy_mj,
        "communication_rx_energy_mj": rx_energy_mj,
        "communication_energy_mj": communication_energy_mj,
        "total_energy_mj": total_energy_mj,
        "sensing_energy_proxy": sensing_energy_mj,
        "alert_energy_proxy": rx_energy_mj,
        "trigger_energy_proxy": tx_energy_mj,
        "total_energy_proxy": total_energy_mj,
    }
