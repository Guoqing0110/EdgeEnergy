import time
import numpy as np
import src.config as config


class SentinelSelector:
    def __init__(self, node_positions):
        self.node_positions = node_positions

    def select(self, strategy, node_ids, sentinel_ratio, random_seed=42):
        if strategy == 'random_ratio':
            return self._select_random_ratio(node_ids, sentinel_ratio, random_seed)
        if strategy == 'k_center':
            return self._select_k_center(node_ids, sentinel_ratio)
        if strategy == 'spatial_optimal_cover':
            return self._select_spatial_optimal_cover(node_ids, sentinel_ratio)
        raise ValueError("strategy must be 'random_ratio', 'k_center', or 'spatial_optimal_cover'")

    def _sentinel_count(self, node_ids, sentinel_ratio):
        n = len(node_ids)
        count = int(round(n * sentinel_ratio))
        count = max(1, count)
        return min(n, count)

    def _select_random_ratio(self, node_ids, sentinel_ratio, random_seed):
        count = self._sentinel_count(node_ids, sentinel_ratio)
        rng = np.random.default_rng(random_seed)
        selected = rng.choice(sorted(node_ids), size=count, replace=False)
        return sorted([int(x) for x in selected])

    def _select_k_center(self, node_ids, sentinel_ratio):
        count = self._sentinel_count(node_ids, sentinel_ratio)
        candidates = sorted(node_ids)
        if count >= len(candidates):
            return candidates
        centers = [candidates[0]]
        while len(centers) < count:
            best_id = None
            best_dist = -1.0
            for node_id in candidates:
                if node_id in centers:
                    continue
                dist = self._distance_to_nearest_center(node_id, centers)
                if dist > best_dist:
                    best_dist = dist
                    best_id = node_id
            if best_id is None:
                break
            centers.append(best_id)
        return sorted(centers)

    def _distance_to_nearest_center(self, node_id, centers):
        node_pos = self.node_positions[node_id]
        min_dist = np.inf
        for center_id in centers:
            center_pos = self.node_positions[center_id]
            dx = node_pos['x'] - center_pos['x']
            dy = node_pos['y'] - center_pos['y']
            dist = float(np.sqrt(dx * dx + dy * dy))
            if dist < min_dist:
                min_dist = dist
        return min_dist

    def _build_cover_masks(self, node_ids, radius):
        sorted_ids = sorted(node_ids)
        masks = []
        for sid in sorted_ids:
            spos = self.node_positions[sid]
            mask = 0
            for j, cid in enumerate(sorted_ids):
                cpos = self.node_positions[cid]
                dx = spos['x'] - cpos['x']
                dy = spos['y'] - cpos['y']
                if float(np.sqrt(dx * dx + dy * dy)) <= radius:
                    mask |= (1 << j)
            masks.append((sid, mask, int(mask.bit_count())))
        masks.sort(key=lambda x: (-x[2], x[0]))
        return sorted_ids, masks

    def _mask_from_selected(self, selected_ids, masks):
        selected_set = set(selected_ids)
        covered = 0
        for sid, smask, _ in masks:
            if sid in selected_set:
                covered |= smask
        return covered

    def _select_spatial_optimal_cover(self, node_ids, sentinel_ratio):
        k = self._sentinel_count(node_ids, sentinel_ratio)
        cover_radius = float(getattr(config, "SENTINEL_OPT_COVER_RADIUS", config.SPATIAL_STATIC_RADIUS))
        timeout_sec = float(getattr(config, "SENTINEL_OPT_SOLVER_TIMEOUT_SEC", 30.0))
        allow_fewer = bool(getattr(config, "SENTINEL_OPT_ALLOW_FEWER", True))
        target_ratio = float(getattr(config, "SENTINEL_OPT_MIN_COVERAGE_TARGET", 0.95))
        target_ratio = max(0.0, min(1.0, target_ratio))
        centers, masks = self._build_cover_masks(node_ids, cover_radius)
        n = len(masks)
        m = len(centers)
        target_hits = int(np.ceil(target_ratio * m))
        suffix_or = [0] * (n + 1)
        for i in range(n - 1, -1, -1):
            suffix_or[i] = suffix_or[i + 1] | masks[i][1]

        init_selected = self._select_k_center(node_ids, sentinel_ratio)
        init_mask = self._mask_from_selected(init_selected, masks)
        best_cover = int(init_mask.bit_count())
        best_selected = sorted(init_selected)
        start = time.time()

        def update_best(selected_ids, covered_mask):
            nonlocal best_cover, best_selected
            covered = int(covered_mask.bit_count())
            if covered > best_cover:
                best_cover = covered
                best_selected = sorted(selected_ids)
            elif covered == best_cover and len(selected_ids) < len(best_selected):
                best_selected = sorted(selected_ids)

        def dfs(i, chosen, covered_mask, selected_ids):
            if time.time() - start > timeout_sec:
                return
            if chosen > k:
                return
            if i == n or chosen == k:
                update_best(selected_ids, covered_mask)
                return
            if chosen + (n - i) < k:
                return
            optimistic = int((covered_mask | suffix_or[i]).bit_count())
            if optimistic < best_cover:
                return
            sid, smask, _ = masks[i]
            dfs(i + 1, chosen + 1, covered_mask | smask, selected_ids + [sid])
            dfs(i + 1, chosen, covered_mask, selected_ids)

        dfs(0, 0, 0, [])

        if allow_fewer and len(best_selected) > 1:
            selected = list(best_selected)
            changed = True
            while changed and len(selected) > 1:
                changed = False
                for nid in list(selected):
                    cand = [x for x in selected if x != nid]
                    cand_mask = self._mask_from_selected(cand, masks)
                    if int(cand_mask.bit_count()) >= target_hits:
                        selected = cand
                        changed = True
            best_selected = sorted(selected)

        if len(best_selected) == 0:
            best_selected = [sorted(node_ids)[0]]
        return sorted(best_selected)
