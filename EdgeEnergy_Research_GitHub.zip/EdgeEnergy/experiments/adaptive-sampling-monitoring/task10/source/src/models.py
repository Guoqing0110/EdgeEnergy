import numpy as np
import pandas as pd
import src.config as config

class Node:
    def __init__(self, node_id, initial_state, P0, F, H, Q, R, threshold_gamma):
        self.node_id = node_id
        self.x = initial_state  # State vector [x, v]^T
        self.P = P0             # Covariance matrix
        self.F = F              # State transition matrix
        self.H = H              # Observation matrix
        self.Q = Q              # Process noise covariance
        self.R = R              # Measurement noise covariance
        self.gamma = threshold_gamma

        # State Management
        # Role: normal, sentinel
        self.role = 'normal'
        # Mode: adaptive (default), alert (triggered)
        self.mode = 'adaptive' 
        self.alert_timer = 0
        
        # Cache for anomaly detection (before update)
        self.x_pred = None
        self.P_pred = None
        self.last_innovation = None
        self.last_innovation_var = None
        self.last_nis = None
        self.last_signed_norm_innovation = None
        self.trigger_mode = str(getattr(config, "SENTINEL_TRIGGER_MODE", "single")).strip().lower()
        self.consecutive_required = max(1, int(getattr(config, "SENTINEL_TRIGGER_CONSECUTIVE_STEPS", 2)))
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0
        self.glr_stat_up = 0.0
        self.glr_stat_down = 0.0
        self.mosum_stat_up = 0.0
        self.mosum_stat_down = 0.0
        self.detector_signal_buffer = []
        self.glr_background_stat_buffer = []
        self.self_trigger_enabled = bool(getattr(config, "NORMAL_SELF_TRIGGER_ENABLED", False))
        self.alert_elapsed = 0
        self.alert_bg_x = None
        self.alert_bg_P = None
        self.alert_exit_streak = 0
        self.alert_neighbor_quiet_streak = 0
        self.alert_early_exit_enabled = bool(getattr(config, "ALERT_EARLY_EXIT_ENABLED", False))
        self.alert_min_duration = max(1, int(getattr(config, "ALERT_MIN_DURATION_L", 2)))
        self.alert_exit_mode = str(getattr(config, "ALERT_EXIT_MODE", "threshold")).strip().lower()
        self.alert_verify_wait_steps = max(1, int(getattr(config, "ALERT_VERIFY_WAIT_STEPS", 5)))
        self.alert_exit_consecutive = max(1, int(getattr(config, "ALERT_EXIT_CONSECUTIVE_STEPS", 2)))
        self.alert_exit_abs_threshold = float(getattr(config, "ALERT_EXIT_ABS_THRESHOLD", 0.35))
        self.alert_exit_sigma_factor = float(getattr(config, "ALERT_EXIT_SIGMA_FACTOR", 1.2))
        self.alert_exit_glr_window_min = max(1, int(getattr(config, "ALERT_EXIT_GLR_WINDOW_MIN", 1)))
        self.alert_exit_glr_window_max = max(self.alert_exit_glr_window_min, int(getattr(config, "ALERT_EXIT_GLR_WINDOW_MAX", 8)))
        self.alert_exit_glr_threshold = float(getattr(config, "ALERT_EXIT_GLR_THRESHOLD", 6.0))
        self.alert_exit_glr_reset = float(getattr(config, "ALERT_EXIT_GLR_RESET", 1.0))
        self.alert_neighbor_silence_steps = max(0, int(getattr(config, "ALERT_EXIT_NEIGHBOR_SILENCE_STEPS", 2)))
        self.alert_neighbor_recovery_ratio = float(getattr(config, "ALERT_EXIT_NEIGHBOR_RECOVERY_RATIO", 0.0))
        self.alert_exit_cooldown_steps = max(0, int(getattr(config, "ALERT_EXIT_COOLDOWN_STEPS", 0)))
        self.alert_cooldown_timer = 0
        self.alert_exit_glr_stat = 0.0
        self.alert_exit_signal_buffer = []
        self.alert_exit_reference_sign = 0.0
        self.alert_exit_latched = False
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self.last_detector_trigger_direction = 0
        
        # History for plotting
        self.history = {
            'estimated': [],
            'measured': [],
            'uncertainty_pred': [], # H*P_pred*H^T (Prior)
            'uncertainty_post': [], # H*P*H^T (Posterior)
            'sampled': [],          # 1 if sampled, 0 otherwise
            'predicted': [],        # predicted value (before update)
            'innovation': [],       # residual (y = z - Hx_pred)
            'nis': [],             # Normalized Innovation Squared
            'signed_norm_innovation': [],
            'glr_stat_up': [],
            'glr_stat_down': [],
            'mosum_stat_up': [],
            'mosum_stat_down': [],
            'mode': [],             # adaptive, alert
            'anomaly_flag': [],      # 1 if anomaly detected (Sentinel only)
            'gt_anomaly_flag': [],    # 1 if ground truth is anomaly
            'gt_event_ids': []
        }
    def predict(self):
        """
        Kalman Filter Prediction Step
        x_{k|k-1} = F * x_{k-1|k-1}
        P_{k|k-1} = F * P_{k-1|k-1} * F^T + Q
        """
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q
        
        # Cache predicted state for anomaly detection
        self.x_pred = self.x.copy()
        self.P_pred = self.P.copy()
        if self.alert_bg_x is not None and self.alert_bg_P is not None:
            self.alert_bg_x = self.F @ self.alert_bg_x
            self.alert_bg_P = self.F @ self.alert_bg_P @ self.F.T + self.Q
        
        # Reset innovation/nis for this step (will be filled if sampled)
        self.last_innovation = np.nan
        self.last_innovation_var = np.nan
        self.last_nis = np.nan
        self.last_signed_norm_innovation = np.nan
        
        return self.x

    def update(self, z):
        """
        Kalman Filter Update Step
        """
        if z is None:
            # No measurement, state remains as predicted
            return

        # 1. Innovation (Residual) y = z - H * x_pred
        # Use cached predicted state to avoid using updated state
        y = z - self.H @ self.x_pred
        self.last_innovation = y[0, 0] # Scalar for single sensor
        
        # 2. Innovation Covariance S = H * P_pred * H^T + R
        S = self.H @ self.P_pred @ self.H.T + self.R
        s_scalar = float(S[0, 0])
        self.last_innovation_var = s_scalar
        if np.isfinite(s_scalar) and s_scalar > 1e-12:
            self.last_signed_norm_innovation = float(self.last_innovation / np.sqrt(s_scalar))
        else:
            self.last_signed_norm_innovation = np.nan
        
        # 3. Calculate NIS = y^T * S^-1 * y
        try:
            S_inv = np.linalg.inv(S)
            self.last_nis = (y.T @ S_inv @ y)[0, 0]
        except np.linalg.LinAlgError:
            S_inv = np.linalg.pinv(S) # Fallback to pseudo-inverse
            self.last_nis = (y.T @ S_inv @ y)[0, 0]
            
        # 4. Optimal Kalman Gain K = P_pred * H^T * S^-1
        K = self.P_pred @ self.H.T @ S_inv
        
        # 5. Update state x = x_pred + K * y
        self.x = self.x_pred + K @ y
        
        # 6. Update covariance (Joseph form for stability)
        # P = (I - KH)P(I - KH)^T + KRK^T
        I = np.eye(self.P.shape[0])
        I_KH = I - K @ self.H
        self.P = I_KH @ self.P_pred @ I_KH.T + K @ self.R @ K.T

    def should_sample(self):
        """
        Decide whether to sample based on role, mode and uncertainty.
        Using Predicted Observation Variance: sigma_y^2 = H * P_pred * H^T
        """
        # 1. Sentinel Role: Always sample
        if self.role == 'sentinel':
            return True
            
        # 2. Alert Mode: Triggered high-frequency sampling
        if self.mode == 'alert':
            return True
        
        # 3. Adaptive Mode: Check uncertainty in observation space
        # Use Predicted Uncertainty (Prior)
        obs_uncertainty = (self.H @ self.P_pred @ self.H.T)[0, 0]
        
        if obs_uncertainty > self.gamma:
            return True
            
        return False

    def _reset_alert_exit_tracking(self):
        self.alert_exit_streak = 0
        self.alert_neighbor_quiet_streak = 0
        self.alert_exit_glr_stat = 0.0
        self.alert_exit_signal_buffer = []
        self.alert_exit_reference_sign = 0.0
        self.alert_exit_latched = False

    def confirm_alert(self):
        self.alert_confirmed = True
        self.alert_verify_elapsed = 0
        self._reset_alert_exit_tracking()

    def trigger_alert(self, duration, confirmed=False):
        """
        Trigger alert mode for a specific duration.
        """
        if self.mode != 'alert':
            self.alert_bg_x = self.x_pred.copy() if self.x_pred is not None else self.x.copy()
            self.alert_bg_P = self.P_pred.copy() if self.P_pred is not None else self.P.copy()
            self.alert_elapsed = 0
            self.alert_confirmed = bool(confirmed)
            self.alert_verify_elapsed = 0
            self._reset_alert_exit_tracking()
        elif confirmed and (not self.alert_confirmed):
            self.confirm_alert()
        elif (not confirmed) and (not self.alert_confirmed):
            self.alert_verify_elapsed = 0
        self.alert_cooldown_timer = 0
        self.mode = 'alert'
        self.alert_timer = max(int(duration), int(self.alert_timer))

    def _clear_alert_state(self, start_local_cooldown=False):
        self.mode = 'adaptive'
        self.alert_timer = 0
        self.alert_elapsed = 0
        self.alert_bg_x = None
        self.alert_bg_P = None
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self._reset_alert_exit_tracking()
        if start_local_cooldown and self.role != 'sentinel' and self.self_trigger_enabled:
            self.alert_cooldown_timer = max(self.alert_cooldown_timer, self.alert_exit_cooldown_steps + 1)

    def _background_prediction_stats(self):
        if self.alert_bg_x is None or self.alert_bg_P is None:
            return None, None
        bg_y = float((self.H @ self.alert_bg_x)[0, 0])
        bg_var = float((self.H @ self.alert_bg_P @ self.H.T)[0, 0] + self.R[0, 0])
        return bg_y, max(bg_var, 1e-9)

    def update_alert_exit_state(self, z):
        if self.mode != 'alert' or z is None:
            self._reset_alert_exit_tracking()
            return
        if not self.alert_early_exit_enabled:
            return
        if not self.alert_confirmed:
            self._reset_alert_exit_tracking()
            return
        bg_y, bg_var = self._background_prediction_stats()
        if bg_y is None:
            self._reset_alert_exit_tracking()
            return
        if self.alert_exit_mode == 'glr':
            bg_signed = float(float(z) - float(bg_y)) / float(np.sqrt(bg_var))
            if not np.isfinite(bg_signed):
                self.alert_exit_streak = 0
                self.alert_exit_glr_stat = 0.0
                self.alert_exit_signal_buffer = []
                self.alert_exit_reference_sign = 0.0
                self.alert_exit_latched = False
                return
            if self.alert_exit_reference_sign == 0.0 and abs(bg_signed) > 1e-9:
                self.alert_exit_reference_sign = 1.0 if bg_signed > 0.0 else -1.0
            if self.alert_exit_reference_sign == 0.0:
                self.alert_exit_streak = 0
                self.alert_exit_glr_stat = 0.0
                self.alert_exit_signal_buffer = []
                self.alert_exit_latched = False
                return
            exit_signal = -self.alert_exit_reference_sign * bg_signed
            self.alert_exit_signal_buffer.append(float(exit_signal))
            if len(self.alert_exit_signal_buffer) > self.alert_exit_glr_window_max:
                self.alert_exit_signal_buffer = self.alert_exit_signal_buffer[-self.alert_exit_glr_window_max:]
            vals = np.asarray(self.alert_exit_signal_buffer, dtype=float)
            n = len(vals)
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            glr_up = 0.0
            for win in range(self.alert_exit_glr_window_min, min(self.alert_exit_glr_window_max, n) + 1):
                seg_sum = float(csum[n] - csum[n - win])
                glr_up = max(glr_up, (max(0.0, seg_sum) ** 2) / (2.0 * float(win)))
            self.alert_exit_glr_stat = float(glr_up)
            if self.alert_exit_glr_stat < self.alert_exit_glr_reset:
                self.alert_exit_latched = False
                self.alert_exit_streak = 0
            elif self.alert_exit_glr_stat >= self.alert_exit_glr_threshold:
                if not self.alert_exit_latched:
                    self.alert_exit_latched = True
                self.alert_exit_streak = self.alert_exit_consecutive
            else:
                self.alert_exit_streak = 0
            return
        threshold = self.alert_exit_abs_threshold + self.alert_exit_sigma_factor * np.sqrt(bg_var)
        if abs(float(z) - float(bg_y)) <= float(threshold):
            self.alert_exit_streak += 1
        else:
            self.alert_exit_streak = 0

    def update_neighbor_quiet_state(self, neighborhood_active):
        if self.mode != 'alert':
            self.alert_neighbor_quiet_streak = 0
            return
        if neighborhood_active:
            self.alert_neighbor_quiet_streak = 0
        else:
            self.alert_neighbor_quiet_streak += 1

    def is_background_recovered(self):
        if self.mode != 'alert':
            return False
        if not self.alert_confirmed:
            return False
        if self.alert_exit_mode == 'glr':
            return bool(self.alert_exit_latched and self.alert_exit_glr_stat >= self.alert_exit_glr_threshold)
        return bool(self.alert_exit_streak >= self.alert_exit_consecutive)

    def in_alert_cooldown(self):
        return bool(self.alert_cooldown_timer > 0)

    def step_cooldown(self):
        if self.alert_cooldown_timer > 0:
            self.alert_cooldown_timer -= 1

    def reset_detector_state(self):
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.last_detector_trigger_direction = 0
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0
        self.glr_stat_up = 0.0
        self.glr_stat_down = 0.0
        self.mosum_stat_up = 0.0
        self.mosum_stat_down = 0.0
        self.detector_signal_buffer = []

    def _detector_mode(self):
        return str(getattr(config, "SENTINEL_DETECTOR_MODE", "nis")).strip().lower()

    def _nis_signal(self):
        if self.last_nis is None or np.isnan(self.last_nis):
            return np.nan
        return float(np.sqrt(max(0.0, float(self.last_nis))))

    def _normalized_innovation_signal(self):
        if self.last_signed_norm_innovation is None or np.isnan(self.last_signed_norm_innovation):
            return np.nan
        return float(self.last_signed_norm_innovation)

    def _detector_direction(self, prefix):
        raw = str(getattr(config, prefix, "both")).strip().lower()
        if raw in {"up", "pos", "positive", "rise", "increase"}:
            return "up"
        if raw in {"down", "neg", "negative", "fall", "decrease"}:
            return "down"
        return "both"

    def _selected_detector_stat(self, up_stat, down_stat, direction):
        if direction == "up":
            return float(up_stat)
        if direction == "down":
            return float(down_stat)
        return float(max(up_stat, down_stat))

    def _dominant_detector_direction(self, up_stat, down_stat, signal_value=np.nan):
        up_val = float(up_stat)
        down_val = float(down_stat)
        if up_val > down_val:
            return 1
        if down_val > up_val:
            return -1
        if np.isfinite(signal_value) and float(signal_value) != 0.0:
            return 1 if float(signal_value) > 0.0 else -1
        return 0

    def _detector_buffer_maxlen(self):
        glr_max = max(1, int(getattr(config, "SENTINEL_GLR_WINDOW_MAX", 12)))
        mosum_max = max(1, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MAX", 6)))
        return max(glr_max, 2 * mosum_max)

    def _append_detector_signal(self, x):
        self.detector_signal_buffer.append(float(x))
        maxlen = self._detector_buffer_maxlen()
        if len(self.detector_signal_buffer) > maxlen:
            self.detector_signal_buffer = self.detector_signal_buffer[-maxlen:]

    def _update_glr_stat(self):
        vals = np.asarray(self.detector_signal_buffer, dtype=float)
        n = len(vals)
        min_w = max(1, int(getattr(config, "SENTINEL_GLR_WINDOW_MIN", 1)))
        max_w = max(min_w, int(getattr(config, "SENTINEL_GLR_WINDOW_MAX", 12)))
        up_stat = 0.0
        down_stat = 0.0
        if n > 0:
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            upper = min(max_w, n)
            for win in range(min_w, upper + 1):
                seg_sum = float(csum[n] - csum[n - win])
                up_stat = max(up_stat, (max(0.0, seg_sum) ** 2) / (2.0 * float(win)))
                down_stat = max(down_stat, (max(0.0, -seg_sum) ** 2) / (2.0 * float(win)))
        self.glr_stat_up = float(up_stat)
        self.glr_stat_down = float(down_stat)

    def _glr_relative_enabled(self):
        return bool(getattr(config, "SENTINEL_GLR_RELATIVE_ENABLED", False))

    def _glr_relative_window(self):
        return max(5, int(getattr(config, "SENTINEL_GLR_RELATIVE_WINDOW", 40)))

    def _glr_relative_min_count(self):
        return max(5, int(getattr(config, "SENTINEL_GLR_RELATIVE_MIN_COUNT", 12)))

    def _glr_relative_floor(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_FLOOR", 3.0))

    def _glr_relative_k(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_K", 3.5))

    def _glr_relative_scale_floor(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_SCALE_FLOOR", 0.35))

    def _glr_relative_background_cap(self, hard_threshold):
        frac = float(getattr(config, "SENTINEL_GLR_RELATIVE_BACKGROUND_MAX_FRACTION", 0.8))
        frac = min(max(frac, 0.05), 1.0)
        return float(hard_threshold) * frac

    def _glr_relative_threshold_stats(self):
        vals = np.asarray(self.glr_background_stat_buffer, dtype=float)
        vals = vals[np.isfinite(vals)]
        if len(vals) < self._glr_relative_min_count():
            return np.nan, np.nan, np.nan
        center = float(np.median(vals))
        mad = float(np.median(np.abs(vals - center)))
        scale = max(1.4826 * mad, self._glr_relative_scale_floor())
        threshold = max(self._glr_relative_floor(), center + self._glr_relative_k() * scale)
        return center, scale, float(threshold)

    def _glr_relative_hit(self, stat):
        if (not self._glr_relative_enabled()) or (not np.isfinite(stat)):
            return False
        _, _, threshold = self._glr_relative_threshold_stats()
        if not np.isfinite(threshold):
            return False
        return float(stat) >= float(threshold)

    def _update_glr_relative_background(self, stat, hard_threshold, should_trigger):
        if not self._glr_relative_enabled():
            return
        if self.mode == 'alert':
            return
        if should_trigger or (not np.isfinite(stat)):
            return
        background_cap = min(self._glr_relative_background_cap(hard_threshold), float(hard_threshold))
        if float(stat) >= background_cap:
            return
        self.glr_background_stat_buffer.append(float(stat))
        maxlen = self._glr_relative_window()
        if len(self.glr_background_stat_buffer) > maxlen:
            self.glr_background_stat_buffer = self.glr_background_stat_buffer[-maxlen:]

    def _update_mosum_stat(self):
        vals = np.asarray(self.detector_signal_buffer, dtype=float)
        n = len(vals)
        min_w = max(1, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MIN", 2)))
        max_w = max(min_w, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MAX", 6)))
        up_stat = 0.0
        down_stat = 0.0
        if n >= 2:
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            upper = min(max_w, n // 2)
            for win in range(min_w, upper + 1):
                recent_sum = float(csum[n] - csum[n - win])
                prev_sum = float(csum[n - win] - csum[n - 2 * win])
                diff = (recent_sum - prev_sum) / np.sqrt(2.0 * float(win))
                up_stat = max(up_stat, max(0.0, diff))
                down_stat = max(down_stat, max(0.0, -diff))
        self.mosum_stat_up = float(up_stat)
        self.mosum_stat_down = float(down_stat)

    def is_anomaly_signal(self):
        mode = self._detector_mode()
        if mode == 'nis':
            return self.is_anomaly_raw()
        if mode == 'cusum':
            return self.cusum_stat >= float(getattr(config, "SENTINEL_CUSUM_H", 3.2))
        if mode == 'page_hinkley':
            return (self.ph_cum - self.ph_min) >= float(getattr(config, "SENTINEL_PH_LAMBDA", 1.8))
        if mode == 'glr':
            direction = self._detector_direction("SENTINEL_GLR_DIRECTION")
            stat = self._selected_detector_stat(self.glr_stat_up, self.glr_stat_down, direction)
            return bool((stat >= float(getattr(config, "SENTINEL_GLR_THRESHOLD", 8.0))) or self._glr_relative_hit(stat))
        if mode == 'mosum':
            direction = self._detector_direction("SENTINEL_MOSUM_DIRECTION")
            stat = self._selected_detector_stat(self.mosum_stat_up, self.mosum_stat_down, direction)
            return stat >= float(getattr(config, "SENTINEL_MOSUM_THRESHOLD", 3.0))
        return self.is_anomaly_raw()

    def check_anomaly(self):
        mode = self._detector_mode()
        if self.last_nis is None or np.isnan(self.last_nis):
            self.reset_detector_state()
            return False
        if mode in {'glr', 'mosum'}:
            x = self._normalized_innovation_signal()
            if not np.isfinite(x):
                self.reset_detector_state()
                return False
            self._append_detector_signal(x)
            if mode == 'glr':
                self._update_glr_stat()
                direction = self._detector_direction("SENTINEL_GLR_DIRECTION")
                threshold = float(getattr(config, "SENTINEL_GLR_THRESHOLD", 8.0))
                reset = float(getattr(config, "SENTINEL_GLR_RESET", 1.0))
                stat = self._selected_detector_stat(self.glr_stat_up, self.glr_stat_down, direction)
                relative_hit = self._glr_relative_hit(stat)
            else:
                self._update_mosum_stat()
                direction = self._detector_direction("SENTINEL_MOSUM_DIRECTION")
                threshold = float(getattr(config, "SENTINEL_MOSUM_THRESHOLD", 3.0))
                reset = float(getattr(config, "SENTINEL_MOSUM_RESET", 0.5))
                stat = self._selected_detector_stat(self.mosum_stat_up, self.mosum_stat_down, direction)
                relative_hit = False
            if stat < reset:
                self.alert_latched = False
            dominant_direction = self._dominant_detector_direction(
                self.glr_stat_up if mode == 'glr' else self.mosum_stat_up,
                self.glr_stat_down if mode == 'glr' else self.mosum_stat_down,
                signal_value=x,
            )
            should_trigger = bool((stat >= threshold) or relative_hit)
            if mode == 'glr':
                self._update_glr_relative_background(stat, threshold, should_trigger)
            if should_trigger and self.mode == 'alert' and self.alert_confirmed:
                self.last_detector_trigger_direction = dominant_direction
                return False
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                self.last_detector_trigger_direction = dominant_direction
                return True
            return False
        if mode == 'cusum':
            x = self._nis_signal()
            k = float(getattr(config, "SENTINEL_CUSUM_K", 0.35))
            h = float(getattr(config, "SENTINEL_CUSUM_H", 3.2))
            reset = float(getattr(config, "SENTINEL_CUSUM_RESET", 0.6))
            self.cusum_stat = max(0.0, self.cusum_stat + x - k)
            if self.cusum_stat < reset:
                self.alert_latched = False
            should_trigger = self.cusum_stat >= h
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                return True
            return False
        if mode == 'page_hinkley':
            x = self._nis_signal()
            delta = float(getattr(config, "SENTINEL_PH_DELTA", 0.03))
            lamb = float(getattr(config, "SENTINEL_PH_LAMBDA", 1.8))
            reset = float(getattr(config, "SENTINEL_PH_RESET", 0.25))
            self.ph_count += 1
            if self.ph_count == 1:
                self.ph_mean = x
            else:
                self.ph_mean += (x - self.ph_mean) / self.ph_count
            self.ph_cum += x - self.ph_mean - delta
            self.ph_min = min(self.ph_min, self.ph_cum)
            gap = self.ph_cum - self.ph_min
            if gap < reset:
                self.alert_latched = False
            should_trigger = gap >= lamb
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                return True
            return False
        raw = self.last_nis > float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63)))
        soft_factor = float(getattr(config, "SENTINEL_TRIGGER_SOFT_FACTOR", 0.75))
        soft_steps = max(1, int(getattr(config, "SENTINEL_TRIGGER_SOFT_CONSECUTIVE_STEPS", self.consecutive_required)))
        eta = float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63)))
        if self.last_nis > eta:
            self.nis_exceed_streak += 1
        else:
            self.nis_exceed_streak = 0
        if self.last_nis > eta * soft_factor:
            self.soft_exceed_streak += 1
        else:
            self.soft_exceed_streak = 0
        if self.nis_exceed_streak == 0 and self.soft_exceed_streak == 0:
            self.alert_latched = False
        if self.trigger_mode == 'consecutive':
            high_override = float(getattr(config, "SENTINEL_TRIGGER_HIGH_OVERRIDE_FACTOR", 1.2)) * eta
            should_trigger = (self.nis_exceed_streak >= self.consecutive_required) or (self.last_nis >= high_override) or (self.soft_exceed_streak >= soft_steps)
        else:
            should_trigger = raw or (self.soft_exceed_streak >= soft_steps)
        if should_trigger and (not self.alert_latched):
            self.alert_latched = True
            return True
        return False

    def is_anomaly_raw(self):
        if self.last_nis is None or np.isnan(self.last_nis):
            return False
        return bool(self.last_nis > float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63))))

    def step_timer(self, neighbor_recovery_ratio=None):
        if self.mode == 'alert':
            self.alert_elapsed += 1
            if not self.alert_confirmed:
                self.alert_verify_elapsed += 1
                if self.alert_verify_elapsed >= self.alert_verify_wait_steps:
                    self._clear_alert_state(start_local_cooldown=False)
                return
            allow_exit = False
            if (
                self.alert_early_exit_enabled
                and self.alert_elapsed >= self.alert_min_duration
            ):
                if self.alert_exit_mode == 'glr':
                    allow_exit = self.is_background_recovered()
                elif self.alert_exit_streak >= self.alert_exit_consecutive and self.alert_neighbor_recovery_ratio > 0.0:
                    ratio_val = 1.0 if neighbor_recovery_ratio is None else float(neighbor_recovery_ratio)
                    allow_exit = ratio_val >= self.alert_neighbor_recovery_ratio
                elif self.alert_exit_streak >= self.alert_exit_consecutive:
                    allow_exit = self.alert_neighbor_quiet_streak >= self.alert_neighbor_silence_steps
            if allow_exit:
                self._clear_alert_state(start_local_cooldown=True)
                return
            if self.alert_exit_mode == 'glr':
                return
            if self.alert_timer > 1:
                self.alert_timer -= 1
            else:
                self._clear_alert_state()

    def log_status(self, z=None, sampled=False, anomaly_detected=False, gt_anomaly=False, gt_event_ids=None):
        self.history['estimated'].append(self.x[0, 0])
        self.history['measured'].append(z if z is not None else np.nan)
        
        # Log Predicted Observation Variance (Prior) - Decision Basis
        unc_pred = (self.H @ self.P_pred @ self.H.T)[0, 0] if self.P_pred is not None else np.nan
        self.history['uncertainty_pred'].append(unc_pred)
        
        # Log Posterior Observation Variance (Post) - Resulting Confidence
        unc_post = (self.H @ self.P @ self.H.T)[0, 0]
        self.history['uncertainty_post'].append(unc_post)
        
        self.history['sampled'].append(1 if sampled else 0)
        
        # New fields
        pred_val = (self.H @ self.x_pred)[0, 0] if self.x_pred is not None else np.nan
        self.history['predicted'].append(pred_val)
        self.history['innovation'].append(self.last_innovation)
        self.history['nis'].append(self.last_nis)
        self.history['signed_norm_innovation'].append(self.last_signed_norm_innovation)
        self.history['glr_stat_up'].append(self.glr_stat_up)
        self.history['glr_stat_down'].append(self.glr_stat_down)
        self.history['mosum_stat_up'].append(self.mosum_stat_up)
        self.history['mosum_stat_down'].append(self.mosum_stat_down)
        self.history['mode'].append(self.mode)
        self.history['anomaly_flag'].append(1 if anomaly_detected else 0)
        self.history['gt_anomaly_flag'].append(1 if gt_anomaly else 0)
        if gt_event_ids is None:
            self.history['gt_event_ids'].append('')
        else:
            self.history['gt_event_ids'].append(','.join([str(x) for x in gt_event_ids]))


class Sentinel(Node):
    def __init__(self, node_id, initial_state, P0, F, H, Q, R, threshold_gamma, anomaly_threshold_eta, trigger_mode='single', consecutive_required=2):
        super().__init__(node_id, initial_state, P0, F, H, Q, R, threshold_gamma)
        self.role = 'sentinel'
        self.eta = anomaly_threshold_eta
        self.trigger_mode = str(trigger_mode).strip().lower()
        self.consecutive_required = max(1, int(consecutive_required))
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0

    def _detector_mode(self):
        return super()._detector_mode()

    def _nis_signal(self):
        return super()._nis_signal()

    def is_anomaly_signal(self):
        return super().is_anomaly_signal()

    def check_anomaly(self):
        return super().check_anomaly()

    def is_anomaly_raw(self):
        return super().is_anomaly_raw()


from src.anomaly import AnomalyInjector

class SimulationEnvironment:
    def __init__(self, nodes, data_loader, start_time, time_step_sec=30, value_col='temperature', node_positions=None, alert_duration_steps=3, alert_neighbor_graph='communication', alert_propagation_mode='one_hop', alert_max_hops=1, enable_sentinel_alert_trigger=True, oracle_wakeup_enabled=False, oracle_wakeup_graph='spatial'):
        self.nodes = nodes
        self.data_loader = data_loader
        self.current_time = start_time
        self.time_step = pd.Timedelta(seconds=time_step_sec)
        self.value_col = value_col
        self.node_data = {}
        self.node_positions = node_positions if node_positions is not None else {}
        self.adjacency = {node_id: [] for node_id in self.nodes.keys()}
        self.topology_mode = None
        self.topology_params = {}
        self.communication_weights = {}
        self.communication_adjacency = {node_id: [] for node_id in self.nodes.keys()}
        self.communication_threshold = None
        self.communication_model = 'threshold_cut'
        self.alert_duration_steps = alert_duration_steps
        self.alert_neighbor_graph = alert_neighbor_graph
        self.alert_propagation_mode = alert_propagation_mode
        self.alert_max_hops = alert_max_hops
        self.enable_sentinel_alert_trigger = enable_sentinel_alert_trigger
        self.oracle_wakeup_enabled = oracle_wakeup_enabled
        self.oracle_wakeup_graph = oracle_wakeup_graph
        self.alert_events = []
        self.oracle_alert_events = []
        self.node_comm_energy_records = []
        self.anomaly_injector = AnomalyInjector() # Initialize injector
        
    def load_node_data(self, moteid, dataframe):
        self.node_data[moteid] = dataframe

    def load_node_positions(self, node_positions):
        self.node_positions = node_positions

    def build_topology(self, mode='radius', radius=None, k=None):
        node_ids = sorted([node_id for node_id in self.nodes.keys() if node_id in self.node_positions])
        if len(node_ids) == 0:
            self.adjacency = {}
            self.topology_mode = mode
            self.topology_params = {'radius': radius, 'k': k}
            return self.adjacency
        adjacency_set = {node_id: set() for node_id in node_ids}
        if mode == 'radius':
            if radius is None or radius <= 0:
                raise ValueError('radius mode requires radius > 0')
            for i, src in enumerate(node_ids):
                src_pos = self.node_positions[src]
                for dst in node_ids[i + 1:]:
                    dst_pos = self.node_positions[dst]
                    dx = src_pos['x'] - dst_pos['x']
                    dy = src_pos['y'] - dst_pos['y']
                    dist = np.sqrt(dx * dx + dy * dy)
                    if dist <= radius:
                        adjacency_set[src].add(dst)
                        adjacency_set[dst].add(src)
        elif mode == 'knn':
            if k is None or k <= 0:
                raise ValueError('knn mode requires k > 0')
            k_eff = min(k, max(0, len(node_ids) - 1))
            for src in node_ids:
                src_pos = self.node_positions[src]
                dist_pairs = []
                for dst in node_ids:
                    if dst == src:
                        continue
                    dst_pos = self.node_positions[dst]
                    dx = src_pos['x'] - dst_pos['x']
                    dy = src_pos['y'] - dst_pos['y']
                    dist = np.sqrt(dx * dx + dy * dy)
                    dist_pairs.append((dist, dst))
                dist_pairs.sort(key=lambda x: (x[0], x[1]))
                for _, dst in dist_pairs[:k_eff]:
                    adjacency_set[src].add(dst)
                    adjacency_set[dst].add(src)
        else:
            raise ValueError("mode must be 'radius' or 'knn'")
        self.adjacency = {node_id: sorted(list(neighbors)) for node_id, neighbors in adjacency_set.items()}
        self.topology_mode = mode
        self.topology_params = {'radius': radius, 'k': k}
        return self.adjacency

    def get_neighbors(self, node_id):
        return self.adjacency.get(node_id, [])

    def load_communication_weights(self, communication_weights):
        self.communication_weights = communication_weights

    def build_communication_topology(self, threshold, directed=True, model='threshold_cut', random_seed=None):
        node_ids = sorted(self.nodes.keys())
        adjacency_set = {node_id: set() for node_id in node_ids}
        rng = np.random.default_rng(random_seed) if random_seed is not None else None
        for src in node_ids:
            for dst in node_ids:
                if src == dst:
                    continue
                weight = self.communication_weights.get(src, {}).get(dst, 0.0)
                keep_edge = False
                if model == 'threshold_cut':
                    keep_edge = weight >= threshold
                elif model == 'probability_propagation':
                    if weight > 0:
                        sampled = rng.random() if rng is not None else np.random.random()
                        keep_edge = sampled <= weight
                else:
                    raise ValueError("model must be 'threshold_cut' or 'probability_propagation'")
                if keep_edge:
                    adjacency_set[src].add(dst)
                    if not directed:
                        adjacency_set[dst].add(src)
        self.communication_adjacency = {node_id: sorted(list(neighbors)) for node_id, neighbors in adjacency_set.items()}
        self.communication_threshold = threshold
        self.communication_model = model
        return self.communication_adjacency

    def get_comm_neighbors(self, node_id):
        return self.communication_adjacency.get(node_id, [])

    def get_comm_reverse_neighbors(self, node_id):
        reverse_neighbors = set()
        for src, dst_list in self.communication_adjacency.items():
            if node_id in dst_list:
                reverse_neighbors.add(src)
        return sorted(list(reverse_neighbors))

    def _get_alert_neighbors(self, node_id):
        if self.alert_neighbor_graph == 'communication':
            return self.get_comm_neighbors(node_id)
        if self.alert_neighbor_graph == 'spatial':
            return self.get_neighbors(node_id)
        raise ValueError("alert_neighbor_graph must be 'communication' or 'spatial'")

    def _get_alert_monitor_neighbors(self, node_id):
        if self.alert_neighbor_graph == 'communication':
            neighbors = set(self.get_comm_neighbors(node_id))
            neighbors.update(self.get_comm_reverse_neighbors(node_id))
            if node_id in neighbors:
                neighbors.remove(node_id)
            return sorted(list(neighbors))
        neighbors = set(self._get_alert_neighbors(node_id))
        if node_id in neighbors:
            neighbors.remove(node_id)
        return sorted(list(neighbors))

    def _resolve_alert_targets(self, sentinel_id, dynamic_max_hops=None):
        if self.alert_propagation_mode == 'one_hop':
            return {nid for nid in self._get_alert_neighbors(sentinel_id) if nid in self.nodes and self.nodes[nid].role != 'sentinel'}
        if self.alert_propagation_mode == 'k_hop':
            if dynamic_max_hops is None:
                max_hops = max(1, int(self.alert_max_hops))
            else:
                max_hops = max(1, int(dynamic_max_hops))
            visited = {sentinel_id: 0}
            queue = [sentinel_id]
            head = 0
            while head < len(queue):
                cur = queue[head]
                head += 1
                cur_hop = visited[cur]
                if cur_hop >= max_hops:
                    continue
                for nxt in self._get_alert_neighbors(cur):
                    if nxt in visited:
                        continue
                    visited[nxt] = cur_hop + 1
                    queue.append(nxt)
            targets = set(visited.keys())
            if sentinel_id in targets:
                targets.remove(sentinel_id)
            return {nid for nid in targets if nid in self.nodes and self.nodes[nid].role != 'sentinel'}
        raise NotImplementedError("alert_propagation_mode only supports one_hop or k_hop")

    def _compute_dynamic_alert_hops(self, nis_value):
        base_hops = max(1, int(self.alert_max_hops))
        if (not config.ALERT_ADAPTIVE_HOPS_ENABLED) or self.alert_propagation_mode != 'k_hop':
            return base_hops
        if nis_value is None or np.isnan(nis_value):
            return base_hops
        high = float(config.ALERT_ADAPTIVE_NIS_HIGH)
        medium = float(config.ALERT_ADAPTIVE_NIS_MEDIUM)
        if nis_value >= high:
            delta = int(config.ALERT_ADAPTIVE_HOPS_HIGH_DELTA)
        elif nis_value >= medium:
            delta = int(config.ALERT_ADAPTIVE_HOPS_MEDIUM_DELTA)
        else:
            delta = 0
        max_allow = max(base_hops, int(config.ALERT_ADAPTIVE_MAX_HOPS))
        return min(max_allow, base_hops + max(0, delta))

    def _get_oracle_neighbors(self, node_id):
        if self.oracle_wakeup_graph == 'communication':
            return self.get_comm_neighbors(node_id)
        if self.oracle_wakeup_graph == 'spatial':
            return self.get_neighbors(node_id)
        raise ValueError("oracle_wakeup_graph must be 'communication' or 'spatial'")

    def get_ground_truth(self, moteid, timestamp):
        if moteid not in self.node_data:
            return None, False, []
            
        df = self.node_data[moteid]
        try:
            val = None
            if timestamp in df.index:
                val = df.loc[timestamp][self.value_col]
                if pd.isna(val):
                    val = None
            
            # Inject Anomaly if val exists
            if val is not None:
                injected_val, is_anomaly, event_ids = self.anomaly_injector.get_injected_value(
                    val, timestamp, moteid, self.time_step,
                    node_positions=self.node_positions,
                    spatial_adjacency=self.adjacency,
                    communication_adjacency=self.communication_adjacency
                )
                return injected_val, is_anomaly, event_ids
            return None, False, []
            
        except KeyError:
            return None, False, []

    def step(self):
        for node in self.nodes.values():
            node.step_cooldown()
        pre_alert_nodes = {node_id for node_id, node in self.nodes.items() if node.mode == 'alert'}
        for node in self.nodes.values():
            node.predict()
        triggered_alert_sources = {}
        gt_anomaly_nodes = set()
        step_records = {}
        
        for node_id, node in self.nodes.items():
            gt_val, gt_anomaly, gt_event_ids = self.get_ground_truth(node_id, self.current_time)
            if gt_anomaly:
                gt_anomaly_nodes.add(node_id)
            is_sampled = node.should_sample()
            anomaly_detected = False
            z = None
            
            if is_sampled and gt_val is not None:
                noise_std = np.sqrt(node.R[0,0])
                noise = np.random.normal(0, noise_std)
                z = gt_val + noise
                node.update(z)
                node.update_alert_exit_state(z)
                anomaly_detected = node.is_anomaly_signal()
                local_trigger = False
                if node.role == 'sentinel':
                    local_trigger = bool(node.check_anomaly())
                    if local_trigger and node.mode == 'alert':
                        node.confirm_alert()
                    if local_trigger:
                        nis_val = float(node.last_nis) if node.last_nis is not None and not np.isnan(node.last_nis) else np.nan
                        old = triggered_alert_sources.get(node_id, np.nan)
                        if np.isnan(old) or (not np.isnan(nis_val) and nis_val > old):
                            triggered_alert_sources[node_id] = nis_val
                elif node.self_trigger_enabled and (not node.in_alert_cooldown()):
                    local_trigger = bool(node.check_anomaly())
                    if local_trigger and node.mode == 'alert':
                        node.confirm_alert()
                    if local_trigger:
                        nis_val = float(node.last_nis) if node.last_nis is not None and not np.isnan(node.last_nis) else np.nan
                        old = triggered_alert_sources.get(node_id, np.nan)
                        if np.isnan(old) or (not np.isnan(nis_val) and nis_val > old):
                            triggered_alert_sources[node_id] = nis_val
            else:
                node.update(None)
                node.reset_detector_state()
            step_records[node_id] = {
                "sampled": bool(is_sampled and gt_val is not None),
                "anomaly_detected": bool(anomaly_detected),
                "gt_anomaly": bool(gt_anomaly),
                "gt_event_ids": gt_event_ids,
                "z": z,
                "gt_val": gt_val
            }
        newly_alerted_nodes = set()
        if self.enable_sentinel_alert_trigger and self.alert_duration_steps > 0 and len(triggered_alert_sources) > 0:
            triggered_nodes = set()
            for source_id, nis_val in triggered_alert_sources.items():
                dyn_hops = self._compute_dynamic_alert_hops(nis_val)
                alert_targets = self._resolve_alert_targets(source_id, dynamic_max_hops=dyn_hops)
                tx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                rx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                self.node_comm_energy_records.append({
                    "time": self.current_time,
                    "step_type": "sentinel_tx",
                    "node_id": int(source_id),
                    "peer_count": int(len(alert_targets)),
                    "comm_energy_mj": float(tx_energy * len(alert_targets))
                })
                self.nodes[source_id].trigger_alert(self.alert_duration_steps, confirmed=True)
                for neighbor_id in alert_targets:
                    if neighbor_id in self.nodes and neighbor_id != source_id:
                        was_alert = self.nodes[neighbor_id].mode == 'alert'
                        self.nodes[neighbor_id].trigger_alert(self.alert_duration_steps, confirmed=False)
                        if not was_alert:
                            newly_alerted_nodes.add(neighbor_id)
                        triggered_nodes.add(neighbor_id)
                        self.node_comm_energy_records.append({
                            "time": self.current_time,
                            "step_type": "alert_rx",
                            "node_id": int(neighbor_id),
                            "peer_count": 1,
                            "comm_energy_mj": float(rx_energy)
                        })
            self.alert_events.append({
                'time': self.current_time,
                'sentinels': sorted(list(triggered_alert_sources.keys())),
                'neighbor_count': len(triggered_nodes),
                'neighbors': sorted(list(triggered_nodes))
            })
        if self.oracle_wakeup_enabled and self.alert_duration_steps > 0 and len(gt_anomaly_nodes) > 0:
            oracle_triggered_nodes = set()
            source_nodes = sorted(list(gt_anomaly_nodes))
            for source_id in source_nodes:
                oracle_targets = set(self._get_oracle_neighbors(source_id))
                oracle_targets.add(source_id)
                tx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                rx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                self.node_comm_energy_records.append({
                    "time": self.current_time,
                    "step_type": "oracle_tx",
                    "node_id": int(source_id),
                    "peer_count": int(len(oracle_targets)),
                    "comm_energy_mj": float(tx_energy * len(oracle_targets))
                })
                for target_id in oracle_targets:
                    if target_id in self.nodes:
                        was_alert = self.nodes[target_id].mode == 'alert'
                        self.nodes[target_id].trigger_alert(self.alert_duration_steps, confirmed=False)
                        if not was_alert:
                            newly_alerted_nodes.add(target_id)
                        oracle_triggered_nodes.add(target_id)
                        self.node_comm_energy_records.append({
                            "time": self.current_time,
                            "step_type": "oracle_rx",
                            "node_id": int(target_id),
                            "peer_count": 1,
                            "comm_energy_mj": float(rx_energy)
                        })
            oracle_event = {
                'time': self.current_time,
                'sentinels': source_nodes,
                'neighbor_count': len(oracle_triggered_nodes),
                'neighbors': sorted(list(oracle_triggered_nodes))
            }
            self.alert_events.append(oracle_event)
            self.oracle_alert_events.append(oracle_event)
        for node_id in sorted(list(newly_alerted_nodes)):
            rec = step_records.get(node_id, None)
            if rec is None:
                continue
            if rec["sampled"]:
                continue
            gt_val = rec["gt_val"]
            if gt_val is None:
                continue
            node = self.nodes[node_id]
            noise_std = np.sqrt(node.R[0,0])
            noise = np.random.normal(0, noise_std)
            z = gt_val + noise
            node.update(z)
            node.update_alert_exit_state(z)
            late_detected = bool(node.is_anomaly_signal())
            rec["sampled"] = True
            rec["z"] = z
            rec["anomaly_detected"] = bool(rec["anomaly_detected"] or late_detected)
        for node_id, node in self.nodes.items():
            rec = step_records[node_id]
            node.log_status(
                rec["z"],
                sampled=rec["sampled"],
                anomaly_detected=rec["anomaly_detected"],
                gt_anomaly=rec["gt_anomaly"],
                gt_event_ids=rec["gt_event_ids"]
            )

        triggered_source_nodes = set(triggered_alert_sources.keys())
        for node_id in pre_alert_nodes:
            node = self.nodes[node_id]
            monitor_neighbors = set(self._get_alert_monitor_neighbors(node_id))
            node.update_neighbor_quiet_state(len(monitor_neighbors & triggered_source_nodes) > 0)
            alert_neighbors = [nid for nid in monitor_neighbors if nid in self.nodes and self.nodes[nid].mode == 'alert']
            if len(alert_neighbors) == 0:
                neighbor_recovery_ratio = 1.0
            else:
                recovered_neighbors = sum(1 for nid in alert_neighbors if self.nodes[nid].is_background_recovered())
                neighbor_recovery_ratio = float(recovered_neighbors) / float(len(alert_neighbors))
            node.step_timer(neighbor_recovery_ratio=neighbor_recovery_ratio)
        self.current_time += self.time_step
