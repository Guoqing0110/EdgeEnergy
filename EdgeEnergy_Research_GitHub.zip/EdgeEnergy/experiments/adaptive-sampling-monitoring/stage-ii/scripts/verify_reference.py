"""Recalculate chapter results from the public method-by-seed records."""
import argparse
import csv
import math
from collections import Counter
from pathlib import Path
from statistics import fmean

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "reference"
DF = "DF-ReAlert"
CONTROLS = ["Random-TopK", "Nearest-front-TopK", "Lowest-route-cost-TopK"]
FIXED = "Fixed-two-hop-verify3"
BLOCKS = {
    "primary": ([DF] + CONTROLS, range(401, 421)),
    "transfer": ([DF] + CONTROLS + [FIXED], range(421, 441)),
    "backbone": (["DF-ReAlert-corrected-B2.7-Y1", FIXED], range(441, 461)),
}
PLOT_METRICS = ("delta_front_recall", "delta_detected_delay_slots", "delta_command_rx", "delta_energy_j")
TABLE_SIZES = {"6.6": 36, "6.7": 15, "6.8": 36, "D.4": 28, "D.5": 24, "D.6": 40, "D.7": 32, "D.8": 10}


def load(name):
    with (REF / name).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def metric(row, name):
    if name == "communication_energy_mj":
        return float(row["tx_energy_mj"]) + float(row["rx_energy_mj"])
    if name.endswith("_energy_j"):
        return metric(row, name[:-1] + "mj") / 1000.0
    return float(row[name])


def per_run(study):
    records = load(study + "_per_run.csv")
    keyed = {(r["method"], int(r["seed"])): r for r in records}
    methods, seeds = BLOCKS[study]
    expected = {(m, s) for m in methods for s in seeds}
    if len(keyed) != len(records) or set(keyed) != expected:
        raise ValueError(f"{study}: method–seed pairs are duplicated, missing or unexpected")
    for k, r in keyed.items():
        for col, v in r.items():
            if col not in ("method", "seed") and not math.isfinite(float(v)):
                raise ValueError(f"{study} {k}: invalid {col}")
        if "alert_node_slots" in r:
            fraction = float(r["useful_sampled_alert_node_slots"]) / float(r["alert_node_slots"])
            if not math.isclose(fraction, float(r["useful_wakeup_precision"]), abs_tol=1e-12):
                raise ValueError(f"{study} {k}: wake-up precision disagrees with its counts")
    return keyed


def chart(values, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.2), constrained_layout=True)
    labels = ["Front recall", "Detected-front delay (slots)", "Routed command receptions", "Modelled energy (J)"]
    for ax, key, label in zip(axes.flat, PLOT_METRICS, labels):
        ax.boxplot([[float(v[key]) for v in values if v["comparator"] == m] for m in CONTROLS],
                   showmeans=True, meanline=True)
        ax.set_xticks([1, 2, 3], ["Random", "Nearest front", "Route cost"])
        ax.axhline(0, color="0.45", linewidth=0.7)
        ax.set_ylabel(label)
    fig.suptitle("Paired differences: DF-ReAlert minus control")
    fig.savefig(path)
    plt.close(fig)



def compare_transfer_costs(path, table_rows):
    """Compare a separate simulation with the displayed transfer-window means."""
    with path.open(encoding="utf-8", newline="") as handle:
        records = list(csv.DictReader(handle))
    keyed = {(r["method"], int(r["seed"])): r for r in records}
    methods, seeds = BLOCKS["transfer"]
    if len(records) != 100 or set(keyed) != {(m, s) for m in methods for s in seeds}:
        raise ValueError("The independent cost comparison needs five methods for each seed 421–440")
    out = []
    for row in table_rows:
        field = row["metric"]
        if row["study"] != "transfer" or row["table"] != "6.6" or field not in ("command_rx", "total_energy_j"):
            continue
        m = row["method_or_comparator"]
        if field == "command_rx":
            values = [float(keyed[m, s]["routed_alert_command_rx"]) for s in seeds]
        else:
            values = [float(keyed[m, s]["total_energy_mj"]) / 1000 for s in seeds]
        if not all(math.isfinite(v) and v >= 0 for v in values):
            raise ValueError(f"{m}: invalid {field}")
        mean = fmean(values)
        ref = row["reference_value"]
        digits = len(ref.split(".")[1]) if "." in ref else 0
        out.append({"method": m, "metric": field, "reported_mean": ref, "independent_mean": mean,
                    "difference_from_reported": mean-float(ref),
                    "matches_displayed_precision": abs(mean-float(ref)) <= .5*10**(-digits)+1e-11})
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, help="write table and figure data here")
    parser.add_argument("--plot", action="store_true", help="also draw Figure 6.8 (requires --output-dir and Matplotlib)")
    parser.add_argument("--transfer-costs", type=Path, help="compare a separate 100-run simulation cost CSV with the five reported transfer means")
    args = parser.parse_args()
    if args.plot and args.output_dir is None:
        parser.error("--plot requires --output-dir")
    data = {study: per_run(study) for study in BLOCKS}
    fig_values = []
    _, seeds = BLOCKS["primary"]
    for control in CONTROLS:
        for seed in seeds:
            a, b = data["primary"][DF, seed], data["primary"][control, seed]
            row = {"seed": seed, "comparator": control}
            for key, col in zip(PLOT_METRICS, ("front_recall", "detected_delay_slots", "command_rx", "total_energy_j")):
                row[key] = metric(a, col) - metric(b, col)
            fig_values.append(row)
    frozen = load("figure_6_8_differences.csv")
    frozen_by_pair = {(r["comparator"], int(r["seed"])): r for r in frozen}
    if len(frozen) != 60 or set(frozen_by_pair) != {(m, s) for m in CONTROLS for s in seeds}:
        raise ValueError("Figure 6.8: unexpected set of pairs")
    for r in fig_values:
        ref = frozen_by_pair[r["comparator"], r["seed"]]
        for key in PLOT_METRICS:
            if not math.isclose(r[key], float(ref[key]), abs_tol=1e-10, rel_tol=1e-12):
                raise ValueError(f"Figure 6.8: {key}, {r['comparator']}, seed {r['seed']}")
    rows = load("table_values.csv")
    if Counter(r["table"] for r in rows) != TABLE_SIZES:
        raise ValueError("The reference table inventory is incomplete")
    if len({(r["table"],r["study"],r["method_or_comparator"],r["metric"]) for r in rows}) != len(rows):
        raise ValueError("The reference table contains duplicate cells")
    counts = Counter()
    for r in rows:
        study, table, m, col = r["study"], r["table"], r["method_or_comparator"], r["metric"]
        if study == "transfer" and col in {"command_rx", "total_energy_j", "total_energy_mj"}:
            if r["evidence"] != "reported_mean":
                raise ValueError("Expected a method mean for this historical transfer-window cost cell")
            r.update(recalculated="", status="reported mean only")
            continue
        if r["evidence"] != "per_run":
            raise ValueError(f"{table}, {m}, {col}: unexpected evidence class")
        if table == "6.7":
            paired = [x for x in fig_values if x["comparator"] == m]
            if col in ("wins","ties","losses"):
                sign = {"wins":1,"ties":0,"losses":-1}[col]
                value = sum((int(x["delta_front_recall"] > 0) - int(x["delta_front_recall"] < 0)) == sign for x in paired)
            else:
                value = fmean(x[col] for x in paired)
        else:
            value = fmean(metric(data[study][m, s], col) for s in BLOCKS[study][1])
        shown = r["reference_value"]
        decimals = len(shown.split(".")[1]) if "." in shown else 0
        if abs(value - float(shown)) > 0.5 * 10**-decimals + 1e-11:
            raise ValueError(f"Table {table}: {m}, {col}: expected {shown}, recalculated {value}")
        counts[table] += 1
        r.update(recalculated=value, status="matched")
    for table in TABLE_SIZES:
        print(f"Table {table}: {counts[table]} of {TABLE_SIZES[table]} cells checked against per-run data.")
    print("Figure 6.8: 240 within-seed differences matched for the three controls.")
    print("The original transfer-window tables report mean command receptions and modelled energy for each method.")
    independent = None
    cost_path = args.transfer_costs
    if cost_path is None:
        candidate = REF / "reproduction" / "transfer_window_reproduction.csv"
        if candidate.is_file():
            cost_path = candidate
    if cost_path is not None:
        independent = compare_transfer_costs(cost_path, rows)
        matches = sum(row["matches_displayed_precision"] for row in independent)
        print(f"Independent transfer-window simulation: {matches}/10 cost means match at displayed precision.")
    if args.output_dir is not None:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        write(args.output_dir / "table_comparison.csv", rows)
        write(args.output_dir / "paired_differences.csv", fig_values)
        if independent is not None:
            write(args.output_dir / "independent_transfer_cost_comparison.csv", independent)
        if args.plot:
            chart(fig_values, args.output_dir / "paired_differences.pdf")


if __name__ == "__main__":
    main()
