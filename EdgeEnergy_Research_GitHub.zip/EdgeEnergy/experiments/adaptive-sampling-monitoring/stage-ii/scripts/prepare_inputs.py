"""Extract the two Stage II dates from the complete Intel Lab Data measurements."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import tempfile

DAYS = (b"2004-02-28", b"2004-03-05")
ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    with path.open("rb") as src:
        h = hashlib.sha256()
        for block in iter(lambda: src.read(1024 * 1024), b""):
            h.update(block)
        return h.hexdigest()


def extract(source, target):
    if source.resolve() == target.resolve():
        raise ValueError("Choose a different output path from the source file.")
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as src:
        compressed = src.read(2) == b"\x1f\x8b"
    op = gzip.open if compressed else open
    seen = Counter()
    raw_in, raw_out = hashlib.sha256(), hashlib.sha256()
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as tmp:
        tmp_path = Path(tmp.name)
    try:
        with op(source, "rb") as inp, tmp_path.open("wb") as dst:
            with gzip.GzipFile(filename="", mode="wb", fileobj=dst, mtime=0, compresslevel=9) as out:
                for line in inp:
                    raw_in.update(line)
                    first = line.split(maxsplit=1)[:1]
                    if first and first[0] in DAYS:
                        out.write(line)
                        raw_out.update(line)
                        seen[first[0].decode("ascii")] += 1
        expected = json.loads((ROOT / "data" / "input_manifest.json").read_text()) if (ROOT / "data" / "input_manifest.json").is_file() else {}
        if seen.keys() != {b.decode("ascii") for b in DAYS}:
            raise ValueError("Input is missing one or both measurement dates.")
        if expected and (raw_in.hexdigest() != expected["source_uncompressed_sha256"] or raw_out.hexdigest() != expected["selected_uncompressed_sha256"]):
            raise ValueError("The uncompressed input or selected rows do not match the reference archive; the output has not been written.")
        if target.exists():
            with gzip.open(target, "rb") as old:
                existing = hashlib.sha256()
                for block in iter(lambda: old.read(1024 * 1024), b""):
                    existing.update(block)
            if raw_out.digest() != existing.digest():
                raise ValueError("The target exists with different records; choose another output location.")
        tmp_path.chmod(0o644)
        tmp_path.replace(target)
    finally:
        tmp_path.unlink(missing_ok=True)
    return dict(source_file_sha256=digest(source), source_uncompressed_sha256=raw_in.hexdigest(),
                selected_uncompressed_sha256=raw_out.hexdigest(), selected_gzip_sha256=digest(target), rows_by_date=dict(seen))


def verify_alignment(full, extract_path):
    """Compare Intel measurements after exactly the simulator's preprocessing."""
    import sys
    import numpy as np
    import pandas as pd
    sys.path.insert(0, str(ROOT))
    from src import config, run_multinode_baseline as core

    config.DATASET_MODE = "intel"
    config.MOTE_LOC_FILE = str(ROOT / "data" / "mote_locs.txt")
    config.USE_DATA_CACHE = False
    specs = {"primary": ("2004-02-28 01:03", "2004-02-28 05:03"),
             "transfer": ("2004-03-05 08:00", "2004-03-05 12:00")}

    def aligned(source):
        config.DATA_FILE = str(source.resolve())
        data, locations = core._load_experiment_inputs()
        collection = {}
        for name, (start, end) in specs.items():
            start, end = pd.Timestamp(start), pd.Timestamp(end)
            window = data[(data.index >= start) & (data.index <= end)]
            observed = set(window["moteid"].dropna())
            ids = [n for n in sorted(locations) if n in observed]
            series, times = core.prepare_multinode_data(data, ids, start, end, 31)
            values = np.column_stack([series[i]["temperature"] for i in ids]).astype("<f8")
            collection[name] = (ids, times, values)
        return collection

    a, b = aligned(full), aligned(extract_path)
    for name in specs:
        n, t, values = a[name]
        n2, t2, values2 = b[name]
        if n != n2 or not t.equals(t2) or not np.array_equal(values.view("<u8"), values2.view("<u8")):
            raise ValueError(f"{name}: the node IDs, timestamps or temperatures differ")
        print(f"{name}: identical node IDs, time index and {len(t)*len(n)} temperatures "
              f"({len(t)} timestamps, {len(n)} nodes).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Complete data.txt.gz or uncompressed data.txt from Intel Lab Data")
    parser.add_argument("--output", type=Path, default=ROOT / "data" / "data.txt.gz", help="Output path for the two-date gzip file")
    parser.add_argument("--check-alignment", action="store_true", help="compare both windows after the simulator preprocessing; requires the study dependencies and data/mote_locs.txt")
    args = parser.parse_args()
    print(json.dumps(extract(args.source, args.output), indent=2))
    if args.check_alignment:
        verify_alignment(args.source, args.output)
