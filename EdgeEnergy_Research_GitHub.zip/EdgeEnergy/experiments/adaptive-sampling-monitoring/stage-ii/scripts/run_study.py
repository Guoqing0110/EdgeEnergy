"""Run a Stage II policy on its registered Intel Lab window and seed."""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from contextlib import redirect_stdout
from hashlib import sha256
import json
import logging
import math
import os
from pathlib import Path
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("MPLBACKEND", "Agg")

STUDIES = {
    "primary": (401, 420, ("DF-ReAlert", "Random-TopK", "Nearest-front-TopK", "Lowest-route-cost-TopK")),
    "transfer": (421, 440, ("DF-ReAlert", "Random-TopK", "Nearest-front-TopK", "Lowest-route-cost-TopK", "Fixed-two-hop-verify3")),
    "backbone": (441, 460, ("DF-ReAlert-corrected-B2.7-Y1", "Fixed-two-hop-verify3")),
}
EVIDENCE = ROOT / "phase2_paper_evidence"


def arguments():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--study", choices=STUDIES, default="transfer")
    ap.add_argument("--seed", type=int, help="One paired experimental seed (default: 422 for transfer; first seed otherwise)")
    ap.add_argument("--method", help="One method identifier (default: DF-ReAlert or the corresponding backbone variant)")
    ap.add_argument("--all", action="store_true", help="Run every registered method on every seed in this study")
    ap.add_argument("--data-dir", type=Path, default=ROOT / "data", help="Directory containing measurements, connectivity.txt and mote_locs.txt")
    ap.add_argument("--output-dir", type=Path, default=ROOT / "outputs" / "demo", help="A new or empty results directory")
    ap.add_argument("--keep-traces", action="store_true", help="Retain all node-slot traces in addition to the run summaries, energy table and execution settings")
    a = ap.parse_args()
    lo, hi, methods = STUDIES[a.study]
    if a.all and (a.seed is not None or a.method is not None):
        ap.error("--all cannot be combined with --seed or --method")
    if a.method and a.method not in methods:
        ap.error("Choose a method for this study: " + ", ".join(methods))
    if a.seed is not None and not lo <= a.seed <= hi:
        ap.error(f"The {a.study} window uses seeds {lo}–{hi}.")
    return a


def digest(p):
    h = sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def document(p):
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def verify_sources(study):
    """Validate the registration and scientific source used by the public entry point."""
    e1 = EVIDENCE / "e1_budget_matched_baselines/manifests/E1_IMPLEMENTATION_FREEZE_MANIFEST.json"
    e0 = EVIDENCE / "e0_evidence_preregistration/PAPER_EVIDENCE_FREEZE_MANIFEST.json"
    m = document(e1)
    d0 = document(e0)
    protocol = ROOT / d0["protocol_file"]
    checks = [(protocol, d0["protocol_sha256"]), (protocol, m["e0_protocol_sha256"]),
              (ROOT / m["audit_receipt"], m["audit_receipt_sha256"])]
    checks.extend((ROOT / f, h) for f, h in m["implementation_source_hashes"].items())
    if document(ROOT / m["audit_receipt"])["status"] != "PASS":
        raise ValueError("The primary ranking implementation did not pass its registered checks")
    if study == "transfer":
        d = document(EVIDENCE / "e3_second_temporal_window/E3_TEMPORAL_TRANSFER_FREEZE_MANIFEST.json")
        checks.extend([(ROOT / d["protocol_file"], d["protocol_sha256"]),
                       (ROOT / d["runner_file"], d["runner_sha256"]), (e1, d["e1_implementation_freeze_sha256"])])
    if study == "backbone":
        d = document(EVIDENCE / "e5_3_issc_backbone_control/E5_3_ISSC_BACKBONE_FREEZE_MANIFEST.json")
        would_run = EVIDENCE / "e5_3_issc_backbone_control/E5_3_PROTOCOL_CLARIFICATION_01.md"
        checks.extend([(ROOT / d["protocol_file"], d["preregistration_sha256"]), (would_run, d["protocol_clarification_sha256"])])
        checks.extend((ROOT / f, h) for f, h in d["runtime_source_sha256"].items())
    for path, expected in checks:
        if digest(path).lower() != expected.lower():
            raise ValueError(f"Registered file does not match: {path.relative_to(ROOT)}")


def inputs(directory):
    folder = directory.resolve()
    matches = [folder / x for x in ("data.txt", "data.txt.gz", "data (1).txt.gz") if (folder / x).is_file()]
    if not matches:
        raise FileNotFoundError(f"Put the Intel Lab measurements (data.txt or data.txt.gz) in {folder}")
    data = {"DATA_FILE": matches[0], "MOTE_LOC_FILE": folder / "mote_locs.txt", "CONNECTIVITY_FILE": folder / "connectivity.txt"}
    for p in data.values():
        if not p.is_file():
            raise FileNotFoundError(f"Input file not found: {p}")
    return data


def csv_rows(p):
    with p.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def output_csv(p, rows):
    with p.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(study, method, seed, output):
    from src import config, phase2e1_budget_matched_baselines as e1
    from src import phase2e3_temporal_transfer as e3, phase2e53_issc_backbone_control as e5
    from src.run_conclusion_experiments import config_override
    base = output / "simulations"
    parent = base / "runs" / method / f"seed_{seed}"
    if study == "primary":
        run_path = e1.run_one(method, seed, True, root=parent)
        overrides = e1.overrides(method, seed, parent, True)
        # The archived wrapper read these scalars after the settings context had
        # closed. Record the actual settings for this new run within that context.
        with config_override(overrides):
            write_json(run_path / "E1_EFFECTIVE_CONFIG.json", e1.run_manifest(method, seed))
    elif study == "transfer":
        e3.OUT = base
        run_path = e3.run_one(method, seed)
        overrides = e3.override(method, seed, parent)
    else:
        run_path = e5.run_one(method, seed, target_root=base / "runs")
        overrides = e5.overrides(method, seed, parent)
    names = ("START_TIME", "END_TIME", "DATASET_MODE", "RANDOM_SEED", "SPATIAL_ANOMALY_RANDOM_SEED",
             "COMM_RANDOM_SEED", "ALERT_CONFIRMATION_REALERT_TOP_M", "ALERT_CONFIRMATION_REALERT_PROBE_STEPS",
             "ALERT_VERIFY_WAIT_STEPS", "ALERT_CONFIRMATION_REALERT_MAX_HOPS", "ALERT_CONFIRMATION_REALERT_RANKING_MODE")
    with config_override(overrides):
        values = {name: str(getattr(config, name)) for name in names}
    write_json(run_path / "settings.json", {"study":study, "method":method, "seed":seed, "settings":values})
    return run_path


def measure(study, method, seed, run_path, output):
    from src import e2_continuity_metric_reconstruction as metrics
    metrics.ROOT = output
    src = metrics.Source(study, method, "policy", "paired_within_window", run_path.parent, (seed,), 0)
    r, flags = metrics.reconstruct(src, seed, run_path)
    if any(x == 0 for x in flags.values()):
        raise ValueError(f"Node-slot reconstruction differs from simulator metrics: {flags}")
    energy = csv_rows(run_path / "task6_energy_proxy.csv")[0]
    with (run_path / "communication_energy_events.csv").open(encoding="utf-8", newline="") as f:
        events = Counter(x["step_type"] for x in csv.DictReader(f))
    row = {"study":study, "method":method, "seed":seed}
    for k, rk in {
        "coverage":"coverage","front_recall":"front_recall","detected_delay_slots":"front_delay_detected_mean_slots",
        "p95_detected_delay_slots":"front_delay_detected_p95_slots","restricted_delay_slots":"front_delay_restricted_mean_slots",
        "missed_fronts":"missed_front_count","awsr":"awsr_affected_event_membership","gsr":"gsr_physical_node_slots",
        "false_wakeup_node_slots":"false_wakeup_node_time","false_wakeup_episodes":"false_wakeup_episode_count",
        "over_wakeup_ratio":"over_wakeup_ratio","useful_sampled_alert_node_slots":"useful_sampled_alert_node_time",
        "alert_node_slots":"total_alert_node_time","useful_wakeup_precision":"useful_wakeup_precision"
    }.items():
        row[k] = r[rk]
    for k, ek in {"command_rx":"routed_command_rx_operations","sensing_energy_mj":"sensing_energy_mj",
                  "tx_energy_mj":"communication_tx_energy_mj","rx_energy_mj":"communication_rx_energy_mj",
                  "idle_energy_mj":"idle_listening_energy_mj","computation_energy_mj":"computation_energy_mj",
                  "total_energy_mj":"total_energy_mj"}.items():
        row[k] = float(energy[ek])
    row.update(alert_rx=events["event_alert_rx"], probe_rx=events["event_probe_rx"], relay_tx=events["event_relay_tx"])
    if not math.isclose(sum(row[k] for k in ("sensing_energy_mj","tx_energy_mj","rx_energy_mj","idle_energy_mj","computation_energy_mj")),row["total_energy_mj"],abs_tol=1e-6,rel_tol=1e-10):
        raise ValueError("Energy components do not sum to the modelled total")
    return row


def main():
    a = arguments()
    import numpy, pandas, scipy, matplotlib
    from src import config
    verify_sources(a.study)
    paths = inputs(a.data_dir)
    output = a.output_dir.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError(f"Use a new or empty output directory: {output}")
    refs = csv_rows(ROOT / "reference" / f"{a.study}_per_run.csv")
    reference = {(r["method"], int(r["seed"])): r for r in refs}
    lo, hi, methods = STUDIES[a.study]
    cases = [(m, s) for s in range(lo, hi+1) for m in methods] if a.all else [(a.method or methods[0], a.seed if a.seed is not None else (422 if a.study=="transfer" else lo))]
    output.mkdir(parents=True, exist_ok=True)
    for k, p in paths.items():
        setattr(config, k, str(p))
    config.DATA_DIR = str(a.data_dir.resolve())
    write_json(output / "experiment.json", {"study":a.study, "seed_method_runs":len(cases),
        "inputs":{k: {"filename":p.name,"sha256":digest(p)} for k,p in paths.items()},
        "versions":{"python":sys.version.split()[0], "numpy":numpy.__version__,"pandas":pandas.__version__,"scipy":scipy.__version__,"matplotlib":matplotlib.__version__}})
    rows, checks = [], []
    for i,(method,seed) in enumerate(cases,1):
        print(f"[{i}/{len(cases)}] {a.study}: {method}, seed {seed}",flush=True)
        with (output / "simulation.log").open("a", encoding="utf-8") as log, redirect_stdout(log):
            try:
                run_path = run(a.study,method,seed,output)
            finally:
                for handler in logging.getLogger().handlers[:]:
                    logging.getLogger().removeHandler(handler)
                    handler.close()
        row = measure(a.study,method,seed,run_path,output)
        rows.append(row)
        ref = reference[method, seed]
        for k,v in ref.items():
            if k in {"method","seed"} or v in ("","NA"): continue
            expected, actual = float(v), float(row[k])
            same = math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-8)
            checks.append(dict(method=method,seed=seed,metric=k,archived=expected,simulated=actual,match=same))
        output_csv(output/"runs.csv",rows)
        output_csv(output/"reference_checks.csv",checks)
        if not a.keep_traces:
            keep = {"task8_metrics_main.csv","task6_energy_proxy.csv","settings.json","spatial_anomaly_config.csv","sentinel_nodes.csv"}
            for p in run_path.iterdir():
                if p.name in keep or p.name.endswith("EFFECTIVE_CONFIG.json"):continue
                if p.is_dir(): shutil.rmtree(p)
                else:p.unlink()
    keys = [k for k in rows[0] if k not in {"study","method","seed"}]
    grouped=[]
    for m in dict.fromkeys(r["method"] for r in rows):
        vals=[r for r in rows if r["method"]==m]
        grouped.append({"method":m,"n_seeds":len(vals),**{k:statistics.fmean(r[k] for r in vals) for k in keys}})
    output_csv(output/"method_means.csv",grouped)
    if a.all:
        indexed={(r["method"],r["seed"]):r for r in rows}
        paired=[{"method":methods[0],"comparator":m,"seed":s,**{k:indexed[methods[0],s][k]-indexed[m,s][k] for k in keys}}
                for m in methods[1:] for s in range(lo,hi+1)]
        output_csv(output/"paired_differences.csv",paired)
    passed = sum(r["match"] for r in checks)
    print(f"{len(rows)} run(s); {passed}/{len(checks)} archived metric comparisons matched. Results: {output}")
    if passed != len(checks):return 2
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        raise SystemExit(str(exc)) from exc
