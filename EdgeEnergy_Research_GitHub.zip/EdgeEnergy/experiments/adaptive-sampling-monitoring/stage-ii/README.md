# Revisit decisions at a moving anomaly front

A negative observation is informative when a sensor makes it; the front may reach that same sensor a few minutes later. DF-ReAlert ranks previously checked sites for a limited number of revisits. The experiments compare which arrivals each policy observes and what it spends in routed command receptions and modelled energy. The temperature background is measured; the propagation and sensing policies are simulated.

## Run a single seed

From this directory, on 64-bit Linux with CPython 3.12:

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python -B scripts/run_study.py --study transfer --method DF-ReAlert --seed 422 --output-dir results/demo
```

The reference for this case is **0.5163934 arrival-slot front recall, 809 routed command receptions and 366.593522 J** of modelled energy. Run outputs use mJ. Use a new or empty output directory; add `--keep-traces` to retain node-level time histories. The [input data](data/README.md) are included.

## Compare policies

| Study | Background window (2004) | Paired design | Question |
| --- | --- | --- | --- |
| `primary` | 28 February, 01:03–05:03 | 4 rankings × seeds 401–420 | Which sites merit a revisit under the same admission budget? |
| `transfer` | 5 March, 08:00–12:00 | 4 rankings and fixed two-hop response × seeds 421–440 | Does the ordering hold on another day with fresh events and placements? |
| `backbone` | 28 February, 01:03–05:03 | DF-ReAlert and fixed two-hop response × seeds 441–460 | How does the comparison change under a common signed GLR detector and spatial-cover sentinel placement? |

In the primary window, DF-ReAlert gains 0.0272 in mean front recall over lowest-route-cost ranking for 0.45 additional routed receptions per seed. In the transfer window, fixed two-hop response captures more arrivals. Selective revisiting requires fewer routed command receptions but spends more energy on sustained sensing.

```sh
python -B scripts/run_study.py --study primary --all --output-dir results/primary
python -B scripts/run_study.py --study transfer --all --output-dir results/transfer
python -B scripts/run_study.py --study backbone --all --output-dir results/backbone
python -B scripts/verify_reference.py --output-dir results/tables --plot
```

The first three commands simulate new runs. The last reconstructs the chapter comparisons and Figure 6.8 from the [reference records](reference/README.md), including a separate comparison with the completed 100-run transfer-window reproduction.
