# Intel Lab Data used by Stage II

The simulated anomalies are superimposed on temperatures measured at the Intel Berkeley Research Lab. The data were collected by **Peter Bodik, Wei Hong, Carlos Guestrin, Sam Madden, Mark Paskin and Romain Thibaux**. The [Intel Lab Data project](https://db.lcs.mit.edu/labdata/labdata.html) permits use and reproduction and requests acknowledgement in published work. These data retain the collectors’ terms. For the licence applicable to each software component, see the [repository licence scope](../../../../legal/LICENSE_SCOPE.md).

| File | Contents |
| --- | --- |
| `data.txt.gz` | All measurement records on 28 February 2004 (85,830) and 5 March 2004 (89,770), in source order. Columns: date, time, epoch, mote ID, temperature (°C), relative humidity, light and supply voltage. |
| `mote_locs.txt` | Sensor IDs and two-dimensional coordinates. |
| `connectivity.txt` | Directed sensor pairs and their connectivity weights. |
| `input_manifest.json` | Input SHA-256 digests, ordered node IDs and aligned-temperature digests for both windows. |

The simulator retains positioned nodes with readings in the four-hour window and aligns temperatures on a 31-second grid. The first window has 54 nodes, the second 52; each has 465 timestamps. The full source archive and this extract give identical node IDs, timestamps and temperatures at all 49,290 node–time positions.

To recreate the extract and check that agreement, download the full measurements from the project page and run the following from the Stage II directory. The script accepts either the original gzip file or its uncompressed text.

```sh
python scripts/prepare_inputs.py /path/to/full/data.txt.gz --output rebuilt/data.txt.gz --check-alignment
```
