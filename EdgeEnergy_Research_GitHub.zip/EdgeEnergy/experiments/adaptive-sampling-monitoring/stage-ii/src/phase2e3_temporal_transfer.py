"""E3 frozen temporal-window runner (421--440 only)."""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
import src.config as config
from src.run_conclusion_experiments import config_override
from src.run_multinode_baseline import run_multinode_baseline_experiment
from src.run_ream_experiments import PROPAGATION_VARIANTS

ROOT=Path(config.PROJECT_ROOT); OUT=ROOT/'phase2_paper_evidence/e3_second_temporal_window'; E1=ROOT/'phase2_paper_evidence/e1_budget_matched_baselines/manifests/E1_IMPLEMENTATION_FREEZE_MANIFEST.json'; SEEDS=set(range(421,441))
METHODS={'DF-ReAlert':('CR-delayedFront-locked-topK5','full'),'Random-TopK':('CR-delayedFront-locked-topK5','random'),'Nearest-front-TopK':('CR-delayedFront-locked-topK5','nearest_confirmed'),'Lowest-route-cost-TopK':('CR-delayedFront-locked-topK5','route_cost_only'),'Fixed-two-hop-verify3':('fixed_2_hop_verify3',None)}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def override(method,seed,out,trace=True):
 base=PROPAGATION_VARIANTS[METHODS[method][0]]; mode=METHODS[method][1]; d={**base,'START_TIME':pd.Timestamp('2004-03-05 08:00:00'),'END_TIME':pd.Timestamp('2004-03-05 12:00:00'),'OUTPUT_DIR':str(out),'DATASET_MODE':'intel','RANDOM_SEED':int(seed),'SPATIAL_ANOMALY_RANDOM_SEED':int(seed),'COMM_RANDOM_SEED':42,'STRUCTURAL_TRACE_ENABLED':bool(trace),'ENABLE_PLOTS':False,'SAVE_NODE_HISTORIES':False,'ENABLE_DETAILED_LOGS':True}
 if mode is not None: d.update({'ALERT_FRONTIER_ANCHORED_RETAINED_SCOPE_ENABLED':True,'ALERT_FRONT_TRIGGERED_RECONSIDERATION_ENABLED':True,'ALERT_FRONT_TRIGGERED_RECONSIDERATION_MIN_REFRACTORY_STEPS':2,'ALERT_CONFIRMED_TRACKING_HANDOFF_RELEASE_ENABLED':False,'ALERT_EVENT_EXPIRY_CONFIRMED_HANDOFF_ENABLED':False,'ALERT_FRONTIER_PRESERVING_CONFIRMED_HANDOFF_ENABLED':True,'ALERT_CONFIRMED_TRACKING_MIN_STEPS':3,'ALERT_CONFIRMED_TRACKING_MAX_STEPS':0,'ALERT_BUDGETED_FRONTIER_TRACKING_ENABLED':True,'ALERT_BUDGETED_FRONTIER_UNIQUE_COVERAGE_ENABLED':False,'ALERT_CONFIRMATION_REALERT_RANKING_MODE':mode})
 return d
def run_one(method,seed,trace=True):
 if seed not in SEEDS: raise ValueError('E3 accepts only seeds 421-440')
 out=OUT/'runs'/method/f'seed_{seed}'; out.mkdir(parents=True,exist_ok=True); before=set(p for p in out.iterdir() if p.is_dir())
 with config_override(override(method,seed,out,trace)): np.random.seed(seed); run_multinode_baseline_experiment()
 made=[p for p in out.iterdir() if p.is_dir() and p not in before]
 if len(made)!=1: raise RuntimeError(f'expected one run, got {made}')
 (made[0]/'E3_EFFECTIVE_CONFIG.json').write_text(json.dumps({'phase':'E3 temporal transfer','method':method,'seed':seed,'second_window':'2004-03-05 08:00:00–12:00:00','e1_freeze_manifest_sha256':sha(E1)},indent=2),encoding='utf-8'); return made[0]
if __name__=='__main__': print('E3 runner frozen; invoke run_one explicitly for authorized 421-440 seeds.')
