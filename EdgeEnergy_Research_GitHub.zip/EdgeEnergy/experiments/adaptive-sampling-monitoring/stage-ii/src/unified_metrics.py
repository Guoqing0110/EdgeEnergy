import numpy as np

import src.config as config


def calc_rmse(estimated, truth):
    estimated = np.asarray(estimated, dtype=float)
    truth = np.asarray(truth, dtype=float)
    mask = ~np.isnan(estimated) & ~np.isnan(truth)
    if not np.any(mask):
        return np.nan
    return float(np.sqrt(np.mean((estimated[mask] - truth[mask]) ** 2)))


def calc_masked_rmse(estimated, truth, mask):
    estimated = np.asarray(estimated, dtype=float)
    truth = np.asarray(truth, dtype=float)
    mask = np.asarray(mask, dtype=bool)
    valid_mask = mask & ~np.isnan(estimated) & ~np.isnan(truth)
    if not np.any(valid_mask):
        return np.nan
    return float(np.sqrt(np.mean((estimated[valid_mask] - truth[valid_mask]) ** 2)))


def compute_reconstruction_rmse_metrics(estimated, truth, anomaly_mask=None):
    estimated_arr = np.asarray(estimated, dtype=float)
    truth_arr = np.asarray(truth, dtype=float)
    global_valid = np.isfinite(estimated_arr) & np.isfinite(truth_arr)
    metrics = {
        "rmse_global": calc_rmse(estimated_arr, truth_arr),
        "rmse_global_valid_node_time": int(global_valid.sum()),
        "rmse_global_total_node_time": int(truth_arr.size),
        "rmse_anomaly_window": np.nan,
        "rmse_anomaly_valid_node_time": 0,
        "rmse_anomaly_total_node_time": 0,
    }
    if anomaly_mask is not None:
        anomaly = np.asarray(anomaly_mask, dtype=bool)
        metrics["rmse_anomaly_window"] = calc_masked_rmse(estimated_arr, truth_arr, anomaly)
        metrics["rmse_anomaly_valid_node_time"] = int((global_valid & anomaly).sum())
        metrics["rmse_anomaly_total_node_time"] = int(anomaly.sum())
    return metrics


def compute_energy_proxy_metrics(sample_count, tx_peer_count=0, rx_peer_count=0, idle_steps=0, computation_count=0,
                                 tx_bytes=None, rx_bytes=None):
    sample_count = int(sample_count)
    tx_peer_count = int(tx_peer_count)
    rx_peer_count = int(rx_peer_count)
    sensing_energy_per_sample_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.SENSING_ACTIVE_CURRENT_MA) / 1000.0 * float(config.SENSING_DURATION_SEC) * 1000.0
    tx_bytes = int(tx_bytes if tx_bytes is not None else tx_peer_count * int(getattr(config, "CONTROL_PACKET_BYTES", 36)))
    rx_bytes = int(rx_bytes if rx_bytes is not None else rx_peer_count * int(getattr(config, "CONTROL_PACKET_BYTES", 36)))
    bitrate = max(1.0, float(getattr(config, "RADIO_BITRATE_BPS", 19200)))
    startup_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(getattr(config, "RADIO_STARTUP_CURRENT_MA", 8.0)) * float(getattr(config, "RADIO_STARTUP_DURATION_SEC", 0.002))
    tx_airtime = 8.0 * tx_bytes / bitrate
    rx_airtime = 8.0 * rx_bytes / bitrate
    amp_mj = float(getattr(config, "RADIO_TX_AMP_NJ_PER_BIT_M2", 0.0)) * 1e-6 * 8.0 * tx_bytes * float(getattr(config, "RADIO_REFERENCE_LINK_DISTANCE", 6.0)) ** 2
    tx_energy_per_peer_mj = (float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) * tx_airtime + startup_mj * tx_peer_count + amp_mj) / max(1, tx_peer_count)
    rx_energy_per_peer_mj = (float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) * rx_airtime + startup_mj * rx_peer_count) / max(1, rx_peer_count)
    sensing_energy_mj = float(sample_count) * sensing_energy_per_sample_mj
    tx_energy_mj = float(tx_peer_count) * tx_energy_per_peer_mj
    rx_energy_mj = float(rx_peer_count) * rx_energy_per_peer_mj
    idle_energy_mj = float(idle_steps) * float(config.NODE_SUPPLY_VOLTAGE_V) * float(getattr(config, "IDLE_LISTEN_CURRENT_MA", 0.0)) * float(config.DT_SEC)
    computation_energy_mj = float(computation_count) * float(getattr(config, "COMPUTATION_ENERGY_MJ", 0.0))
    communication_energy_mj = tx_energy_mj + rx_energy_mj
    total_energy_mj = sensing_energy_mj + communication_energy_mj + idle_energy_mj + computation_energy_mj
    return {
        "sensing_energy_per_sample_mj": sensing_energy_per_sample_mj,
        "communication_tx_energy_per_peer_mj": tx_energy_per_peer_mj,
        "communication_rx_energy_per_peer_mj": rx_energy_per_peer_mj,
        "sensing_energy_mj": sensing_energy_mj,
        "communication_tx_energy_mj": tx_energy_mj,
        "communication_rx_energy_mj": rx_energy_mj,
        "communication_energy_mj": communication_energy_mj,
        "radio_startup_energy_mj": startup_mj * (tx_peer_count + rx_peer_count),
        "radio_distance_amplifier_energy_mj": amp_mj,
        "tx_bytes": tx_bytes,
        "rx_bytes": rx_bytes,
        "idle_listening_energy_mj": idle_energy_mj,
        "computation_energy_mj": computation_energy_mj,
        "total_energy_mj": total_energy_mj,
        "sensing_energy_proxy": sensing_energy_mj,
        "alert_energy_proxy": rx_energy_mj,
        "trigger_energy_proxy": tx_energy_mj,
        "total_energy_proxy": total_energy_mj,
    }
