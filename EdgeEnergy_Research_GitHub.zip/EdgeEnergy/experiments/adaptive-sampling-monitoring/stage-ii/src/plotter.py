import numpy as np
import matplotlib.pyplot as plt


def plot_network_adjacency(node_positions, adjacency, output_path, title='Network Adjacency'):
    node_ids = sorted(node_positions.keys())
    fig, ax = plt.subplots(figsize=(10, 8))
    for src in node_ids:
        src_pos = node_positions[src]
        for dst in adjacency.get(src, []):
            if src < dst and dst in node_positions:
                dst_pos = node_positions[dst]
                ax.plot([src_pos['x'], dst_pos['x']], [src_pos['y'], dst_pos['y']], color='lightgray', linewidth=0.8, alpha=0.8)
    xs = [node_positions[node_id]['x'] for node_id in node_ids]
    ys = [node_positions[node_id]['y'] for node_id in node_ids]
    ax.scatter(xs, ys, c='tab:blue', s=30)
    for node_id in node_ids:
        pos = node_positions[node_id]
        ax.text(pos['x'] + 0.15, pos['y'] + 0.15, str(node_id), fontsize=7)
    ax.set_title(title)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_aspect('equal', adjustable='box')
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_node_roles(node_positions, sentinel_ids, output_path, title='Sentinel Placement'):
    sentinel_set = set(sentinel_ids)
    node_ids = sorted(node_positions.keys())
    fig, ax = plt.subplots(figsize=(10, 8))
    normal_x = [node_positions[node_id]['x'] for node_id in node_ids if node_id not in sentinel_set]
    normal_y = [node_positions[node_id]['y'] for node_id in node_ids if node_id not in sentinel_set]
    sentinel_x = [node_positions[node_id]['x'] for node_id in node_ids if node_id in sentinel_set]
    sentinel_y = [node_positions[node_id]['y'] for node_id in node_ids if node_id in sentinel_set]
    ax.scatter(normal_x, normal_y, c='tab:blue', s=28, label='Normal')
    ax.scatter(sentinel_x, sentinel_y, c='tab:red', s=58, marker='^', label='Sentinel')
    for node_id in node_ids:
        pos = node_positions[node_id]
        ax.text(pos['x'] + 0.15, pos['y'] + 0.15, str(node_id), fontsize=7)
    ax.set_title(title)
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_aspect('equal', adjustable='box')
    ax.grid(alpha=0.25)
    ax.legend(loc='best')
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_degree_distribution(spatial_degrees, comm_degrees, output_path):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    axes[0].hist(spatial_degrees, bins=12, color='tab:blue', alpha=0.8)
    axes[0].set_title('Spatial Degree Distribution')
    axes[0].set_xlabel('Degree')
    axes[0].set_ylabel('Node Count')
    axes[0].grid(alpha=0.2)
    axes[1].hist(comm_degrees, bins=12, color='tab:orange', alpha=0.8)
    axes[1].set_title('Communication Out-Degree Distribution')
    axes[1].set_xlabel('Out-Degree')
    axes[1].set_ylabel('Node Count')
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_metrics_distribution(metrics_df, output_path):
    sampling = metrics_df['sampling_rate'].values
    rmse = metrics_df['rmse'].values
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    axes[0].hist(sampling, bins=12, color='tab:green', alpha=0.85)
    axes[0].set_title('Sampling Rate Distribution')
    axes[0].set_xlabel('Sampling Rate')
    axes[0].set_ylabel('Node Count')
    axes[0].grid(alpha=0.2)
    axes[1].hist(rmse, bins=12, color='tab:purple', alpha=0.85)
    axes[1].set_title('RMSE Distribution')
    axes[1].set_xlabel('RMSE')
    axes[1].set_ylabel('Node Count')
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_connectivity_heatmap(communication_weights, node_ids, output_path):
    n = len(node_ids)
    mat = np.zeros((n, n), dtype=float)
    id_to_idx = {node_id: idx for idx, node_id in enumerate(node_ids)}
    for src, dst_map in communication_weights.items():
        if src not in id_to_idx:
            continue
        i = id_to_idx[src]
        for dst, w in dst_map.items():
            if dst not in id_to_idx:
                continue
            j = id_to_idx[dst]
            mat[i, j] = w
    fig, ax = plt.subplots(figsize=(8.5, 7.2))
    im = ax.imshow(mat, cmap='viridis', aspect='auto')
    ax.set_title('Connectivity Weight Heatmap')
    ticks = np.arange(n)
    ax.set_xticks(ticks[::3])
    ax.set_yticks(ticks[::3])
    ax.set_xticklabels([str(node_ids[i]) for i in ticks[::3]], rotation=90)
    ax.set_yticklabels([str(node_ids[i]) for i in ticks[::3]])
    ax.set_xlabel('Dst Node ID')
    ax.set_ylabel('Src Node ID')
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label('Connectivity Weight')
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_sentinel_vs_normal_boxplot(metrics_df, sentinel_ids, output_path):
    sentinel_set = set(sentinel_ids)
    sentinel_rows = metrics_df[metrics_df['node_id'].isin(sentinel_set)]
    normal_rows = metrics_df[~metrics_df['node_id'].isin(sentinel_set)]
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8))
    axes[0].boxplot([normal_rows['sampling_rate'].values, sentinel_rows['sampling_rate'].values], labels=['Normal', 'Sentinel'])
    axes[0].set_title('Sampling Rate by Role')
    axes[0].set_ylabel('Sampling Rate')
    axes[0].grid(alpha=0.2)
    axes[1].boxplot([normal_rows['rmse'].values, sentinel_rows['rmse'].values], labels=['Normal', 'Sentinel'])
    axes[1].set_title('RMSE by Role')
    axes[1].set_ylabel('RMSE')
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_sentinel_detection_bar(sentinel_ids, detect_counts, output_path):
    ordered_ids = sorted(sentinel_ids)
    values = [detect_counts.get(node_id, 0) for node_id in ordered_ids]
    fig, ax = plt.subplots(figsize=(10, 4.6))
    ax.bar([str(x) for x in ordered_ids], values, color='tab:red', alpha=0.85)
    ax.set_title('Sentinel Detection Count')
    ax.set_xlabel('Sentinel Node ID')
    ax.set_ylabel('Detected Anomaly Steps')
    ax.grid(axis='y', alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_alert_detection_timeline(times, gt_count_per_step, sentinel_detect_count_per_step, alert_count_per_step, output_path):
    fig, axes = plt.subplots(2, 1, figsize=(13, 7.2), sharex=True)
    axes[0].plot(times, gt_count_per_step, color='tab:purple', label='GT Anomaly Node Count')
    axes[0].plot(times, sentinel_detect_count_per_step, color='tab:red', label='Sentinel Detection Count')
    axes[0].set_ylabel('Node Count')
    axes[0].set_title('Anomaly vs Sentinel Detection Timeline')
    axes[0].legend(loc='upper right')
    axes[0].grid(alpha=0.2)
    axes[1].plot(times, alert_count_per_step, color='tab:orange')
    axes[1].set_ylabel('Alert Nodes')
    axes[1].set_title('Alert Mode Node Count Timeline')
    axes[1].set_xlabel('Time')
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_node_kf_anomaly_diagnostic(times, ground_truth, estimated, measured, sampled_flags, gt_anomaly_flags, alert_mode_flags, nis, uncertainty_pred, gamma, output_path, title):
    fig, axes = plt.subplots(3, 1, figsize=(13, 10), sharex=True)
    axes[0].plot(times, ground_truth, color='tab:green', linewidth=1.6, label='Ground Truth')
    axes[0].plot(times, estimated, color='tab:blue', linestyle='--', linewidth=1.3, label='KF Estimate')
    measured_arr = np.asarray(measured, dtype=float)
    sampled_mask = np.asarray(sampled_flags, dtype=int) == 1
    if sampled_mask.any():
        axes[0].scatter(np.array(times)[sampled_mask], measured_arr[sampled_mask], c='tab:red', s=20, marker='x', label='Sampled Measurements')
    gt_mask = np.asarray(gt_anomaly_flags, dtype=int) == 1
    if gt_mask.any():
        axes[0].fill_between(times, np.nanmin(ground_truth) - 1, np.nanmax(ground_truth) + 1, where=gt_mask, color='tab:orange', alpha=0.16, step='pre', label='GT Anomaly Active')
    axes[0].set_ylabel('Temperature (C)')
    axes[0].set_title(title)
    axes[0].grid(alpha=0.2)
    axes[0].legend(loc='upper left')
    sampled_arr = np.asarray(sampled_flags, dtype=float)
    window = min(21, len(sampled_arr))
    if window % 2 == 0:
        window -= 1
    if window < 3:
        rolling_rate = sampled_arr.copy()
    else:
        kernel = np.ones(window, dtype=float) / window
        rolling_rate = np.convolve(sampled_arr, kernel, mode='same')
    axes[1].plot(times, rolling_rate, color='tab:blue', linewidth=1.8, label=f'Rolling Sampling Rate ({window} steps)')
    axes[1].plot(times, alert_mode_flags, color='tab:orange', linewidth=1.2, label='Alert Mode (0/1)')
    axes[1].fill_between(times, 0, 1.05, where=np.asarray(alert_mode_flags, dtype=float) > 0.5, color='tab:orange', alpha=0.10, step='pre', label='Alert Active Window')
    axes[1].set_ylabel('Rate / Status')
    axes[1].set_ylim(-0.05, 1.15)
    axes[1].set_title('Sampling Frequency (Curve) and Alert Mode')
    axes[1].grid(alpha=0.2)
    axes[1].legend(loc='upper left')
    axes[2].plot(times, nis, color='goldenrod', marker='o', markersize=3, linewidth=1.0, label='NIS')
    axes[2].plot(times, uncertainty_pred, color='black', linewidth=1.2, label='Predicted Obs Var')
    axes[2].axhline(gamma, color='tab:red', linestyle='--', linewidth=1.0, label='Gamma')
    axes[2].set_ylabel('NIS / Uncertainty')
    axes[2].set_xlabel('Time')
    axes[2].set_title('NIS and Observation Uncertainty')
    axes[2].grid(alpha=0.2)
    axes[2].legend(loc='upper right')
    if len(times) > 0:
        axes[0].set_xlim(times[0], times[-1])
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_event_onset_detection_timeline(event_df, output_path):
    if len(event_df) == 0:
        fig, ax = plt.subplots(figsize=(10, 2.8))
        ax.set_title('Event Onset Detection Timeline (No Events)')
        ax.set_xlabel('Event Order')
        ax.set_ylabel('Step')
        ax.grid(alpha=0.2)
        fig.tight_layout()
        fig.savefig(output_path, dpi=200)
        plt.close(fig)
        return
    ordered = event_df.sort_values('event_start_step').reset_index(drop=True)
    x = np.arange(len(ordered))
    starts = ordered['event_start_step'].values
    dets = ordered['detected_step'].values
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.scatter(x, starts, c='tab:purple', label='Event Start Step')
    detected_mask = ~np.isnan(dets)
    if detected_mask.any():
        ax.scatter(x[detected_mask], dets[detected_mask], c='tab:green', marker='x', s=45, label='Detected Step')
        for i in x[detected_mask]:
            ax.plot([i, i], [starts[i], dets[i]], color='tab:gray', alpha=0.5)
    miss_mask = np.isnan(dets)
    if miss_mask.any():
        ax.scatter(x[miss_mask], starts[miss_mask], c='tab:red', marker='s', s=36, label='Missed Event')
    ax.set_title('Event Onset and Detection Step')
    ax.set_xlabel('Event Index')
    ax.set_ylabel('Step')
    ax.grid(alpha=0.2)
    ax.legend(loc='best')
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_deadline_hit_rates(deadline_df, output_path):
    labels = [str(x) for x in deadline_df['deadline_steps'].values]
    rates = deadline_df['hit_rate'].values
    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    ax.bar(labels, rates, color='tab:blue', alpha=0.85)
    ax.set_ylim(0, 1.05)
    ax.set_title('Deadline-hit Rate by Detection Deadline')
    ax.set_xlabel('Deadline (steps)')
    ax.set_ylabel('Hit Rate')
    ax.grid(axis='y', alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_task8_metric_bars(alert_metrics, output_path):
    names = ['Alert Precision', 'Alert Coverage@L', 'Wake-up Effectiveness', 'Recovery Gain']
    values = [
        alert_metrics.get('alert_precision', 0.0),
        alert_metrics.get('alert_coverage_l', 0.0),
        alert_metrics.get('wakeup_effectiveness', 0.0),
        alert_metrics.get('recovery_gain_proxy', 0.0)
    ]
    fig, ax = plt.subplots(figsize=(9.8, 4.6))
    ax.bar(names, values, color=['tab:orange', 'tab:green', 'tab:cyan', 'tab:red'], alpha=0.85)
    ax.set_title('Task8 Alert Usefulness Metrics')
    ax.set_ylabel('Value')
    ax.grid(axis='y', alpha=0.2)
    ax.set_ylim(min(-1.0, min(values) - 0.1), max(1.05, max(values) + 0.1))
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_cost_benefit_point(cost_metrics, output_path):
    energy = cost_metrics.get('total_energy_proxy', np.nan)
    odd = cost_metrics.get('odd_mean_steps', np.nan)
    coverage = cost_metrics.get('alert_coverage_l', np.nan)
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
    axes[0].scatter([energy], [odd], c='tab:red', s=70)
    axes[0].set_title('Delay-Energy Point')
    axes[0].set_xlabel('Energy Proxy')
    axes[0].set_ylabel('ODD Mean (steps)')
    axes[0].grid(alpha=0.2)
    axes[1].scatter([energy], [coverage], c='tab:blue', s=70)
    axes[1].set_title('Coverage-Energy Point')
    axes[1].set_xlabel('Energy Proxy')
    axes[1].set_ylabel('Alert Coverage@L')
    axes[1].set_ylim(0, 1.05)
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
