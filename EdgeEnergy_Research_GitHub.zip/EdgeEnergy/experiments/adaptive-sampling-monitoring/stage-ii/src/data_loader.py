import pandas as pd
import numpy as np
import os

def load_raw_data(filepath):
    """
    Loads the raw Intel Lab Data from the given filepath.
    Schema: date time epoch moteid temperature humidity light voltage
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")
    
    # Read the data, assuming space separation
    # The file has no header, so we provide names
    column_names = ['date', 'time', 'epoch', 'moteid', 'temperature', 'humidity', 'light', 'voltage']
    
    try:
        df = pd.read_csv(filepath, sep=r'\s+', names=column_names, on_bad_lines='skip')
        print(f"Loaded {len(df)} rows from {filepath}")
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def preprocess_data(df):
    """
    Preprocesses the raw dataframe:
    1. Combine date and time into a datetime index.
    2. Sort by time.
    3. Drop duplicates if any.
    """
    if df is None or df.empty:
        return None
    
    # Combine date and time
    # Note: Some time entries might be malformed, so we coerce errors
    df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], errors='coerce')
    
    # Drop rows where datetime parsing failed
    df = df.dropna(subset=['datetime'])
    
    # Set index
    df = df.set_index('datetime').sort_index()
    
    return df

def get_sensor_data(df, moteid, start_time=None, end_time=None):
    """
    Extracts data for a specific sensor within a time window.
    """
    sensor_df = df[df['moteid'] == moteid].copy()
    
    if start_time:
        sensor_df = sensor_df[sensor_df.index >= start_time]
    if end_time:
        sensor_df = sensor_df[sensor_df.index <= end_time]
        
    return sensor_df

def resample_and_interpolate(sensor_df, freq='30s'):
    """
    Resamples the sensor data to a fixed frequency and fills missing values using linear interpolation.
    """
    if sensor_df.empty:
        return sensor_df
        
    # Resample to fixed grid
    # We take the mean if multiple readings fall in the same bin
    # Ensure we cover the full range if start/end provided, but here we just resample the index
    resampled = sensor_df.resample(freq).mean()
    
    # Interpolate missing values
    # Limit interpolation to avoid filling huge gaps which might be real outages
    interpolated = resampled.interpolate(method='linear', limit=10)
    
    return interpolated

if __name__ == "__main__":
    # Test the loader
    data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'data.txt')
    print(f"Testing loader with path: {data_path}")
    
    df = load_raw_data(data_path)
    if df is not None:
        df = preprocess_data(df)
        print("Data preprocessed.")
        print(df.head())
        
        # Test getting data for moteid 1
        sensor_1 = get_sensor_data(df, 1)
        print(f"Sensor 1 data points: {len(sensor_1)}")
        
        # Test resampling
        sensor_1_resampled = resample_and_interpolate(sensor_1[['temperature']])
        print("Resampled Sensor 1 data:")
        print(sensor_1_resampled.head())
