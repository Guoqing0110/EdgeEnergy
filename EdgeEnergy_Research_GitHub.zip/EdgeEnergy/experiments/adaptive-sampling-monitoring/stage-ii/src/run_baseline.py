import sys
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging
from datetime import datetime
from src.data_loader import load_raw_data, preprocess_data, get_sensor_data, resample_and_interpolate
from src.models import Node, SimulationEnvironment
import src.config as config

def setup_experiment_output():
    """
    Sets up the output directory and logging configuration.
    Returns: output_dir (str)
    """
    # Create timestamped directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # Use absolute path to be safe
    output_base = config.OUTPUT_DIR
    output_dir = os.path.join(output_base, timestamp)
    
    if not os.path.exists(output_dir):
        try:
            os.makedirs(output_dir)
        except Exception as e:
            print(f"Failed to create directory: {e}")
            return None
        
    # Configure Logging
    log_file = os.path.join(output_dir, 'experiment.log')
    
    # Reset any existing handlers
    root = logging.getLogger()
    if root.handlers:
        for handler in root.handlers:
            root.removeHandler(handler)
            
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    logging.info(f"Experiment Output Directory: {output_dir}")
    return output_dir

def run_baseline_experiment():
    # 0. Setup Output
    output_dir = setup_experiment_output()
    if output_dir is None:
        print("Failed to setup output directory. Exiting.")
        return

    # 1. Load and Preprocess Data
    data_path = config.DATA_FILE
    logging.info(f"Loading data from {data_path}...")
    raw_df = load_raw_data(data_path)
    if raw_df is None:
        logging.error("Failed to load data.")
        return

    logging.info("Preprocessing data...")
    df = preprocess_data(raw_df)
    
    # Select Node and a specific time window
    mote_id = config.TARGET_MOTE_ID
    start_time = config.START_TIME
    end_time = config.END_TIME
    
    logging.info(f"Extracting data for Node {mote_id} from {start_time} to {end_time}...")
    sensor_df = get_sensor_data(df, mote_id, start_time, end_time)
    
    # Resample to dt_sec to have a regular grid for simulation
    dt_sec = config.DT_SEC
    sensor_df = resample_and_interpolate(sensor_df[['temperature']], freq=f'{dt_sec}s')
    
    if sensor_df.empty:
        logging.warning("No data found for the specified range.")
        return

    logging.info(f"Data points: {len(sensor_df)}")
    logging.info(f"First 5 indices: {sensor_df.index[:5]}")
    logging.info(f"Start Time: {start_time}")
    logging.info(f"Checking if start_time in index: {start_time in sensor_df.index}")

    # 2. Setup Simulation Parameters
    # State: [temp, temp_rate]
    F = np.array([[1, dt_sec], [0, 1]])
    H = np.array([[1, 0]])
    
    # Process noise covariance Q
    # Q = [[Q_POS, 0], [0, Q_VEL]]
    Q = np.array([[config.Q_POS, 0], [0, config.Q_VEL]]) 

    # Measurement noise covariance R
    R = np.array([[config.R_VAR]])

    # Initial State
    initial_temp = sensor_df.iloc[0]['temperature']
    x0 = np.array([[initial_temp], [0.0]])
    P0 = np.eye(2) * config.P0_SCALE
    
    # Threshold Gamma
    gamma = config.GAMMA 

    logging.info("Simulation Parameters:")
    logging.info(f"  dt_sec: {dt_sec}")
    logging.info(f"  Q: {Q.tolist()}")
    logging.info(f"  R: {R.tolist()}")
    logging.info(f"  Gamma: {gamma}")

    # 3. Initialize Node and Environment
    node = Node(node_id=mote_id, 
                initial_state=x0, 
                P0=P0, 
                F=F, 
                H=H, 
                Q=Q, 
                R=R, 
                threshold_gamma=gamma)
    
    nodes = {mote_id: node}
    
    env = SimulationEnvironment(nodes, None, start_time, time_step_sec=dt_sec)
    # Manually load data into env
    env.load_node_data(mote_id, sensor_df)
    
    # --- Inject Anomalies for Testing ---
    # 1. Pulse Anomaly (Short spike)
    # 30 mins after start (60 steps)
    t1 = start_time + pd.Timedelta(minutes=30)
    env.anomaly_injector.add_anomaly('pulse', t1, duration_steps=5, magnitude=5.0, node_id=mote_id)
    logging.info(f"Injected Pulse Anomaly at {t1} (Mag=5.0)")
    
    # 2. Step Anomaly (Sustained change)
    # 2 hours after start (240 steps)
    t2 = start_time + pd.Timedelta(hours=2)
    env.anomaly_injector.add_anomaly('step', t2, duration_steps=40, magnitude=-3.0, node_id=mote_id)
    logging.info(f"Injected Step Anomaly at {t2} (Mag=-3.0)")

    # 3. Ramp Anomaly (Gradual Drift)
    # 3 hours after start (360 steps)
    t3 = start_time + pd.Timedelta(hours=3)
    env.anomaly_injector.add_anomaly('ramp', t3, duration_steps=60, magnitude=4.0, node_id=mote_id)
    logging.info(f"Injected Ramp Anomaly at {t3} (Mag=4.0 over 60 steps)")
    
    # 4. Run Simulation
    steps = len(sensor_df)
    logging.info(f"Running simulation for {steps} steps...")
    
    for i in range(steps):
        env.step()
        # Log every step (optional, can be verbose)
        # logging.debug(f"Step {i}: Trace(P)={node.history['uncertainty'][-1]:.4f}, Sampled={node.history['sampled'][-1]}")
        
    # 5. Plot Results
    logging.info("Simulation finished. Plotting results...")
    
    history = node.history
    
    # Create time array
    times = pd.date_range(start=start_time, periods=len(history['estimated']), freq=f'{dt_sec}s')
    
    plt.figure(figsize=(12, 10))
    
    # Subplot 1: Temperature (True vs Estimated vs Measured)
    plt.subplot(3, 1, 1)
    plt.plot(times, sensor_df['temperature'], 'g-', label='Ground Truth', alpha=0.5)
    plt.plot(times, history['estimated'], 'b--', label='KF Estimate')
    
    # Plot measurements (dots) only where sampled
    sampled_indices = [i for i, x in enumerate(history['sampled']) if x == 1]
    if sampled_indices:
        sampled_times = times[sampled_indices]
        sampled_vals = [history['measured'][i] for i in sampled_indices]
        plt.scatter(sampled_times, sampled_vals, c='r', marker='x', label='Sampled Measurements')
    
    plt.title(f'Node {mote_id} Temperature Monitoring (Gamma={gamma})')
    plt.ylabel('Temperature (C)')
    plt.legend()
    
    # Subplot 2: Sampling Events & NIS
    plt.subplot(3, 1, 2)
    # Double axis for Sampling Status and NIS
    ax1 = plt.gca()
    ax1.step(times, history['sampled'], where='post', label='Sampling Status', color='b', alpha=0.5)
    ax1.set_ylabel('Sampling Status', color='b')
    ax1.set_ylim(-0.1, 1.1)
    
    # Highlight Alert Mode
    alert_indices = [i for i, m in enumerate(history['mode']) if m == 'alert']
    if alert_indices:
        # Create a boolean mask for alert mode
        alert_mask = np.array([m == 'alert' for m in history['mode']])
        ax1.fill_between(times, 0, 1, where=alert_mask, color='red', alpha=0.2, transform=ax1.get_xaxis_transform(), label='Alert Mode')

    ax2 = ax1.twinx()
    # Plot NIS where available
    valid_nis = [(t, n) for t, n in zip(times, history['nis']) if not np.isnan(n)]
    if valid_nis:
        t_nis, n_nis = zip(*valid_nis)
        ax2.scatter(t_nis, n_nis, color='orange', s=10, label='NIS')
        ax2.set_ylabel('NIS', color='orange')
    
    plt.title('Sampling Trigger & NIS')
    
    # Subplot 3: Covariance Trace (Predicted vs Posterior)
    plt.subplot(3, 1, 3)
    # Plot Predicted Uncertainty (Prior) - Decision Basis
    plt.plot(times, history['uncertainty_pred'], 'k-', label='Predicted Obs Var (Prior)')
    # Plot Posterior Uncertainty - Resulting Confidence
    # Sampled points have lower posterior uncertainty
    plt.plot(times, history['uncertainty_post'], 'g--', alpha=0.5, label='Posterior Obs Var')
    
    plt.axhline(y=gamma, color='r', linestyle='--', label='Threshold Gamma')
    plt.title('Uncertainty Evolution')
    plt.ylabel('H*P*H^T')
    plt.legend()
    
    plt.tight_layout()
    plot_path = os.path.join(output_dir, 'baseline_result.png')
    plt.savefig(plot_path)
    logging.info(f"Plot saved to {plot_path}")

    # Calculate metrics
    sampling_rate = sum(history['sampled']) / len(history['sampled'])
    logging.info(f"Sampling Rate: {sampling_rate:.2%}")
    
    # Calculate RMSE
    estimated = np.array(history['estimated'])
    truth = sensor_df['temperature'].values
    # Truncate to min length if needed (should be same)
    min_len = min(len(estimated), len(truth))
    
    # Calculate RMSE ignoring NaNs
    valid_mask = ~np.isnan(estimated[:min_len]) & ~np.isnan(truth[:min_len])
    if np.any(valid_mask):
        rmse = np.sqrt(np.mean((estimated[:min_len][valid_mask] - truth[:min_len][valid_mask])**2))
        logging.info(f"RMSE: {rmse:.4f} °C")
    else:
        logging.warning("Cannot calculate RMSE: No valid matching data points.")

    # Save detailed history to CSV
    # Ensure all arrays have the same length
    min_len = len(history['estimated'])
    
    history_df = pd.DataFrame({
        'time': times[:min_len],
        'ground_truth': sensor_df['temperature'].values[:min_len],
        'estimated': history['estimated'][:min_len],
        'measured': history['measured'][:min_len],
        'uncertainty_pred': history['uncertainty_pred'][:min_len],
        'uncertainty_post': history['uncertainty_post'][:min_len],
        'sampled': history['sampled'][:min_len],
        'predicted': history['predicted'][:min_len],
        'innovation': history['innovation'][:min_len],
        'nis': history['nis'][:min_len],
        'mode': history['mode'][:min_len],
        'anomaly_flag': history['anomaly_flag'][:min_len]
    })
    csv_path = os.path.join(output_dir, 'detailed_history.csv')
    history_df.to_csv(csv_path, index=False)
    logging.info(f"Detailed history saved to {csv_path}")


if __name__ == "__main__":
    run_baseline_experiment()
