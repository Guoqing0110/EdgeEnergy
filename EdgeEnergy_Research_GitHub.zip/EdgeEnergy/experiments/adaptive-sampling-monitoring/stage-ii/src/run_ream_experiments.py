"""Unified experiment runner for the REAM-Sampling research questions.

This runner reuses the established simulation and output format.  Each row is
one repeat of one propagation treatment, so paired seeds can be aggregated
without silently changing the anomaly scenarios.
"""

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

import src.config as config

CALIBRATION_SEEDS = tuple(range(1, 7))
VALIDATION_SEEDS = tuple(range(7, 11))


def _source_hashes():
    """Hash executable sources that determine one propagation treatment."""
    root = Path(__file__).resolve().parents[1]
    relative_paths = [
        "src/anomaly.py",
        "src/alert_policy.py",
        "src/config.py",
        "src/data_loader.py",
        "src/energy_model.py",
        "src/models.py",
        "src/run_multinode_baseline.py",
        "src/run_conclusion_experiments.py",
        "src/run_ream_experiments.py",
        "src/sentinel_selector.py",
        "src/unified_metrics.py",
    ]
    return {
        name: hashlib.sha256((root / name).read_bytes()).hexdigest()
        for name in relative_paths
    }


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _input_hashes(overrides):
    mode = str(overrides.get("DATASET_MODE", config.DATASET_MODE)).lower()
    if mode == "synthetic":
        paths = [overrides.get("CONNECTIVITY_FILE", config.CONNECTIVITY_FILE)]
    else:
        paths = [
            overrides.get("DATA_FILE", config.DATA_FILE),
            overrides.get("MOTE_LOC_FILE", config.MOTE_LOC_FILE),
            overrides.get("CONNECTIVITY_FILE", config.CONNECTIVITY_FILE),
        ]
    return {
        os.path.abspath(path): _sha256_file(path)
        for path in paths if path and os.path.isfile(path)
    }
TEST_SEEDS = tuple(range(101, 121))


def _read_row_csv(path):
    frame = pd.read_csv(path)
    return frame.iloc[0].to_dict() if len(frame) else {}


PROPAGATION_VARIANTS = {
    "sparse_no_alert": {"ENABLE_SENTINEL_ALERT_TRIGGER": False},
    "one_hop": {"ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "one_hop", "ALERT_MAX_HOPS": 1, "ALERT_ADAPTIVE_HOPS_ENABLED": False},
    "fixed_2_hop": {"ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 2, "ALERT_ADAPTIVE_HOPS_ENABLED": False},
    "fixed_3_hop": {"ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 3, "ALERT_ADAPTIVE_HOPS_ENABLED": False},
    "adaptive_multi_hop": {"ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1, "ALERT_ADAPTIVE_HOPS_ENABLED": True},
    "adaptive_confirmed_relay": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_CONFIRMATION_GATED_RELAY": True,
        "ALERT_GATED_INITIAL_HOPS": 2,
        "ALERT_SPATIAL_TARGET_GATE": True,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 5,
        "ALERT_HOP_TTL_ENABLED": True,
    },
    "adaptive_event_relay": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_CONFIRMATION_GATED_RELAY": False,
        "ALERT_SPATIAL_TARGET_GATE": False,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_HOP_TTL_ENABLED": True,
        "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
        "ALERT_EVENT_INITIAL_HOPS": 2,
    },
    "adaptive_event_merged": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "adaptive_event_directional": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_EVENT_DIRECTIONAL_ENABLED": True,
        "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "adaptive_event_radial": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_EVENT_DIRECTIONAL_ENABLED": False,
        "ALERT_EVENT_RADIAL_FRONTIER_ENABLED": True,
        "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "geobound_v1": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_GEOBOUND_ENABLED": True,
        "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
        "ALERT_GEOBOUND_MESSAGE_BUDGET": 20,
    },
    "ltr_collect": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1, "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True, "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_LEARNED_RANKER_ENABLED": True, "ALERT_LEARNED_RANKER_COLLECT": True,
        "ALERT_EVENT_INITIAL_HOPS": 2, "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3, "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "learned_target_ranker": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1, "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True, "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_LEARNED_RANKER_ENABLED": True, "ALERT_LEARNED_RANKER_COLLECT": False,
        "ALERT_EVENT_INITIAL_HOPS": 2, "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3, "ALERT_SOFT_WATCH_STEPS": 20,
        "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "learned_outer_1hop_core": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop",
        "ALERT_MAX_HOPS": 1, "ALERT_ADAPTIVE_HOPS_ENABLED": True,
        "ALERT_EVENT_RELAY_ENABLED": True, "ALERT_EVENT_MERGE_ENABLED": True,
        "ALERT_LEARNED_RANKER_ENABLED": True, "ALERT_LEARNED_POLICY": "one_hop_core",
        "ALERT_EVENT_INITIAL_HOPS": 2, "ALERT_VERIFICATION_FAIL_FAST": True,
        "ALERT_VERIFY_WAIT_STEPS": 3, "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "learned_prune_2hop_80": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True, "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True, "ALERT_LEARNED_RANKER_ENABLED": True,
        "ALERT_LEARNED_POLICY": "prune_2hop", "ALERT_LEARNED_PRUNE_FRACTION": 0.8,
        "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 2, "ALERT_LEARNED_TOP_M": 54,
        "ALERT_LEARNED_MESSAGE_BUDGET": 100, "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True, "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "learned_prune_2hop_60": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True, "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True, "ALERT_LEARNED_RANKER_ENABLED": True,
        "ALERT_LEARNED_POLICY": "prune_2hop", "ALERT_LEARNED_PRUNE_FRACTION": 0.6,
        "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 2, "ALERT_LEARNED_TOP_M": 54,
        "ALERT_LEARNED_MESSAGE_BUDGET": 100, "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True, "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "learned_prune_2hop_40": {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True, "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True, "ALERT_LEARNED_RANKER_ENABLED": True,
        "ALERT_LEARNED_POLICY": "prune_2hop", "ALERT_LEARNED_PRUNE_FRACTION": 0.4,
        "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 2, "ALERT_LEARNED_TOP_M": 54,
        "ALERT_LEARNED_MESSAGE_BUDGET": 100, "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True, "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
    },
    "oracle_local": {"ENABLE_SENTINEL_ALERT_TRIGGER": False, "ORACLE_WAKEUP_ENABLED": True},
}

PROPAGATION_VARIANTS["fixed_2_hop_verify3"] = {
    **PROPAGATION_VARIANTS["fixed_2_hop"],
    "ALERT_VERIFICATION_FAIL_FAST": True, "ALERT_VERIFY_WAIT_STEPS": 3,
}

for _budget in (500, 615, 1000, 2000, 4500):
    PROPAGATION_VARIANTS["candidate_oracle_%d" % _budget] = {
        "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": True, "ALERT_EVENT_RELAY_ENABLED": True,
        "ALERT_EVENT_MERGE_ENABLED": True, "ALERT_LEARNED_RANKER_ENABLED": True,
        "ALERT_LEARNED_ORACLE_SCORING": True, "ALERT_LEARNED_POLICY": "pure",
        "ALERT_LEARNED_TOP_M": 54, "ALERT_LEARNED_MESSAGE_BUDGET": 100,
        "ALERT_LEARNED_MIN_SCORE": 1.0,
        "ALERT_LEARNED_GLOBAL_MESSAGE_BUDGET": _budget, "ALERT_EVENT_INITIAL_HOPS": 2,
        "ALERT_VERIFICATION_FAIL_FAST": True, "ALERT_VERIFY_WAIT_STEPS": 3,
        "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
    }

_ORACLE_GENERATOR_BASE = {
    "ENABLE_SENTINEL_ALERT_TRIGGER": True, "ALERT_PROPAGATION_MODE": "k_hop", "ALERT_MAX_HOPS": 1,
    "ALERT_ADAPTIVE_HOPS_ENABLED": True, "ALERT_ADAPTIVE_MAX_HOPS": 8,
    "ALERT_EVENT_RELAY_ENABLED": True, "ALERT_EVENT_MERGE_ENABLED": True,
    "ALERT_LEARNED_RANKER_ENABLED": True, "ALERT_LEARNED_ORACLE_SCORING": True,
    "ALERT_LEARNED_POLICY": "pure", "ALERT_LEARNED_TOP_M": 54,
    "ALERT_LEARNED_MIN_SCORE": 1.0,
    "ALERT_LEARNED_MESSAGE_BUDGET": 200, "ALERT_LEARNED_GLOBAL_MESSAGE_BUDGET": 4500,
    "ALERT_EVENT_INITIAL_HOPS": 2, "ALERT_VERIFICATION_FAIL_FAST": True,
    "ALERT_VERIFY_WAIT_STEPS": 3, "ALERT_SOFT_WATCH_STEPS": 20, "ALERT_SOFT_WATCH_PERIOD": 2,
}

for _name, _extra in {
    "oracle_gen_current": {"ALERT_CANDIDATE_GENERATOR": "current", "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 4},
    "oracle_gen_comm4": {"ALERT_CANDIDATE_GENERATOR": "comm_hop", "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 4},
    "oracle_gen_comm5": {"ALERT_CANDIDATE_GENERATOR": "comm_hop", "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 5},
    "oracle_gen_spatial": {"ALERT_CANDIDATE_GENERATOR": "spatial_frontier", "ALERT_CANDIDATE_SPATIAL_HOPS": 2,
                           "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8},
    "oracle_gen_confirmed": {"ALERT_CANDIDATE_GENERATOR": "confirmed_frontier", "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 2,
                             "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8},
    "oracle_gen_hybrid": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_LEARNED_CANDIDATE_MAX_HOPS": 3,
                          "ALERT_CANDIDATE_SPATIAL_HOPS": 2, "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8},
    "oracle_requery_confirmation": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "none",
                                    "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8},
    "oracle_requery_confirmation_realert": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "none",
                                            "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
                                            "ALERT_EVENT_REALERT_ENABLED": True},
    "oracle_requery_time": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "time",
                            "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3, "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
                            "ALERT_EVENT_REALERT_ENABLED": True},
    "oracle_requery_time_confirmation": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "time_confirmation",
                                         "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3, "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
                                         "ALERT_EVENT_REALERT_ENABLED": True},
    "oracle_requery_soft_trend": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "soft_trend",
                                  "ALERT_EVENT_SOFT_TREND_THRESHOLD": 2.0, "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
                                  "ALERT_EVENT_REALERT_ENABLED": True},
    "oracle_requery_hybrid": {"ALERT_CANDIDATE_GENERATOR": "hybrid", "ALERT_EVENT_REQUERY_MODE": "hybrid",
                              "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3, "ALERT_EVENT_SOFT_TREND_THRESHOLD": 2.0,
                              "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8, "ALERT_EVENT_REALERT_ENABLED": True},
}.items():
    PROPAGATION_VARIANTS[_name] = {**_ORACLE_GENERATOR_BASE, **_extra}

for _budget in (200, 300, 400, 500, 800):
    PROPAGATION_VARIANTS["oracle_confirmation_realert_budget_%d" % _budget] = {
        **_ORACLE_GENERATOR_BASE,
        "ALERT_CANDIDATE_GENERATOR": "hybrid",
        "ALERT_EVENT_REQUERY_MODE": "none",
        "ALERT_EVENT_REALERT_ENABLED": True,
        "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
        "ALERT_LEARNED_GLOBAL_MESSAGE_BUDGET": _budget,
    }

PROPAGATION_VARIANTS["learned_confirmation_realert"] = {
    **_ORACLE_GENERATOR_BASE,
    "ALERT_LEARNED_ORACLE_SCORING": False,
    "ALERT_LEARNED_MIN_SCORE": -999.0,
    "ALERT_LEARNED_TOP_M": 6,
    "ALERT_LEARNED_MESSAGE_BUDGET": 20,
    "ALERT_LEARNED_GLOBAL_MESSAGE_BUDGET": 800,
    "ALERT_CANDIDATE_GENERATOR": "hybrid",
    "ALERT_EVENT_REQUERY_MODE": "none",
    "ALERT_EVENT_REALERT_ENABLED": True,
    "ALERT_CANDIDATE_ROUTE_MAX_HOPS": 8,
}
PROPAGATION_VARIANTS["learned_confirmation_realert_core"] = {
    **PROPAGATION_VARIANTS["learned_confirmation_realert"],
    "ALERT_LEARNED_POLICY": "one_hop_core",
}

PROPAGATION_VARIANTS["ap_dfrealert_collect"] = {
    **_ORACLE_GENERATOR_BASE,
    "ALERT_LEARNED_RANKER_ENABLED": False,
    "ALERT_CONFIRMATION_REALERT_POLICY_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_PREVIOUS_FALSE_ONLY": True,
    "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
    "ALERT_CANDIDATE_GENERATOR": "hybrid",
    "AP_DFREALERT_ENABLED": True,
    "AP_DFREALERT_MODEL_PATH": "",
}
PROPAGATION_VARIANTS["ap_dfrealert_locked"] = {
    **PROPAGATION_VARIANTS["ap_dfrealert_collect"],
    "AP_DFREALERT_MODEL_PATH": config.AP_DFREALERT_MODEL_PATH,
}

_CONFIRMATION_REALERT_BASE = {
    "ENABLE_SENTINEL_ALERT_TRIGGER": True,
    "ALERT_PROPAGATION_MODE": "k_hop",
    "ALERT_MAX_HOPS": 1,
    "ALERT_ADAPTIVE_HOPS_ENABLED": True,
    "ALERT_ADAPTIVE_MAX_HOPS": 8,
    "ALERT_EVENT_RELAY_ENABLED": True,
    "ALERT_EVENT_MERGE_ENABLED": True,
    "ALERT_EVENT_REALERT_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_POLICY_ENABLED": True,
    "ALERT_LEARNED_RANKER_ENABLED": False,
    "ALERT_GEOBOUND_ENABLED": False,
    "ALERT_EVENT_REQUERY_MODE": "none",
    "ALERT_EVENT_INITIAL_HOPS": 2,
    "ALERT_VERIFICATION_FAIL_FAST": True,
    "ALERT_VERIFY_WAIT_STEPS": 3,
    "ALERT_SOFT_WATCH_STEPS": 20,
    "ALERT_SOFT_WATCH_PERIOD": 2,
    "ALERT_EVENT_REALERT_COOLDOWN_STEPS": 4,
    "ALERT_CONFIRMATION_REALERT_TOP_M": 54,
}

PROPAGATION_VARIANTS["cr_1hop"] = {
    **_CONFIRMATION_REALERT_BASE,
    "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 1,
    "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 0,
}
for _budget in (400, 600):
    PROPAGATION_VARIANTS["cr_2hop_b%d" % _budget] = {
        **_CONFIRMATION_REALERT_BASE,
        "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
        "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": _budget,
    }
    PROPAGATION_VARIANTS["frontier_cr_b%d" % _budget] = {
        **_CONFIRMATION_REALERT_BASE,
        "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
        "ALERT_CONFIRMATION_REALERT_FRONTIER_ONLY": True,
        "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": _budget,
    }

PROPAGATION_VARIANTS["CR-1hop"] = PROPAGATION_VARIANTS["cr_1hop"]
PROPAGATION_VARIANTS["CR-2hop-B400"] = PROPAGATION_VARIANTS["cr_2hop_b400"]
PROPAGATION_VARIANTS["CR-2hop-B600"] = PROPAGATION_VARIANTS["cr_2hop_b600"]
PROPAGATION_VARIANTS["Frontier-CR-B400"] = PROPAGATION_VARIANTS["frontier_cr_b400"]
PROPAGATION_VARIANTS["Frontier-CR-B600"] = PROPAGATION_VARIANTS["frontier_cr_b600"]

for _top_k in (1, 2, 3):
    PROPAGATION_VARIANTS["CR-topK%d" % _top_k] = {
        **_CONFIRMATION_REALERT_BASE,
        "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
        "ALERT_CONFIRMATION_REALERT_TOP_M": _top_k,
        "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 400,
    }
for _top_k in (2, 3):
    PROPAGATION_VARIANTS["CR-topK%d-probe" % _top_k] = {
        **PROPAGATION_VARIANTS["CR-topK%d" % _top_k],
        "ALERT_CONFIRMATION_REALERT_PROBE_ENABLED": True,
        "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 2,
    }
PROPAGATION_VARIANTS["CR-filter-falsePenalty-probe"] = {
    **PROPAGATION_VARIANTS["CR-topK3-probe"],
    "ALERT_CONFIRMATION_REALERT_FALSE_PENALTY": 3.0,
    "ALERT_CONFIRMATION_REALERT_REQUIRE_EVIDENCE": True,
}
PROPAGATION_VARIANTS["CR-eventBudget100-probe"] = {
    **PROPAGATION_VARIANTS["CR-topK3-probe"],
    "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 100,
}
PROPAGATION_VARIANTS["CR-filter-basic"] = {
    **_CONFIRMATION_REALERT_BASE,
    "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
    "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 400,
    "ALERT_CONFIRMATION_REALERT_REQUIRE_EVIDENCE": True,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1"] = {
    **_CONFIRMATION_REALERT_BASE,
    "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 1,
    "ALERT_CONFIRMATION_REALERT_TOP_M": 54,
    "ALERT_CONFIRMATION_REALERT_STRICT_FALSE_GATE": True,
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 2.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1-topK2"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 2,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1-probe"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1"],
    "ALERT_CONFIRMATION_REALERT_PROBE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 2,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 2.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1plus2strong"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1"],
    "ALERT_CONFIRMATION_REALERT_MAX_HOPS": 2,
    "ALERT_CONFIRMATION_REALERT_TOP_M": 3,
    "ALERT_CONFIRMATION_REALERT_REQUIRE_EVIDENCE": True,
    "ALERT_CONFIRMATION_REALERT_UNCERTAINTY_FACTOR": 0.8,
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 2.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1-allEvidence"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "all",
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1plus2-allEvidence"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1plus2strong"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "all",
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1-probe-loose"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1-allEvidence"],
    "ALERT_CONFIRMATION_REALERT_PROBE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 3,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1-hopSensitive"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "hop_sensitive",
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-strictFalse-hop1plus2-hopSensitive"] = {
    **PROPAGATION_VARIANTS["CR-strictFalse-hop1plus2strong"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "hop_sensitive",
    "ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-2hop-B400-probeFailed"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400"],
    "ALERT_CONFIRMATION_REALERT_PROBE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 3,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 1.0,
}
PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFailed"],
    "ALERT_CONFIRMATION_REALERT_PROBE_PREVIOUS_FALSE_ONLY": True,
}
PROPAGATION_VARIANTS["CR-2hop-B300-probeFalseOnly"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 300,
}
PROPAGATION_VARIANTS["CR-2hop-B250-probeFalseOnly"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_EVENT_BUDGET": 250,
}
PROPAGATION_VARIANTS["CR-probeFalseOnly-looseUpgrade"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_PROBE_LOOSE_UPGRADE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 1.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_WEAK_STREAK_STEPS": 2,
}
PROPAGATION_VARIANTS["CR-probeFalseOnly-weakAND"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_STRICT_FALSE_GATE": True,
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "weak_and",
}
PROPAGATION_VARIANTS["CR-probeFalseOnly-weakAND-looseUpgrade"] = {
    **PROPAGATION_VARIANTS["CR-probeFalseOnly-weakAND"],
    "ALERT_CONFIRMATION_REALERT_PROBE_LOOSE_UPGRADE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 1.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_WEAK_STREAK_STEPS": 2,
}
PROPAGATION_VARIANTS["CR-probeFalseOnly-activeCap15"] = {
    **PROPAGATION_VARIANTS["CR-probeFalseOnly-looseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_ACTIVE_FULL_ALERT_CAP": 15,
}
PROPAGATION_VARIANTS["CR-frontApproach"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_STRICT_FALSE_GATE": True,
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "front_approach",
}
PROPAGATION_VARIANTS["CR-frontApproach-weakEvidence"] = {
    **PROPAGATION_VARIANTS["CR-frontApproach"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "front_approach_weak",
    "ALERT_CONFIRMATION_REALERT_EVIDENCE_TREND_ENABLED": True,
}
PROPAGATION_VARIANTS["CR-frontApproach-weakEvidence-looseProbe"] = {
    **PROPAGATION_VARIANTS["CR-frontApproach-weakEvidence"],
    "ALERT_CONFIRMATION_REALERT_PROBE_LOOSE_UPGRADE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_WEAK_STREAK_STEPS": 2,
}
PROPAGATION_VARIANTS["CR-frontApproach-hop2Strict"] = {
    **PROPAGATION_VARIANTS["CR-frontApproach-weakEvidence"],
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "front_approach_hop2_strict",
}
PROPAGATION_VARIANTS["CR-approachScore-probeFalseOnly"] = {
    **PROPAGATION_VARIANTS["CR-2hop-B400-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_STRICT_FALSE_GATE": False,
    "ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE": "approach_score_soft",
    "ALERT_CONFIRMATION_REALERT_TOP_M": 6,
}
PROPAGATION_VARIANTS["CR-approachScore-probeFalseOnly-topK5"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 5,
}
PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeFalseOnly"],
    "ALERT_CONFIRMATION_REALERT_PROBE_LOOSE_UPGRADE_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_RELATIVE_GLR_ENABLED": True,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD": 2.0,
    "ALERT_CONFIRMATION_REALERT_PROBE_WEAK_STREAK_STEPS": 2,
}
PROPAGATION_VARIANTS["CR-approachScore-topK4"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 4,
}
PROPAGATION_VARIANTS["CR-delayedFront-calibrated-topK4"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-topK4"],
    "ALERT_CONFIRMATION_REALERT_APPROACH_SCORE_WEIGHT": 1.0,
    "ALERT_CONFIRMATION_REALERT_CLOSE_FRONTIER_BONUS": 0.0,
    "ALERT_CONFIRMATION_REALERT_EVIDENCE_TREND_BONUS": 0.0,
    "ALERT_CONFIRMATION_REALERT_WEAK_EVIDENCE_BONUS": 1.5,
    "ALERT_CONFIRMATION_REALERT_PREVIOUS_FALSE_EXTRA_HOP_PENALTY": 0.5,
}
PROPAGATION_VARIANTS["CR-delayedFront-calibrated-topK5"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-calibrated-topK4"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 5,
}
PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-calibrated-topK5"],
}
for _admission_k in (1, 2, 3, 4):
    PROPAGATION_VARIANTS[f"CR-delayedFront-locked-topK{_admission_k}"] = {
        **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
        "ALERT_CONFIRMATION_REALERT_TOP_M": _admission_k,
    }
PROPAGATION_VARIANTS["DF-ReAlert-v2-noPassiveWatch"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
    "ALERT_SOFT_WATCH_SAMPLING_ENABLED": False,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-eventBudget12"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-noPassiveWatch"],
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 12,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-strictProbe"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-eventBudget12"],
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 2,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_UNCERTAINTY_ENABLED": False,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD": 2.5,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD": 6.63,
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD": 6.0,
    "ALERT_CONFIRMATION_REALERT_WEAK_INNOVATION_THRESHOLD": 1.5,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-velocity"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-strictProbe"],
    "ALERT_CONFIRMATION_REALERT_RANKING_MODE": "velocity_extrapolation",
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled24"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-noPassiveWatch"],
    "ALERT_EVENT_REQUERY_MODE": "time_confirmation",
    "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3,
    "ALERT_EVENT_REQUERY_MAX_ANCHORS": 2,
    "ALERT_CONFIRMATION_REALERT_ALLOW_SOURCE_REPEAT": True,
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 24,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled-action24"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled24"],
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 0,
    "ALERT_CONFIRMATION_REALERT_EVENT_ACTION_BUDGET": 24,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled-action36"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled-action24"],
    "ALERT_CONFIRMATION_REALERT_EVENT_ACTION_BUDGET": 36,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled-action24-i6"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled-action24"],
    "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 6,
    "ALERT_EVENT_REQUERY_MAX_ANCHORS": 1,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled36"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled24"],
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 36,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-scheduled24-strict"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-strictProbe"],
    "ALERT_EVENT_REQUERY_MODE": "time_confirmation",
    "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3,
    "ALERT_EVENT_REQUERY_MAX_ANCHORS": 2,
    "ALERT_CONFIRMATION_REALERT_ALLOW_SOURCE_REPEAT": True,
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 24,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
    "ALERT_SOFT_WATCH_PERIOD": 4,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-expiryBound"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
    "ALERT_CLEAR_ON_EVENT_EXPIRY": True,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4-expiry"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4"],
    "ALERT_CLEAR_ON_EVENT_EXPIRY": True,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch6-expiry"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4-expiry"],
    "ALERT_SOFT_WATCH_PERIOD": 6,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch8-expiry"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4-expiry"],
    "ALERT_SOFT_WATCH_PERIOD": 8,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch6-budget24-expiry"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch6-expiry"],
    "ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET": 24,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-expiry80"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-expiryBound"],
    "ALERT_EVENT_LIFETIME_STEPS": 80,
    "ALERT_EVENT_MERGE_MIN_REMAINING_STEPS": 20,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4-expiry80"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch4-expiry"],
    "ALERT_EVENT_LIFETIME_STEPS": 80,
    "ALERT_EVENT_MERGE_MIN_REMAINING_STEPS": 20,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-watch6-expiry80"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-watch6-expiry"],
    "ALERT_EVENT_LIFETIME_STEPS": 80,
    "ALERT_EVENT_MERGE_MIN_REMAINING_STEPS": 20,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-reserve1"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
    "AP_DFREALERT_ENABLED": True,
    "AP_DFREALERT_MODEL_PATH": str(config.OUTPUT_DIR + "/dfrealert_v2_dev_model/front_likelihood.json"),
    "AP_DFREALERT_PROBABILITY_THRESHOLD": 0.14,
    "AP_DFREALERT_MIN_CANDIDATES": 5,
    "AP_DFREALERT_MAX_CANDIDATES": 5,
    "AP_DFREALERT_PREVIOUS_FALSE_RESERVED_SLOTS": 1,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-reserve2"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-reserve1"],
    "AP_DFREALERT_PREVIOUS_FALSE_RESERVED_SLOTS": 2,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-p10"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-reserve2"],
    "AP_DFREALERT_PROBABILITY_THRESHOLD": 0.10,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-p08"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-reserve2"],
    "AP_DFREALERT_PROBABILITY_THRESHOLD": 0.08,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-watch4"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-p10"],
    "ALERT_SOFT_WATCH_PERIOD": 4,
}
PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-scheduled36"] = {
    **PROPAGATION_VARIANTS["DF-ReAlert-v2-learned-p10"],
    "ALERT_SOFT_WATCH_SAMPLING_ENABLED": False,
    "ALERT_EVENT_REQUERY_MODE": "time_confirmation",
    "ALERT_EVENT_REQUERY_INTERVAL_STEPS": 3,
    "ALERT_EVENT_REQUERY_MAX_ANCHORS": 2,
    "ALERT_CONFIRMATION_REALERT_ALLOW_SOURCE_REPEAT": True,
    "ALERT_CONFIRMATION_REALERT_EVENT_ACTION_BUDGET": 36,
    "ALERT_EVENT_LIFETIME_STEPS": 80,
    "ALERT_EVENT_MERGE_MIN_REMAINING_STEPS": 20,
    "ALERT_CLEAR_ON_EVENT_EXPIRY": True,
}
for _name, _mode in {
    "random_topK5": "random",
    "distance_only_topK5": "distance_only",
    "nearest_confirmed_topK5": "nearest_confirmed",
    "route_cost_only_topK5": "route_cost_only",
    "approach_only_topK5": "approach_only",
    "probe_only_topK5": "probe_only",
    "periodic_realert_topK5": "periodic",
    "front_velocity_extrapolation_topK5": "velocity_extrapolation",
    "dfo_compatibility_topK5": "dfo_compatibility",
    "failure_time_compatibility_topK5": "failure_time_compatibility",
    "dfo_failure_compatibility_topK5": "dfo_failure_compatibility",
}.items():
    PROPAGATION_VARIANTS[_name] = {
        **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
        "ALERT_CONFIRMATION_REALERT_RANKING_MODE": _mode,
        "ALERT_CONFIRMATION_REALERT_TOP_M": 5,
    }
PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5-verify5-probe5"] = {
    **PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"],
    "ALERT_VERIFY_WAIT_STEPS": 5,
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 5,
}
PROPAGATION_VARIANTS["fixed_2_hop_matched3"] = {
    **PROPAGATION_VARIANTS["fixed_2_hop_verify3"],
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 3,
}
PROPAGATION_VARIANTS["CR-approachScore-topK4-probe5"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-topK4"],
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 5,
}
PROPAGATION_VARIANTS["CR-approachScore-topK4-probe7"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-topK4"],
    "ALERT_CONFIRMATION_REALERT_PROBE_STEPS": 7,
}
PROPAGATION_VARIANTS["CR-approachScore-topK5"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 5,
}
PROPAGATION_VARIANTS["CR-approachScore-topKsoft"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_TOP_M": 3,
}
PROPAGATION_VARIANTS["CR-approachScore-activeCap"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_ACTIVE_CAP": 10,
}
PROPAGATION_VARIANTS["CR-approachScore-activeCap15"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_ACTIVE_CAP": 15,
}
PROPAGATION_VARIANTS["CR-approachScore-activeCap20"] = {
    **PROPAGATION_VARIANTS["CR-approachScore-probeLooseUpgrade"],
    "ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_ACTIVE_CAP": 20,
}
PROPAGATION_VARIANTS["ltr_collect_realert_hybrid"] = {
    **PROPAGATION_VARIANTS["learned_confirmation_realert"],
    "ALERT_LEARNED_RANKER_COLLECT": True,
    "ALERT_LEARNED_RANKER_MODEL": "",
}

DEFAULT_PROPAGATION_METHODS = [
    "fixed_2_hop", "fixed_2_hop_verify3", "fixed_2_hop_matched3",
    "CR-delayedFront-locked-topK5",
    "CR-delayedFront-locked-topK5-verify5-probe5",
    "random_topK5", "distance_only_topK5", "nearest_confirmed_topK5",
    "route_cost_only_topK5", "approach_only_topK5", "probe_only_topK5",
    "periodic_realert_topK5", "front_velocity_extrapolation_topK5",
]


def _find_completed_run(method_root):
    """Return the newest complete run below a method/seed directory."""
    if not os.path.isdir(method_root):
        return None
    candidates = []
    for name in os.listdir(method_root):
        run_dir = os.path.join(method_root, name)
        if not os.path.isdir(run_dir):
            continue
        required = [
            os.path.join(run_dir, "task8_metrics_main.csv"),
            os.path.join(run_dir, "task6_detection_metrics.csv"),
            os.path.join(run_dir, "task6_energy_proxy.csv"),
        ]
        if all(os.path.isfile(path) and os.path.getsize(path) > 0 for path in required):
            candidates.append(run_dir)
    return max(candidates, key=os.path.getmtime) if candidates else None


def run_propagation_study(output_root=None, repeats=10, seed_base=1, resume=True, methods=None, base_overrides=None):
    # Delay the plotting-heavy legacy import so policy modules, tests and CLI
    # help remain usable in minimal environments.
    from src.run_conclusion_experiments import config_override, _run_once
    output_root = output_root or os.path.join(config.OUTPUT_DIR, "ream_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    os.makedirs(output_root, exist_ok=True)
    rows = []
    selected_methods = list(DEFAULT_PROPAGATION_METHODS) if not methods else list(methods)
    unknown = [name for name in selected_methods if name not in PROPAGATION_VARIANTS]
    if unknown:
        raise ValueError("Unknown methods: %s" % ", ".join(unknown))
    total_runs = int(repeats) * len(selected_methods)
    protocol = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": _source_hashes(),
        "input_sha256": _input_hashes(base_overrides or {}),
        "runtime": {
            "python": sys.version,
            "platform": platform.platform(),
            "pandas": pd.__version__,
        },
        "dataset": "Intel Berkeley Research Lab temperature trace" if str((base_overrides or {}).get("DATASET_MODE", config.DATASET_MODE)).lower() == "intel" else "independent synthetic temperature background",
        "dataset_mode": str((base_overrides or {}).get("DATASET_MODE", config.DATASET_MODE)).lower(),
        "seed_partition": {"calibration": list(CALIBRATION_SEEDS), "validation": list(VALIDATION_SEEDS), "locked_test": list(TEST_SEEDS)},
        "randomization_contract": {
            "changes_with_experiment_seed": ["sentinel_selection", "injected_event_schedule_and_parameters", "stateless_measurement_noise"],
            "fixed_within_scenario": ["background_trace", "time_window", "node_coordinates", "spatial_and_communication_graphs", "node_limit", "detector_and_policy_configuration"],
            "synthetic_background_seed_is_separate": True,
        },
        "repeats": int(repeats),
        "seed_base": int(seed_base),
        "methods": selected_methods,
        "base_overrides": base_overrides or {},
        "method_overrides": {name: PROPAGATION_VARIANTS[name] for name in selected_methods},
        "base_config": {
            name: value for name, value in vars(config).items()
            if name.isupper() and not name.startswith("AIRQUALITY_")
            and isinstance(value, (str, int, float, bool, type(None), list, tuple, dict))
        },
    }
    if str((base_overrides or {}).get("DATASET_MODE", config.DATASET_MODE)).lower() not in {"intel", "synthetic"}:
        raise ValueError("Paper protocol supports only the original Intel dataset and independent synthetic backgrounds.")
    protocol_path = os.path.join(output_root, "experiment_protocol.json")
    if resume and os.path.isfile(protocol_path):
        with open(protocol_path, "r", encoding="utf-8") as handle:
            prior_protocol = json.load(handle)
        contract_keys = ("source_sha256", "input_sha256", "methods", "base_overrides", "method_overrides", "base_config")
        changed = [key for key in contract_keys if prior_protocol.get(key) != protocol.get(key)]
        if changed:
            raise RuntimeError(
                "Refusing to resume incompatible experiment output; changed protocol fields: "
                + ", ".join(changed)
                + ". Use a new --output-root or --no-resume."
            )
    with open(protocol_path, "w", encoding="utf-8") as handle:
        json.dump(protocol, handle, indent=2, sort_keys=True, default=str)
    run_number = 0
    study_start = time.time()
    for repeat in range(int(repeats)):
        seed = int(seed_base) + repeat
        for method in selected_methods:
            overrides = PROPAGATION_VARIANTS[method]
            run_number += 1
            run_overrides = {
                "RANDOM_SEED": seed,
                "COMM_RANDOM_SEED": seed,
                "SPATIAL_ANOMALY_RANDOM_SEED": seed,
                "ENABLE_PLOTS": False,
                "SAVE_NODE_HISTORIES": False,
                "ENABLE_DETAILED_LOGS": True,
                "ORACLE_WAKEUP_ENABLED": False,
                **(base_overrides or {}),
                **overrides,
            }
            method_root = os.path.join(output_root, method, "seed_%04d" % seed)
            os.makedirs(method_root, exist_ok=True)
            run_dir = _find_completed_run(method_root) if resume else None
            if run_dir is not None:
                print("[%d/%d] resume %s seed=%d: %s" % (run_number, total_runs, method, seed, run_dir), flush=True)
                task8 = _read_row_csv(os.path.join(run_dir, "task8_metrics_main.csv"))
                energy = _read_row_csv(os.path.join(run_dir, "task6_energy_proxy.csv"))
            else:
                print("[%d/%d] start  %s seed=%d" % (run_number, total_runs, method, seed), flush=True)
                started = time.time()
                with config_override(run_overrides):
                    run_dir, task8, _, energy = _run_once({}, output_root_override=method_root)
                print("[%d/%d] done   %s seed=%d (%.1fs)" % (
                    run_number, total_runs, method, seed, time.time() - started
                ), flush=True)
            row = {
                "method": method,
                "repeat": repeat,
                "seed": seed,
                "run_dir": os.path.abspath(run_dir),
                "base_overrides_json": json.dumps(base_overrides or {}, sort_keys=True, default=str),
                "method_overrides_json": json.dumps(overrides, sort_keys=True),
                **task8,
            }
            if "alert_message_count" in task8:
                row["alert_forwarding_message_count"] = task8["alert_message_count"]
            if "alert_message_count" in energy:
                row["alert_rx_message_count"] = energy["alert_message_count"]
            row.update(energy)
            rows.append(row)
            # Checkpoint after every treatment so Ctrl+C loses no completed data.
            pd.DataFrame(rows).to_csv(os.path.join(output_root, "propagation_checkpoint.csv"), index=False)
    raw = pd.DataFrame(rows)
    raw_path = os.path.join(output_root, "propagation_raw.csv")
    if resume and os.path.isfile(raw_path) and os.path.getsize(raw_path) > 0:
        previous = pd.read_csv(raw_path)
        raw = pd.concat([previous, raw], ignore_index=True, sort=False)
        dedup_cols = [c for c in ["method", "seed"] if c in raw.columns]
        if dedup_cols:
            raw = raw.drop_duplicates(subset=dedup_cols, keep="last")
    raw.to_csv(raw_path, index=False)
    raw = raw.copy()
    numeric = [c for c in raw.select_dtypes(include="number").columns if c not in {"repeat", "seed"}]
    summary = raw.loc[:, ["method", *numeric]].groupby("method", sort=False).agg(["mean", "std"]).reset_index()
    summary.columns = ["_".join([str(x) for x in col if x]) for col in summary.columns]
    summary.to_csv(os.path.join(output_root, "propagation_summary.csv"), index=False)
    print("Completed %d treatments in %.1f minutes" % (total_runs, (time.time() - study_start) / 60.0), flush=True)
    return output_root, raw, summary


def main():
    parser = argparse.ArgumentParser(description="Run paired REAM propagation experiments")
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--seed-base", type=int, default=1)
    parser.add_argument("--output-root", default=None)
    parser.add_argument("--no-resume", action="store_true", help="rerun treatments even when complete outputs exist")
    parser.add_argument("--methods", nargs="+", default=None, help="optional subset of method names")
    args = parser.parse_args()
    output_root, _, _ = run_propagation_study(
        args.output_root, args.repeats, args.seed_base,
        resume=not args.no_resume, methods=args.methods
    )
    print(output_root)


if __name__ == "__main__":
    main()
