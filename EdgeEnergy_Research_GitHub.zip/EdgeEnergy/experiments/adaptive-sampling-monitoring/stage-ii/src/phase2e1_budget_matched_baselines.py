"""Phase II-E1 budget-matched ranking evaluation runner.

This runner changes only ALERT_CONFIRMATION_REALERT_RANKING_MODE.  It is
fail-closed for the frozen E0 protocol and reserves 401--420 for the full
evaluation; ``--audit`` may use already-viewed seed 201 only.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import src.config as config
from src.run_conclusion_experiments import config_override
from src.run_multinode_baseline import run_multinode_baseline_experiment
from src.run_ream_experiments import PROPAGATION_VARIANTS

ROOT = Path(config.PROJECT_ROOT)
OUT = ROOT / "phase2_paper_evidence" / "e1_budget_matched_baselines"
E0 = ROOT / "phase2_paper_evidence" / "e0_evidence_preregistration"
E0_PROTOCOL_SHA256 = "F85ABAEC2620FE89D27768CA9C05447900C315307336CAB61B4F3C1F07B905DC"
BASE = PROPAGATION_VARIANTS["CR-delayedFront-locked-topK5"]
METHODS = {
    "DF-ReAlert": "full",
    "Random-TopK": "random",
    "Nearest-front-TopK": "nearest_confirmed",
    "Lowest-route-cost-TopK": "route_cost_only",
}
AUDIT_SEEDS = {201}
EVAL_SEEDS = set(range(401, 421))
SOURCE_FILES = ("src/config.py", "src/models.py", "src/run_multinode_baseline.py", "src/run_ream_experiments.py", "src/phase2e1_budget_matched_baselines.py")

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def source_hashes():
    return {p: sha256(ROOT / p) for p in SOURCE_FILES}

def overrides(method: str, seed: int, output: Path, trace: bool):
    return {**BASE,
        "ALERT_FRONTIER_ANCHORED_RETAINED_SCOPE_ENABLED": True,
        "ALERT_FRONT_TRIGGERED_RECONSIDERATION_ENABLED": True,
        "ALERT_FRONT_TRIGGERED_RECONSIDERATION_MIN_REFRACTORY_STEPS": 2,
        "ALERT_CONFIRMED_TRACKING_HANDOFF_RELEASE_ENABLED": False,
        "ALERT_EVENT_EXPIRY_CONFIRMED_HANDOFF_ENABLED": False,
        "ALERT_FRONTIER_PRESERVING_CONFIRMED_HANDOFF_ENABLED": True,
        "ALERT_CONFIRMED_TRACKING_MIN_STEPS": 3,
        "ALERT_CONFIRMED_TRACKING_MAX_STEPS": 0,
        "ALERT_BUDGETED_FRONTIER_TRACKING_ENABLED": True,
        "ALERT_BUDGETED_FRONTIER_UNIQUE_COVERAGE_ENABLED": False,
        "ALERT_CONFIRMATION_REALERT_RANKING_MODE": METHODS[method],
        "OUTPUT_DIR": str(output), "DATASET_MODE": "intel",
        "RANDOM_SEED": int(seed), "SPATIAL_ANOMALY_RANDOM_SEED": int(seed),
        "COMM_RANDOM_SEED": 42, "STRUCTURAL_TRACE_ENABLED": bool(trace),
        "ENABLE_PLOTS": False, "SAVE_NODE_HISTORIES": False,
        "ENABLE_DETAILED_LOGS": True}

def run_manifest(method: str, seed: int):
    return {"phase": "Phase II-E1 budget-matched baseline evaluation",
        "e0_protocol_sha256": E0_PROTOCOL_SHA256, "method": method, "seed": int(seed),
        "ranking_mode": METHODS[method], "ranking_only_change": True,
        "K": int(config.ALERT_CONFIRMATION_REALERT_TOP_M),
        "probe_duration": int(config.ALERT_CONFIRMATION_REALERT_PROBE_STEPS),
        "verification_duration": int(config.ALERT_VERIFY_WAIT_STEPS),
        "max_response_hops": int(config.ALERT_CONFIRMATION_REALERT_MAX_HOPS),
        "event_cooldown": int(config.ALERT_EVENT_REALERT_COOLDOWN_STEPS),
        "failed_probe_cooldown": int(config.ALERT_CONFIRMATION_REALERT_PROBE_COOLDOWN_STEPS),
        "rng_policy": "ranking RNG is context-derived for random; anomaly/noise/communication streams unchanged",
        "source_hashes": source_hashes()}

def run_one(method: str, seed: int, trace: bool = True, root: Path | None = None):
    if method not in METHODS: raise ValueError(method)
    target = root or (OUT / "runs" / method / f"seed_{seed}")
    target.mkdir(parents=True, exist_ok=True)
    before = {p for p in target.iterdir() if p.is_dir()}
    with config_override(overrides(method, seed, target, trace)):
        np.random.seed(int(seed)); run_multinode_baseline_experiment()
    made = [p for p in target.iterdir() if p.is_dir() and p not in before]
    if len(made) != 1: raise RuntimeError(f"expected one run, got {made}")
    (made[0] / "E1_EFFECTIVE_CONFIG.json").write_text(json.dumps(run_manifest(method, seed), indent=2), encoding="utf-8")
    return made[0]

def audit():
    # Static audit is deliberately independent of evaluation outcomes.
    text = (ROOT / "src/models.py").read_text(encoding="utf-8")
    required = {"random": "np.random.default_rng(np.random.SeedSequence(words))", "nearest_confirmed": "score = -float(distance_now)", "route_cost_only": "score = -float(path_hops)"}
    checks = {
        "e0_protocol_hash": sha256(E0 / "PAPER_EVIDENCE_PREREGISTRATION.md") == E0_PROTOCOL_SHA256,
        "all_four_methods_declared": set(METHODS) == {"DF-ReAlert", "Random-TopK", "Nearest-front-TopK", "Lowest-route-cost-TopK"},
        "ranking_modes_present": all(k in text and v in text for k, v in required.items()),
        "random_rng_context_derived": "SeedSequence(words)" in text,
        "deterministic_sort_tiebreak": "candidates.sort(key=lambda item: (-item[0], item[1], item[2]))" in text,
        "shared_budget_constants": all(int(getattr(config, k)) > 0 for k in ("ALERT_CONFIRMATION_REALERT_TOP_M", "ALERT_CONFIRMATION_REALERT_PROBE_STEPS", "ALERT_VERIFY_WAIT_STEPS", "ALERT_CONFIRMATION_REALERT_MAX_HOPS")),
        "evaluation_seed_boundary": EVAL_SEEDS == set(range(401, 421)),
        "historical_audit_seed_boundary": AUDIT_SEEDS == {201},
    }
    ok = all(checks.values())
    OUT.joinpath("audits").mkdir(parents=True, exist_ok=True)
    receipt = {"status": "PASS" if ok else "FAIL", "checks": checks, "source_hashes": source_hashes(), "audit_seed_scope": sorted(AUDIT_SEEDS), "evaluation_seed_scope": sorted(EVAL_SEEDS)}
    (OUT / "audits" / "E1_IMPLEMENTATION_AUDIT.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    lines = ["# E1 Implementation Audit", "", f"Status: **{'PASS' if ok else 'FAIL'}**", "", *[f"- {k}: {'PASS' if v else 'FAIL'}" for k,v in checks.items()], "", "No 401–420 evaluation run was started by this audit."]
    (OUT / "audits" / "E1_IMPLEMENTATION_AUDIT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not ok: raise RuntimeError(checks)
    return receipt

def main():
    p = argparse.ArgumentParser(); p.add_argument("--mode", choices=("audit", "smoke", "run"), required=True); p.add_argument("--method", choices=tuple(METHODS)); p.add_argument("--seed", type=int)
    a = p.parse_args()
    if a.mode == "audit": print(json.dumps(audit(), indent=2)); return
    if a.mode == "smoke":
        if a.seed not in AUDIT_SEEDS: raise ValueError("E1 smoke accepts only historical audit seed 201")
        print(run_one(a.method, a.seed, trace=True, root=OUT / "audits" / "smoke_runs" / a.method / f"seed_{a.seed}")); return
    if a.seed not in EVAL_SEEDS: raise ValueError("E1 evaluation accepts only seeds 401–420")
    if not (OUT / "audits" / "E1_IMPLEMENTATION_AUDIT.json").is_file(): raise RuntimeError("run locked until implementation audit exists")
    audit_receipt = json.loads((OUT / "audits" / "E1_IMPLEMENTATION_AUDIT.json").read_text(encoding="utf-8"))
    if audit_receipt.get("status") != "PASS": raise RuntimeError("implementation audit did not PASS")
    print(run_one(a.method, a.seed))

if __name__ == "__main__": main()
