"""Core decisions for Adaptive Probabilistic Delayed-Front Re-Alert."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path

import numpy as np


FEATURE_NAMES = ("approach_score", "distance_now", "distance_delta", "front_speed",
                 "local_evidence", "probe_evidence", "route_cost", "failure_count",
                 "steps_since_failure")


@dataclass(frozen=True)
class AdaptiveDecision:
    probability: float
    candidate_budget: int
    probe_steps: int
    cooldown_steps: int


@dataclass
class FrontLikelihoodModel:
    mean: np.ndarray
    scale: np.ndarray
    weights: np.ndarray
    intercept: float = 0.0
    label: str = "future_affected"

    def predict_proba(self, features):
        x = np.asarray([features.get(name, 0.0) for name in FEATURE_NAMES], dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        margin = float(((x - self.mean) / self.scale) @ self.weights + self.intercept)
        return 1.0 / (1.0 + math.exp(-max(-35.0, min(35.0, margin))))

    def save(self, path):
        payload = {"model_type": "realert_opportunity_logistic_v1", "label": self.label,
                   "feature_names": list(FEATURE_NAMES),
                   "mean": self.mean.tolist(), "scale": self.scale.tolist(),
                   "weights": self.weights.tolist(), "intercept": self.intercept}
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path):
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if payload.get("model_type") not in {"realert_opportunity_logistic_v1", "ap_dfrealert_logistic_v1"} or tuple(payload.get("feature_names", ())) != FEATURE_NAMES:
            raise ValueError("Unsupported or incompatible AP-DFReAlert model")
        return cls(np.asarray(payload["mean"]), np.asarray(payload["scale"]),
                   np.asarray(payload["weights"]), float(payload["intercept"]),
                   str(payload.get("label", "future_affected")))


def fit_front_likelihood(x, y, l2=0.02, epochs=500, learning_rate=0.08,
                         label="future_affected"):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if x.ndim != 2 or x.shape[1] != len(FEATURE_NAMES) or len(x) != len(y):
        raise ValueError("Expected X with nine features and one label per row")
    if len(np.unique(y)) < 2:
        raise ValueError("Training labels must contain both classes")
    mean, scale = np.nanmean(x, axis=0), np.nanstd(x, axis=0)
    scale[scale < 1e-9] = 1.0
    z = np.nan_to_num((x - mean) / scale)
    w, b = np.zeros(z.shape[1]), 0.0
    for epoch in range(int(epochs)):
        margin = np.clip(z @ w + b, -30, 30)
        p = 1.0 / (1.0 + np.exp(-margin))
        eta = learning_rate / math.sqrt(1.0 + epoch / 100.0)
        w -= eta * (z.T @ (p - y) / len(y) + l2 * w)
        b -= eta * float(np.mean(p - y))
    return FrontLikelihoodModel(mean, scale, w, b, str(label))


@dataclass(frozen=True)
class APDFReAlertPolicy:
    min_candidates: int = 3
    max_candidates: int = 8
    min_probe_steps: int = 1
    max_probe_steps: int = 5
    min_cooldown_steps: int = 1
    max_cooldown_steps: int = 20
    probability_threshold: float = 0.35

    def decide(self, probability, distance_now, front_speed, uncertainty=0.0,
               candidate_density=0.0, energy_pressure=0.0, failure_count=0):
        probability = float(np.clip(probability, 0, 1))
        speed = max(0.05, float(front_speed))
        raw_budget = self.min_candidates + 2.0 * speed + 2.0 * candidate_density + 2.0 * uncertainty - 3.0 * energy_pressure
        budget = int(np.clip(round(raw_budget), self.min_candidates, self.max_candidates))
        arrival = max(1.0, float(distance_now)) / speed
        # L denotes future observation slots t+1..t+L. The +1 safety margin
        # prevents ETA=1 candidates from expiring before the arrival sample.
        probe = int(np.clip(math.ceil(arrival) + 1, self.min_probe_steps, self.max_probe_steps))
        cooldown = math.ceil(0.75 * arrival * (1.0 + 0.35 * max(0, int(failure_count))))
        cooldown = int(np.clip(cooldown, self.min_cooldown_steps, self.max_cooldown_steps))
        return AdaptiveDecision(probability, budget, probe, cooldown)

    def select(self, candidates, model):
        scored = [(model.predict_proba(row), row) for row in candidates]
        scored = [item for item in scored if item[0] >= self.probability_threshold]
        return sorted(scored, key=lambda item: item[0], reverse=True)[:self.max_candidates]
