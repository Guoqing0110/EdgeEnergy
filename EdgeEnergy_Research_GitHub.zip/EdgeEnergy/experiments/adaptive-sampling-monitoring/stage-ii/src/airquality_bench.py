"""AirQualityBench data access without destroying authentic missingness.

The yearly arrays are intentionally sliced lazily.  Loading a complete five-year
cube would require several gigabytes and is unnecessary for sampling experiments.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import pickle

import numpy as np
import pandas as pd


POLLUTANTS = ("pm25", "pm10", "no2", "o3", "so2", "co")
YEAR_SPLITS = {"train": (2021, 2022, 2023), "validation": (2024,), "test": (2025,)}


@dataclass(frozen=True)
class AirQualitySlice:
    values: np.ndarray
    masks: np.ndarray
    station_ids: np.ndarray
    pollutant: str
    year: int
    start_hour: int


class AirQualityBench:
    def __init__(self, root=None):
        default = Path(__file__).resolve().parents[1] / "data" / "airquality_experiment" / "data" / "AirQualityBench"
        self.root = Path(root or default).resolve()
        if not self.root.is_dir():
            raise FileNotFoundError(f"AirQualityBench directory not found: {self.root}")

    def _h5py(self):
        try:
            import h5py
        except ImportError as exc:
            raise RuntimeError("AirQualityBench requires h5py (install with: pip install h5py)") from exc
        return h5py

    @property
    def metadata(self):
        return pd.read_csv(self.root / "selected_nodes_metadata.csv")

    @property
    def quality(self):
        return pd.read_csv(self.root / "global_quality_stats.csv")

    def graph(self):
        with (self.root / "adj_mx_10.pkl").open("rb") as handle:
            payload = pickle.load(handle)
        required = {"sensor_ids", "id_to_ind", "adj_mx"}
        if not required.issubset(payload):
            raise ValueError(f"Adjacency payload lacks {sorted(required - set(payload))}")
        return payload

    def select_stations(self, n, pollutant="pm25", seed=1, min_coverage=0.25):
        """Select a deterministic, connected graph subset with usable coverage.

        A seeded graph expansion preserves spatial neighborhoods.  Restarts cover
        disconnected components; no time-series values or test-year labels are used.
        """
        pollutant = pollutant.lower()
        if pollutant not in POLLUTANTS:
            raise ValueError(f"Unknown pollutant {pollutant!r}")
        graph = self.graph()
        ids = np.asarray([str(x) for x in graph["sensor_ids"]])
        quality = self.quality.set_index(self.quality.station_id.astype(str))
        coverage = quality.reindex(ids)[f"{pollutant}_coverage"].fillna(0).to_numpy()
        eligible = np.flatnonzero(coverage >= float(min_coverage))
        if n > len(eligible):
            raise ValueError(f"Requested {n} stations, but only {len(eligible)} meet coverage >= {min_coverage}")
        eligible_set = set(map(int, eligible))
        adjacency = np.asarray(graph["adj_mx"])
        rng = np.random.default_rng(seed)
        selected, seen = [], set()
        starts = list(eligible[rng.permutation(len(eligible))])
        for start in starts:
            if len(selected) >= n:
                break
            queue = [int(start)]
            seen.add(int(start))
            for current in queue:
                if current in eligible_set:
                    selected.append(current)
                    if len(selected) >= n:
                        break
                neighbors = np.flatnonzero(adjacency[current] > 0)
                neighbors = neighbors[rng.permutation(len(neighbors))]
                for neighbor in neighbors:
                    neighbor = int(neighbor)
                    if neighbor in eligible_set and neighbor not in seen:
                        seen.add(neighbor)
                        queue.append(neighbor)
        return np.asarray(selected[:n], dtype=int)

    def induced_graph(self, indices):
        payload = self.graph()
        idx = np.asarray(indices, dtype=int)
        matrix = np.asarray(payload["adj_mx"])[np.ix_(idx, idx)].copy()
        ids = np.asarray(payload["sensor_ids"], dtype=str)[idx]
        return {"sensor_ids": ids, "id_to_ind": {v: i for i, v in enumerate(ids)}, "adj_mx": matrix}

    def read(self, year, pollutant="pm25", station_indices=None, start_hour=0, hours=None):
        pollutant = pollutant.lower()
        if year not in range(2021, 2026) or pollutant not in POLLUTANTS:
            raise ValueError("Expected year 2021..2025 and a supported pollutant")
        h5py = self._h5py()
        path = self.root / f"aq_compact_{year}.h5"
        stop = None if hours is None else int(start_hour) + int(hours)
        with h5py.File(path, "r") as handle:
            params = [x.decode() if isinstance(x, bytes) else str(x) for x in handle["params"][:]]
            normalized = [x.lower().replace(".", "").replace("_", "") for x in params]
            aliases = {"pm25": "pm25", "pm10": "pm10", "no2": "no2", "o3": "o3", "so2": "so2", "co": "co"}
            channel = normalized.index(aliases[pollutant])
            station_ids = np.asarray(handle["station_ids"][:])
            values = np.asarray(handle["values"][int(start_hour):stop, :, channel], dtype=np.float32)
            masks = np.asarray(handle["masks"][int(start_hour):stop, :, channel], dtype=bool)
        if station_indices is not None:
            idx = np.asarray(station_indices, dtype=int)
            values, masks, station_ids = values[:, idx], masks[:, idx], station_ids[idx]
        # Missing values remain missing and are never interpolated.
        values = values.copy()
        values[~masks] = np.nan
        return AirQualitySlice(values, masks, station_ids, pollutant, year, int(start_hour))

