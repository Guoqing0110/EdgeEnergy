"""Alert propagation policies shared by simulations and experiments.

The policy is deliberately rule based: KF/GLR remains the detector, while this
module only decides how far an alert should travel.  Keeping this decision
pure makes it straightforward to test and later replace with a learned ranker.
"""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class AlertContext:
    detector_score: float = 0.0
    confirmed_neighbors: int = 0
    residual_energy_ratio: float = 1.0
    diffusion_speed: float = 0.0


@dataclass(frozen=True)
class AdaptiveHopPolicy:
    min_hops: int = 1
    max_hops: int = 3
    medium_score: float = 10.0
    high_score: float = 20.0
    confirmation_threshold: int = 2
    fast_diffusion_threshold: float = 0.5
    low_energy_threshold: float = 0.2

    def choose_hops(self, context: AlertContext) -> int:
        """Return a bounded hop count using risk evidence and energy guardrails."""
        score = context.detector_score
        score = float(score) if score is not None and math.isfinite(float(score)) else 0.0
        hops = self.min_hops
        if score >= self.high_score:
            hops = self.max_hops
        elif score >= self.medium_score:
            hops = min(self.max_hops, self.min_hops + 1)

        if context.confirmed_neighbors >= self.confirmation_threshold:
            hops = min(self.max_hops, hops + 1)
        if context.diffusion_speed >= self.fast_diffusion_threshold:
            hops = min(self.max_hops, hops + 1)

        # Low remaining energy cannot suppress the essential one-hop warning,
        # but it prevents an expensive outer propagation ring.
        if context.residual_energy_ratio <= self.low_energy_threshold:
            hops = min(hops, max(self.min_hops, self.max_hops - 1))
        return max(self.min_hops, min(self.max_hops, int(hops)))


def bfs_routes(adjacency, source, max_hops, allowed_nodes=None):
    """Return shortest-path parent/hop maps for one alert broadcast.

    Each discovered tree edge corresponds to exactly one TX and one RX.  This
    avoids charging a multi-hop alert as if the source directly contacted all
    nodes in its k-hop ball.
    """
    allowed = None if allowed_nodes is None else set(allowed_nodes)
    hops = {source: 0}
    parents = {}
    queue = [source]
    for current in queue:
        if hops[current] >= max(0, int(max_hops)):
            continue
        for neighbor in adjacency.get(current, []):
            if allowed is not None and neighbor not in allowed:
                continue
            if neighbor in hops:
                continue
            hops[neighbor] = hops[current] + 1
            parents[neighbor] = current
            queue.append(neighbor)
    return parents, hops

