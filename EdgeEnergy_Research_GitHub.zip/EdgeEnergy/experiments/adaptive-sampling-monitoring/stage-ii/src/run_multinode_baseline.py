import os
import hashlib
import json
import logging
import numpy as np
import pandas as pd
from src.data_loader import load_raw_data, preprocess_data, get_sensor_data
from src.models import Node, Sentinel, SimulationEnvironment
from src.plotter import plot_network_adjacency, plot_node_roles, plot_degree_distribution, plot_metrics_distribution, plot_connectivity_heatmap, plot_sentinel_vs_normal_boxplot, plot_sentinel_detection_bar, plot_alert_detection_timeline, plot_node_kf_anomaly_diagnostic, plot_event_onset_detection_timeline, plot_deadline_hit_rates, plot_task8_metric_bars, plot_cost_benefit_point
from src.sentinel_selector import SentinelSelector
from src.run_baseline import setup_experiment_output
import src.config as config
from src.unified_metrics import calc_rmse, compute_energy_proxy_metrics, compute_reconstruction_rmse_metrics

_INPUT_CACHE = {}
_AIRQUALITY_GRAPH_OVERRIDE = None


def _adjacency_hash(adjacency):
    edges = sorted((int(src), int(dst)) for src, neighbors in adjacency.items() for dst in neighbors)
    return hashlib.sha256(json.dumps(edges, separators=(",", ":")).encode("utf-8")).hexdigest()


def _load_experiment_inputs():
    global _AIRQUALITY_GRAPH_OVERRIDE
    if str(getattr(config, "DATASET_MODE", "intel")).lower() == "synthetic":
        count = max(8, int(getattr(config, "SYNTHETIC_NODE_COUNT", 54)))
        side = int(np.ceil(np.sqrt(count)))
        positions = {i + 1: {"x": float(i % side) * 3.0, "y": float(i // side) * 3.0} for i in range(count)}
        timeline = pd.date_range(config.START_TIME, config.END_TIME, freq=f"{int(config.DT_SEC)}s")
        rng = np.random.default_rng(int(getattr(config, "SYNTHETIC_BACKGROUND_SEED", 1001)))
        common = np.zeros(len(timeline), dtype=float)
        innovations = rng.normal(0.0, float(getattr(config, "SYNTHETIC_NOISE_STD", 0.18)), len(timeline))
        for k in range(1, len(common)):
            common[k] = 0.92 * common[k - 1] + innovations[k]
        phase = np.linspace(0.0, 2.0 * np.pi, len(timeline), endpoint=False)
        rows = []
        for nid in range(1, count + 1):
            local = rng.normal(0.0, 0.08, len(timeline))
            temperature = 22.0 + 1.4 * np.sin(phase + 0.07 * nid) + 0.35 * common + local + 0.015 * nid
            rows.append(pd.DataFrame({"moteid": nid, "temperature": temperature}, index=timeline))
        return pd.concat(rows).sort_index(), positions
    if str(getattr(config, "DATASET_MODE", "intel")).lower() == "airquality":
        from src.airquality_bench import AirQualityBench
        bench = AirQualityBench(getattr(config, "AIRQUALITY_BENCH_DIR", None))
        count = int(getattr(config, "AIRQUALITY_NODE_COUNT", 30))
        pollutant = str(getattr(config, "AIRQUALITY_POLLUTANT", "pm25"))
        pool_count = min(3720, max(count, count * 5))
        pool_indices = bench.select_stations(
            pool_count, pollutant, int(getattr(config, "RANDOM_SEED", 1)),
            float(getattr(config, "AIRQUALITY_MIN_COVERAGE", 0.25)),
        )
        pool_sample = bench.read(
            int(getattr(config, "AIRQUALITY_YEAR", 2025)), pollutant, pool_indices,
            int(getattr(config, "AIRQUALITY_START_HOUR", 0)),
            int(getattr(config, "AIRQUALITY_HOURS", 48)),
        )
        usable_set = set(map(int, np.flatnonzero(pool_sample.masks.any(axis=0))))
        pool_graph = np.asarray(bench.induced_graph(pool_indices)["adj_mx"])
        pool_graph = (pool_graph > 0) | (pool_graph.T > 0)
        components = []
        unseen = set(usable_set)
        while unseen:
            start_node = min(unseen)
            queue, component = [start_node], []
            unseen.remove(start_node)
            for current in queue:
                component.append(current)
                for neighbor in sorted(map(int, np.flatnonzero(pool_graph[current]))):
                    if neighbor in unseen:
                        unseen.remove(neighbor); queue.append(neighbor)
            components.append(component)
        largest = max(components, key=lambda x: (len(x), -min(x)))
        component_set = set(largest)
        degrees = {i: int(sum(int(j) in component_set for j in np.flatnonzero(pool_graph[i]))) for i in largest}
        chosen = [max(largest, key=lambda i: (degrees[i], -i))]
        remaining = component_set - set(chosen)
        while remaining and len(chosen) < count:
            selected_set = set(chosen)
            candidate = max(remaining, key=lambda i: (
                sum(int(j) in selected_set for j in np.flatnonzero(pool_graph[i])), degrees[i], -i
            ))
            chosen.append(candidate)
            remaining.remove(candidate)
        usable = np.asarray(chosen, dtype=int)
        if len(usable) < count:
            raise ValueError(f"Largest observed connected component has only {len(usable)} stations")
        indices = pool_indices[usable]
        sample = type(pool_sample)(pool_sample.values[:, usable], pool_sample.masks[:, usable],
                                   pool_sample.station_ids[usable], pool_sample.pollutant,
                                   pool_sample.year, pool_sample.start_hour)
        scaler = pd.read_csv(bench.root / "scaler.csv").set_index("parameter").loc[pollutant]
        normalized_values = (sample.values - float(scaler["mean"])) / max(float(scaler["std"]), 1e-9)
        sample = type(sample)(normalized_values.astype(np.float32), sample.masks, sample.station_ids,
                              sample.pollutant, sample.year, sample.start_hour)
        native = bench.induced_graph(indices)["adj_mx"]
        # The source file is directed k=10. Gate A uses its undirected closure
        # for physical diffusion/communication while preserving only native edges.
        native = (np.asarray(native) > 0) | (np.asarray(native).T > 0)
        _AIRQUALITY_GRAPH_OVERRIDE = {
            local: sorted(int(j + 1) for j in np.flatnonzero(native[local - 1]) if int(j + 1) != local)
            for local in range(1, count + 1)
        }
        start = pd.Timestamp(f"{int(getattr(config, 'AIRQUALITY_YEAR', 2025))}-01-01") + pd.Timedelta(
            hours=int(getattr(config, "AIRQUALITY_START_HOUR", 0))
        )
        timeline = pd.date_range(start, periods=len(sample.values), freq="1h")
        rows = []
        metadata = bench.metadata.set_index(bench.metadata.station_id.astype(str))
        positions = {}
        # Dense simulation IDs keep all legacy anomaly-source settings valid;
        # the manifest retains the original AirQualityBench station IDs.
        for local, (graph_idx, station_id) in enumerate(zip(indices, sample.station_ids), start=1):
            values = sample.values[:, local - 1]
            rows.append(pd.DataFrame({"moteid": local, "temperature": values}, index=timeline))
            key = str(station_id.decode() if isinstance(station_id, bytes) else station_id)
            meta = metadata.loc[key]
            positions[local] = {"x": float(meta["lon"]), "y": float(meta["lat"]),
                                "station_id": key, "graph_index": int(graph_idx)}
        return pd.concat(rows).sort_index(), positions
    use_cache = bool(getattr(config, "USE_DATA_CACHE", True))
    data_file = config.DATA_FILE
    loc_file = config.MOTE_LOC_FILE
    cache_key = (
        os.path.abspath(data_file),
        os.path.getmtime(data_file) if os.path.exists(data_file) else None,
        os.path.abspath(loc_file),
        os.path.getmtime(loc_file) if os.path.exists(loc_file) else None
    )
    if use_cache and _INPUT_CACHE.get("key") == cache_key:
        return _INPUT_CACHE["df"], _INPUT_CACHE["node_positions"]
    raw_df = load_raw_data(data_file)
    if raw_df is None:
        raise ValueError("Failed to load data.")
    df = preprocess_data(raw_df)
    node_positions = load_mote_positions(loc_file)
    if use_cache:
        _INPUT_CACHE["key"] = cache_key
        _INPUT_CACHE["df"] = df
        _INPUT_CACHE["node_positions"] = node_positions
    return df, node_positions


def load_mote_positions(path):
    loc_df = pd.read_csv(path, sep=r"\s+", names=["moteid", "x", "y"])
    loc_df["moteid"] = loc_df["moteid"].astype(int)
    return {int(row["moteid"]): {"x": float(row["x"]), "y": float(row["y"])} for _, row in loc_df.iterrows()}


def prepare_multinode_data(df, node_ids, start_time, end_time, dt_sec):
    per_node_data = {}
    for node_id in node_ids:
        sensor_df = get_sensor_data(df, node_id, start_time, end_time)
        if sensor_df.empty:
            raise ValueError(f"Node {node_id} has no raw data inside the requested time window, so a strict shared timeline cannot be built.")
        aligned = sensor_df[["temperature"]].copy()
        # Intel contains occasional duplicate mote/timestamp rows.  Collapse
        # them deterministically before reindexing; pandas cannot reindex a
        # non-unique DatetimeIndex and silently choosing a row is irreproducible.
        aligned = aligned.groupby(level=0, sort=True).mean()
        if str(getattr(config, "DATASET_MODE", "intel")).lower() == "airquality":
            # Hourly rows are already aligned. Preserve NaNs as unavailable
            # observations; the simulator skips sampling, injection and probe
            # upgrade whenever ground truth is absent.
            full_index = pd.date_range(start=start_time, end=end_time, freq=f"{dt_sec}s")
            per_node_data[node_id] = aligned.reindex(full_index)
            continue
        aligned = aligned.reindex(aligned.index.union(pd.DatetimeIndex([start_time, end_time]))).sort_index()
        aligned["temperature"] = aligned["temperature"].interpolate(method="time", limit_direction="both")
        full_index = pd.date_range(start=start_time, end=end_time, freq=f"{dt_sec}s")
        aligned = aligned.reindex(aligned.index.union(full_index)).sort_index()
        aligned["temperature"] = aligned["temperature"].interpolate(method="time", limit_direction="both")
        aligned = aligned.reindex(full_index)
        if aligned["temperature"].isna().any():
            raise ValueError(f"Node {node_id} has no valid temperature values after resampling, so a strict shared timeline cannot be built.")
        per_node_data[node_id] = aligned
    aligned_index = full_index
    aligned_data = {}
    for node_id, node_df in per_node_data.items():
        aligned_data[node_id] = node_df.loc[aligned_index].copy()
    return aligned_data, aligned_index


def load_connectivity_weights(path, node_ids):
    df = pd.read_csv(path, sep=r"\s+", names=["src", "dst", "weight"])
    df["src"] = df["src"].astype(int)
    df["dst"] = df["dst"].astype(int)
    node_set = set(node_ids)
    df = df[df["src"].isin(node_set) & df["dst"].isin(node_set)]
    weights = {node_id: {} for node_id in node_ids}
    for row in df.itertuples(index=False):
        weights[int(row.src)][int(row.dst)] = float(row.weight)
    return weights


def parse_event_ids(raw_value):
    if raw_value is None:
        return set()
    if isinstance(raw_value, float) and np.isnan(raw_value):
        return set()
    text = str(raw_value).strip()
    if text == '':
        return set()
    return set(int(x) for x in text.split(',') if x.strip() != '')


def compute_task6_metrics(nodes, node_ids, sentinel_ids, aligned_index, env):
    steps = len(aligned_index)
    gt_step_flags = np.zeros(steps, dtype=bool)
    det_step_flags = np.zeros(steps, dtype=bool)
    event_active_step_map = {}
    event_start_idx = {}
    for node_id in node_ids:
        history = nodes[node_id].history
        gt_flags = history["gt_anomaly_flag"][:steps]
        event_texts = history["gt_event_ids"][:steps]
        for i in range(steps):
            if gt_flags[i] == 1:
                gt_step_flags[i] = True
            event_ids = parse_event_ids(event_texts[i])
            for event_id in event_ids:
                event_active_step_map.setdefault(event_id, set()).add(i)
                if event_id not in event_start_idx or i < event_start_idx[event_id]:
                    event_start_idx[event_id] = i
    for node_id in sentinel_ids:
        history = nodes[node_id].history
        det_flags = history["detector_trigger_flag"][:steps]
        for i in range(steps):
            if det_flags[i] == 1:
                det_step_flags[i] = True
    tp = int(np.sum(det_step_flags & gt_step_flags))
    fp = int(np.sum(det_step_flags & (~gt_step_flags)))
    fn = int(np.sum((~det_step_flags) & gt_step_flags))
    tn = int(np.sum((~det_step_flags) & (~gt_step_flags)))
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    delay_rows = []
    detected_event_count = 0
    for event_id in sorted(event_start_idx.keys()):
        start_idx = event_start_idx[event_id]
        active_steps = sorted(event_active_step_map.get(event_id, set()))
        detected_idx = None
        for i in active_steps:
            if det_step_flags[i]:
                detected_idx = i
                break
        if detected_idx is None:
            delay_steps = np.nan
            detected = 0
        else:
            delay_steps = int(detected_idx - start_idx)
            detected = 1
            detected_event_count += 1
        delay_rows.append({
            "event_id": event_id,
            "event_start_time": aligned_index[start_idx],
            "detected": detected,
            "detection_time": aligned_index[detected_idx] if detected_idx is not None else pd.NaT,
            "delay_steps": delay_steps,
            "delay_seconds": float(delay_steps * (aligned_index[1] - aligned_index[0]).total_seconds()) if detected_idx is not None else np.nan
        })
    delay_df = pd.DataFrame(delay_rows, columns=["event_id", "event_start_time", "detected", "detection_time", "delay_steps", "delay_seconds"])
    if len(delay_df) > 0:
        mean_delay_steps = float(delay_df["delay_steps"].dropna().mean()) if delay_df["delay_steps"].notna().any() else np.nan
        mean_delay_seconds = float(delay_df["delay_seconds"].dropna().mean()) if delay_df["delay_seconds"].notna().any() else np.nan
    else:
        mean_delay_steps = np.nan
        mean_delay_seconds = np.nan
    total_sampled = int(sum(np.sum(nodes[node_id].history["sampled"][:steps]) for node_id in node_ids))
    max_sampling = int(len(node_ids) * steps)
    sampling_ratio = total_sampled / max_sampling if max_sampling > 0 else np.nan
    comm_records = getattr(env, "node_comm_energy_records", [])
    total_tx_message_count = int(sum(int(x.get("peer_count", 0)) for x in comm_records if str(x.get("step_type", "")).endswith("_tx")))
    total_rx_message_count = int(sum(int(x.get("peer_count", 0)) for x in comm_records if str(x.get("step_type", "")).endswith("_rx")))
    control_bytes = int(getattr(config, "CONTROL_PACKET_BYTES", 36))
    probe_bytes = int(getattr(config, "PROBE_PACKET_BYTES", 24))
    measurement_bytes = int(getattr(config, "MEASUREMENT_PACKET_BYTES", 16))
    ack_bytes = int(getattr(config, "ACK_PACKET_BYTES", 11))
    confirmation_bytes = int(getattr(config, "CONFIRMATION_PACKET_BYTES", 24))
    probe_request_tx = int(sum(int(x.get("peer_count", 0)) for x in comm_records if "probe" in str(x.get("step_type", "")) and str(x.get("step_type", "")).endswith("_tx")))
    probe_request_rx = int(sum(int(x.get("peer_count", 0)) for x in comm_records if "probe" in str(x.get("step_type", "")) and str(x.get("step_type", "")).endswith("_rx")))
    probe_report_packets = int(getattr(env, "event_relay_stats", {}).get("probe_trigger_count", 0))
    confirmation_packets = int(sum(len(e.get("confirmed_records", {})) for e in getattr(env, "event_relay_events", {}).values()))
    measurement_packets = total_sampled if bool(getattr(config, "MEASUREMENT_REPORT_ENABLED", True)) else 0
    base_tx_bytes = (total_tx_message_count - probe_request_tx) * control_bytes + probe_request_tx * probe_bytes
    base_rx_bytes = (total_rx_message_count - probe_request_rx) * control_bytes + probe_request_rx * probe_bytes
    extra_packets = probe_report_packets + confirmation_packets + measurement_packets
    extra_bytes = probe_report_packets * probe_bytes + confirmation_packets * confirmation_bytes + measurement_packets * measurement_bytes
    ack_packets = (total_rx_message_count + extra_packets) if bool(getattr(config, "ACK_ENABLED", True)) else 0
    packet_tx_count = total_tx_message_count + extra_packets + ack_packets
    packet_rx_count = total_rx_message_count + extra_packets + ack_packets
    tx_bytes = base_tx_bytes + extra_bytes + ack_packets * ack_bytes
    rx_bytes = base_rx_bytes + extra_bytes + ack_packets * ack_bytes
    energy_proxy = compute_energy_proxy_metrics(
        sample_count=total_sampled,
        tx_peer_count=packet_tx_count,
        rx_peer_count=packet_rx_count,
        idle_steps=len(node_ids) * steps,
        computation_count=len(node_ids) * steps + total_sampled + total_tx_message_count + total_rx_message_count,
        tx_bytes=tx_bytes, rx_bytes=rx_bytes,
    )
    detection_metrics = {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "detection_probability": detected_event_count / len(event_start_idx) if event_start_idx else np.nan,
        "temporal_detection_recall": recall,
        "false_positive_rate": fp / (fp + tn) if (fp + tn) > 0 else np.nan,
        "normal_false_alarm_steps": fp,
        "f1": f1,
        "gt_positive_steps": int(np.sum(gt_step_flags)),
        "det_positive_steps": int(np.sum(det_step_flags)),
        "event_count": int(len(event_start_idx)),
        "detected_event_count": int(detected_event_count),
        "missed_event_count": int(len(event_start_idx) - detected_event_count),
        "detection_delay_mean_steps": mean_delay_steps,
        "detection_delay_mean_seconds": mean_delay_seconds
    }
    energy_metrics = {
        "total_sampled_count": total_sampled,
        "sampling_ratio_vs_full": sampling_ratio,
        "alert_message_count": total_rx_message_count,
        "sentinel_trigger_count": total_tx_message_count,
        # Routed-command parent counts include full-alert commands and probe
        # requests.  The disjoint class fields below prevent double counting in
        # packet-breakdown tables while preserving the legacy parent counters.
        "routed_command_tx_operations": total_tx_message_count,
        "routed_command_rx_operations": total_rx_message_count,
        "control_tx_packets": total_tx_message_count,
        "control_rx_packets": total_rx_message_count,
        "full_alert_command_tx_operations": total_tx_message_count - probe_request_tx,
        "full_alert_command_rx_operations": total_rx_message_count - probe_request_rx,
        "probe_request_tx_packets": probe_request_tx,
        "probe_request_rx_packets": probe_request_rx,
        "probe_request_packets": probe_request_rx,
        "probe_report_packets": probe_report_packets,
        "probe_report_tx_operations": probe_report_packets,
        "probe_report_rx_operations": probe_report_packets,
        "confirmation_packets": confirmation_packets,
        "confirmation_tx_operations": confirmation_packets,
        "confirmation_rx_operations": confirmation_packets,
        "measurement_packets": measurement_packets,
        "measurement_tx_operations": measurement_packets,
        "measurement_rx_operations": measurement_packets,
        "ack_packets": ack_packets,
        "ack_tx_operations": ack_packets,
        "ack_rx_operations": ack_packets,
        "packet_tx_count": packet_tx_count,
        "packet_rx_count": packet_rx_count,
        "total_tx_bytes": tx_bytes,
        "total_rx_bytes": rx_bytes,
        **energy_proxy,
    }
    return detection_metrics, delay_df, energy_metrics


def _select_task8_match_adjacency(env):
    graph_name = str(config.TASK8_EVENT_MATCH_GRAPH).strip().lower()
    if graph_name == 'communication':
        return env.communication_adjacency
    return env.adjacency


def _bounded_bfs_hops(adjacency, source, max_hops):
    visited = {source: 0}
    queue = [source]
    head = 0
    while head < len(queue):
        cur = queue[head]
        head += 1
        cur_hop = visited[cur]
        if cur_hop >= max_hops:
            continue
        for nxt in adjacency.get(cur, []):
            if nxt in visited:
                continue
            visited[nxt] = cur_hop + 1
            queue.append(nxt)
    return visited


def _reconstruct_linear_from_samples(truth_matrix, sample_mask):
    truth_arr = np.asarray(truth_matrix, dtype=float)
    mask_arr = np.asarray(sample_mask, dtype=bool)
    estimated = np.full_like(truth_arr, np.nan, dtype=float)
    for idx in range(truth_arr.shape[0]):
        observed = np.where(mask_arr[idx], truth_arr[idx], np.nan)
        series = pd.Series(observed)
        estimated[idx] = series.interpolate(method="linear", limit_direction="both").to_numpy(dtype=float)
    return estimated


def _stateless_measurement_noise(seed, node_id, timestamp, variance):
    timestamp_ns = int(pd.Timestamp(timestamp).value)
    seed_words = [
        int(seed) & 0xFFFFFFFF, int(node_id) & 0xFFFFFFFF,
        timestamp_ns & 0xFFFFFFFF, (timestamp_ns >> 32) & 0xFFFFFFFF,
    ]
    rng = np.random.default_rng(np.random.SeedSequence(seed_words))
    return float(rng.normal(0.0, np.sqrt(float(variance))))


def _compute_no_alert_baseline_rmse(nodes, node_ids, aligned_index, injected_truth_per_node, gt_flags_per_node):
    steps = len(aligned_index)
    if steps == 0:
        return np.nan
    ref_node = nodes[node_ids[0]]
    F = ref_node.F.copy()
    H = ref_node.H.copy()
    Q = ref_node.Q.copy()
    R = ref_node.R.copy()
    gamma = ref_node.gamma
    P0 = np.eye(ref_node.P.shape[0]) * config.P0_SCALE
    err_sq = []
    for node_id in node_ids:
        truth = np.asarray(injected_truth_per_node[node_id], dtype=float)
        initial_temp = float(truth[0])
        x0 = np.array([[initial_temp], [0.0]])
        baseline_node = Node(
            node_id=node_id,
            initial_state=x0,
            P0=P0.copy(),
            F=F,
            H=H,
            Q=Q,
            R=R,
            threshold_gamma=gamma
        )
        gt = gt_flags_per_node[node_id]
        sample_mask = np.zeros(steps, dtype=bool)
        sampled_values = np.full(steps, np.nan, dtype=float)
        for i in range(steps):
            baseline_node.predict()
            if baseline_node.should_sample():
                sample_mask[i] = True
                z = truth[i] + _stateless_measurement_noise(
                    config.RANDOM_SEED, node_id, aligned_index[i], R[0, 0]
                )
                sampled_values[i] = z
                baseline_node.update(z)
            else:
                baseline_node.update(None)
        reconstructed = _reconstruct_linear_from_samples(
            sampled_values.reshape(1, -1), sample_mask.reshape(1, -1)
        )[0]
        for i in range(steps):
            if gt[i] == 1 and np.isfinite(truth[i]) and np.isfinite(reconstructed[i]):
                diff = float(reconstructed[i] - truth[i])
                err_sq.append(diff * diff)
    if len(err_sq) == 0:
        return np.nan
    return float(np.sqrt(np.mean(err_sq)))


def compute_task8_metrics(nodes, node_ids, sentinel_ids, aligned_index, env, detection_metrics, energy_metrics, aligned_data):
    steps = len(aligned_index)
    time_to_idx = {ts: i for i, ts in enumerate(aligned_index)}
    gt_flags_per_node = {node_id: np.array(nodes[node_id].history["gt_anomaly_flag"][:steps], dtype=int) for node_id in node_ids}
    mode_per_node = {node_id: np.array([1 if m == 'alert' else 0 for m in nodes[node_id].history["mode"][:steps]], dtype=int) for node_id in node_ids}
    sampled_per_node = {node_id: np.array(nodes[node_id].history["sampled"][:steps], dtype=int) for node_id in node_ids}
    det_flags_per_sentinel = {
        sid: (np.array(nodes[sid].history["detector_trigger_flag"][:steps], dtype=int) == 1)
        for sid in sentinel_ids
    }
    any_sentinel_det_step = np.zeros(steps, dtype=bool)
    for sid in sentinel_ids:
        any_sentinel_det_step = any_sentinel_det_step | det_flags_per_sentinel[sid]
    event_start = {}
    event_nodes = {}
    event_active_nodes = {}
    for node_id in node_ids:
        events = nodes[node_id].history["gt_event_ids"][:steps]
        for i, raw in enumerate(events):
            for eid in parse_event_ids(raw):
                event_nodes.setdefault(eid, set()).add(node_id)
                event_active_nodes.setdefault(eid, {}).setdefault(i, set()).add(node_id)
                if eid not in event_start or i < event_start[eid]:
                    event_start[eid] = i
    onset_window = max(0, int(config.TASK8_ONSET_WINDOW_STEPS))
    match_max_hops = max(0, int(config.TASK8_EVENT_MATCH_MAX_HOPS))
    match_adjacency = _select_task8_match_adjacency(env)
    sentinel_hop_maps = {sid: _bounded_bfs_hops(match_adjacency, sid, match_max_hops) for sid in sentinel_ids}
    detection_source = str(config.TASK8_DETECTION_SOURCE).strip().lower()
    oracle_det_step_flags = np.zeros(steps, dtype=bool)
    if detection_source == 'oracle_alert':
        for event in env.oracle_alert_events:
            idx = time_to_idx.get(event["time"], None)
            if idx is not None and 0 <= idx < steps:
                oracle_det_step_flags[idx] = True
    event_candidate_sentinels = {}
    for eid, nodes_set in event_nodes.items():
        candidates = []
        for sid in sentinel_ids:
            hop_map = sentinel_hop_maps[sid]
            if any(nid in hop_map for nid in nodes_set):
                candidates.append(sid)
        event_candidate_sentinels[eid] = candidates
    event_rows = []
    detected_events = 0
    odd_values = []
    for eid in sorted(event_start.keys()):
        s = event_start[eid]
        end = min(steps - 1, s + onset_window)
        detected_idx = None
        candidate_sids = event_candidate_sentinels.get(eid, [])
        for i in range(s, end + 1):
            active_nodes_i = event_active_nodes.get(eid, {}).get(i, set())
            if len(active_nodes_i) == 0:
                continue
            if detection_source == 'oracle_alert':
                if oracle_det_step_flags[i]:
                    detected_idx = i
                    break
            matched = False
            for sid in candidate_sids:
                if not det_flags_per_sentinel[sid][i]:
                    continue
                hop_map = sentinel_hop_maps[sid]
                if any(nid in hop_map for nid in active_nodes_i):
                    matched = True
                    break
            if matched:
                detected_idx = i
                break
        detected = 1 if detected_idx is not None else 0
        if detected:
            detected_events += 1
            odd_values.append(detected_idx - s)
        event_rows.append({
            "event_id": eid,
            "event_start_step": s,
            "event_start_time": aligned_index[s],
            "onset_window_steps": onset_window,
            "detected_in_window": detected,
            "detected_step": detected_idx if detected_idx is not None else np.nan,
            "onset_delay_steps": (detected_idx - s) if detected_idx is not None else np.nan
        })
    event_df = pd.DataFrame(event_rows)
    total_events = len(event_rows)
    edr = detected_events / total_events if total_events > 0 else np.nan
    odd_mean = float(np.mean(odd_values)) if len(odd_values) > 0 else np.nan
    deadline_rows = []
    for d in config.TASK8_DEADLINE_STEPS:
        d = int(d)
        hit = 0
        for row in event_rows:
            if row["detected_in_window"] == 1 and row["onset_delay_steps"] <= d:
                hit += 1
        hit_rate = hit / total_events if total_events > 0 else np.nan
        deadline_rows.append({"deadline_steps": d, "hit_count": hit, "event_count": total_events, "hit_rate": hit_rate})
    deadline_df = pd.DataFrame(deadline_rows)
    alert_prec_hit = 0
    alert_prec_total = 0
    prec_delta = max(0, int(config.TASK8_ALERT_PRECISION_FUTURE_STEPS))
    for event in env.alert_events:
        t = time_to_idx.get(event["time"], None)
        if t is None:
            continue
        if t < 0 or t >= steps:
            continue
        t_end = min(steps - 1, t + prec_delta)
        for nid in event["neighbors"]:
            alert_prec_total += 1
            if np.any(gt_flags_per_node[nid][t:t_end + 1] == 1):
                alert_prec_hit += 1
    alert_precision = alert_prec_hit / alert_prec_total if alert_prec_total > 0 else np.nan
    coverage_high_threshold = float(config.TASK8_COVERAGE_HIGH_THRESHOLD)
    sentinel_set = set(sentinel_ids)
    coverage_legacy_vals = []
    coverage_vals = []
    coverage_event_alert_node_vals = []
    coverage_alert_only_vals = []
    coverage_sampling_only_vals = []
    anomaly_window_total = 0
    anomaly_window_sampled = 0
    useful_node_time_total = 0
    affected_node_time_total = 0
    for row in event_rows:
        eid = row["event_id"]
        active_map = event_active_nodes.get(eid, {})
        if len(active_map) == 0:
            continue
        gt_total_all = 0
        covered_all = 0
        covered_alert_only_all = 0
        covered_sampling_only_all = 0
        gt_total = 0
        covered = 0
        affected_nodes = set()
        active_steps = sorted(active_map.keys())
        for step_idx, step_nodes in active_map.items():
            affected_nodes.update(step_nodes)
            for nid in step_nodes:
                gt_total_all += 1
                if sampled_per_node[nid][step_idx] == 1:
                    covered_sampling_only_all += 1
                if mode_per_node[nid][step_idx] == 1:
                    covered_alert_only_all += 1
                if mode_per_node[nid][step_idx] == 1 and sampled_per_node[nid][step_idx] == 1:
                    covered_all += 1
                anomaly_window_total += 1
                if sampled_per_node[nid][step_idx] == 1:
                    anomaly_window_sampled += 1
                if nid in sentinel_set:
                    continue
                gt_total += 1
                if mode_per_node[nid][step_idx] == 1 and sampled_per_node[nid][step_idx] == 1:
                    covered += 1
        if gt_total_all > 0:
            useful_node_time_total += covered_all
            affected_node_time_total += gt_total_all
            coverage_vals.append(covered_all / gt_total_all)
            coverage_alert_only_vals.append(covered_alert_only_all / gt_total_all)
            coverage_sampling_only_vals.append(covered_sampling_only_all / gt_total_all)
        if gt_total > 0:
            coverage_legacy_vals.append(covered / gt_total)
        if len(affected_nodes) > 0:
            uncovered_count = 0
            for nid in affected_nodes:
                node_active_steps = [
                    j for j in active_steps if nid in active_map.get(j, set())
                ]
                if not any(
                    mode_per_node[nid][j] == 1 and sampled_per_node[nid][j] == 1
                    for j in node_active_steps
                ):
                    uncovered_count += 1
            coverage_event_alert_node_vals.append(1.0 - (uncovered_count / len(affected_nodes)))
    # Union over ground-truth node-times prevents overlapping events from
    # counting the same physical observation more than once.
    union_denominator = int(sum(int(gt_flags_per_node[nid][i] == 1) for nid in node_ids for i in range(steps)))
    union_numerator = int(sum(int(gt_flags_per_node[nid][i] == 1 and mode_per_node[nid][i] == 1
                                  and sampled_per_node[nid][i] == 1) for nid in node_ids for i in range(steps)))
    alert_coverage_l = float(union_numerator / union_denominator) if union_denominator > 0 else np.nan
    alert_coverage_event = float(np.mean(coverage_event_alert_node_vals)) if len(coverage_event_alert_node_vals) > 0 else np.nan
    alert_coverage_alert_only = float(np.mean(coverage_alert_only_vals)) if len(coverage_alert_only_vals) > 0 else np.nan
    alert_coverage_sampling_only = float(np.mean(coverage_sampling_only_vals)) if len(coverage_sampling_only_vals) > 0 else np.nan
    legacy_alert_coverage_l = float(np.mean(coverage_legacy_vals)) if len(coverage_legacy_vals) > 0 else np.nan
    anomaly_window_sampling_ratio = float(anomaly_window_sampled / anomaly_window_total) if anomaly_window_total > 0 else np.nan
    coverage_zero_rate = float(np.mean(np.array(coverage_event_alert_node_vals) <= 0.0)) if len(coverage_event_alert_node_vals) > 0 else np.nan
    coverage_high_rate = float(np.mean(np.array(coverage_event_alert_node_vals) >= coverage_high_threshold)) if len(coverage_event_alert_node_vals) > 0 else np.nan
    delta = max(1, int(config.TASK8_WAKEUP_DELTA_STEPS))
    wake_hit = 0
    wake_total = 0
    for event in env.alert_events:
        t = time_to_idx.get(event["time"], None)
        if t is None:
            continue
        for nid in event["neighbors"]:
            wake_total += 1
            j_end = min(steps - 1, t + delta)
            if np.any(gt_flags_per_node[nid][max(0, t + 1):j_end + 1] == 1):
                wake_hit += 1
    wakeup_effectiveness = wake_hit / wake_total if wake_total > 0 else np.nan
    over_wakeup_ratio = 1.0 - wakeup_effectiveness if np.isfinite(wakeup_effectiveness) else np.nan

    # A diffusion-front node is active now but was not active at the preceding
    # step. Recall measures whether that newly reached node was already awake
    # (or sampled immediately) when the front arrived.
    front_total = 0
    front_hits = 0
    front_detection_delays = []
    front_detection_delays_restricted = []
    front_detection_miss_count = 0
    time_to_coverage = []
    coverage_target = float(config.TASK8_COVERAGE_HIGH_THRESHOLD)
    for eid, active_map in event_active_nodes.items():
        previous = set()
        first_step = min(active_map) if active_map else None
        reached = None
        for step_idx in sorted(active_map):
            current = set(active_map[step_idx])
            front = current - previous
            front_total += len(front)
            front_hits += sum(1 for nid in front if mode_per_node[nid][step_idx] == 1 and sampled_per_node[nid][step_idx] == 1)
            for nid in front:
                active_node_steps = [j for j in sorted(active_map) if j >= step_idx and nid in active_map[j]]
                hit_step = next((
                    j for j in active_node_steps
                    if mode_per_node[nid][j] == 1 and sampled_per_node[nid][j] == 1
                ), None)
                if hit_step is not None:
                    delay = int(hit_step - step_idx)
                    front_detection_delays.append(delay)
                    front_detection_delays_restricted.append(delay)
                else:
                    front_detection_miss_count += 1
                    # Restricted delay assigns a missed node the first slot
                    # after its observable affected support.  This prevents a
                    # low-recall policy from appearing fast merely because its
                    # missed fronts are absent from the conditional mean.
                    last_active = max(active_node_steps) if active_node_steps else step_idx
                    front_detection_delays_restricted.append(int(last_active - step_idx + 1))
            covered_now = sum(1 for nid in current if mode_per_node[nid][step_idx] == 1 and sampled_per_node[nid][step_idx] == 1)
            if reached is None and current and covered_now / len(current) >= coverage_target:
                reached = step_idx
            previous = current
        if reached is not None and first_step is not None:
            time_to_coverage.append(reached - first_step)
    diffusion_front_recall = front_hits / front_total if front_total else np.nan
    front_detection_delay_detected_mean = float(np.mean(front_detection_delays)) if front_detection_delays else np.nan
    front_detection_delay_mean = float(np.mean(front_detection_delays_restricted)) if front_detection_delays_restricted else np.nan
    time_to_coverage_mean = float(np.mean(time_to_coverage)) if time_to_coverage else np.nan
    alert_message_count = int(sum(int(e.get("forwarding_message_count", e.get("neighbor_count", 0))) for e in env.alert_events))
    relay_stats = getattr(env, "event_relay_stats", {})
    directional_rows = getattr(env, "directional_selections", [])
    directional_hits = 0
    for selection in directional_rows:
        idx = time_to_idx.get(selection.get("time"), None)
        target_id = selection.get("target_id")
        if idx is None or target_id not in gt_flags_per_node:
            continue
        end_idx = min(steps, idx + max(1, int(getattr(config, "ALERT_SOFT_WATCH_STEPS", 20))) + 1)
        if np.any(gt_flags_per_node[target_id][idx:end_idx] == 1):
            directional_hits += 1
    learned_rows = getattr(env, "target_ranker_records", [])
    learned_selected = learned_hits = 0
    learned_horizon = max(1, int(getattr(config, "ALERT_LEARNED_LABEL_HORIZON_STEPS", 20)))
    for row in learned_rows:
        idx = int(row.get("step", -1))
        target_id = row.get("target_id")
        end_idx = min(steps, idx + learned_horizon + 1)
        label = int(idx >= 0 and target_id in gt_flags_per_node and np.any(gt_flags_per_node[target_id][idx:end_idx] == 1))
        row["label"] = label
        current_flag = int(idx >= 0 and target_id in gt_flags_per_node and gt_flags_per_node[target_id][idx] == 1)
        future_indices = np.flatnonzero(gt_flags_per_node[target_id][idx:end_idx] == 1) if idx >= 0 and target_id in gt_flags_per_node else np.asarray([])
        arrival_offset = int(future_indices[0]) if len(future_indices) else -1
        front_label = int(label == 1 and current_flag == 0 and arrival_offset > 0)
        utility_raw = 2.0 * front_label + float(label) - 0.1 * float(row.get("comm_hops", 0))
        row["front_label"] = front_label
        row["arrival_offset"] = arrival_offset
        row["utility_raw"] = utility_raw
        row["utility_relevance"] = int(max(0, min(3, np.floor(utility_raw + 0.5))))
        row["label_horizon_steps"] = learned_horizon
        row["rank_group"] = "%s:%s:%s:%s" % (
            row.get("seed", 0), row.get("event_id", 0), row.get("source_id", 0), idx
        )
        if int(row.get("selected", 0)):
            learned_selected += 1
            learned_hits += label
    component_purities = []
    mixed_components = 0
    merge_pair_total = 0
    merge_pair_correct = 0
    for relay_event in getattr(env, "event_relay_events", {}).values():
        dominant_ids = []
        for component in relay_event.get("components", {}).values():
            counts = component.get("true_event_counts", {})
            total = sum(counts.values())
            if total > 0:
                component_purities.append(max(counts.values()) / total)
                dominant_ids.append(max(counts, key=counts.get))
                if len(counts) > 1:
                    mixed_components += 1
        for i in range(len(dominant_ids)):
            for j in range(i + 1, len(dominant_ids)):
                merge_pair_total += 1
                merge_pair_correct += int(dominant_ids[i] == dominant_ids[j])
    soft_watch_samples = int(relay_stats.get("soft_watch_sample_count", 0))
    soft_watch_false_samples = int(relay_stats.get("soft_watch_false_sample_count", 0))
    false_alert_node_time = int(sum(
        1 for nid in node_ids for i in range(steps)
        if mode_per_node[nid][i] == 1 and gt_flags_per_node[nid][i] == 0
    ))
    total_alert_node_time = int(sum(np.sum(mode_per_node[nid]) for nid in node_ids))
    over_wakeup_ratio = false_alert_node_time / total_alert_node_time if total_alert_node_time else np.nan
    reconstructed_matrix = []
    truth_matrix = []
    anomaly_mask_matrix = []
    injected_truth_per_node = {}
    for nid in node_ids:
        truth = np.asarray([
            env.get_ground_truth(nid, timestamp)[0] for timestamp in aligned_index
        ], dtype=float)
        injected_truth_per_node[nid] = truth
        sample_mask = np.array(nodes[nid].history["sampled"][:steps], dtype=int) == 1
        sampled_values = np.asarray(nodes[nid].history["measured"][:steps], dtype=float)
        gt = gt_flags_per_node[nid]
        reconstructed = _reconstruct_linear_from_samples(
            sampled_values.reshape(1, -1), sample_mask.reshape(1, -1)
        )[0]
        reconstructed_matrix.append(reconstructed)
        truth_matrix.append(truth)
        anomaly_mask_matrix.append(gt == 1)
    rmse_metrics = compute_reconstruction_rmse_metrics(
        estimated=np.asarray(reconstructed_matrix, dtype=float),
        truth=np.asarray(truth_matrix, dtype=float),
        anomaly_mask=np.asarray(anomaly_mask_matrix, dtype=bool),
    )
    actual_rmse_anomaly = float(rmse_metrics["rmse_anomaly_window"])
    actual_rmse_global = float(rmse_metrics["rmse_global"])
    baseline_rmse_anomaly = _compute_no_alert_baseline_rmse(
        nodes=nodes,
        node_ids=node_ids,
        aligned_index=aligned_index,
        injected_truth_per_node=injected_truth_per_node,
        gt_flags_per_node=gt_flags_per_node
    )
    if np.isfinite(actual_rmse_anomaly) and np.isfinite(baseline_rmse_anomaly) and baseline_rmse_anomaly > 0:
        recovery_gain_strict = (baseline_rmse_anomaly - actual_rmse_anomaly) / baseline_rmse_anomaly
    else:
        recovery_gain_strict = np.nan
    detection_per_energy = detection_metrics["detected_event_count"] / energy_metrics["total_energy_proxy"] if energy_metrics["total_energy_proxy"] > 0 else np.nan
    normal_steps = {i for i in range(steps) if not any(gt_flags_per_node[nid][i] == 1 for nid in node_ids)}
    normal_sample_count = int(sum(1 for nid in node_ids for i in normal_steps if sampled_per_node[nid][i] == 1))
    normal_times = {aligned_index[i] for i in normal_steps}
    normal_records = [x for x in getattr(env, "node_comm_energy_records", []) if x.get("time") in normal_times]
    normal_tx = int(sum(int(x.get("peer_count", 0)) for x in normal_records if str(x.get("step_type", "")).endswith("_tx")))
    normal_rx = int(sum(int(x.get("peer_count", 0)) for x in normal_records if str(x.get("step_type", "")).endswith("_rx")))
    normal_measure = normal_sample_count if bool(getattr(config, "MEASUREMENT_REPORT_ENABLED", True)) else 0
    normal_ack = normal_rx + normal_measure if bool(getattr(config, "ACK_ENABLED", True)) else 0
    normal_tx_packets = normal_tx + normal_measure + normal_ack
    normal_rx_packets = normal_rx + normal_measure + normal_ack
    normal_tx_bytes = normal_tx * int(getattr(config, "CONTROL_PACKET_BYTES", 36)) + normal_measure * int(getattr(config, "MEASUREMENT_PACKET_BYTES", 16)) + normal_ack * int(getattr(config, "ACK_PACKET_BYTES", 11))
    normal_rx_bytes = normal_rx * int(getattr(config, "CONTROL_PACKET_BYTES", 36)) + normal_measure * int(getattr(config, "MEASUREMENT_PACKET_BYTES", 16)) + normal_ack * int(getattr(config, "ACK_PACKET_BYTES", 11))
    normal_energy_parts = compute_energy_proxy_metrics(
        normal_sample_count, normal_tx_packets, normal_rx_packets,
        idle_steps=len(node_ids) * len(normal_steps),
        computation_count=len(node_ids) * len(normal_steps) + normal_sample_count + normal_tx + normal_rx,
        tx_bytes=normal_tx_bytes, rx_bytes=normal_rx_bytes,
    )
    normal_period_energy = float(normal_energy_parts["total_energy_mj"])
    recovery_delays = []
    recovery_delays_detected = []
    recovery_censored_event_count = 0
    recovery_eligible_detected_event_count = 0
    aggregate_det = np.any(np.vstack([det_flags_per_sentinel[sid] for sid in sentinel_ids]), axis=0) if sentinel_ids else np.zeros(steps, dtype=bool)
    false_mask = np.asarray([aggregate_det[i] and not any(gt_flags_per_node[nid][i] for nid in node_ids) for i in range(steps)], dtype=bool)
    false_alarm_episodes = int(sum(1 for i in range(steps) if false_mask[i] and (i == 0 or not false_mask[i - 1])))
    event_level_precision = detected_events / (detected_events + false_alarm_episodes) if (detected_events + false_alarm_episodes) else np.nan
    for active_map in event_active_nodes.values():
        if not active_map:
            continue
        active_support = sorted(active_map)
        if not any(aggregate_det[j] for j in active_support):
            # Trigger recovery is undefined for an event that never produced an
            # aggregate Page--Hinkley pulse during its affected support.
            continue
        recovery_eligible_detected_event_count += 1
        end_step = max(active_map)
        clear_step = next((j for j in range(end_step + 1, steps) if not aggregate_det[j]), None)
        if clear_step is not None:
            delay = clear_step - end_step
            recovery_delays.append(delay)
            recovery_delays_detected.append(delay)
        else:
            recovery_censored_event_count += 1
            recovery_delays.append(max(1, steps - end_step))
    sentinel_count = len(sentinel_ids)
    marginal_sentinel_utility_proxy = edr / sentinel_count if sentinel_count > 0 and np.isfinite(edr) else np.nan
    cost_metrics = {
        "total_energy_proxy": energy_metrics["total_energy_proxy"],
        "odd_mean_steps": odd_mean,
        "alert_coverage_l": alert_coverage_l,
        "alert_coverage_l_legacy_strict": legacy_alert_coverage_l,
        "alert_coverage_alert_only": alert_coverage_alert_only,
        "anomaly_window_sampling_ratio": anomaly_window_sampling_ratio,
        "coverage_zero_rate": coverage_zero_rate,
        "coverage_high_rate": coverage_high_rate,
        "detection_per_energy": detection_per_energy,
        "marginal_sentinel_utility_proxy": marginal_sentinel_utility_proxy,
        "recovery_gain_strict": recovery_gain_strict,
        "energy_per_sentinel": energy_metrics["total_energy_proxy"] / sentinel_count if sentinel_count > 0 else np.nan
    }
    coverage_definition = "micro_affected_node_time_same_step_alert_and_physical_sample;zero_denominator=NA"
    task8_main = {
        "event_count": total_events,
        "event_detection_rate": edr,
        "detection_probability": float(detection_metrics.get("detection_probability", np.nan)),
        "temporal_detection_recall": float(detection_metrics.get("temporal_detection_recall", np.nan)),
        "false_positive_rate": float(detection_metrics.get("false_positive_rate", np.nan)),
        "normal_false_alarm_steps": int(detection_metrics.get("normal_false_alarm_steps", 0)),
        "event_level_precision": float(event_level_precision),
        "event_level_recall": float(edr),
        "onset_detection_delay_mean_steps": odd_mean,
        "alert_precision": alert_precision,
        "alert_coverage_l": alert_coverage_l,
        "alert_coverage_event": alert_coverage_event,
        "alert_coverage_l_legacy_strict": legacy_alert_coverage_l,
        "alert_coverage_alert_only": alert_coverage_alert_only,
        "alert_coverage_sampling_only": alert_coverage_sampling_only,
        "anomaly_window_sampling_ratio": anomaly_window_sampling_ratio,
        "coverage_zero_rate": coverage_zero_rate,
        "coverage_high_rate": coverage_high_rate,
        "wakeup_effectiveness": wakeup_effectiveness,
        "confirmation_ratio": wakeup_effectiveness,
        "over_wakeup_ratio": over_wakeup_ratio,
        "diffusion_front_recall": diffusion_front_recall,
        "front_detection_delay_mean_steps": front_detection_delay_mean,
        "front_detection_delay_detected_mean_steps": front_detection_delay_detected_mean,
        "front_detection_miss_count": int(front_detection_miss_count),
        "normal_period_energy_mj": normal_period_energy,
        "recovery_delay_mean_steps": float(np.mean(recovery_delays)) if recovery_delays else np.nan,
        "recovery_delay_detected_mean_steps": float(np.mean(recovery_delays_detected)) if recovery_delays_detected else np.nan,
        "recovery_censored_event_count": int(recovery_censored_event_count),
        "recovery_eligible_detected_event_count": int(recovery_eligible_detected_event_count),
        "time_to_coverage_mean_steps": time_to_coverage_mean,
        "alert_message_count": alert_message_count,
        "false_alert_node_time": false_alert_node_time,
        "false_wakeup_node_time": false_alert_node_time,
        "total_alert_node_time": total_alert_node_time,
        "useful_alert_node_time": total_alert_node_time - false_alert_node_time,
        "false_alert_node_time_ratio": false_alert_node_time / total_alert_node_time if total_alert_node_time else np.nan,
        "control_packet_count": int(energy_metrics.get("full_alert_command_tx_operations", 0)) + int(energy_metrics.get("full_alert_command_rx_operations", 0)),
        "probe_packet_count": (
            int(energy_metrics.get("probe_request_tx_packets", 0))
            + int(energy_metrics.get("probe_request_rx_packets", 0))
            + int(energy_metrics.get("probe_report_tx_operations", 0))
            + int(energy_metrics.get("probe_report_rx_operations", 0))
        ),
        "measurement_packet_count": int(energy_metrics.get("measurement_tx_operations", 0)) + int(energy_metrics.get("measurement_rx_operations", 0)),
        "ack_packet_count": int(energy_metrics.get("ack_tx_operations", 0)) + int(energy_metrics.get("ack_rx_operations", 0)),
        "total_packet_tx_rx": int(energy_metrics.get("packet_tx_count", 0)) + int(energy_metrics.get("packet_rx_count", 0)),
        "total_radio_bytes_tx_rx": int(energy_metrics.get("total_tx_bytes", 0)) + int(energy_metrics.get("total_rx_bytes", 0)),
        "soft_watch_sample_count": soft_watch_samples,
        "soft_watch_false_sample_count": soft_watch_false_samples,
        "soft_watch_false_sample_ratio": soft_watch_false_samples / soft_watch_samples if soft_watch_samples else np.nan,
        "event_repropagation_count": int(relay_stats.get("repropagation_count", 0)),
        "late_confirm_rescue_count": int(relay_stats.get("late_confirm_rescue_count", 0)),
        "event_created_count": int(relay_stats.get("created_event_count", 0)),
        "raw_event_trigger_count": int(relay_stats.get("raw_event_trigger_count", 0)),
        "event_merge_count": int(relay_stats.get("event_merge_count", 0)),
        "duplicate_event_ratio": (
            float(relay_stats.get("event_merge_count", 0)) / float(relay_stats.get("raw_event_trigger_count", 0))
            if relay_stats.get("raw_event_trigger_count", 0) else np.nan
        ),
        "directional_candidate_count": len(directional_rows),
        "directional_candidate_precision": directional_hits / len(directional_rows) if directional_rows else np.nan,
        "event_component_purity_mean": float(np.mean(component_purities)) if component_purities else np.nan,
        "mixed_component_ratio": mixed_components / len(component_purities) if component_purities else np.nan,
        "merge_precision_gt": merge_pair_correct / merge_pair_total if merge_pair_total else np.nan,
        "direction_confident_relay_count": int(relay_stats.get("direction_confident_relay_count", 0)),
        "direction_fallback_relay_count": int(relay_stats.get("direction_fallback_relay_count", 0)),
        "direction_conflict_count": int(relay_stats.get("direction_conflict_count", 0)),
        "geometry_radial_count": int(relay_stats.get("geometry_radial_count", 0)),
        "geometry_directional_count": int(relay_stats.get("geometry_directional_count", 0)),
        "geometry_multisource_count": int(relay_stats.get("geometry_multisource_count", 0)),
        "geometry_fallback_count": int(relay_stats.get("geometry_fallback_count", 0)),
        "learned_candidate_count": int(len(learned_rows)),
        "learned_selected_count": int(learned_selected),
        "learned_candidate_precision": learned_hits / learned_selected if learned_selected else np.nan,
        "candidate_positive_ratio": (
            float(sum(int(row.get("label", 0)) for row in learned_rows)) / len(learned_rows)
            if learned_rows else np.nan
        ),
        "candidate_generated_count": int(relay_stats.get("candidate_generated_count", 0)),
        "candidate_duplicate_ratio": (
            float(relay_stats.get("candidate_duplicate_count", 0)) /
            float(relay_stats.get("candidate_generated_count", 0))
            if relay_stats.get("candidate_generated_count", 0) else np.nan
        ),
        "candidate_avg_path_hops": (
            float(relay_stats.get("candidate_path_hops_total", 0)) /
            float(relay_stats.get("candidate_path_count", 0))
            if relay_stats.get("candidate_path_count", 0) else np.nan
        ),
        "time_requery_count": int(relay_stats.get("time_requery_count", 0)),
        "confirmation_requery_count": int(relay_stats.get("confirmation_requery_count", 0)),
        "soft_trend_requery_count": int(relay_stats.get("soft_trend_requery_count", 0)),
        "realert_count": int(relay_stats.get("realert_count", 0)),
        "realert_source_count": int(relay_stats.get("realert_source_count", 0)),
        "realert_candidate_count": int(relay_stats.get("realert_candidate_count", 0)),
        "realert_selected_count": int(relay_stats.get("realert_selected_count", 0)),
        "realert_success_ratio": (
            float(relay_stats.get("realert_success_count", 0)) / float(relay_stats.get("realert_selected_count", 0))
            if relay_stats.get("realert_selected_count", 0) else np.nan
        ),
        "reactivated_failed_nodes": int(relay_stats.get("reactivated_failed_nodes", 0)),
        "cooldown_suppression_count": int(relay_stats.get("cooldown_suppression_count", 0)),
        "budget_exhaustion_count": int(relay_stats.get("budget_exhaustion_count", 0)),
        "strict_gate_block_count": int(relay_stats.get("strict_gate_block_count", 0)),
        "weakAND_block_count": int(relay_stats.get("weakAND_block_count", 0)),
        "front_approach_block_count": int(relay_stats.get("front_approach_block_count", 0)),
        "previous_false_candidate_count": int(relay_stats.get("previous_false_candidate_count", 0)),
        "previous_false_selected_count": int(relay_stats.get("previous_false_selected_count", 0)),
        "previous_false_selected_ratio": (
            float(relay_stats.get("previous_false_selected_count", 0)) /
            float(relay_stats.get("previous_false_candidate_count", 0))
            if relay_stats.get("previous_false_candidate_count", 0) else np.nan
        ),
        "probe_upgrade_cap_block_count": int(relay_stats.get("probe_upgrade_cap_block_count", 0)),
        "deferred_by_active_cap_count": int(relay_stats.get("deferred_by_active_cap_count", 0)),
        "probe_trigger_count": int(relay_stats.get("probe_trigger_count", 0)),
        "probe_upgrade_count": int(relay_stats.get("probe_upgrade_count", 0)),
        "probe_fail_count": int(relay_stats.get("probe_fail_count", 0)),
        "probe_upgrade_final_confirmed_count": int(relay_stats.get("probe_upgrade_final_confirmed_count", 0)),
        "probe_upgrade_success_ratio": (
            float(relay_stats.get("probe_upgrade_final_confirmed_count", 0)) / float(relay_stats.get("probe_upgrade_count", 0))
            if relay_stats.get("probe_upgrade_count", 0) else np.nan
        ),
        "full_alert_node_time": int(relay_stats.get("full_alert_node_time", 0)),
        "probe_node_time": int(relay_stats.get("probe_node_time", 0)),
        "probe_upgrade_ratio": (
            float(relay_stats.get("probe_upgrade_count", 0)) / float(relay_stats.get("probe_trigger_count", 0))
            if relay_stats.get("probe_trigger_count", 0) else np.nan
        ),
        "recovery_gain_proxy": recovery_gain_strict,
        "recovery_gain_strict": recovery_gain_strict,
        "recovery_rmse_baseline_noalert": baseline_rmse_anomaly,
        "rmse_anomaly_window": actual_rmse_anomaly,
        "rmse_global": actual_rmse_global,
        "rmse_global_valid_node_time": int(rmse_metrics["rmse_global_valid_node_time"]),
        "rmse_global_total_node_time": int(rmse_metrics["rmse_global_total_node_time"]),
        "rmse_anomaly_valid_node_time": int(rmse_metrics["rmse_anomaly_valid_node_time"]),
        "rmse_anomaly_total_node_time": int(rmse_metrics["rmse_anomaly_total_node_time"]),
        "recovery_rmse_actual": actual_rmse_anomaly,
        "detection_per_energy": detection_per_energy,
        "marginal_sentinel_utility_proxy": marginal_sentinel_utility_proxy,
        "event_match_graph": str(config.TASK8_EVENT_MATCH_GRAPH),
        "event_match_max_hops": match_max_hops,
        "task8_detection_source": detection_source,
        "alert_precision_future_steps": prec_delta,
        "coverage_high_threshold": coverage_high_threshold,
        "alert_coverage_definition": coverage_definition
    }
    return task8_main, event_df, deadline_df, cost_metrics


def build_detailed_log_tables(nodes, node_ids, sentinel_ids, aligned_index, env):
    steps = len(aligned_index)
    sentinel_set = set(sentinel_ids)
    time_to_idx = {ts: i for i, ts in enumerate(aligned_index)}
    alert_event_count_per_step = np.zeros(steps, dtype=int)
    alert_target_count_per_step = np.zeros(steps, dtype=int)
    oracle_alert_event_count_per_step = np.zeros(steps, dtype=int)
    oracle_alert_target_count_per_step = np.zeros(steps, dtype=int)
    for event in env.alert_events:
        idx = time_to_idx.get(event.get("time"), None)
        if idx is None or idx < 0 or idx >= steps:
            continue
        alert_event_count_per_step[idx] += 1
        alert_target_count_per_step[idx] += int(event.get("neighbor_count", 0))
    for event in env.oracle_alert_events:
        idx = time_to_idx.get(event.get("time"), None)
        if idx is None or idx < 0 or idx >= steps:
            continue
        oracle_alert_event_count_per_step[idx] += 1
        oracle_alert_target_count_per_step[idx] += int(event.get("neighbor_count", 0))
    step_rows = []
    anomaly_rows = []
    event_active_nodes = {}
    comm_records = getattr(env, "node_comm_energy_records", [])
    comm_energy_map = {}
    tx_count_map = {}
    rx_count_map = {}
    for rec in comm_records:
        idx = time_to_idx.get(rec.get("time"), None)
        node_id = int(rec.get("node_id", -1))
        if idx is None or node_id not in nodes:
            continue
        key = (idx, node_id)
        comm_energy_map[key] = comm_energy_map.get(key, 0.0) + float(rec.get("comm_energy_mj", 0.0))
        step_type = str(rec.get("step_type", ""))
        if step_type.endswith("_tx"):
            tx_count_map[key] = tx_count_map.get(key, 0) + int(rec.get("peer_count", 0))
        elif step_type.endswith("_rx"):
            rx_count_map[key] = rx_count_map.get(key, 0) + int(rec.get("peer_count", 0))
    sensing_energy_per_sample_mj = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.SENSING_ACTIVE_CURRENT_MA) / 1000.0 * float(config.SENSING_DURATION_SEC) * 1000.0
    battery_capacity_mj = float(config.BATTERY_CAPACITY_MAH) * float(config.NODE_SUPPLY_VOLTAGE_V) * 3.6 * 1000.0
    node_cumulative_energy = {int(nid): 0.0 for nid in node_ids}
    node_energy_rows = []
    for i, ts in enumerate(aligned_index):
        gt_nodes = 0
        alert_nodes = 0
        sampled_nodes = 0
        sentinel_sampled_nodes = 0
        non_sentinel_alert_nodes = 0
        sentinel_detect_nodes = 0
        active_events_step = set()
        for nid in node_ids:
            history = nodes[nid].history
            mode_val = history["mode"][i]
            sampled_val = int(history["sampled"][i])
            anomaly_val = int(history["anomaly_flag"][i])
            trigger_val = int(history["detector_trigger_flag"][i])
            gt_val = int(history["gt_anomaly_flag"][i])
            nis_val = history["nis"][i]
            event_text = history["gt_event_ids"][i]
            event_ids = parse_event_ids(event_text)
            if gt_val == 1:
                gt_nodes += 1
            if mode_val == 'alert':
                alert_nodes += 1
                if nid not in sentinel_set:
                    non_sentinel_alert_nodes += 1
            if sampled_val == 1:
                sampled_nodes += 1
                if nid in sentinel_set:
                    sentinel_sampled_nodes += 1
            if nid in sentinel_set and trigger_val == 1:
                sentinel_detect_nodes += 1
            if len(event_ids) > 0:
                active_events_step.update(event_ids)
                for eid in event_ids:
                    event_active_nodes.setdefault(eid, {}).setdefault(i, set()).add(nid)
                    anomaly_rows.append({
                        "step": i,
                        "time": ts,
                        "event_id": int(eid),
                        "node_id": int(nid),
                        "is_sentinel": 1 if nid in sentinel_set else 0,
                        "mode": mode_val,
                        "alerted": 1 if mode_val == 'alert' else 0,
                        "sampled": sampled_val,
                        "anomaly_flag": anomaly_val,
                        "detector_trigger_flag": trigger_val
                    })
            step_rows.append({
                "step": i,
                "time": ts,
                "node_id": int(nid),
                "is_sentinel": 1 if nid in sentinel_set else 0,
                "mode": mode_val,
                "sampled": sampled_val,
                "anomaly_flag": anomaly_val,
                "detector_trigger_flag": trigger_val,
                "gt_anomaly_flag": gt_val,
                "gt_event_ids": "" if event_text is None else str(event_text),
                "nis": nis_val
            })
            sensing_energy_mj = float(sampled_val) * sensing_energy_per_sample_mj
            communication_energy_mj = float(comm_energy_map.get((i, int(nid)), 0.0))
            total_energy_mj = sensing_energy_mj + communication_energy_mj
            node_cumulative_energy[int(nid)] += total_energy_mj
            node_energy_rows.append({
                "step": i,
                "time": ts,
                "node_id": int(nid),
                "is_sentinel": 1 if nid in sentinel_set else 0,
                "sampled": int(sampled_val),
                "tx_message_count": int(tx_count_map.get((i, int(nid)), 0)),
                "rx_message_count": int(rx_count_map.get((i, int(nid)), 0)),
                "sensing_energy_mj": sensing_energy_mj,
                "communication_energy_mj": communication_energy_mj,
                "total_energy_mj": total_energy_mj,
                "cumulative_energy_mj": float(node_cumulative_energy[int(nid)]),
                "battery_capacity_mj": battery_capacity_mj,
                "remaining_energy_mj": float(max(0.0, battery_capacity_mj - node_cumulative_energy[int(nid)])),
                "remaining_energy_ratio": float(max(0.0, battery_capacity_mj - node_cumulative_energy[int(nid)]) / battery_capacity_mj) if battery_capacity_mj > 0 else np.nan
            })
        step_rows.append({
            "step": i,
            "time": ts,
            "node_id": -1,
            "is_sentinel": -1,
            "mode": "aggregate",
            "sampled": sampled_nodes,
            "anomaly_flag": sentinel_detect_nodes,
            "gt_anomaly_flag": gt_nodes,
            "gt_event_ids": ",".join([str(x) for x in sorted(list(active_events_step))]),
            "nis": np.nan
        })
    alert_load_rows = []
    for i, ts in enumerate(aligned_index):
        gt_nodes = 0
        alert_nodes = 0
        sampled_nodes = 0
        sentinel_sampled_nodes = 0
        non_sentinel_alert_nodes = 0
        sentinel_detect_nodes = 0
        active_events = set()
        for nid in node_ids:
            history = nodes[nid].history
            if int(history["gt_anomaly_flag"][i]) == 1:
                gt_nodes += 1
            if history["mode"][i] == 'alert':
                alert_nodes += 1
                if nid not in sentinel_set:
                    non_sentinel_alert_nodes += 1
            if int(history["sampled"][i]) == 1:
                sampled_nodes += 1
                if nid in sentinel_set:
                    sentinel_sampled_nodes += 1
            if nid in sentinel_set and int(history["anomaly_flag"][i]) == 1:
                sentinel_detect_nodes += 1
            active_events.update(parse_event_ids(history["gt_event_ids"][i]))
        alert_load_rows.append({
            "step": i,
            "time": ts,
            "gt_anomaly_nodes": gt_nodes,
            "active_event_count": len(active_events),
            "alert_mode_nodes": alert_nodes,
            "non_sentinel_alert_nodes": non_sentinel_alert_nodes,
            "sampled_nodes": sampled_nodes,
            "sentinel_sampled_nodes": sentinel_sampled_nodes,
            "sentinel_detect_nodes": sentinel_detect_nodes,
            "new_alert_event_count": int(alert_event_count_per_step[i]),
            "new_alert_target_count": int(alert_target_count_per_step[i]),
            "new_oracle_alert_event_count": int(oracle_alert_event_count_per_step[i]),
            "new_oracle_alert_target_count": int(oracle_alert_target_count_per_step[i])
        })
    event_summary_rows = []
    for eid, step_map in event_active_nodes.items():
        steps_list = sorted(step_map.keys())
        if len(steps_list) == 0:
            continue
        affected_nodes = set()
        for s in steps_list:
            affected_nodes.update(step_map[s])
        if len(affected_nodes) == 0:
            continue
        sentinel_affected = [nid for nid in affected_nodes if nid in sentinel_set]
        non_sentinel_affected = [nid for nid in affected_nodes if nid not in sentinel_set]
        non_sentinel_alert_hit = 0
        non_sentinel_never_alert = 0
        for nid in non_sentinel_affected:
            mode_hist = nodes[nid].history["mode"]
            mode_seq = np.array([mode_hist[s] for s in steps_list], dtype=object)
            if np.any(mode_seq == 'alert'):
                non_sentinel_alert_hit += 1
            else:
                non_sentinel_never_alert += 1
        event_alert_hit_ratio = 1.0 - (non_sentinel_never_alert / len(affected_nodes))
        event_summary_rows.append({
            "event_id": int(eid),
            "start_step": int(steps_list[0]),
            "end_step": int(steps_list[-1]),
            "duration_steps": int(steps_list[-1] - steps_list[0] + 1),
            "affected_nodes_count": int(len(affected_nodes)),
            "sentinel_affected_nodes_count": int(len(sentinel_affected)),
            "non_sentinel_affected_nodes_count": int(len(non_sentinel_affected)),
            "non_sentinel_alert_hit_nodes_count": int(non_sentinel_alert_hit),
            "non_sentinel_never_alert_nodes_count": int(non_sentinel_never_alert),
            "event_alert_hit_ratio_including_sentinel_default": float(event_alert_hit_ratio)
        })
    step_df = pd.DataFrame(step_rows)
    anomaly_df = pd.DataFrame(anomaly_rows)
    alert_load_df = pd.DataFrame(alert_load_rows)
    event_summary_df = pd.DataFrame(event_summary_rows)
    node_energy_df = pd.DataFrame(node_energy_rows)
    return step_df, anomaly_df, alert_load_df, event_summary_df, node_energy_df


def select_diagnostic_target_node(nodes, node_ids, sentinel_ids, node_positions):
    sentinel_set = set(sentinel_ids)
    normal_ids = [node_id for node_id in node_ids if node_id not in sentinel_set]
    if len(normal_ids) == 0:
        return node_ids[0], None
    candidates = []
    for node_id in normal_ids:
        gt_count = int(np.nansum(nodes[node_id].history["gt_anomaly_flag"]))
        min_dist = np.inf
        nearest = None
        for sid in sentinel_ids:
            dx = node_positions[node_id]["x"] - node_positions[sid]["x"]
            dy = node_positions[node_id]["y"] - node_positions[sid]["y"]
            dist = float(np.sqrt(dx * dx + dy * dy))
            if dist < min_dist:
                min_dist = dist
                nearest = sid
        candidates.append((node_id, gt_count, min_dist, nearest))
    anomaly_candidates = [c for c in candidates if c[1] > 0]
    if len(anomaly_candidates) > 0:
        chosen = sorted(anomaly_candidates, key=lambda x: (x[2], -x[1], x[0]))[0]
    else:
        chosen = sorted(candidates, key=lambda x: (x[2], x[0]))[0]
    return chosen[0], chosen[3]


def configure_spatial_anomalies(env, start_time, dt_sec, total_steps, node_ids):
    configured = []
    if not config.SPATIAL_ANOMALY_ENABLED:
        return configured
    time_step_delta = pd.Timedelta(seconds=dt_sec)
    anomaly_mode = str(getattr(config, "SPATIAL_ANOMALY_MODE", "fixed")).strip().lower()
    if anomaly_mode == 'controlled':
        from src.controlled_event_scheduler import install_manifest
        manifest_path = getattr(config, "CONTROLLED_EVENT_MANIFEST", "")
        if not manifest_path:
            raise ValueError("CONTROLLED_EVENT_MANIFEST is required in controlled mode")
        with open(manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)
        if set(int(x) for event in manifest["events"] for x in event["allowed_nodes"]) - set(node_ids):
            raise ValueError("controlled manifest contains nodes outside the active graph")
        return install_manifest(env.anomaly_injector, manifest, start_time, time_step_delta)
    if anomaly_mode == 'randomized':
        rng_seed = int(getattr(config, "SPATIAL_ANOMALY_RANDOM_SEED", config.RANDOM_SEED))
        rng = np.random.default_rng(rng_seed)
        event_count = max(1, int(getattr(config, "SPATIAL_RANDOM_EVENT_COUNT", 10)))
        nonoverlap = bool(getattr(config, "SPATIAL_RANDOM_NONOVERLAP", False))
        gap_min = max(0, int(getattr(config, "SPATIAL_RANDOM_EVENT_GAP_MIN_STEPS", 0)))
        gap_max = max(gap_min, int(getattr(config, "SPATIAL_RANDOM_EVENT_GAP_MAX_STEPS", gap_min)))
        if (not nonoverlap) and total_steps > 1:
            anchors = np.linspace(0, total_steps - 1, event_count, dtype=int)
            jitter = max(0, int(getattr(config, "SPATIAL_RANDOM_EVENT_START_JITTER_STEPS", 0)))
            start_steps = []
            for anchor in anchors:
                if jitter > 0:
                    delta = int(rng.integers(-jitter, jitter + 1))
                else:
                    delta = 0
                step_idx = int(np.clip(anchor + delta, 0, total_steps - 1))
                start_steps.append(step_idx)
            start_steps = sorted(start_steps)
        else:
            start_steps = []
        types = [str(x).strip().lower() for x in list(config.SPATIAL_ANOMALY_TYPES)]
        available_types = []
        for t in types:
            if t == 'static':
                available_types.append('static')
            if t == 'diffusion':
                available_types.append('diffusion')
        if len(available_types) == 0:
            return configured
        duration_min = max(1, int(getattr(config, "SPATIAL_RANDOM_DURATION_MIN_STEPS", 20)))
        duration_max = max(duration_min, int(getattr(config, "SPATIAL_RANDOM_DURATION_MAX_STEPS", duration_min)))
        mag_abs_min = max(1e-6, float(getattr(config, "SPATIAL_RANDOM_MAGNITUDE_ABS_MIN", 1.0)))
        mag_abs_max = max(mag_abs_min, float(getattr(config, "SPATIAL_RANDOM_MAGNITUDE_ABS_MAX", mag_abs_min)))
        radius_min = max(1e-6, float(getattr(config, "SPATIAL_RANDOM_STATIC_RADIUS_MIN", 3.0)))
        radius_max = max(radius_min, float(getattr(config, "SPATIAL_RANDOM_STATIC_RADIUS_MAX", radius_min)))
        diff_hops_min = max(1, int(getattr(config, "SPATIAL_RANDOM_DIFF_MAX_HOPS_MIN", 2)))
        diff_hops_max = max(diff_hops_min, int(getattr(config, "SPATIAL_RANDOM_DIFF_MAX_HOPS_MAX", diff_hops_min)))
        diff_delay_min = max(0, int(getattr(config, "SPATIAL_RANDOM_DIFF_PROP_DELAY_MIN", 1)))
        diff_delay_max = max(diff_delay_min, int(getattr(config, "SPATIAL_RANDOM_DIFF_PROP_DELAY_MAX", diff_delay_min)))
        diff_decay_min = max(0.01, float(getattr(config, "SPATIAL_RANDOM_DIFF_HOP_DECAY_MIN", 0.6)))
        diff_decay_max = min(1.0, max(diff_decay_min, float(getattr(config, "SPATIAL_RANDOM_DIFF_HOP_DECAY_MAX", diff_decay_min))))
        diff_growth_min = max(0, int(getattr(config, "SPATIAL_RANDOM_DIFF_GROWTH_MIN_STEPS", 4)))
        diff_growth_max = max(diff_growth_min, int(getattr(config, "SPATIAL_RANDOM_DIFF_GROWTH_MAX_STEPS", diff_growth_min)))
        recovery_modes = [str(x).strip().lower() for x in list(getattr(config, "SPATIAL_RANDOM_RECOVERY_MODES", ["abrupt"]))]
        recovery_modes = [x for x in recovery_modes if x in {"abrupt", "gradual"}]
        if len(recovery_modes) == 0:
            recovery_modes = ["abrupt"]
        recovery_min = max(1, int(getattr(config, "SPATIAL_RANDOM_RECOVERY_MIN_STEPS", 20)))
        recovery_max = max(recovery_min, int(getattr(config, "SPATIAL_RANDOM_RECOVERY_MAX_STEPS", recovery_min)))
        next_available_step = 0
        for event_idx in range(event_count):
            if set(available_types) == {"static", "diffusion"}:
                static_probability = float(np.clip(getattr(config, "SPATIAL_RANDOM_STATIC_PROBABILITY", 0.4), 0.0, 1.0))
                event_type = "static" if float(rng.random()) < static_probability else "diffusion"
            else:
                event_type = str(rng.choice(available_types))
            center_or_source = int(rng.choice(node_ids))
            mag_abs = float(rng.uniform(mag_abs_min, mag_abs_max))
            sign = -1.0 if float(rng.uniform(0.0, 1.0)) < 0.5 else 1.0
            magnitude = sign * mag_abs
            recovery_mode = str(rng.choice(recovery_modes))
            recovery_steps = 0
            if recovery_mode == 'gradual':
                recovery_steps = int(rng.integers(recovery_min, recovery_max + 1))
            # Include the last hop's delayed arrival in the nonoverlap support.
            if event_type == 'diffusion':
                max_hops = int(rng.integers(diff_hops_min, diff_hops_max + 1))
                prop_delay = int(rng.integers(diff_delay_min, diff_delay_max + 1))
                hop_decay = float(rng.uniform(diff_decay_min, diff_decay_max))
                propagation_tail = max_hops * prop_delay
            else:
                max_hops, prop_delay, hop_decay, propagation_tail = 0, 0, np.nan, 0
            if nonoverlap:
                remaining_events = event_count - event_idx - 1
                earliest_start = max(0, int(next_available_step))
                # Reserve the worst configured gap, because the actual gap is
                # sampled later.  Reserving only gap_min can strand the final
                # events when earlier draws happen to use gap_max.
                future_recovery_reserve = recovery_min if set(recovery_modes) == {'gradual'} else 0
                remaining_min_span = remaining_events * (
                    duration_min + diff_hops_max * diff_delay_max
                    + future_recovery_reserve + gap_max
                )
                max_total_event_span = total_steps - earliest_start - remaining_min_span
                if max_total_event_span < 1:
                    break
                if recovery_mode == 'gradual':
                    max_recovery_allowed = max(0, min(
                        recovery_steps, max_total_event_span - duration_min - propagation_tail
                    ))
                    if max_recovery_allowed <= 0:
                        recovery_mode = 'abrupt'
                        recovery_steps = 0
                    else:
                        recovery_steps = int(max_recovery_allowed)
                max_duration_allowed = max_total_event_span - max(0, int(recovery_steps)) - propagation_tail
                max_duration_allowed = max(1, min(duration_max, max_duration_allowed))
                if max_duration_allowed < duration_min:
                    if recovery_mode == 'gradual':
                        recovery_mode = 'abrupt'
                        recovery_steps = 0
                        max_duration_allowed = max(1, min(duration_max, max_total_event_span - propagation_tail))
                    if max_duration_allowed < duration_min:
                        break
                duration_steps = int(rng.integers(duration_min, max_duration_allowed + 1))
                total_event_span = max(1, int(duration_steps)) + max(0, int(recovery_steps)) + propagation_tail
                latest_start = total_steps - total_event_span - remaining_min_span
                if latest_start < earliest_start:
                    step_idx = int(earliest_start)
                elif latest_start > earliest_start:
                    step_idx = int(rng.integers(earliest_start, latest_start + 1))
                else:
                    step_idx = int(earliest_start)
            else:
                duration_steps = int(rng.integers(duration_min, duration_max + 1))
                total_event_span = max(1, int(duration_steps)) + max(0, int(recovery_steps)) + propagation_tail
                if event_idx >= len(start_steps):
                    break
                step_idx = int(start_steps[event_idx])
            duration_steps = max(1, min(duration_steps, total_steps - step_idx))
            if recovery_mode == 'gradual':
                recovery_steps = max(1, min(recovery_steps, total_steps - step_idx - duration_steps))
                if recovery_steps <= 0:
                    recovery_mode = 'abrupt'
                    recovery_steps = 0
            total_event_span = max(1, int(duration_steps)) + max(0, int(recovery_steps)) + propagation_tail
            start_ts = start_time + step_idx * time_step_delta
            if event_type == 'static':
                radius = float(rng.uniform(radius_min, radius_max))
                event_id = env.anomaly_injector.add_spatial_static_anomaly(
                    start_time=start_ts,
                    duration_steps=duration_steps,
                    center_node_id=center_or_source,
                    radius=radius,
                    magnitude=magnitude,
                    distance_mode=config.SPATIAL_STATIC_DISTANCE_MODE,
                    graph=config.SPATIAL_STATIC_GRAPH,
                    max_hops=config.SPATIAL_STATIC_MAX_HOPS,
                    recovery_mode=recovery_mode,
                    recovery_steps=recovery_steps
                )
                configured.append({
                    'event_id': event_id,
                    'type': 'spatial_static',
                    'start_time': start_ts,
                    'start_step': step_idx,
                    'duration_steps': duration_steps,
                    'recovery_mode': recovery_mode,
                    'recovery_steps': recovery_steps,
                    'center_or_source_node': center_or_source,
                    'radius_or_hops': radius,
                    'magnitude': magnitude,
                    'graph': config.SPATIAL_STATIC_GRAPH,
                    'distance_mode': config.SPATIAL_STATIC_DISTANCE_MODE
                })
            else:
                onset_mode = str(getattr(config, "SPATIAL_RANDOM_DIFF_ONSET_MODE", "abrupt")).strip().lower()
                growth_steps = int(rng.integers(diff_growth_min, diff_growth_max + 1)) if diff_growth_max > 0 else 0
                if onset_mode == 'abrupt':
                    growth_steps = 0
                event_id = env.anomaly_injector.add_spatiotemporal_diffusion_anomaly(
                    start_time=start_ts,
                    duration_steps=duration_steps,
                    source_node_id=center_or_source,
                    base_magnitude=magnitude,
                    graph=config.SPATIOTEMP_DIFF_GRAPH,
                    max_hops=max_hops,
                    propagation_delay_steps=prop_delay,
                    hop_decay=hop_decay,
                    temporal_growth_steps=growth_steps,
                    onset_mode=onset_mode,
                    recovery_mode=recovery_mode,
                    recovery_steps=recovery_steps
                )
                configured.append({
                    'event_id': event_id,
                    'type': 'spatiotemporal_diffusion',
                    'start_time': start_ts,
                    'start_step': step_idx,
                    'duration_steps': duration_steps,
                    'recovery_mode': recovery_mode,
                    'recovery_steps': recovery_steps,
                    'center_or_source_node': center_or_source,
                    'radius_or_hops': max_hops,
                    'magnitude': magnitude,
                    'graph': config.SPATIOTEMP_DIFF_GRAPH,
                    'propagation_delay_steps': prop_delay,
                    'hop_decay': hop_decay,
                    'temporal_growth_steps': growth_steps,
                    'onset_mode': onset_mode
                })
            if nonoverlap:
                gap_after = int(rng.integers(gap_min, gap_max + 1)) if gap_max > gap_min else int(gap_min)
                next_available_step = int(step_idx + total_event_span + gap_after)
        return configured
    if 'static' in config.SPATIAL_ANOMALY_TYPES:
        static_start = start_time + config.SPATIAL_STATIC_START_OFFSET_STEPS * time_step_delta
        event_id = env.anomaly_injector.add_spatial_static_anomaly(
            start_time=static_start,
            duration_steps=config.SPATIAL_STATIC_DURATION_STEPS,
            center_node_id=config.SPATIAL_STATIC_CENTER_NODE,
            radius=config.SPATIAL_STATIC_RADIUS,
            magnitude=config.SPATIAL_STATIC_MAGNITUDE,
            distance_mode=config.SPATIAL_STATIC_DISTANCE_MODE,
            graph=config.SPATIAL_STATIC_GRAPH,
            max_hops=config.SPATIAL_STATIC_MAX_HOPS,
            recovery_mode=getattr(config, "SPATIAL_STATIC_RECOVERY_MODE", "abrupt"),
            recovery_steps=getattr(config, "SPATIAL_STATIC_RECOVERY_STEPS", 0)
        )
        configured.append({
            'event_id': event_id,
            'type': 'spatial_static',
            'start_time': static_start,
            'duration_steps': config.SPATIAL_STATIC_DURATION_STEPS,
            'recovery_mode': getattr(config, "SPATIAL_STATIC_RECOVERY_MODE", "abrupt"),
            'recovery_steps': int(getattr(config, "SPATIAL_STATIC_RECOVERY_STEPS", 0)),
            'center_or_source_node': config.SPATIAL_STATIC_CENTER_NODE,
            'radius_or_hops': config.SPATIAL_STATIC_RADIUS if config.SPATIAL_STATIC_DISTANCE_MODE == 'euclidean' else config.SPATIAL_STATIC_MAX_HOPS,
            'magnitude': config.SPATIAL_STATIC_MAGNITUDE
        })
    if 'diffusion' in config.SPATIAL_ANOMALY_TYPES:
        diff_start = start_time + config.SPATIOTEMP_DIFF_START_OFFSET_STEPS * time_step_delta
        event_id = env.anomaly_injector.add_spatiotemporal_diffusion_anomaly(
            start_time=diff_start,
            duration_steps=config.SPATIOTEMP_DIFF_DURATION_STEPS,
            source_node_id=config.SPATIOTEMP_DIFF_SOURCE_NODE,
            base_magnitude=config.SPATIOTEMP_DIFF_BASE_MAGNITUDE,
            graph=config.SPATIOTEMP_DIFF_GRAPH,
            max_hops=config.SPATIOTEMP_DIFF_MAX_HOPS,
            propagation_delay_steps=config.SPATIOTEMP_DIFF_PROPAGATION_DELAY_STEPS,
            hop_decay=config.SPATIOTEMP_DIFF_HOP_DECAY,
            temporal_growth_steps=config.SPATIOTEMP_DIFF_TEMPORAL_GROWTH_STEPS,
            onset_mode=getattr(config, "SPATIOTEMP_DIFF_ONSET_MODE", "abrupt"),
            recovery_mode=getattr(config, "SPATIOTEMP_DIFF_RECOVERY_MODE", "abrupt"),
            recovery_steps=getattr(config, "SPATIOTEMP_DIFF_RECOVERY_STEPS", 0)
        )
        configured.append({
            'event_id': event_id,
            'type': 'spatiotemporal_diffusion',
            'start_time': diff_start,
            'duration_steps': config.SPATIOTEMP_DIFF_DURATION_STEPS,
            'recovery_mode': getattr(config, "SPATIOTEMP_DIFF_RECOVERY_MODE", "abrupt"),
            'recovery_steps': int(getattr(config, "SPATIOTEMP_DIFF_RECOVERY_STEPS", 0)),
            'center_or_source_node': config.SPATIOTEMP_DIFF_SOURCE_NODE,
            'radius_or_hops': config.SPATIOTEMP_DIFF_MAX_HOPS,
            'magnitude': config.SPATIOTEMP_DIFF_BASE_MAGNITUDE,
            'onset_mode': getattr(config, "SPATIOTEMP_DIFF_ONSET_MODE", "abrupt")
        })
    return configured


def run_multinode_baseline_experiment():
    output_dir = setup_experiment_output()
    if output_dir is None:
        print("Failed to setup output directory. Exiting.")
        return

    try:
        df, node_positions = _load_experiment_inputs()
    except ValueError as e:
        logging.error(str(e))
        return
    start_time = config.START_TIME
    end_time = config.END_TIME
    dt_sec = config.DT_SEC
    positioned_ids = sorted(node_positions.keys())
    window_df = df[(df.index >= start_time) & (df.index <= end_time)]
    available_ids = set(int(x) for x in window_df["moteid"].dropna().unique())
    node_ids = [nid for nid in positioned_ids if nid in available_ids]
    node_limit = max(0, int(getattr(config, "EXPERIMENT_NODE_LIMIT", 0)))
    if node_limit and len(node_ids) > node_limit:
        node_ids = node_ids[:node_limit]
    excluded_node_ids = [nid for nid in positioned_ids if nid not in available_ids]
    if len(node_ids) == 0:
        logging.error("No positioned sensor has observations in the requested time window.")
        return
    if excluded_node_ids:
        logging.warning("Excluding %d positioned nodes with no data in the time window: %s", len(excluded_node_ids), excluded_node_ids)
    node_positions = {nid: node_positions[nid] for nid in node_ids}
    aligned_data, aligned_index = prepare_multinode_data(df, node_ids, start_time, end_time, dt_sec)

    model_dt = float(getattr(config, "MODEL_DT", None) or dt_sec)
    F = np.array([[1, model_dt], [0, 1]])
    H = np.array([[1, 0]])
    Q = np.array([[config.Q_POS, 0], [0, config.Q_VEL]])
    R = np.array([[config.R_VAR]])
    P0 = np.eye(2) * config.P0_SCALE
    gamma = config.GAMMA

    selector = SentinelSelector(node_positions=node_positions)
    sentinel_ids = selector.select(
        strategy=config.SENTINEL_STRATEGY,
        node_ids=node_ids,
        sentinel_ratio=config.SENTINEL_RATIO,
        random_seed=config.RANDOM_SEED
    )

    nodes = {}
    sentinel_set = set(sentinel_ids)
    for node_id in node_ids:
        valid_initial = aligned_data[node_id]["temperature"].dropna()
        if valid_initial.empty:
            raise ValueError(f"Node {node_id} has no observed value in the experiment window")
        initial_temp = valid_initial.iloc[0]
        x0 = np.array([[initial_temp], [0.0]])
        if node_id in sentinel_set:
            nodes[node_id] = Sentinel(
                node_id=node_id,
                initial_state=x0,
                P0=P0.copy(),
                F=F,
                H=H,
                Q=Q,
                R=R,
                threshold_gamma=gamma,
                anomaly_threshold_eta=config.ANOMALY_THRESHOLD_ETA,
                trigger_mode=config.SENTINEL_TRIGGER_MODE,
                consecutive_required=config.SENTINEL_TRIGGER_CONSECUTIVE_STEPS
            )
        else:
            nodes[node_id] = Node(
                node_id=node_id,
                initial_state=x0,
                P0=P0.copy(),
                F=F,
                H=H,
                Q=Q,
                R=R,
                threshold_gamma=gamma
            )

    env = SimulationEnvironment(
        nodes=nodes,
        data_loader=None,
        start_time=aligned_index[0],
        time_step_sec=dt_sec,
        node_positions=node_positions,
        alert_duration_steps=config.ALERT_DURATION_L,
        alert_neighbor_graph=config.ALERT_NEIGHBOR_GRAPH,
        alert_propagation_mode=config.ALERT_PROPAGATION_MODE,
        alert_max_hops=config.ALERT_MAX_HOPS,
        enable_sentinel_alert_trigger=config.ENABLE_SENTINEL_ALERT_TRIGGER,
        oracle_wakeup_enabled=config.ORACLE_WAKEUP_ENABLED,
        oracle_wakeup_graph=config.ORACLE_WAKEUP_GRAPH
    )

    for node_id in node_ids:
        env.load_node_data(node_id, aligned_data[node_id])

    sentinel_df = pd.DataFrame({"node_id": sentinel_ids})
    sentinel_path = os.path.join(output_dir, "sentinel_nodes.csv")
    sentinel_df.to_csv(sentinel_path, index=False)
    pd.DataFrame({"excluded_node_id": excluded_node_ids}).to_csv(
        os.path.join(output_dir, "excluded_nodes_no_window_data.csv"), index=False
    )

    spatial_adjacency = env.build_topology(mode=config.TOPOLOGY_MODE, radius=config.NEIGHBOR_RADIUS, k=config.K_NEIGHBORS)
    graph_integrity = {}
    if str(getattr(config, "DATASET_MODE", "intel")).lower() == "airquality":
        if _AIRQUALITY_GRAPH_OVERRIDE is None:
            raise AssertionError("AirQualityBench graph override was not prepared")
        spatial_adjacency = {nid: list(_AIRQUALITY_GRAPH_OVERRIDE.get(nid, [])) for nid in node_ids}
        env.adjacency = spatial_adjacency
        graph_integrity["adapter_spatial_edges"] = int(sum(map(len, spatial_adjacency.values())) // 2)
        graph_integrity["adapter_spatial_hash"] = _adjacency_hash(spatial_adjacency)
    spatial_rows = []
    spatial_degrees = []
    for src in sorted(spatial_adjacency.keys()):
        neighbors = spatial_adjacency[src]
        spatial_degrees.append(len(neighbors))
        for dst in neighbors:
            if src < dst:
                spatial_rows.append({'src': src, 'dst': dst})
    spatial_df = pd.DataFrame(spatial_rows)
    spatial_path = os.path.join(output_dir, 'spatial_adjacency_edges.csv')
    spatial_df.to_csv(spatial_path, index=False)
    spatial_degree_df = pd.DataFrame({
        'node_id': sorted(spatial_adjacency.keys()),
        'degree': [len(spatial_adjacency[node_id]) for node_id in sorted(spatial_adjacency.keys())]
    })
    spatial_degree_path = os.path.join(output_dir, 'spatial_adjacency_degree.csv')
    spatial_degree_df.to_csv(spatial_degree_path, index=False)

    if str(getattr(config, "DATASET_MODE", "intel")).lower() == "airquality":
        comm_adjacency = {nid: list(spatial_adjacency[nid]) for nid in node_ids}
        env.communication_adjacency = comm_adjacency
        env.communication_weights = {nid: {dst: 1.0 for dst in comm_adjacency[nid]} for nid in node_ids}
        graph_integrity.update({
            "simulator_spatial_edges": int(sum(map(len, env.adjacency.values())) // 2),
            "simulator_communication_edges": int(sum(map(len, comm_adjacency.values())) // 2),
            "simulator_spatial_hash": _adjacency_hash(env.adjacency),
            "simulator_communication_hash": _adjacency_hash(comm_adjacency),
        })
        assert graph_integrity["adapter_spatial_hash"] == graph_integrity["simulator_spatial_hash"]
        assert set(env.adjacency) == set(node_ids)
        with open(os.path.join(output_dir, "graph_integrity.json"), "w", encoding="utf-8") as handle:
            json.dump(graph_integrity, handle, indent=2)
    else:
        comm_weights = load_connectivity_weights(config.CONNECTIVITY_FILE, node_ids)
        env.load_communication_weights(comm_weights)
        comm_adjacency = env.build_communication_topology(
            threshold=config.COMM_THRESHOLD, directed=config.COMM_DIRECTED,
            model=config.COMM_MODEL, random_seed=config.COMM_RANDOM_SEED
        )
    comm_rows = []
    for src in sorted(comm_adjacency.keys()):
        for dst in comm_adjacency[src]:
            if config.COMM_DIRECTED:
                comm_rows.append({"src": src, "dst": dst})
            elif src < dst:
                comm_rows.append({"src": src, "dst": dst})
    comm_df = pd.DataFrame(comm_rows)
    comm_path = os.path.join(output_dir, "communication_adjacency_edges.csv")
    comm_df.to_csv(comm_path, index=False)
    comm_degree_df = pd.DataFrame({
        "node_id": sorted(comm_adjacency.keys()),
        "out_degree": [len(comm_adjacency[node_id]) for node_id in sorted(comm_adjacency.keys())]
    })
    comm_degree_path = os.path.join(output_dir, "communication_adjacency_degree.csv")
    comm_degree_df.to_csv(comm_degree_path, index=False)

    enable_plots = bool(getattr(config, "ENABLE_PLOTS", True))
    detailed_logs_enabled = bool(getattr(config, "ENABLE_DETAILED_LOGS", True))
    graph_plot_path = os.path.join(output_dir, 'network_adjacency.png')
    sentinel_plot_path = os.path.join(output_dir, 'sentinel_layout.png')
    comm_graph_plot_path = os.path.join(output_dir, 'communication_adjacency.png')
    connectivity_heatmap_path = os.path.join(output_dir, 'connectivity_heatmap.png')
    if enable_plots:
        plot_network_adjacency(
            node_positions=node_positions,
            adjacency=spatial_adjacency,
            output_path=graph_plot_path,
            title=f"Spatial Adjacency ({config.TOPOLOGY_MODE})"
        )
        plot_node_roles(
            node_positions=node_positions,
            sentinel_ids=sentinel_ids,
            output_path=sentinel_plot_path,
            title=f"Sentinel Layout ({config.SENTINEL_STRATEGY})"
        )
        plot_network_adjacency(
            node_positions=node_positions,
            adjacency=comm_adjacency,
            output_path=comm_graph_plot_path,
            title=f"Communication Adjacency ({config.COMM_MODEL})"
        )
        plot_connectivity_heatmap(
            communication_weights=comm_weights,
            node_ids=node_ids,
            output_path=connectivity_heatmap_path
        )
    spatial_degree_min = int(min(spatial_degrees)) if len(spatial_degrees) > 0 else 0
    spatial_degree_max = int(max(spatial_degrees)) if len(spatial_degrees) > 0 else 0
    spatial_degree_mean = float(np.mean(spatial_degrees)) if len(spatial_degrees) > 0 else 0.0
    comm_degrees = [len(comm_adjacency[node_id]) for node_id in sorted(comm_adjacency.keys())]
    comm_degree_min = int(min(comm_degrees)) if len(comm_degrees) > 0 else 0
    comm_degree_max = int(max(comm_degrees)) if len(comm_degrees) > 0 else 0
    comm_degree_mean = float(np.mean(comm_degrees)) if len(comm_degrees) > 0 else 0.0
    topology_summary_path = os.path.join(output_dir, 'topology_summary.txt')
    with open(topology_summary_path, 'w', encoding='utf-8') as f:
        f.write(f"node_count={len(node_ids)}\n")
        f.write(f"spatial_topology_mode={config.TOPOLOGY_MODE}\n")
        f.write(f"spatial_neighbor_radius={config.NEIGHBOR_RADIUS}\n")
        f.write(f"spatial_k_neighbors={config.K_NEIGHBORS}\n")
        f.write(f"spatial_edge_count={len(spatial_rows)}\n")
        f.write(f"spatial_degree_min={spatial_degree_min}\n")
        f.write(f"spatial_degree_max={spatial_degree_max}\n")
        f.write(f"spatial_degree_mean={spatial_degree_mean:.6f}\n")
        f.write(f"comm_threshold={config.COMM_THRESHOLD}\n")
        f.write(f"comm_directed={config.COMM_DIRECTED}\n")
        f.write(f"comm_model={config.COMM_MODEL}\n")
        f.write(f"comm_random_seed={config.COMM_RANDOM_SEED}\n")
        f.write(f"comm_edge_count={len(comm_rows)}\n")
        f.write(f"comm_degree_min={comm_degree_min}\n")
        f.write(f"comm_degree_max={comm_degree_max}\n")
        f.write(f"comm_degree_mean={comm_degree_mean:.6f}\n")
        f.write(f"sentinel_strategy={config.SENTINEL_STRATEGY}\n")
        f.write(f"sentinel_ratio={config.SENTINEL_RATIO}\n")
        f.write(f"sentinel_anomaly_eta={config.ANOMALY_THRESHOLD_ETA}\n")
        f.write(f"sentinel_trigger_mode={config.SENTINEL_TRIGGER_MODE}\n")
        f.write(f"sentinel_trigger_consecutive_steps={config.SENTINEL_TRIGGER_CONSECUTIVE_STEPS}\n")
        f.write(f"sentinel_trigger_high_override_factor={config.SENTINEL_TRIGGER_HIGH_OVERRIDE_FACTOR}\n")
        f.write(f"sentinel_count={len(sentinel_ids)}\n")
        f.write(f"alert_duration_l={config.ALERT_DURATION_L}\n")
        f.write(f"alert_duration_semantics={config.ALERT_DURATION_SEMANTICS}\n")
        f.write(f"alert_neighbor_graph={config.ALERT_NEIGHBOR_GRAPH}\n")
        f.write(f"alert_propagation_mode={config.ALERT_PROPAGATION_MODE}\n")
        f.write(f"alert_max_hops={config.ALERT_MAX_HOPS}\n")
        f.write(f"alert_adaptive_hops_enabled={config.ALERT_ADAPTIVE_HOPS_ENABLED}\n")
        f.write(f"alert_adaptive_nis_medium={config.ALERT_ADAPTIVE_NIS_MEDIUM}\n")
        f.write(f"alert_adaptive_nis_high={config.ALERT_ADAPTIVE_NIS_HIGH}\n")
        f.write(f"alert_adaptive_hops_medium_delta={config.ALERT_ADAPTIVE_HOPS_MEDIUM_DELTA}\n")
        f.write(f"alert_adaptive_hops_high_delta={config.ALERT_ADAPTIVE_HOPS_HIGH_DELTA}\n")
        f.write(f"alert_adaptive_max_hops={config.ALERT_ADAPTIVE_MAX_HOPS}\n")
        f.write(f"enable_sentinel_alert_trigger={config.ENABLE_SENTINEL_ALERT_TRIGGER}\n")
        f.write(f"oracle_wakeup_enabled={config.ORACLE_WAKEUP_ENABLED}\n")
        f.write(f"oracle_wakeup_graph={config.ORACLE_WAKEUP_GRAPH}\n")
        f.write(f"enable_detailed_logs={detailed_logs_enabled}\n")
        f.write(f"spatial_anomaly_enabled={config.SPATIAL_ANOMALY_ENABLED}\n")
        f.write(f"spatial_anomaly_types={','.join(config.SPATIAL_ANOMALY_TYPES)}\n")
        f.write(f"spatial_anomaly_mode={getattr(config, 'SPATIAL_ANOMALY_MODE', 'fixed')}\n")
        f.write(f"spatial_anomaly_random_seed={getattr(config, 'SPATIAL_ANOMALY_RANDOM_SEED', config.RANDOM_SEED)}\n")
        f.write(f"spatial_random_event_count_target={getattr(config, 'SPATIAL_RANDOM_EVENT_COUNT', 0)}\n")
        f.write(f"spatial_static_distance_mode={config.SPATIAL_STATIC_DISTANCE_MODE}\n")
        f.write(f"spatial_static_graph={config.SPATIAL_STATIC_GRAPH}\n")
        f.write(f"spatial_static_max_hops={config.SPATIAL_STATIC_MAX_HOPS}\n")
    logging.info(f"Spatial topology mode: {config.TOPOLOGY_MODE}")
    logging.info(f"Spatial edges: {len(spatial_rows)}")
    logging.info(f"Spatial degree range: {spatial_degree_min}-{spatial_degree_max}, mean={spatial_degree_mean:.2f}")
    logging.info(f"Communication edges: {len(comm_rows)}")
    logging.info(f"Communication degree range: {comm_degree_min}-{comm_degree_max}, mean={comm_degree_mean:.2f}")
    logging.info(f"Communication model: {config.COMM_MODEL}")
    logging.info(f"Sentinel strategy: {config.SENTINEL_STRATEGY}, count: {len(sentinel_ids)}")
    logging.info(f"Sentinel anomaly eta: {config.ANOMALY_THRESHOLD_ETA}")
    logging.info(f"Sentinel trigger mode: {config.SENTINEL_TRIGGER_MODE}, consecutive_steps: {config.SENTINEL_TRIGGER_CONSECUTIVE_STEPS}")
    logging.info(f"Sentinel trigger high override factor: {config.SENTINEL_TRIGGER_HIGH_OVERRIDE_FACTOR}")
    logging.info(f"Alert duration L: {config.ALERT_DURATION_L}, semantics: {config.ALERT_DURATION_SEMANTICS}")
    logging.info(f"Alert graph: {config.ALERT_NEIGHBOR_GRAPH}, propagation: {config.ALERT_PROPAGATION_MODE}, hops: {config.ALERT_MAX_HOPS}")
    logging.info(f"Alert adaptive hops enabled: {config.ALERT_ADAPTIVE_HOPS_ENABLED}, nis_medium/high: {config.ALERT_ADAPTIVE_NIS_MEDIUM}/{config.ALERT_ADAPTIVE_NIS_HIGH}")
    logging.info(f"Sentinel alert trigger enabled: {config.ENABLE_SENTINEL_ALERT_TRIGGER}")
    logging.info(f"Oracle wake-up enabled: {config.ORACLE_WAKEUP_ENABLED}, graph: {config.ORACLE_WAKEUP_GRAPH}")
    if enable_plots:
        logging.info(f"Network adjacency plot saved: {graph_plot_path}")
        logging.info(f"Sentinel layout plot saved: {sentinel_plot_path}")
        logging.info(f"Communication adjacency plot saved: {comm_graph_plot_path}")
        logging.info(f"Connectivity heatmap saved: {connectivity_heatmap_path}")

    configured_anomalies = configure_spatial_anomalies(
        env,
        start_time=aligned_index[0],
        dt_sec=dt_sec,
        total_steps=len(aligned_index),
        node_ids=node_ids
    )
    anomaly_config_path = os.path.join(output_dir, "spatial_anomaly_config.csv")
    configured_anomaly_df = pd.DataFrame(configured_anomalies)
    configured_anomaly_df.to_csv(anomaly_config_path, index=False)
    if str(getattr(config, "SPATIAL_ANOMALY_MODE", "")).lower() == "controlled":
        manifest_path = getattr(config, "CONTROLLED_EVENT_MANIFEST", "")
        with open(manifest_path, "r", encoding="utf-8") as handle:
            manifest_payload = json.load(handle)
        with open(os.path.join(output_dir, "event_manifest.json"), "w", encoding="utf-8") as handle:
            json.dump(manifest_payload, handle, indent=2)
    logging.info(f"Spatial anomaly enabled: {config.SPATIAL_ANOMALY_ENABLED}, types: {config.SPATIAL_ANOMALY_TYPES}")
    logging.info(f"Spatial anomaly mode: {getattr(config, 'SPATIAL_ANOMALY_MODE', 'fixed')}, random_seed: {getattr(config, 'SPATIAL_ANOMALY_RANDOM_SEED', config.RANDOM_SEED)}")
    logging.info(f"Spatial anomaly configured events: {len(configured_anomalies)}")
    logging.info(f"Spatial anomaly config saved: {anomaly_config_path}")

    steps = len(aligned_index)
    logging.info(f"Multi-node baseline started with {len(node_ids)} nodes and {steps} strict-intersection steps.")
    for _ in range(steps):
        env.step()

    alert_events_path = os.path.join(output_dir, "alert_events.csv")
    alert_event_rows = []
    for event in env.alert_events:
        for sentinel_id in event["sentinels"]:
            alert_event_rows.append({
                "time": event["time"],
                "sentinel_id": sentinel_id,
                "neighbor_count": event["neighbor_count"],
                "neighbors": ",".join([str(x) for x in event["neighbors"]])
            })
    alert_events_df = pd.DataFrame(alert_event_rows, columns=["time", "sentinel_id", "neighbor_count", "neighbors"])
    alert_events_df.to_csv(alert_events_path, index=False)
    step_status_path = os.path.join(output_dir, "step_node_status.csv")
    anomaly_active_path = os.path.join(output_dir, "anomaly_active_nodes_by_step.csv")
    alert_load_path = os.path.join(output_dir, "alert_load_by_step.csv")
    event_alert_summary_path = os.path.join(output_dir, "event_alert_hit_summary.csv")
    node_energy_timeline_path = os.path.join(output_dir, "node_energy_timeline.csv")
    if detailed_logs_enabled:
        step_df, anomaly_active_df, alert_load_df, event_alert_summary_df, node_energy_df = build_detailed_log_tables(
            nodes=nodes,
            node_ids=node_ids,
            sentinel_ids=sentinel_ids,
            aligned_index=aligned_index,
            env=env
        )
        step_df.to_csv(step_status_path, index=False)
        anomaly_active_df.to_csv(anomaly_active_path, index=False)
        alert_load_df.to_csv(alert_load_path, index=False)
        event_alert_summary_df.to_csv(event_alert_summary_path, index=False)
        node_energy_df.to_csv(node_energy_timeline_path, index=False)

    metrics_rows = []
    save_node_histories = bool(getattr(config, "SAVE_NODE_HISTORIES", True))
    histories_dir = os.path.join(output_dir, "node_histories")
    if save_node_histories:
        os.makedirs(histories_dir, exist_ok=True)
    total_sampled = 0
    total_slots = len(node_ids) * steps

    for node_id in node_ids:
        node = nodes[node_id]
        history = node.history
        truth = aligned_data[node_id].loc[aligned_index, "temperature"].values
        sampled_count = int(np.sum(history["sampled"]))
        sampling_rate = sampled_count / steps if steps > 0 else np.nan
        rmse = calc_rmse(history["estimated"], truth)
        total_sampled += sampled_count

        metrics_rows.append({
            "node_id": node_id,
            "x": node_positions[node_id]["x"],
            "y": node_positions[node_id]["y"],
            "steps": steps,
            "sampled_count": sampled_count,
            "sampling_rate": sampling_rate,
            "rmse": rmse
        })

        if save_node_histories:
            node_history_df = pd.DataFrame({
                "time": aligned_index,
                "ground_truth": truth,
                "estimated": history["estimated"][:steps],
                "measured": history["measured"][:steps],
                "uncertainty_pred": history["uncertainty_pred"][:steps],
                "uncertainty_post": history["uncertainty_post"][:steps],
                "sampled": history["sampled"][:steps],
                "predicted": history["predicted"][:steps],
                "innovation": history["innovation"][:steps],
                "nis": history["nis"][:steps],
                "signed_norm_innovation": history["signed_norm_innovation"][:steps],
                "glr_stat_up": history["glr_stat_up"][:steps],
                "glr_stat_down": history["glr_stat_down"][:steps],
                "mosum_stat_up": history["mosum_stat_up"][:steps],
                "mosum_stat_down": history["mosum_stat_down"][:steps],
                "mode": history["mode"][:steps],
                "anomaly_flag": history["anomaly_flag"][:steps],
                "gt_anomaly_flag": history["gt_anomaly_flag"][:steps],
                "gt_event_ids": history["gt_event_ids"][:steps]
            })
            node_history_df.to_csv(os.path.join(histories_dir, f"node_{node_id}.csv"), index=False)

    gt_anomaly_total = int(sum(np.nansum(nodes[node_id].history["gt_anomaly_flag"]) for node_id in node_ids))
    gt_anomaly_nodes = int(sum(1 for node_id in node_ids if np.nansum(nodes[node_id].history["gt_anomaly_flag"]) > 0))
    detection_metrics, delay_df, energy_metrics = compute_task6_metrics(nodes, node_ids, sentinel_ids, aligned_index, env)
    detection_metrics_path = os.path.join(output_dir, "task6_detection_metrics.csv")
    pd.DataFrame([detection_metrics]).to_csv(detection_metrics_path, index=False)
    delay_path = os.path.join(output_dir, "task6_detection_delay_by_event.csv")
    delay_df.to_csv(delay_path, index=False)
    energy_path = os.path.join(output_dir, "task6_energy_proxy.csv")
    pd.DataFrame([energy_metrics]).to_csv(energy_path, index=False)
    task8_main, task8_event_df, task8_deadline_df, task8_cost_metrics = compute_task8_metrics(
        nodes=nodes,
        node_ids=node_ids,
        sentinel_ids=sentinel_ids,
        aligned_index=aligned_index,
        env=env,
        detection_metrics=detection_metrics,
        energy_metrics=energy_metrics,
        aligned_data=aligned_data
    )
    task8_main_path = os.path.join(output_dir, "task8_metrics_main.csv")
    pd.DataFrame([task8_main]).to_csv(task8_main_path, index=False)
    task8_event_path = os.path.join(output_dir, "task8_event_onset_detection.csv")
    task8_event_df.to_csv(task8_event_path, index=False)
    task8_deadline_path = os.path.join(output_dir, "task8_deadline_hit.csv")
    task8_deadline_df.to_csv(task8_deadline_path, index=False)
    task8_cost_path = os.path.join(output_dir, "task8_cost_normalized.csv")
    pd.DataFrame([task8_cost_metrics]).to_csv(task8_cost_path, index=False)
    learned_candidate_path = os.path.join(output_dir, "target_ranker_candidates.csv")
    if getattr(env, "target_ranker_records", []):
        pd.DataFrame(env.target_ranker_records).to_csv(learned_candidate_path, index=False)
    realert_target_path = os.path.join(output_dir, "realert_target_records.csv")
    if getattr(env, "realert_target_records", []):
        pd.DataFrame(env.realert_target_records).to_csv(realert_target_path, index=False)
    if bool(getattr(config, "STRUCTURAL_TRACE_ENABLED", False)) and getattr(env, "realert_funnel_records", []):
        pd.DataFrame(env.realert_funnel_records).to_csv(
            os.path.join(output_dir, "realert_funnel_diagnostic.csv"), index=False
        )
    if bool(getattr(config, "STRUCTURAL_TRACE_ENABLED", False)) and getattr(env, "realert_decision_context_records", []):
        pd.DataFrame(env.realert_decision_context_records).to_csv(
            os.path.join(output_dir, "realert_decision_context_diagnostic.csv"), index=False
        )
    comm_event_path = os.path.join(output_dir, "communication_energy_events.csv")
    if getattr(env, "node_comm_energy_records", []):
        pd.DataFrame(env.node_comm_energy_records).to_csv(comm_event_path, index=False)
    probe_trace_path = os.path.join(output_dir, "probe_evidence_trace.csv")
    if getattr(env, "probe_evidence_records", []):
        pd.DataFrame(env.probe_evidence_records).to_csv(probe_trace_path, index=False)
    if bool(getattr(config, "STRUCTURAL_TRACE_ENABLED", False)):
        trace_exports = {
            "EVENT_STATE_TRACE.csv": (env.event_state_trace, [
                "step", "time", "event_id", "created_step", "expires_step", "active", "source_id",
                "confirmed_node_count", "confirmed_node_ids", "true_event_ids_observed",
                "true_event_front_node_count", "true_event_front_node_ids",
                "global_gt_front_node_count", "global_gt_front_node_ids", "realert_record_count",
            ]),
            "RETAINED_RECORD_TIMELINE.csv": (env.retained_record_timeline, [
                "step", "time", "record_index", "event_id", "target_id", "event_active", "selected",
                "probe_upgraded", "probe_failed", "final_confirmed", "final_confirmed_by_probe_upgrade",
                "deferred_by_active_cap", "cooldown", "path_hops",
            ]),
            "NODE_STATE_DURATION_TRACE.csv": (env.node_state_duration_trace, [
                "step", "time", "node_id", "state_during_slot", "state_after_slot", "state_duration_sec",
                "sampled", "sample_duration_sec", "tx_packets", "rx_packets", "tx_energy_mj", "rx_energy_mj",
                "budgeted_frontier_active", "budgeted_frontier_high_rate",
            ]),
            "BUDGETED_FRONTIER_SELECTION_TRACE.csv": (env.budgeted_frontier_selection_trace, [
                "step", "event_id", "node_id", "confirmation_step",
                "unconfirmed_nonsentinel_neighbor_count", "event_route_hops",
                "unique_coverage_mandatory", "rank_position",
                "selected_for_event_high_rate", "selected_by_any_event_high_rate",
            ]),
        }
        if bool(getattr(config, "ALERT_POST_EXPIRY_COVERAGE_SERVICE_ENABLED", False)):
            trace_exports["POST_EXPIRY_COVERAGE_SELECTION_TRACE.csv"] = (
                env.post_expiry_coverage_selection_trace,
                [
                    "step", "record_type", "event_id", "node_id",
                    "retained_confirmed_count", "eligible_candidate_count",
                    "forced_full_observer_count", "coverable_unresolved_count",
                    "selected_count", "selected_node_ids", "coverage_invariant_pass",
                    "failure_reason", "active_event_involvement",
                    "retained_expired_event_count", "selected_by_event_count",
                    "physical_full_rate", "period2_due_after_clock",
                    "physical_service_command", "initial_sample_command",
                    "observation_available", "parent_late_sample_override",
                    "actual_sample", "sampled", "logical_state_preserved_by_y3",
                    "logical_mode_before", "logical_mode_after",
                    "alert_confirmed_before", "alert_confirmed_after",
                    "alert_event_id_before", "alert_event_id_after",
                    "event_watch_ids_before", "event_watch_ids_after",
                    "failure_count_before", "failure_count_after",
                ],
            )
        for filename, (rows, columns) in trace_exports.items():
            pd.DataFrame(rows, columns=columns).to_csv(os.path.join(output_dir, filename), index=False)

    metrics_df = pd.DataFrame(metrics_rows).sort_values("node_id")
    metrics_path = os.path.join(output_dir, "node_metrics.csv")
    metrics_df.to_csv(metrics_path, index=False)
    degree_dist_path = os.path.join(output_dir, "degree_distribution.png")
    metrics_dist_path = os.path.join(output_dir, "metrics_distribution.png")
    sentinel_vs_normal_path = os.path.join(output_dir, "sentinel_vs_normal_boxplot.png")
    if enable_plots:
        plot_degree_distribution(
            spatial_degrees=spatial_degrees,
            comm_degrees=comm_degrees,
            output_path=degree_dist_path
        )
        plot_metrics_distribution(
            metrics_df=metrics_df,
            output_path=metrics_dist_path
        )
        plot_sentinel_vs_normal_boxplot(
            metrics_df=metrics_df,
            sentinel_ids=sentinel_ids,
            output_path=sentinel_vs_normal_path
        )
    sentinel_detect_counts = {node_id: int(np.nansum(nodes[node_id].history["anomaly_flag"][:steps])) for node_id in sentinel_ids}
    sentinel_detect_bar_path = os.path.join(output_dir, "sentinel_detection_bar.png")
    if enable_plots:
        plot_sentinel_detection_bar(
            sentinel_ids=sentinel_ids,
            detect_counts=sentinel_detect_counts,
            output_path=sentinel_detect_bar_path
        )
    gt_count_per_step = np.array([sum(nodes[node_id].history["gt_anomaly_flag"][i] for node_id in node_ids) for i in range(steps)])
    sentinel_detect_count_per_step = np.array([sum(nodes[node_id].history["anomaly_flag"][i] for node_id in sentinel_ids) for i in range(steps)])
    alert_count_per_step = np.array([sum(1 for node_id in node_ids if nodes[node_id].history["mode"][i] == 'alert') for i in range(steps)])
    timeline_path = os.path.join(output_dir, "alert_detection_timeline.png")
    if enable_plots:
        plot_alert_detection_timeline(
            times=aligned_index,
            gt_count_per_step=gt_count_per_step,
            sentinel_detect_count_per_step=sentinel_detect_count_per_step,
            alert_count_per_step=alert_count_per_step,
            output_path=timeline_path
        )
    task8_onset_plot_path = os.path.join(output_dir, "task8_event_onset_timeline.png")
    task8_deadline_plot_path = os.path.join(output_dir, "task8_deadline_hit.png")
    task8_alert_usefulness_plot_path = os.path.join(output_dir, "task8_alert_usefulness.png")
    task8_cost_benefit_plot_path = os.path.join(output_dir, "task8_cost_benefit_point.png")
    if enable_plots:
        plot_event_onset_detection_timeline(
            event_df=task8_event_df,
            output_path=task8_onset_plot_path
        )
        plot_deadline_hit_rates(
            deadline_df=task8_deadline_df,
            output_path=task8_deadline_plot_path
        )
        plot_task8_metric_bars(
            alert_metrics=task8_main,
            output_path=task8_alert_usefulness_plot_path
        )
        plot_cost_benefit_point(
            cost_metrics=task8_cost_metrics,
            output_path=task8_cost_benefit_plot_path
        )
    diag_node_id, nearest_sentinel_id = select_diagnostic_target_node(nodes, node_ids, sentinel_ids, node_positions)
    diag_history = nodes[diag_node_id].history
    diag_truth = aligned_data[diag_node_id].loc[aligned_index, "temperature"].values
    diag_sampled = np.array(diag_history["sampled"][:steps], dtype=float)
    diag_alert = np.array([1.0 if m == 'alert' else 0.0 for m in diag_history["mode"][:steps]], dtype=float)
    diag_plot_path = os.path.join(output_dir, "node_anomaly_diagnostic.png")
    if enable_plots:
        plot_node_kf_anomaly_diagnostic(
            times=aligned_index,
            ground_truth=diag_truth,
            estimated=np.array(diag_history["estimated"][:steps], dtype=float),
            measured=np.array(diag_history["measured"][:steps], dtype=float),
            sampled_flags=diag_sampled,
            gt_anomaly_flags=np.array(diag_history["gt_anomaly_flag"][:steps], dtype=float),
            alert_mode_flags=diag_alert,
            nis=np.array(diag_history["nis"][:steps], dtype=float),
            uncertainty_pred=np.array(diag_history["uncertainty_pred"][:steps], dtype=float),
            gamma=config.GAMMA,
            output_path=diag_plot_path,
            title=f"Node {diag_node_id} Diagnostic (nearest sentinel={nearest_sentinel_id})"
        )
    diag_meta_path = os.path.join(output_dir, "node_anomaly_diagnostic_meta.csv")
    pd.DataFrame([{
        "diagnostic_node_id": diag_node_id,
        "nearest_sentinel_id": nearest_sentinel_id,
        "distance_to_nearest_sentinel": np.sqrt((node_positions[diag_node_id]["x"] - node_positions[nearest_sentinel_id]["x"]) ** 2 + (node_positions[diag_node_id]["y"] - node_positions[nearest_sentinel_id]["y"]) ** 2) if nearest_sentinel_id is not None else np.nan,
        "diagnostic_node_gt_anomaly_count": int(np.nansum(diag_history["gt_anomaly_flag"][:steps]))
    }]).to_csv(diag_meta_path, index=False)

    aggregate_sampling_rate = total_sampled / total_slots if total_slots > 0 else np.nan
    aggregate_rmse_mean = float(metrics_df["rmse"].mean())
    aggregate_rmse_std = float(metrics_df["rmse"].std(ddof=0))

    aggregate_path = os.path.join(output_dir, "aggregate_metrics.txt")
    with open(aggregate_path, "w", encoding="utf-8") as f:
        f.write(f"node_count={len(node_ids)}\n")
        f.write(f"sentinel_count={len(sentinel_ids)}\n")
        f.write(f"sentinel_strategy={config.SENTINEL_STRATEGY}\n")
        f.write(f"sentinel_anomaly_eta={config.ANOMALY_THRESHOLD_ETA}\n")
        f.write(f"sentinel_trigger_mode={config.SENTINEL_TRIGGER_MODE}\n")
        f.write(f"sentinel_trigger_consecutive_steps={config.SENTINEL_TRIGGER_CONSECUTIVE_STEPS}\n")
        f.write(f"sentinel_trigger_high_override_factor={config.SENTINEL_TRIGGER_HIGH_OVERRIDE_FACTOR}\n")
        f.write(f"alert_duration_l={config.ALERT_DURATION_L}\n")
        f.write(f"alert_duration_semantics={config.ALERT_DURATION_SEMANTICS}\n")
        f.write(f"alert_neighbor_graph={config.ALERT_NEIGHBOR_GRAPH}\n")
        f.write(f"alert_propagation_mode={config.ALERT_PROPAGATION_MODE}\n")
        f.write(f"alert_max_hops={config.ALERT_MAX_HOPS}\n")
        f.write(f"alert_adaptive_hops_enabled={config.ALERT_ADAPTIVE_HOPS_ENABLED}\n")
        f.write(f"alert_adaptive_nis_medium={config.ALERT_ADAPTIVE_NIS_MEDIUM}\n")
        f.write(f"alert_adaptive_nis_high={config.ALERT_ADAPTIVE_NIS_HIGH}\n")
        f.write(f"alert_adaptive_hops_medium_delta={config.ALERT_ADAPTIVE_HOPS_MEDIUM_DELTA}\n")
        f.write(f"alert_adaptive_hops_high_delta={config.ALERT_ADAPTIVE_HOPS_HIGH_DELTA}\n")
        f.write(f"alert_adaptive_max_hops={config.ALERT_ADAPTIVE_MAX_HOPS}\n")
        f.write(f"enable_sentinel_alert_trigger={config.ENABLE_SENTINEL_ALERT_TRIGGER}\n")
        f.write(f"oracle_wakeup_enabled={config.ORACLE_WAKEUP_ENABLED}\n")
        f.write(f"oracle_wakeup_graph={config.ORACLE_WAKEUP_GRAPH}\n")
        f.write(f"alert_event_count={len(env.alert_events)}\n")
        f.write(f"oracle_alert_event_count={len(env.oracle_alert_events)}\n")
        f.write(f"enable_detailed_logs={detailed_logs_enabled}\n")
        f.write(f"spatial_anomaly_enabled={config.SPATIAL_ANOMALY_ENABLED}\n")
        f.write(f"spatial_anomaly_types={','.join(config.SPATIAL_ANOMALY_TYPES)}\n")
        f.write(f"spatial_anomaly_mode={getattr(config, 'SPATIAL_ANOMALY_MODE', 'fixed')}\n")
        f.write(f"spatial_anomaly_random_seed={getattr(config, 'SPATIAL_ANOMALY_RANDOM_SEED', config.RANDOM_SEED)}\n")
        f.write(f"spatial_random_event_count_target={getattr(config, 'SPATIAL_RANDOM_EVENT_COUNT', 0)}\n")
        f.write(f"spatial_anomaly_configured_count={len(configured_anomalies)}\n")
        f.write(f"spatial_static_distance_mode={config.SPATIAL_STATIC_DISTANCE_MODE}\n")
        f.write(f"spatial_static_graph={config.SPATIAL_STATIC_GRAPH}\n")
        f.write(f"spatial_static_max_hops={config.SPATIAL_STATIC_MAX_HOPS}\n")
        f.write(f"gt_anomaly_total_flags={gt_anomaly_total}\n")
        f.write(f"gt_anomaly_affected_nodes={gt_anomaly_nodes}\n")
        f.write(f"tp={detection_metrics['tp']}\n")
        f.write(f"fp={detection_metrics['fp']}\n")
        f.write(f"fn={detection_metrics['fn']}\n")
        f.write(f"precision={detection_metrics['precision']:.6f}\n")
        f.write(f"recall={detection_metrics['recall']:.6f}\n")
        f.write(f"f1={detection_metrics['f1']:.6f}\n")
        f.write(f"detection_delay_mean_steps={detection_metrics['detection_delay_mean_steps']}\n")
        f.write(f"detection_delay_mean_seconds={detection_metrics['detection_delay_mean_seconds']}\n")
        f.write(f"energy_proxy_total={energy_metrics['total_energy_proxy']:.6f}\n")
        f.write(f"energy_proxy_sensing={energy_metrics['sensing_energy_proxy']:.6f}\n")
        f.write(f"energy_proxy_alert={energy_metrics['alert_energy_proxy']:.6f}\n")
        f.write(f"energy_proxy_trigger={energy_metrics['trigger_energy_proxy']:.6f}\n")
        f.write(f"task8_event_detection_rate={task8_main['event_detection_rate']}\n")
        f.write(f"task8_onset_delay_mean_steps={task8_main['onset_detection_delay_mean_steps']}\n")
        f.write(f"task8_alert_precision={task8_main['alert_precision']}\n")
        f.write(f"task8_alert_coverage_l={task8_main['alert_coverage_l']}\n")
        f.write(f"task8_alert_coverage_l_legacy_strict={task8_main['alert_coverage_l_legacy_strict']}\n")
        f.write(f"task8_alert_coverage_alert_only={task8_main['alert_coverage_alert_only']}\n")
        f.write(f"task8_alert_coverage_sampling_only={task8_main['alert_coverage_sampling_only']}\n")
        f.write(f"task8_alert_coverage_definition={task8_main['alert_coverage_definition']}\n")
        f.write(f"task8_coverage_zero_rate={task8_main['coverage_zero_rate']}\n")
        f.write(f"task8_coverage_high_rate={task8_main['coverage_high_rate']}\n")
        f.write(f"task8_wakeup_effectiveness={task8_main['wakeup_effectiveness']}\n")
        f.write(f"task8_recovery_gain_proxy={task8_main['recovery_gain_proxy']}\n")
        f.write(f"task8_recovery_gain_strict={task8_main['recovery_gain_strict']}\n")
        f.write(f"task8_recovery_rmse_baseline_noalert={task8_main['recovery_rmse_baseline_noalert']}\n")
        f.write(f"task8_rmse_anomaly_window={task8_main['rmse_anomaly_window']}\n")
        f.write(f"task8_rmse_global={task8_main['rmse_global']}\n")
        f.write(f"task8_recovery_rmse_actual={task8_main['recovery_rmse_actual']}\n")
        f.write(f"task8_detection_per_energy={task8_main['detection_per_energy']}\n")
        f.write(f"task8_marginal_sentinel_utility_proxy={task8_main['marginal_sentinel_utility_proxy']}\n")
        f.write(f"task8_detection_source={task8_main['task8_detection_source']}\n")
        for row in task8_deadline_df.itertuples(index=False):
            f.write(f"task8_deadline_hit_rate_{int(row.deadline_steps)}={row.hit_rate}\n")
        f.write(f"steps={steps}\n")
        f.write(f"timeline_start={aligned_index[0]}\n")
        f.write(f"timeline_end={aligned_index[-1]}\n")
        f.write(f"sampling_rate_global={aggregate_sampling_rate:.6f}\n")
        f.write(f"rmse_mean={aggregate_rmse_mean:.6f}\n")
        f.write(f"rmse_std={aggregate_rmse_std:.6f}\n")

    logging.info(f"Node metrics saved: {metrics_path}")
    logging.info(f"Alert events saved: {alert_events_path}")
    if detailed_logs_enabled:
        logging.info(f"Step node status saved: {step_status_path}")
        logging.info(f"Anomaly active nodes by step saved: {anomaly_active_path}")
        logging.info(f"Alert load by step saved: {alert_load_path}")
        logging.info(f"Event alert hit summary saved: {event_alert_summary_path}")
    if enable_plots:
        logging.info(f"Degree distribution plot saved: {degree_dist_path}")
        logging.info(f"Metrics distribution plot saved: {metrics_dist_path}")
        logging.info(f"Sentinel vs normal boxplot saved: {sentinel_vs_normal_path}")
        logging.info(f"Sentinel detection bar saved: {sentinel_detect_bar_path}")
        logging.info(f"Alert detection timeline saved: {timeline_path}")
        logging.info(f"Node anomaly diagnostic saved: {diag_plot_path}")
    logging.info(f"Task6 detection metrics saved: {detection_metrics_path}")
    logging.info(f"Task6 delay metrics saved: {delay_path}")
    logging.info(f"Task6 energy proxy saved: {energy_path}")
    logging.info(f"Task8 main metrics saved: {task8_main_path}")
    logging.info(f"Task8 event onset saved: {task8_event_path}")
    logging.info(f"Task8 deadline hit saved: {task8_deadline_path}")
    logging.info(f"Task8 cost-normalized saved: {task8_cost_path}")
    if enable_plots:
        logging.info(f"Task8 onset timeline plot saved: {task8_onset_plot_path}")
        logging.info(f"Task8 deadline plot saved: {task8_deadline_plot_path}")
        logging.info(f"Task8 alert usefulness plot saved: {task8_alert_usefulness_plot_path}")
        logging.info(f"Task8 cost-benefit plot saved: {task8_cost_benefit_plot_path}")
    logging.info(f"Task8 EDR/ODD: {task8_main['event_detection_rate']}/{task8_main['onset_detection_delay_mean_steps']}")
    logging.info(f"Task8 deadline hit rates: {task8_deadline_df.to_dict(orient='records')}")
    logging.info(f"Task8 Alert Precision/Coverage/Wakeup: {task8_main['alert_precision']}/{task8_main['alert_coverage_l']}/{task8_main['wakeup_effectiveness']}")
    logging.info(f"Task8 Coverage Definition: {task8_main['alert_coverage_definition']}")
    logging.info(f"Task8 Coverage Legacy Strict: {task8_main['alert_coverage_l_legacy_strict']}")
    logging.info(f"Task8 Alert Coverage (alert_only): {task8_main['alert_coverage_alert_only']}")
    logging.info(f"Task8 Alert Coverage (sampling_only): {task8_main['alert_coverage_sampling_only']}")
    logging.info(f"Task8 Coverage Zero/High Rate: {task8_main['coverage_zero_rate']}/{task8_main['coverage_high_rate']}")
    logging.info(f"Task8 Recovery Strict Gain: {task8_main['recovery_gain_strict']}, baseline_rmse={task8_main['recovery_rmse_baseline_noalert']}, actual_rmse={task8_main['recovery_rmse_actual']}")
    logging.info(f"Task6 Precision/Recall/F1: {detection_metrics['precision']:.4f}/{detection_metrics['recall']:.4f}/{detection_metrics['f1']:.4f}")
    logging.info(f"Task6 TP/FP/FN: {detection_metrics['tp']}/{detection_metrics['fp']}/{detection_metrics['fn']}")
    logging.info(f"Aggregate metrics saved: {aggregate_path}")
    logging.info(f"Global Sampling Rate: {aggregate_sampling_rate:.2%}")
    logging.info(f"RMSE Mean ± Std: {aggregate_rmse_mean:.4f} ± {aggregate_rmse_std:.4f}")


if __name__ == "__main__":
    run_multinode_baseline_experiment()
