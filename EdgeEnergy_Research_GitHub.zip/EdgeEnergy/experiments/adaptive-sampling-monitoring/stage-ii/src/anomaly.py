import numpy as np
import pandas as pd


class AnomalyInjector:
    def __init__(self):
        self.anomalies = []
        self.next_event_id = 1
        self._dist_map_cache = {}

    def _alloc_event_id(self):
        event_id = self.next_event_id
        self.next_event_id += 1
        return event_id

    def add_anomaly(self, anomaly_type, start_time, duration_steps, magnitude, node_id=None, recovery_mode='abrupt', recovery_steps=0):
        event_id = self._alloc_event_id()
        self.anomalies.append({
            'event_id': event_id,
            'type': anomaly_type,
            'start_time': start_time,
            'duration_steps': duration_steps,
            'magnitude': magnitude,
            'node_id': node_id,
            'recovery_mode': str(recovery_mode),
            'recovery_steps': int(recovery_steps)
        })
        return event_id

    def add_spatial_static_anomaly(self, start_time, duration_steps, center_node_id, radius, magnitude, spatial_decay='linear', distance_mode='euclidean', graph='spatial', max_hops=3, recovery_mode='abrupt', recovery_steps=0):
        event_id = self._alloc_event_id()
        self.anomalies.append({
            'event_id': event_id,
            'type': 'spatial_static',
            'start_time': start_time,
            'duration_steps': duration_steps,
            'center_node_id': center_node_id,
            'radius': float(radius),
            'magnitude': float(magnitude),
            'spatial_decay': spatial_decay,
            'distance_mode': distance_mode,
            'graph': graph,
            'max_hops': int(max_hops),
            'recovery_mode': str(recovery_mode),
            'recovery_steps': int(recovery_steps)
        })
        return event_id

    def add_spatiotemporal_diffusion_anomaly(self, start_time, duration_steps, source_node_id, base_magnitude, graph='spatial', max_hops=4, propagation_delay_steps=2, hop_decay=0.7, temporal_growth_steps=6, onset_mode='gradual', recovery_mode='abrupt', recovery_steps=0, propagation_edges=None, allowed_nodes=None, contract_type=None):
        event_id = self._alloc_event_id()
        self.anomalies.append({
            'event_id': event_id,
            'type': 'spatiotemporal_diffusion',
            'start_time': start_time,
            'duration_steps': duration_steps,
            'source_node_id': source_node_id,
            'base_magnitude': float(base_magnitude),
            'graph': graph,
            'max_hops': int(max_hops),
            'propagation_delay_steps': int(propagation_delay_steps),
            'hop_decay': float(hop_decay),
            'temporal_growth_steps': int(temporal_growth_steps),
            'onset_mode': str(onset_mode).strip().lower(),
            'recovery_mode': str(recovery_mode),
            'recovery_steps': int(recovery_steps)
            , 'propagation_edges': propagation_edges
            , 'allowed_nodes': None if allowed_nodes is None else [int(x) for x in allowed_nodes]
            , 'contract_type': contract_type
        })
        return event_id

    def _recovery_factor(self, anomaly, step_idx):
        duration_steps = max(1, int(anomaly.get('duration_steps', 1)))
        recovery_mode = str(anomaly.get('recovery_mode', 'abrupt')).strip().lower()
        recovery_steps = max(0, int(anomaly.get('recovery_steps', 0)))
        if step_idx < duration_steps:
            return 1.0
        if recovery_mode != 'gradual' or recovery_steps <= 0:
            return 0.0
        decay_idx = step_idx - duration_steps
        if decay_idx < 0 or decay_idx >= recovery_steps:
            return 0.0
        return max(0.0, 1.0 - float(decay_idx + 1) / float(recovery_steps + 1))

    def _build_dist_map(self, src, adjacency, graph_name):
        key = (graph_name, src)
        if key in self._dist_map_cache:
            return self._dist_map_cache[key]
        dist_map = {src: 0}
        frontier = [src]
        while len(frontier) > 0:
            node = frontier.pop(0)
            next_dist = dist_map[node] + 1
            for neigh in adjacency.get(node, []):
                if neigh not in dist_map:
                    dist_map[neigh] = next_dist
                    frontier.append(neigh)
        self._dist_map_cache[key] = dist_map
        return dist_map

    def _get_hop(self, src, dst, adjacency, graph_name):
        dist_map = self._build_dist_map(src, adjacency, graph_name)
        return dist_map.get(dst, None)

    def _diffusion_temporal_factor(self, anomaly, active_steps):
        onset_mode = str(anomaly.get('onset_mode', 'gradual')).strip().lower()
        if onset_mode == 'abrupt':
            return 1.0
        growth = max(0, int(anomaly.get('temporal_growth_steps', 0)))
        if growth <= 0:
            return 1.0
        return min(1.0, float(active_steps) / float(growth))

    def get_injected_value(self, original_value, current_time, node_id, time_step_delta, node_positions=None, spatial_adjacency=None, communication_adjacency=None):
        if original_value is None:
            return None, False, []
        final_value = original_value
        active_event_ids = []
        eps = 1e-12
        for anomaly in self.anomalies:
            anomaly_node_id = anomaly.get('node_id', None)
            if anomaly_node_id is not None and anomaly_node_id != node_id:
                continue
            if current_time < anomaly['start_time']:
                continue
            elapsed_time = current_time - anomaly['start_time']
            step_idx = int(elapsed_time / time_step_delta)
            # Non-propagating anomalies share the event clock.  A propagating
            # anomaly instead starts its duration/recovery clock when the front
            # reaches each node; applying the source clock here truncates late
            # arrivals and can make configured outer hops unreachable.
            recovery_factor = None
            if anomaly['type'] != 'spatiotemporal_diffusion':
                total_steps = int(anomaly['duration_steps']) + max(0, int(anomaly.get('recovery_steps', 0)))
                if step_idx >= total_steps:
                    continue
                recovery_factor = self._recovery_factor(anomaly, step_idx)
                if recovery_factor <= 0.0:
                    continue
            delta = 0.0
            if anomaly['type'] == 'pulse':
                if step_idx == 0:
                    delta = float(anomaly['magnitude'])
            elif anomaly['type'] == 'step':
                delta = float(anomaly['magnitude'])
            elif anomaly['type'] == 'ramp':
                progress = min(step_idx, max(0, anomaly['duration_steps'] - 1)) / max(1, anomaly['duration_steps'] - 1)
                delta = float(anomaly['magnitude']) * progress
            elif anomaly['type'] == 'spatial_static':
                if node_positions is not None:
                    center_id = anomaly['center_node_id']
                    if center_id in node_positions and node_id in node_positions:
                        if anomaly.get('distance_mode', 'euclidean') == 'euclidean':
                            center_pos = node_positions[center_id]
                            node_pos = node_positions[node_id]
                            dx = node_pos['x'] - center_pos['x']
                            dy = node_pos['y'] - center_pos['y']
                            dist = float(np.sqrt(dx * dx + dy * dy))
                            radius = max(1e-9, anomaly['radius'])
                            if dist <= radius:
                                if anomaly['spatial_decay'] == 'linear':
                                    factor = max(0.0, 1.0 - dist / radius)
                                else:
                                    factor = 1.0
                                delta = float(anomaly['magnitude']) * factor
                        else:
                            if anomaly.get('graph', 'spatial') == 'communication':
                                adjacency = communication_adjacency if communication_adjacency is not None else {}
                                graph_name = 'communication'
                            else:
                                adjacency = spatial_adjacency if spatial_adjacency is not None else {}
                                graph_name = 'spatial'
                            hop = self._get_hop(center_id, node_id, adjacency, graph_name)
                            max_hops = max(1, int(anomaly.get('max_hops', 1)))
                            if hop is not None and hop <= max_hops:
                                if anomaly['spatial_decay'] == 'linear':
                                    factor = max(0.0, 1.0 - hop / max_hops)
                                else:
                                    factor = 1.0
                                delta = float(anomaly['magnitude']) * factor
            elif anomaly['type'] == 'spatiotemporal_diffusion':
                if anomaly['graph'] == 'communication':
                    adjacency = communication_adjacency if communication_adjacency is not None else {}
                    graph_name = 'communication'
                else:
                    adjacency = spatial_adjacency if spatial_adjacency is not None else {}
                    graph_name = 'spatial'
                allowed = anomaly.get('allowed_nodes')
                if allowed is not None and node_id not in set(allowed):
                    continue
                masked_edges = anomaly.get('propagation_edges')
                if masked_edges is not None:
                    masked = {nid: [] for nid in adjacency}
                    for edge in masked_edges:
                        src, dst = int(edge[0]), int(edge[1])
                        if src in masked and dst in masked:
                            masked[src].append(dst)
                            masked[dst].append(src)
                    adjacency = masked
                    graph_name = f"{graph_name}:event:{anomaly['event_id']}"
                hop = self._get_hop(anomaly['source_node_id'], node_id, adjacency, graph_name)
                if hop is not None and hop <= anomaly['max_hops']:
                    arrival_step = hop * max(0, anomaly['propagation_delay_steps'])
                    if step_idx >= arrival_step:
                        active_steps = step_idx - arrival_step
                        recovery_factor = self._recovery_factor(anomaly, active_steps)
                        if recovery_factor > 0.0:
                            temporal_factor = self._diffusion_temporal_factor(anomaly, active_steps)
                            hop_factor = anomaly['hop_decay'] ** hop
                            delta = anomaly['base_magnitude'] * hop_factor * temporal_factor
            if recovery_factor is None:
                continue
            delta *= recovery_factor
            if abs(delta) > eps:
                final_value += delta
                active_event_ids.append(anomaly['event_id'])
        is_anomaly = len(active_event_ids) > 0
        return final_value, is_anomaly, sorted(list(set(active_event_ids)))
