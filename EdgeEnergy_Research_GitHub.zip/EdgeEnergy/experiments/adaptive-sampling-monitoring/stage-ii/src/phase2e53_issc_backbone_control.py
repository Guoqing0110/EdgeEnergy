"""E5-3 formula-level ISSC-backbone control runner.

This wrapper changes only the upstream detector/placement and selects one of the
two preregistered post-trigger policies. It is fail-closed for 441-460 and does
not expose a calibration path.
"""
from pathlib import Path
import hashlib, json
import argparse
import numpy as np
import pandas as pd
import src.config as config
from src.run_conclusion_experiments import config_override
from src.run_multinode_baseline import run_multinode_baseline_experiment
from src.run_ream_experiments import PROPAGATION_VARIANTS

ROOT=Path(config.PROJECT_ROOT)
OUT=ROOT/'phase2_paper_evidence/e5_3_issc_backbone_control'
SEEDS=set(range(441,461))
METHODS={'DF-ReAlert-corrected-B2.7-Y1':('CR-delayedFront-locked-topK5','full'), 'Fixed-two-hop-verify3':('fixed_2_hop_verify3',None)}
PROTOCOL=OUT/'E5_3_ISSC_BACKBONE_PREREGISTRATION.md'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def overrides(method, seed, output, trace=True):
    base=PROPAGATION_VARIANTS[METHODS[method][0]]
    d={**base,'START_TIME':pd.Timestamp('2004-02-28 01:03:00'),'END_TIME':pd.Timestamp('2004-02-28 05:03:00'),'OUTPUT_DIR':str(output),'DATASET_MODE':'intel','RANDOM_SEED':int(seed),'SPATIAL_ANOMALY_RANDOM_SEED':int(seed),'COMM_RANDOM_SEED':42,'STRUCTURAL_TRACE_ENABLED':bool(trace),'ENABLE_PLOTS':False,'SAVE_NODE_HISTORIES':False,'ENABLE_DETAILED_LOGS':True,'SENTINEL_DETECTOR_MODE':'glr','SENTINEL_GLR_WINDOW_MIN':1,'SENTINEL_GLR_WINDOW_MAX':8,'SENTINEL_GLR_THRESHOLD':6.0,'SENTINEL_GLR_DIRECTION':'both','SENTINEL_GLR_RESET':1.0,'SENTINEL_GLR_RELATIVE_ENABLED':True,'SENTINEL_GLR_RELATIVE_K':3.0,'SENTINEL_GLR_RELATIVE_FLOOR':3.4,'SENTINEL_STRATEGY':'spatial_optimal_cover','SENTINEL_RATIO':0.15,'SENTINEL_OPT_ALLOW_FEWER':False}
    if mode:=METHODS[method][1]:
        d.update({'ALERT_FRONTIER_ANCHORED_RETAINED_SCOPE_ENABLED':True,'ALERT_FRONT_TRIGGERED_RECONSIDERATION_ENABLED':True,'ALERT_FRONT_TRIGGERED_RECONSIDERATION_MIN_REFRACTORY_STEPS':2,'ALERT_FRONTIER_PRESERVING_CONFIRMED_HANDOFF_ENABLED':True,'ALERT_BUDGETED_FRONTIER_TRACKING_ENABLED':True,'ALERT_BUDGETED_FRONTIER_UNIQUE_COVERAGE_ENABLED':False,'ALERT_CONFIRMATION_REALERT_RANKING_MODE':mode})
    return d

def run_one(method,seed,trace=True,target_root=None,smoke=False):
    if (seed not in SEEDS) and not (smoke and seed == 101): raise ValueError('E5-3 formal run accepts only seeds 441-460')
    target=(target_root or (OUT/'runs'))/method/f'seed_{seed}'; target.mkdir(parents=True,exist_ok=True)
    before={p for p in target.iterdir() if p.is_dir()}
    with config_override(overrides(method,seed,target,trace)):
        np.random.seed(int(seed)); run_multinode_baseline_experiment()
    made=[p for p in target.iterdir() if p.is_dir() and p not in before]
    if len(made)!=1: raise RuntimeError(f'expected one run, got {made}')
    (made[0]/'E5_3_EFFECTIVE_CONFIG.json').write_text(json.dumps({'phase':'E5-3 ISSC backbone control','method':method,'seed':seed,'protocol_sha256':sha(PROTOCOL),'formula_level_lineage_only':True},indent=2),encoding='utf-8')
    return made[0]

def main():
    p=argparse.ArgumentParser(); p.add_argument('--mode',choices=('smoke','run'),required=True); p.add_argument('--method',choices=tuple(METHODS)); p.add_argument('--seed',type=int); p.add_argument('--trace-off',action='store_true'); a=p.parse_args()
    if a.mode=='smoke':
        if a.seed != 101: raise ValueError('smoke accepts historical seed 101 only')
        if not a.method: raise ValueError('--method required')
        print(run_one(a.method, 101, trace=not a.trace_off, target_root=OUT/'audits'/'smoke_runs_traceoff' if a.trace_off else OUT/'audits'/'smoke_runs', smoke=True))
    else:
        if a.seed not in SEEDS: raise ValueError('formal mode accepts only seeds 441-460')
        if not a.method: raise ValueError('--method required')
        print(run_one(a.method, a.seed))
if __name__=='__main__': main()
