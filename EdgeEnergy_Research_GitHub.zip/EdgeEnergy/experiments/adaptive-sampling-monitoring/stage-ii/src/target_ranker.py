"""Leakage-safe learning-to-rank model for alert target selection.

The model is deliberately dependency-light: a regularised pairwise-logistic
linear ranker is trained with NumPy and serialised as auditable JSON.  Pairwise
training optimises ordering within a relay event, rather than treating the
large number of unaffected nodes as an ordinary classification problem.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
import numpy as np


FEATURE_NAMES = [
    "comm_hops", "path_energy_mj", "spatial_distance_source",
    "spatial_distance_confirmed_min", "spatial_distance_confirmed_mean",
    "distance_event_centroid", "uncertainty", "abs_signed_innovation",
    "nis", "glr_strength", "sign_consistency", "comm_degree",
    "spatial_degree", "already_false_woken", "event_age",
    "confirmed_count", "source_depth",
]


@dataclass
class LinearTargetRanker:
    mean: np.ndarray
    scale: np.ndarray
    weights: np.ndarray
    feature_names: list[str]
    metadata: dict

    def score_vector(self, values):
        x = np.asarray(values, dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        return float(((x - self.mean) / self.scale) @ self.weights)

    def score(self, features):
        return self.score_vector([features.get(name, 0.0) for name in self.feature_names])

    def save(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        payload = {
            "model_type": "pairwise_logistic_linear_ranker_v1",
            "feature_names": self.feature_names,
            "mean": self.mean.tolist(), "scale": self.scale.tolist(),
            "weights": self.weights.tolist(), "metadata": self.metadata,
        }
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)

    @classmethod
    def load(cls, path):
        with open(path, "r", encoding="utf-8") as handle:
            p = json.load(handle)
        if p.get("model_type") != "pairwise_logistic_linear_ranker_v1":
            raise ValueError("Unsupported target-ranker model: " + str(p.get("model_type")))
        return cls(np.asarray(p["mean"]), np.asarray(p["scale"]),
                   np.asarray(p["weights"]), list(p["feature_names"]),
                   dict(p.get("metadata", {})))


class LightGBMTargetRanker:
    def __init__(self, booster, feature_names, metadata=None):
        self.booster = booster
        self.feature_names = list(feature_names)
        self.metadata = metadata or {}

    def score(self, features):
        x = np.asarray([[features.get(name, 0.0) for name in self.feature_names]], dtype=float)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        return float(self.booster.predict(x)[0])


def load_target_ranker(path):
    """Load either the auditable linear JSON or a LightGBM manifest."""
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if payload.get("model_type") == "pairwise_logistic_linear_ranker_v1":
        return LinearTargetRanker.load(path)
    if payload.get("model_type", "").startswith("lightgbm_"):
        import lightgbm as lgb
        model_path = payload["booster_path"]
        if not os.path.isabs(model_path):
            model_path = os.path.join(os.path.dirname(os.path.abspath(path)), model_path)
        return LightGBMTargetRanker(lgb.Booster(model_file=model_path), payload["feature_names"], payload)
    raise ValueError("Unsupported target-ranker model: " + str(payload.get("model_type")))


def fit_pairwise_ranker(frame, feature_names=None, group_col="rank_group",
                        label_col="label", epochs=400, learning_rate=0.05,
                        l2=0.02, max_pairs_per_group=2000, seed=1):
    """Fit on positive-negative differences formed only inside each event."""
    names = list(feature_names or FEATURE_NAMES)
    x = frame[names].astype(float).replace([np.inf, -np.inf], np.nan).fillna(0.0).to_numpy()
    mean, scale = x.mean(axis=0), x.std(axis=0)
    scale[scale < 1e-9] = 1.0
    z = (x - mean) / scale
    rng = np.random.default_rng(seed)
    pairs = []
    for _, indices in frame.groupby(group_col, sort=False).indices.items():
        indices = np.asarray(indices, dtype=int)
        labels = frame.iloc[indices][label_col].astype(float).to_numpy()
        local_pairs = [(int(indices[i]), int(indices[j]), float(labels[i] - labels[j]))
                       for i in range(len(indices)) for j in range(len(indices)) if labels[i] > labels[j]]
        if not local_pairs:
            continue
        total = len(local_pairs)
        if total <= max_pairs_per_group:
            pairs.extend(local_pairs)
        else:
            chosen = rng.choice(total, size=max_pairs_per_group, replace=False)
            pairs.extend(local_pairs[i] for i in chosen)
    if not pairs:
        raise ValueError("No within-event positive/negative pairs in training data")
    d = np.asarray([z[p] - z[n] for p, n, _ in pairs])
    importance = np.asarray([gap for _, _, gap in pairs], dtype=float)
    importance /= max(1e-9, importance.mean())
    weights = np.zeros(d.shape[1], dtype=float)
    for epoch in range(int(epochs)):
        order = rng.permutation(len(d))
        batch_size = min(512, len(d))
        eta = learning_rate / np.sqrt(1.0 + epoch / 50.0)
        for start in range(0, len(d), batch_size):
            b = d[order[start:start + batch_size]]
            margin = np.clip(b @ weights, -30.0, 30.0)
            imp = importance[order[start:start + batch_size]]
            grad = -(b * (imp / (1.0 + np.exp(margin)))[:, None]).mean(axis=0) + l2 * weights
            weights -= eta * grad
    metadata = {"pair_count": len(pairs), "row_count": len(frame),
                "group_count": int(frame[group_col].nunique()), "seed": int(seed),
                "epochs": int(epochs), "l2": float(l2)}
    return LinearTargetRanker(mean, scale, weights, names, metadata)


def ranking_metrics(frame, scores, group_col="rank_group", label_col="label", top_k=5):
    work = frame[[group_col, label_col]].copy()
    work["score"] = np.asarray(scores, dtype=float)
    pair_correct = pair_total = 0
    precisions, recalls, ndcgs = [], [], []
    for _, group in work.groupby(group_col):
        pos = group[group[label_col] == 1]["score"].to_numpy()
        neg = group[group[label_col] == 0]["score"].to_numpy()
        if len(pos) and len(neg):
            pair_correct += sum(float(p > n) + 0.5 * float(p == n) for p in pos for n in neg)
            pair_total += len(pos) * len(neg)
        chosen = group.sort_values("score", ascending=False).head(top_k)
        precisions.append(float(chosen[label_col].mean()) if len(chosen) else 0.0)
        positives = int(group[label_col].sum())
        recalls.append(float(chosen[label_col].sum() / positives) if positives else np.nan)
        rel = group.sort_values("score", ascending=False)[label_col].astype(float).to_numpy()[:top_k]
        ideal = np.sort(group[label_col].astype(float).to_numpy())[::-1][:top_k]
        discounts = 1.0 / np.log2(np.arange(2, 2 + len(rel)))
        dcg = float(np.sum((np.power(2.0, rel) - 1.0) * discounts))
        idcg = float(np.sum((np.power(2.0, ideal) - 1.0) * discounts[:len(ideal)]))
        ndcgs.append(dcg / idcg if idcg > 0 else np.nan)
    valid_recalls = [x for x in recalls if np.isfinite(x)]
    return {"pairwise_auc": pair_correct / pair_total if pair_total else np.nan,
            "precision_at_k": float(np.mean(precisions)) if precisions else np.nan,
            "recall_at_k": float(np.mean(valid_recalls)) if valid_recalls else np.nan,
            "ndcg_at_k": float(np.nanmean(ndcgs)) if np.any(np.isfinite(ndcgs)) else np.nan,
            "top_k": int(top_k), "group_count": int(work[group_col].nunique())}
