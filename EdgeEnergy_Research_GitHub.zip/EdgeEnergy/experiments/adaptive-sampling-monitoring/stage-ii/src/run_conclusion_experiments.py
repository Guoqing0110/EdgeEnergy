import os
import json
import time
from datetime import datetime
from contextlib import contextmanager
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from src.run_multinode_baseline import run_multinode_baseline_experiment, load_mote_positions
from src.sentinel_selector import SentinelSelector
import src.config as config


@contextmanager
def config_override(overrides):
    old = {}
    for k, v in overrides.items():
        old[k] = getattr(config, k)
        setattr(config, k, v)
    try:
        yield
    finally:
        for k, v in old.items():
            setattr(config, k, v)


def _list_output_dirs(root_dir=None):
    if root_dir is None:
        root_dir = config.OUTPUT_DIR
    if not os.path.isdir(root_dir):
        return set()
    return set(
        x for x in os.listdir(root_dir)
        if os.path.isdir(os.path.join(root_dir, x))
    )


def _find_new_output_dir(before_dirs, root_dir=None):
    if root_dir is None:
        root_dir = config.OUTPUT_DIR
    after_dirs = _list_output_dirs(root_dir)
    new_dirs = sorted(list(after_dirs - before_dirs))
    if len(new_dirs) > 0:
        return os.path.join(root_dir, new_dirs[-1])
    all_dirs = [os.path.join(root_dir, x) for x in after_dirs]
    if len(all_dirs) == 0:
        raise RuntimeError("No experiment output directory was found")
    return max(all_dirs, key=os.path.getmtime)


def _read_row_csv(path):
    return pd.read_csv(path).iloc[0].to_dict()


def _read_kv_txt(path):
    if not os.path.exists(path):
        return {}
    kv = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if "=" not in line:
                continue
            k, v = line.strip().split("=", 1)
            kv[k] = v
    return kv


def _run_once(overrides, output_root_override=None):
    before = _list_output_dirs(output_root_override)
    applied_overrides = dict(overrides)
    if output_root_override is not None:
        applied_overrides["OUTPUT_DIR"] = output_root_override
    with config_override(applied_overrides):
        np.random.seed(config.RANDOM_SEED)
        run_multinode_baseline_experiment()
    out_dir = _find_new_output_dir(before, output_root_override)
    task8 = _read_row_csv(os.path.join(out_dir, "task8_metrics_main.csv"))
    task6_det = _read_row_csv(os.path.join(out_dir, "task6_detection_metrics.csv"))
    task6_energy = _read_row_csv(os.path.join(out_dir, "task6_energy_proxy.csv"))
    return out_dir, task8, task6_det, task6_energy


def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def _plot_group_a_bar(df, out_path):
    methods = df["method"].tolist()
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    metric_specs = [
        ("event_detection_rate", "Event Detection Rate", True),
        ("onset_detection_delay_mean_steps", "Onset Detection Delay", False),
        ("alert_coverage_l", "Alert Coverage@L", True),
        ("recovery_gain_strict", "Recovery Gain", True),
    ]
    for ax, (col, title, higher_better) in zip(axes.flatten(), metric_specs):
        vals = df[col].astype(float).values
        ax.bar(methods, vals, color=["#4C78A8", "#F58518", "#54A24B", "#E45756"], alpha=0.9)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.2)
        if higher_better:
            ax.set_ylim(min(-0.1, np.nanmin(vals) - 0.05), max(1.05, np.nanmax(vals) + 0.05))
        ax.tick_params(axis='x', rotation=20)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def _plot_group_a_energy(df, out_path):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    metrics = [
        ("event_detection_rate", "EDR vs Energy", "EDR"),
        ("onset_detection_delay_mean_steps", "Delay vs Energy", "ODD (steps)"),
        ("alert_coverage_l", "Coverage vs Energy", "Coverage@L"),
    ]
    colors = ["#4C78A8", "#F58518", "#54A24B", "#E45756"]
    for ax, (col, title, ylab) in zip(axes, metrics):
        for i, row in df.iterrows():
            ax.scatter(row["energy_proxy_total"], row[col], s=80, color=colors[i], label=row["method"])
            ax.text(row["energy_proxy_total"], row[col], row["method"], fontsize=8)
        ax.set_title(title)
        ax.set_xlabel("Energy Proxy")
        ax.set_ylabel(ylab)
        ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def _plot_group_a_coverage_split(df, out_path):
    methods = df["method"].tolist()
    strict_vals = df["alert_coverage_l"].astype(float).values
    alert_only_vals = df["alert_coverage_alert_only"].astype(float).values
    x = np.arange(len(methods))
    w = 0.36
    fig, ax = plt.subplots(figsize=(10.5, 4.8))
    ax.bar(x - w / 2, alert_only_vals, width=w, color="#4C78A8", alpha=0.9, label="Coverage Alert-Only")
    ax.bar(x + w / 2, strict_vals, width=w, color="#E45756", alpha=0.9, label="Coverage Alert-Hit")
    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=20)
    ax.set_ylim(0, max(1.05, np.nanmax(np.r_[strict_vals, alert_only_vals]) + 0.05))
    ax.set_ylabel("Coverage")
    ax.set_title("A Group Coverage Split")
    ax.grid(axis="y", alpha=0.2)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def _read_node_history(output_dir, node_id):
    path = os.path.join(output_dir, "node_histories", f"node_{int(node_id)}.csv")
    return pd.read_csv(path, parse_dates=["time"])


def _first_event_info(output_dir):
    event_df = pd.read_csv(os.path.join(output_dir, "task8_event_onset_detection.csv"))
    if len(event_df) == 0:
        return None
    row = event_df.sort_values("event_start_step").iloc[0]
    return {
        "event_start_step": int(row["event_start_step"]),
        "detected_step": None if pd.isna(row["detected_step"]) else int(row["detected_step"])
    }


def _first_alert_activation_time(output_dir, dt_sec):
    path = os.path.join(output_dir, "alert_events.csv")
    if not os.path.exists(path):
        return None
    df = pd.read_csv(path, parse_dates=["time"])
    if len(df) == 0:
        return None
    return df.iloc[0]["time"] + pd.Timedelta(seconds=dt_sec)


def _plot_group_a_timeline(df, method_to_dir, out_path):
    sentinel_dir = method_to_dir["Sentinel-assisted KF"]
    meta = pd.read_csv(os.path.join(sentinel_dir, "node_anomaly_diagnostic_meta.csv")).iloc[0].to_dict()
    node_id = int(meta["diagnostic_node_id"])
    histories = {}
    for method, out_dir in method_to_dir.items():
        histories[method] = _read_node_history(out_dir, node_id)
    base = histories["Sentinel-assisted KF"].copy()
    times = base["time"].values
    ground_truth = base["ground_truth"].values
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
    axes[0].plot(times, ground_truth, color="black", linewidth=1.8, label="Ground Truth")
    style_map = {
        "Pure KF sparse": ("#F58518", "--"),
        "Sentinel-assisted KF": ("#54A24B", "-."),
        "Oracle-local wake-up": ("#E45756", "-"),
    }
    for method, (color, ls) in style_map.items():
        axes[0].plot(times, histories[method]["estimated"].values, color=color, linestyle=ls, linewidth=1.2, label=method)
    ev = _first_event_info(sentinel_dir)
    if ev is not None:
        onset_t = times[ev["event_start_step"]]
        axes[0].axvline(onset_t, color="#7F3C8D", linewidth=1.2, label="Event Onset")
        det_s = ev["detected_step"]
        if det_s is not None and 0 <= det_s < len(times):
            axes[0].axvline(times[det_s], color="#11A579", linewidth=1.2, label="Sentinel Detect")
    oracle_ev = _first_event_info(method_to_dir["Oracle-local wake-up"])
    if oracle_ev is not None and oracle_ev["detected_step"] is not None:
        od = oracle_ev["detected_step"]
        if 0 <= od < len(times):
            axes[0].axvline(times[od], color="#E73F74", linewidth=1.2, label="Oracle Detect")
    act_t = _first_alert_activation_time(sentinel_dir, int(config.DT_SEC))
    if act_t is not None:
        axes[0].axvline(act_t, color="#3969AC", linewidth=1.2, label="Alert Activation (t+1)")
    axes[0].set_ylabel("Temperature")
    axes[0].set_title(f"Representative Event Timeline (Node {node_id})")
    axes[0].grid(alpha=0.2)
    axes[0].legend(loc="best", fontsize=8)
    strip_methods = ["Pure KF sparse", "Sentinel-assisted KF", "Oracle-local wake-up", "Full sampling"]
    mat = np.vstack([histories[m]["sampled"].values.astype(float) for m in strip_methods])
    im = axes[1].imshow(mat, aspect="auto", cmap="Blues", vmin=0.0, vmax=1.0)
    axes[1].set_yticks(np.arange(len(strip_methods)))
    axes[1].set_yticklabels(strip_methods)
    axes[1].set_xlabel("Time Step")
    axes[1].set_title("Sampled / Skipped Strip")
    plt.colorbar(im, ax=axes[1], fraction=0.02, pad=0.02)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def run_group_a(output_root):
    group_dir = os.path.join(output_root, "group_a")
    _ensure_dir(group_dir)
    aligned_overrides = {
        "SENTINEL_STRATEGY": "k_center",
        "SENTINEL_RATIO": 0.24,
        "ANOMALY_THRESHOLD_ETA": 4.0,
        "ALERT_NEIGHBOR_GRAPH": "spatial",
        "ALERT_PROPAGATION_MODE": "one_hop",
        "ALERT_MAX_HOPS": 1,
        "TASK8_EVENT_MATCH_GRAPH": "spatial",
        "TASK8_EVENT_MATCH_MAX_HOPS": 8
    }
    methods = [
        ("Full sampling", {
            **aligned_overrides,
            "GAMMA": -1.0,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Pure KF sparse", {
            **aligned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Sentinel-assisted KF", {
            **aligned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": True,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Oracle-local wake-up", {
            **aligned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": True,
            "ORACLE_WAKEUP_GRAPH": "spatial",
            "TASK8_DETECTION_SOURCE": "oracle_alert"
        }),
    ]
    rows = []
    method_to_dir = {}
    for method, overrides in methods:
        out_dir, task8, task6_det, task6_energy = _run_once(overrides)
        method_to_dir[method] = out_dir
        rows.append({
            "method": method,
            "output_dir": out_dir,
            "event_detection_rate": float(task8.get("event_detection_rate", np.nan)),
            "onset_detection_delay_mean_steps": float(task8.get("onset_detection_delay_mean_steps", np.nan)),
            "alert_coverage_l": float(task8.get("alert_coverage_l", np.nan)),
            "alert_coverage_alert_only": float(task8.get("alert_coverage_alert_only", np.nan)),
            "recovery_gain_strict": float(task8.get("recovery_gain_strict", np.nan)),
            "recovery_rmse_actual": float(task8.get("recovery_rmse_actual", np.nan)),
            "energy_proxy_total": float(task6_energy.get("total_energy_proxy", np.nan)),
            "precision": float(task6_det.get("precision", np.nan)),
            "recall": float(task6_det.get("recall", np.nan)),
            "f1": float(task6_det.get("f1", np.nan))
        })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(group_dir, "group_a_summary.csv"), index=False)
    _plot_group_a_bar(df, os.path.join(group_dir, "group_a_main_2x2.png"))
    _plot_group_a_energy(df, os.path.join(group_dir, "group_a_energy_pareto.png"))
    _plot_group_a_coverage_split(df, os.path.join(group_dir, "group_a_coverage_split.png"))
    _plot_group_a_timeline(df, method_to_dir, os.path.join(group_dir, "group_a_representative_timeline.png"))
    with open(os.path.join(group_dir, "group_a_method_dirs.json"), "w", encoding="utf-8") as f:
        json.dump(method_to_dir, f, ensure_ascii=False, indent=2)
    return df


def _plot_heatmap(ax, mat, xlabels, ylabels, title, invert=False):
    cmap = "viridis_r" if invert else "viridis"
    im = ax.imshow(mat, cmap=cmap, aspect="auto")
    ax.set_xticks(np.arange(len(xlabels)))
    ax.set_xticklabels(xlabels)
    ax.set_yticks(np.arange(len(ylabels)))
    ax.set_yticklabels(ylabels)
    ax.set_title(title)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            val = mat[i, j]
            ax.text(j, i, f"{val:.3f}" if np.isfinite(val) else "nan", ha="center", va="center", color="white", fontsize=9)
    return im


def _parse_neighbors(text):
    if pd.isna(text):
        return set()
    s = str(text).strip()
    if s == "":
        return set()
    return set(int(x) for x in s.split(",") if str(x).strip() != "")


def _extract_region_case(output_dir):
    alerts = pd.read_csv(os.path.join(output_dir, "alert_events.csv"), parse_dates=["time"])
    if len(alerts) == 0:
        return None
    row = alerts.iloc[0]
    t = row["time"]
    alerted = _parse_neighbors(row["neighbors"])
    sentinel_ids = set(pd.read_csv(os.path.join(output_dir, "sentinel_nodes.csv"))["node_id"].astype(int).tolist())
    anomaly_nodes = set()
    histories_dir = os.path.join(output_dir, "node_histories")
    for fn in os.listdir(histories_dir):
        if not fn.startswith("node_") or not fn.endswith(".csv"):
            continue
        nid = int(fn.replace("node_", "").replace(".csv", ""))
        h = pd.read_csv(os.path.join(histories_dir, fn), parse_dates=["time"], usecols=["time", "gt_anomaly_flag"])
        hit = h.loc[h["time"] == t, "gt_anomaly_flag"]
        if len(hit) > 0 and int(hit.iloc[0]) == 1:
            anomaly_nodes.add(nid)
    return {"time": t, "alerted": alerted, "anomaly": anomaly_nodes, "sentinel": sentinel_ids}


def _plot_group_b_structure(case_left, case_right, out_path):
    node_positions = load_mote_positions(config.MOTE_LOC_FILE)
    fig, axes = plt.subplots(1, 2, figsize=(13, 6))
    for ax, case, title in [
        (axes[0], case_left, "Matched (spatial inject + spatial alert)"),
        (axes[1], case_right, "Mismatched (spatial inject + comm alert)")
    ]:
        node_ids = sorted(node_positions.keys())
        xs = [node_positions[n]["x"] for n in node_ids]
        ys = [node_positions[n]["y"] for n in node_ids]
        ax.scatter(xs, ys, c="#DDDDDD", s=28)
        if case is not None:
            anomaly = sorted(list(case["anomaly"]))
            alerted = sorted(list(case["alerted"]))
            sentinel = sorted(list(case["sentinel"]))
            both = sorted(list(set(anomaly) & set(alerted)))
            only_anom = sorted(list(set(anomaly) - set(both)))
            only_alert = sorted(list(set(alerted) - set(both)))
            if len(only_anom) > 0:
                ax.scatter([node_positions[n]["x"] for n in only_anom], [node_positions[n]["y"] for n in only_anom], c="#E45756", s=52, label="Anomaly Region")
            if len(only_alert) > 0:
                ax.scatter([node_positions[n]["x"] for n in only_alert], [node_positions[n]["y"] for n in only_alert], c="#4C78A8", s=52, label="Alert Region")
            if len(both) > 0:
                ax.scatter([node_positions[n]["x"] for n in both], [node_positions[n]["y"] for n in both], c="#72B7B2", s=60, label="Overlap")
            if len(sentinel) > 0:
                ax.scatter([node_positions[n]["x"] for n in sentinel], [node_positions[n]["y"] for n in sentinel], c="black", marker="^", s=40, label="Sentinel")
        ax.set_title(title)
        ax.set_aspect("equal", adjustable="box")
        ax.grid(alpha=0.2)
    handles, labels = axes[1].get_legend_handles_labels()
    if len(handles) > 0:
        fig.legend(handles, labels, loc="upper center", ncol=4)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def run_group_b(output_root):
    group_dir = os.path.join(output_root, "group_b")
    _ensure_dir(group_dir)
    aligned_overrides = {
        "SENTINEL_STRATEGY": "k_center",
        "SENTINEL_RATIO": 0.24,
        "ANOMALY_THRESHOLD_ETA": 4.0,
        "ALERT_PROPAGATION_MODE": "one_hop",
        "ALERT_MAX_HOPS": 1,
        "TASK8_EVENT_MATCH_MAX_HOPS": 8,
        "TASK8_DETECTION_SOURCE": "sentinel",
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ORACLE_WAKEUP_ENABLED": False,
    }
    combos = [
        ("spatial_spatial", "spatial", "spatial"),
        ("spatial_communication", "spatial", "communication"),
        ("communication_spatial", "communication", "spatial"),
        ("communication_communication", "communication", "communication"),
    ]
    rows = []
    out_map = {}
    for name, inject_graph, alert_graph in combos:
        overrides = {
            **aligned_overrides,
            "SPATIAL_STATIC_GRAPH": inject_graph,
            "SPATIOTEMP_DIFF_GRAPH": inject_graph,
            "ALERT_NEIGHBOR_GRAPH": alert_graph,
            "TASK8_EVENT_MATCH_GRAPH": inject_graph
        }
        out_dir, task8, _, task6_energy = _run_once(overrides)
        out_map[name] = out_dir
        rows.append({
            "case": name,
            "inject_graph": inject_graph,
            "alert_graph": alert_graph,
            "event_detection_rate": float(task8.get("event_detection_rate", np.nan)),
            "onset_detection_delay_mean_steps": float(task8.get("onset_detection_delay_mean_steps", np.nan)),
            "alert_coverage_l": float(task8.get("alert_coverage_l", np.nan)),
            "alert_coverage_alert_only": float(task8.get("alert_coverage_alert_only", np.nan)),
            "recovery_gain_strict": float(task8.get("recovery_gain_strict", np.nan)),
            "energy_proxy_total": float(task6_energy.get("total_energy_proxy", np.nan)),
            "output_dir": out_dir
        })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(group_dir, "group_b_2x2_summary.csv"), index=False)
    idx_y = ["spatial", "communication"]
    idx_x = ["spatial", "communication"]
    def build_mat(metric):
        mat = np.full((2, 2), np.nan, dtype=float)
        for i, ig in enumerate(idx_y):
            for j, ag in enumerate(idx_x):
                hit = df[(df["inject_graph"] == ig) & (df["alert_graph"] == ag)]
                if len(hit) > 0:
                    mat[i, j] = float(hit.iloc[0][metric])
        return mat
    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.8))
    im1 = _plot_heatmap(axes[0], build_mat("event_detection_rate"), idx_x, idx_y, "EDR Heatmap", invert=False)
    im2 = _plot_heatmap(axes[1], build_mat("onset_detection_delay_mean_steps"), idx_x, idx_y, "ODD Heatmap", invert=True)
    im3 = _plot_heatmap(axes[2], build_mat("alert_coverage_l"), idx_x, idx_y, "Coverage@L Heatmap", invert=False)
    for im, ax in zip([im1, im2, im3], axes):
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(os.path.join(group_dir, "group_b_heatmaps.png"), dpi=220)
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6))
    im4 = _plot_heatmap(axes[0], build_mat("alert_coverage_alert_only"), idx_x, idx_y, "Coverage Alert-Only", invert=False)
    im5 = _plot_heatmap(axes[1], build_mat("recovery_gain_strict"), idx_x, idx_y, "Recovery Gain", invert=False)
    for im, ax in zip([im4, im5], axes):
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(os.path.join(group_dir, "group_b_heatmaps_extended.png"), dpi=220)
    plt.close(fig)
    matched = df[df["inject_graph"] == df["alert_graph"]]
    mismatched = df[df["inject_graph"] != df["alert_graph"]]
    agg = pd.DataFrame([
        {
            "regime": "matched",
            "event_detection_rate": float(matched["event_detection_rate"].mean()),
            "onset_detection_delay_mean_steps": float(matched["onset_detection_delay_mean_steps"].mean()),
            "recovery_gain_strict": float(matched["recovery_gain_strict"].mean()),
        },
        {
            "regime": "mismatched",
            "event_detection_rate": float(mismatched["event_detection_rate"].mean()),
            "onset_detection_delay_mean_steps": float(mismatched["onset_detection_delay_mean_steps"].mean()),
            "recovery_gain_strict": float(mismatched["recovery_gain_strict"].mean()),
        }
    ])
    agg.to_csv(os.path.join(group_dir, "group_b_matched_vs_mismatched.csv"), index=False)
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.2))
    for ax, metric, title in zip(
        axes,
        ["event_detection_rate", "onset_detection_delay_mean_steps", "recovery_gain_strict"],
        ["EDR", "ODD", "Recovery Gain"]
    ):
        ax.bar(agg["regime"], agg[metric], color=["#4C78A8", "#E45756"], alpha=0.9)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(os.path.join(group_dir, "group_b_matched_vs_mismatched.png"), dpi=220)
    plt.close(fig)
    case_left = _extract_region_case(out_map["spatial_spatial"])
    case_right = _extract_region_case(out_map["spatial_communication"])
    _plot_group_b_structure(case_left, case_right, os.path.join(group_dir, "group_b_structure_case.png"))
    with open(os.path.join(group_dir, "group_b_case_dirs.json"), "w", encoding="utf-8") as f:
        json.dump(out_map, f, ensure_ascii=False, indent=2)
    return df


def _plot_scan_param_curves(df, param_name, out_dir):
    sub = df[df["param_name"] == param_name].sort_values("param_value")
    x = sub["param_value"].values
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))
    specs = [
        ("event_detection_rate", "EDR vs Parameter"),
        ("onset_detection_delay_mean_steps", "ODD vs Parameter"),
        ("alert_coverage_l", "Coverage@L vs Parameter")
    ]
    for ax, (col, title) in zip(axes, specs):
        ax.plot(x, sub[col].values, marker="o", color="#4C78A8")
        ax.set_title(title)
        ax.set_xlabel(param_name)
        ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"group_c_{param_name}_metric_curves.png"), dpi=220)
    plt.close(fig)


def _plot_scan_energy_views(df, param_name, out_dir):
    sub = df[df["param_name"] == param_name].sort_values("param_value")
    c = sub["param_value"].values
    fig, axes = plt.subplots(1, 3, figsize=(14.2, 4.4))
    specs = [
        ("event_detection_rate", "EDR vs Energy", "EDR"),
        ("onset_detection_delay_mean_steps", "Delay vs Energy", "ODD (steps)"),
        ("alert_coverage_l", "Coverage vs Energy", "Coverage@L"),
    ]
    for ax, (col, title, ylab) in zip(axes, specs):
        sc = ax.scatter(sub["energy_proxy_total"].values, sub[col].values, c=c, cmap="viridis", s=75)
        ax.plot(sub["energy_proxy_total"].values, sub[col].values, color="#999999", alpha=0.6)
        ax.set_title(title)
        ax.set_xlabel("Energy Proxy")
        ax.set_ylabel(ylab)
        ax.grid(alpha=0.2)
        cb = plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label(param_name)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"group_c_{param_name}_energy_views.png"), dpi=220)
    plt.close(fig)


def _plot_scan_coverage_split(df, param_name, out_dir):
    sub = df[df["param_name"] == param_name].sort_values("param_value")
    x = sub["param_value"].values
    strict_vals = sub["alert_coverage_l"].values
    alert_only_vals = sub["alert_coverage_alert_only"].values
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.plot(x, alert_only_vals, marker="o", color="#4C78A8", label="Coverage Alert-Only")
    ax.plot(x, strict_vals, marker="s", color="#E45756", label="Coverage Alert-Hit")
    ax.set_title("Coverage Split vs Parameter")
    ax.set_xlabel(param_name)
    ax.set_ylabel("Coverage")
    ax.grid(alpha=0.2)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"group_c_{param_name}_coverage_split.png"), dpi=220)
    plt.close(fig)


def run_group_c(output_root):
    group_dir = os.path.join(output_root, "group_c")
    _ensure_dir(group_dir)
    aligned_overrides = {
        "SENTINEL_STRATEGY": "k_center",
        "SENTINEL_RATIO": 0.24,
        "ANOMALY_THRESHOLD_ETA": 4.0,
        "ALERT_NEIGHBOR_GRAPH": "spatial",
        "ALERT_PROPAGATION_MODE": "one_hop",
        "ALERT_MAX_HOPS": 1,
        "TASK8_EVENT_MATCH_GRAPH": "spatial",
        "TASK8_EVENT_MATCH_MAX_HOPS": 8,
        "TASK8_DETECTION_SOURCE": "sentinel",
        "ENABLE_SENTINEL_ALERT_TRIGGER": True,
        "ORACLE_WAKEUP_ENABLED": False,
    }
    scans = {
        "SENTINEL_RATIO": [0.08, 0.12, 0.16, 0.24],
        "ALERT_DURATION_L": [1, 3, 5, 7],
        "ANOMALY_THRESHOLD_ETA": [4.0, 6.63, 9.0, 12.0],
    }
    rows = []
    for param, values in scans.items():
        for v in values:
            overrides = {
                **aligned_overrides,
                param: v
            }
            out_dir, task8, task6_det, task6_energy = _run_once(overrides, output_root)
            tp = float(task6_det.get("tp", np.nan))
            fp = float(task6_det.get("fp", np.nan))
            far = fp / (tp + fp) if np.isfinite(tp) and np.isfinite(fp) and (tp + fp) > 0 else np.nan
            rows.append({
                "param_name": param,
                "param_value": float(v),
                "event_detection_rate": float(task8.get("event_detection_rate", np.nan)),
                "onset_detection_delay_mean_steps": float(task8.get("onset_detection_delay_mean_steps", np.nan)),
                "alert_coverage_l": float(task8.get("alert_coverage_l", np.nan)),
                "alert_coverage_alert_only": float(task8.get("alert_coverage_alert_only", np.nan)),
                "recovery_gain_strict": float(task8.get("recovery_gain_strict", np.nan)),
                "energy_proxy_total": float(task6_energy.get("total_energy_proxy", np.nan)),
                "false_alarm_rate": far,
                "output_dir": out_dir
            })
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(group_dir, "group_c_scan_summary.csv"), index=False)
    for param in scans.keys():
        _plot_scan_param_curves(df, param, group_dir)
        _plot_scan_energy_views(df, param, group_dir)
        _plot_scan_coverage_split(df, param, group_dir)
    eta_df = df[df["param_name"] == "ANOMALY_THRESHOLD_ETA"].sort_values("param_value")
    fig, ax = plt.subplots(figsize=(6.2, 4.6))
    ax.plot(eta_df["false_alarm_rate"].values, eta_df["event_detection_rate"].values, marker="o", color="#E45756")
    for _, row in eta_df.iterrows():
        ax.text(row["false_alarm_rate"], row["event_detection_rate"], f"η={row['param_value']:.2f}", fontsize=8)
    ax.set_xlabel("False Alarm Rate")
    ax.set_ylabel("EDR")
    ax.set_title("ETA Scan: False Alarm Rate vs EDR")
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(os.path.join(group_dir, "group_c_eta_far_vs_edr.png"), dpi=220)
    plt.close(fig)
    return df


def _plot_task10_main_effectiveness(summary_df, out_path):
    ordered = summary_df.copy()
    methods = ordered["method"].tolist()
    fig, axes = plt.subplots(2, 3, figsize=(15.5, 8.2))
    specs = [
        ("event_detection_rate_mean", "event_detection_rate_std", "Event Detection Rate"),
        ("onset_detection_delay_mean_steps_mean", "onset_detection_delay_mean_steps_std", "Onset Detection Delay"),
        ("energy_proxy_total_mean", "energy_proxy_total_std", "Energy Proxy Total"),
        ("alert_coverage_l_mean", "alert_coverage_l_std", "Alert-Hit Coverage"),
        ("false_alarm_rate_mean", "false_alarm_rate_std", "False Alarm Rate"),
        ("rmse_anomaly_window_mean", "rmse_anomaly_window_std", "Anomaly-window RMSE"),
    ]
    colors = ["#4C78A8", "#F58518", "#54A24B", "#E45756"]
    for ax, (m_col, s_col, title) in zip(axes.flatten(), specs):
        means = ordered[m_col].astype(float).values
        stds = ordered[s_col].astype(float).values
        x = np.arange(len(methods))
        ax.bar(x, means, yerr=stds, capsize=4, color=colors, alpha=0.9)
        ax.set_xticks(x)
        ax.set_xticklabels(methods, rotation=20)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def run_task10_main_effectiveness(output_root, repeats=None, seed_base=None):
    group_dir = os.path.join(output_root, "task10_main_effectiveness")
    _ensure_dir(group_dir)
    tuned_overrides = {
        "SENTINEL_STRATEGY": "spatial_optimal_cover",
        "SENTINEL_RATIO": 0.15,
        "ENABLE_PLOTS": False,
        "SAVE_NODE_HISTORIES": True,
        "SENTINEL_GLR_WINDOW_MIN": 1,
        "SENTINEL_GLR_WINDOW_MAX": 8,
        "SENTINEL_GLR_THRESHOLD": 6.0,
        "SENTINEL_GLR_RESET": 1.0,
        "SENTINEL_GLR_DIRECTION": "both",
        "SENTINEL_GLR_RELATIVE_ENABLED": True,
        "SENTINEL_GLR_RELATIVE_WINDOW": 40,
        "SENTINEL_GLR_RELATIVE_MIN_COUNT": 12,
        "SENTINEL_GLR_RELATIVE_K": 3.0,
        "SENTINEL_GLR_RELATIVE_FLOOR": 3.4,
        "SENTINEL_GLR_RELATIVE_SCALE_FLOOR": 0.35,
        "SENTINEL_GLR_RELATIVE_BACKGROUND_MAX_FRACTION": 0.8,
        "NORMAL_SELF_TRIGGER_ENABLED": True,
        "NORMAL_SELF_TRIGGER_DURATION_L": 3,
        "ALERT_DURATION_L": 999,
        "ALERT_EARLY_EXIT_ENABLED": True,
        "ALERT_MIN_DURATION_L": 3,
        "ALERT_EXIT_MODE": "glr",
        "ALERT_VERIFY_WAIT_STEPS": 5,
        "ALERT_EXIT_CONSECUTIVE_STEPS": 2,
        "ALERT_EXIT_ABS_THRESHOLD": 0.35,
        "ALERT_EXIT_SIGMA_FACTOR": 1.2,
        "ALERT_EXIT_NEIGHBOR_SILENCE_STEPS": 2,
        "ALERT_NEIGHBOR_GRAPH": "communication",
        "ALERT_PROPAGATION_MODE": "one_hop",
        "ALERT_MAX_HOPS": 1,
        "ALERT_ADAPTIVE_HOPS_ENABLED": False,
        "ALERT_ADAPTIVE_NIS_MEDIUM": 6.0,
        "ALERT_ADAPTIVE_NIS_HIGH": 10.0,
        "ALERT_ADAPTIVE_HOPS_MEDIUM_DELTA": 1,
        "ALERT_ADAPTIVE_HOPS_HIGH_DELTA": 3,
        "ALERT_ADAPTIVE_MAX_HOPS": 5,
        "TASK8_EVENT_MATCH_GRAPH": "spatial",
        "TASK8_EVENT_MATCH_MAX_HOPS": 8,
        "SENTINEL_DETECTOR_MODE": "glr"
    }
    methods = [
        ("Full sampling", {
            **tuned_overrides,
            "GAMMA": -1.0,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Pure KF sparse", {
            **tuned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Sentinel-assisted KF", {
            **tuned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": True,
            "ORACLE_WAKEUP_ENABLED": False,
            "TASK8_DETECTION_SOURCE": "sentinel"
        }),
        ("Oracle-local wake-up", {
            **tuned_overrides,
            "ENABLE_SENTINEL_ALERT_TRIGGER": False,
            "ORACLE_WAKEUP_ENABLED": True,
            "ORACLE_WAKEUP_GRAPH": "spatial",
            "TASK8_DETECTION_SOURCE": "oracle_alert"
        }),
    ]
    if repeats is None:
        repeats = int(getattr(config, "TASK10_MAIN_REPEATS", 3))
    if seed_base is None:
        seed_base = int(getattr(config, "TASK10_MAIN_SEED_BASE", config.RANDOM_SEED))
    raw_rows = []
    method_to_runs = {}
    for method, base_overrides in methods:
        method_to_runs[method] = []
        for i in range(int(repeats)):
            seed = seed_base + i
            overrides = {**base_overrides, "RANDOM_SEED": seed, "SPATIAL_ANOMALY_RANDOM_SEED": seed}
            t0 = time.perf_counter()
            out_dir, task8, task6_det, task6_energy = _run_once(overrides, output_root)
            run_seconds = float(time.perf_counter() - t0)
            method_to_runs[method].append(out_dir)
            tp = float(task6_det.get("tp", np.nan))
            fp = float(task6_det.get("fp", np.nan))
            far = fp / (tp + fp) if np.isfinite(tp) and np.isfinite(fp) and (tp + fp) > 0 else np.nan
            aggregate_kv = _read_kv_txt(os.path.join(out_dir, "aggregate_metrics.txt"))
            raw_rows.append({
                "method": method,
                "seed": seed,
                "algo_seed": seed,
                "anomaly_seed": seed,
                "output_dir": out_dir,
                "event_detection_rate": float(task8.get("event_detection_rate", np.nan)),
                "onset_detection_delay_mean_steps": float(task8.get("onset_detection_delay_mean_steps", np.nan)),
                "energy_proxy_total": float(task6_energy.get("total_energy_proxy", np.nan)),
                "alert_coverage_l": float(task8.get("alert_coverage_l", np.nan)),
                "alert_coverage_alert_only": float(task8.get("alert_coverage_alert_only", np.nan)),
                "alert_coverage_sampling_only": float(task8.get("alert_coverage_sampling_only", np.nan)),
                "anomaly_window_sampling_ratio": float(task8.get("anomaly_window_sampling_ratio", np.nan)),
                "coverage_zero_rate": float(task8.get("coverage_zero_rate", np.nan)),
                "coverage_high_rate": float(task8.get("coverage_high_rate", np.nan)),
                "wakeup_effectiveness": float(task8.get("wakeup_effectiveness", np.nan)),
                "event_count": float(task8.get("event_count", np.nan)),
                "detection_per_energy": float(task8.get("detection_per_energy", np.nan)),
                "marginal_sentinel_utility_proxy": float(task8.get("marginal_sentinel_utility_proxy", np.nan)),
                "alert_coverage_definition": str(task8.get("alert_coverage_definition", "")),
                "false_alarm_rate": far,
                "rmse_anomaly_window": float(task8.get("rmse_anomaly_window", task8.get("recovery_rmse_actual", np.nan))),
                "rmse_global": float(task8.get("rmse_global", np.nan)),
                "recovery_rmse_actual": float(task8.get("recovery_rmse_actual", np.nan)),
                "recovery_gain_strict": float(task8.get("recovery_gain_strict", np.nan)),
                "global_sampling_rate": float(aggregate_kv.get("sampling_rate_global", np.nan)),
                "alert_event_count": float(aggregate_kv.get("alert_event_count", np.nan)),
                "oracle_alert_event_count": float(aggregate_kv.get("oracle_alert_event_count", np.nan)),
                "run_seconds": run_seconds
            })
    raw_df = pd.DataFrame(raw_rows)
    raw_path = os.path.join(group_dir, "task10_main_raw_runs.csv")
    raw_df.to_csv(raw_path, index=False)
    dist_rows = []
    for method in sorted(raw_df["method"].unique()):
        sub = raw_df[raw_df["method"] == method]
        for metric in ["event_detection_rate", "onset_detection_delay_mean_steps", "energy_proxy_total", "alert_coverage_l", "anomaly_window_sampling_ratio", "false_alarm_rate", "rmse_anomaly_window", "rmse_global", "run_seconds"]:
            vals = sub[metric].astype(float).values
            dist_rows.append({
                "method": method,
                "metric": metric,
                "count": int(len(vals)),
                "mean": float(np.mean(vals)),
                "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
                "p10": float(np.percentile(vals, 10)),
                "p50": float(np.percentile(vals, 50)),
                "p90": float(np.percentile(vals, 90)),
                "min": float(np.min(vals)),
                "max": float(np.max(vals))
            })
    pd.DataFrame(dist_rows).to_csv(os.path.join(group_dir, "task10_main_distribution_stats.csv"), index=False)
    order = ["Full sampling", "Pure KF sparse", "Sentinel-assisted KF", "Oracle-local wake-up"]
    summary_df = (
        raw_df.groupby("method", as_index=False)
        .agg({
            "event_detection_rate": ["mean", "std"],
            "onset_detection_delay_mean_steps": ["mean", "std"],
            "energy_proxy_total": ["mean", "std"],
            "alert_coverage_l": ["mean", "std"],
            "anomaly_window_sampling_ratio": ["mean", "std"],
            "false_alarm_rate": ["mean", "std"],
            "rmse_anomaly_window": ["mean", "std"],
            "rmse_global": ["mean", "std"],
            "recovery_rmse_actual": ["mean", "std"],
            "recovery_gain_strict": ["mean", "std"]
        })
    )
    summary_df.columns = ["_".join([c for c in col if c]).rstrip("_") for col in summary_df.columns.values]
    summary_df = summary_df.rename(columns={"method": "method"})
    summary_df["method"] = pd.Categorical(summary_df["method"], categories=order, ordered=True)
    summary_df = summary_df.sort_values("method").reset_index(drop=True)
    summary_path = os.path.join(group_dir, "task10_main_summary.csv")
    summary_df.to_csv(summary_path, index=False)
    _plot_task10_main_effectiveness(summary_df, os.path.join(group_dir, "task10_main_effectiveness_panel.png"))
    base = summary_df.set_index("method")
    pure = base.loc["Pure KF sparse"]
    full = base.loc["Full sampling"]
    sent = base.loc["Sentinel-assisted KF"]
    oracle = base.loc["Oracle-local wake-up"]
    compare_rows = [
        {"comparison": "sentinel_vs_pure_edr_delta", "value": sent["event_detection_rate_mean"] - pure["event_detection_rate_mean"]},
        {"comparison": "sentinel_vs_pure_delay_reduction", "value": pure["onset_detection_delay_mean_steps_mean"] - sent["onset_detection_delay_mean_steps_mean"]},
        {"comparison": "sentinel_vs_pure_coverage_delta", "value": sent["alert_coverage_l_mean"] - pure["alert_coverage_l_mean"]},
        {"comparison": "sentinel_vs_pure_far_delta", "value": sent["false_alarm_rate_mean"] - pure["false_alarm_rate_mean"]},
        {"comparison": "sentinel_vs_full_energy_saving_ratio", "value": (full["energy_proxy_total_mean"] - sent["energy_proxy_total_mean"]) / full["energy_proxy_total_mean"] if full["energy_proxy_total_mean"] > 0 else np.nan},
        {"comparison": "sentinel_vs_oracle_edr_gap", "value": oracle["event_detection_rate_mean"] - sent["event_detection_rate_mean"]},
        {"comparison": "sentinel_vs_oracle_coverage_gap", "value": oracle["alert_coverage_l_mean"] - sent["alert_coverage_l_mean"]},
        {"comparison": "sentinel_vs_oracle_anomaly_rmse_gap", "value": sent["rmse_anomaly_window_mean"] - oracle["rmse_anomaly_window_mean"]},
        {"comparison": "sentinel_vs_oracle_global_rmse_gap", "value": sent["rmse_global_mean"] - oracle["rmse_global_mean"]},
    ]
    compare_df = pd.DataFrame(compare_rows)
    compare_df.to_csv(os.path.join(group_dir, "task10_main_key_comparisons.csv"), index=False)
    with open(os.path.join(group_dir, "task10_main_run_dirs.json"), "w", encoding="utf-8") as f:
        json.dump(method_to_runs, f, ensure_ascii=False, indent=2)
    return summary_df


def _plot_task12_selector_tradeoff(summary_df, out_path):
    ordered = summary_df.sort_values(["k", "strategy"]).reset_index(drop=True)
    ks = sorted(ordered["k"].unique().tolist())
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for strategy, color in [("random_ratio", "#4C78A8"), ("k_center", "#F58518"), ("spatial_optimal_cover", "#54A24B")]:
        sub = ordered[ordered["strategy"] == strategy].sort_values("k")
        if len(sub) == 0:
            continue
        axes[0].plot(sub["k"].values, sub["coverage_mean"].values, marker="o", label=strategy, color=color)
        axes[1].plot(sub["k"].values, sub["sentinel_count_mean"].values, marker="o", label=strategy, color=color)
    axes[0].set_title("Spatial Coverage vs K")
    axes[0].set_xlabel("K (target sentinel count)")
    axes[0].set_ylabel("Coverage")
    axes[0].grid(alpha=0.2)
    axes[1].set_title("Actual Selected Count vs K")
    axes[1].set_xlabel("K (target sentinel count)")
    axes[1].set_ylabel("Selected Sentinel Count")
    axes[1].grid(alpha=0.2)
    axes[0].legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=220)
    plt.close(fig)


def _spatial_coverage_ratio(node_positions, node_ids, selected_ids, radius):
    if len(selected_ids) == 0:
        return 0.0
    selected = list(selected_ids)
    covered = 0
    for cid in node_ids:
        cpos = node_positions[cid]
        hit = False
        for sid in selected:
            spos = node_positions[sid]
            dx = cpos['x'] - spos['x']
            dy = cpos['y'] - spos['y']
            if float(np.sqrt(dx * dx + dy * dy)) <= radius:
                hit = True
                break
        if hit:
            covered += 1
    return float(covered / len(node_ids))


def run_task12_selector_optimization(output_root, random_trials=20):
    group_dir = os.path.join(output_root, "task12_selector_optimization")
    _ensure_dir(group_dir)
    node_positions = load_mote_positions(config.MOTE_LOC_FILE)
    node_ids = sorted(list(node_positions.keys()))
    selector = SentinelSelector(node_positions)
    k_values = [4, 6, 8, 10, 12, 14, 16]
    radius = float(getattr(config, "SENTINEL_OPT_COVER_RADIUS", config.SPATIAL_STATIC_RADIUS))
    rows = []
    for k in k_values:
        ratio = float(k / len(node_ids))
        selected_kcenter = selector.select("k_center", node_ids, ratio, random_seed=42)
        coverage_kcenter = _spatial_coverage_ratio(node_positions, node_ids, selected_kcenter, radius)
        rows.append({
            "k": int(k),
            "strategy": "k_center",
            "trial_seed": 0,
            "sentinel_count": float(len(selected_kcenter)),
            "coverage": float(coverage_kcenter),
            "radius": float(radius)
        })
        selected_opt = selector.select("spatial_optimal_cover", node_ids, ratio, random_seed=42)
        coverage_opt = _spatial_coverage_ratio(node_positions, node_ids, selected_opt, radius)
        rows.append({
            "k": int(k),
            "strategy": "spatial_optimal_cover",
            "trial_seed": 0,
            "sentinel_count": float(len(selected_opt)),
            "coverage": float(coverage_opt),
            "radius": float(radius)
        })
        for trial_seed in range(random_trials):
            random_seed = 42 + trial_seed
            selected_rand = selector.select("random_ratio", node_ids, ratio, random_seed=random_seed)
            coverage_rand = _spatial_coverage_ratio(node_positions, node_ids, selected_rand, radius)
            rows.append({
                "k": int(k),
                "strategy": "random_ratio",
                "trial_seed": int(trial_seed),
                "sentinel_count": float(len(selected_rand)),
                "coverage": float(coverage_rand),
                "radius": float(radius)
            })
    raw_df = pd.DataFrame(rows)
    raw_path = os.path.join(group_dir, "task12_selector_raw_runs.csv")
    raw_df.to_csv(raw_path, index=False)
    summary_df = (
        raw_df.groupby(["k", "strategy"], as_index=False)
        .agg({
            "sentinel_count": ["mean", "std"],
            "coverage": ["mean", "std"],
            "trial_seed": "count"
        })
    )
    summary_df.columns = ["_".join([c for c in col if c]).rstrip("_") for col in summary_df.columns.values]
    summary_df = summary_df.rename(columns={"k": "k", "strategy": "strategy", "trial_seed_count": "runs"})
    order = ["random_ratio", "k_center", "spatial_optimal_cover"]
    summary_df["strategy"] = pd.Categorical(summary_df["strategy"], categories=order, ordered=True)
    summary_df = summary_df.sort_values(["k", "strategy"]).reset_index(drop=True)
    summary_df["sentinel_count_std"] = summary_df["sentinel_count_std"].fillna(0.0)
    summary_df["coverage_std"] = summary_df["coverage_std"].fillna(0.0)
    summary_path = os.path.join(group_dir, "task12_selector_summary.csv")
    summary_df.to_csv(summary_path, index=False)
    _plot_task12_selector_tradeoff(summary_df, os.path.join(group_dir, "task12_selector_tradeoff.png"))
    best_rows = summary_df.sort_values(["k", "coverage_mean", "sentinel_count_mean"], ascending=[True, False, True]).groupby("k", as_index=False).head(1)
    best_rows.to_csv(os.path.join(group_dir, "task12_selector_best_by_k.csv"), index=False)
    return summary_df


def run_all_conclusion_experiments():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"conclusion_experiments_{ts}")
    _ensure_dir(output_root)
    a = run_group_a(output_root)
    b = run_group_b(output_root)
    c = run_group_c(output_root)
    summary = {
        "output_root": output_root,
        "group_a_rows": int(len(a)),
        "group_b_rows": int(len(b)),
        "group_c_rows": int(len(c))
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def run_group_a_only():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"conclusion_experiments_Aonly_{ts}")
    _ensure_dir(output_root)
    a = run_group_a(output_root)
    summary = {
        "output_root": output_root,
        "group_a_rows": int(len(a))
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def run_group_b_only():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"conclusion_experiments_Bonly_{ts}")
    _ensure_dir(output_root)
    b = run_group_b(output_root)
    summary = {
        "output_root": output_root,
        "group_b_rows": int(len(b))
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def run_group_c_only():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"conclusion_experiments_Conly_{ts}")
    _ensure_dir(output_root)
    c = run_group_c(output_root)
    summary = {
        "output_root": output_root,
        "group_c_rows": int(len(c))
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def run_task10_main_only():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"task10_main_{ts}")
    _ensure_dir(output_root)
    repeats = int(getattr(config, "TASK10_MAIN_REPEATS", 3))
    seed_base = int(getattr(config, "TASK10_MAIN_SEED_BASE", config.RANDOM_SEED))
    summary_df = run_task10_main_effectiveness(output_root=output_root, repeats=repeats, seed_base=seed_base)
    summary = {
        "output_root": output_root,
        "rows": int(len(summary_df)),
        "repeats": repeats,
        "seed_base": seed_base
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def run_task12_only():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_root = os.path.join(config.OUTPUT_DIR, f"task12_selector_{ts}")
    _ensure_dir(output_root)
    summary_df = run_task12_selector_optimization(output_root=output_root, random_trials=10)
    summary = {
        "output_root": output_root,
        "rows": int(len(summary_df)),
        "k_count": int(summary_df["k"].nunique())
    }
    with open(os.path.join(output_root, "run_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


if __name__ == "__main__":
    run_task10_main_only()
