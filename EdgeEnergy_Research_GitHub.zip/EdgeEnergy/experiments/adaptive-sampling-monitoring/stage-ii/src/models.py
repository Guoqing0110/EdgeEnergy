import os
import numpy as np
import pandas as pd
import src.config as config
from src.alert_policy import AdaptiveHopPolicy, AlertContext, bfs_routes

class Node:
    def __init__(self, node_id, initial_state, P0, F, H, Q, R, threshold_gamma):
        self.node_id = node_id
        self.x = initial_state  # State vector [x, v]^T
        self.P = P0             # Covariance matrix
        self.F = F              # State transition matrix
        self.H = H              # Observation matrix
        self.Q = Q              # Process noise covariance
        self.R = R              # Measurement noise covariance
        self.gamma = threshold_gamma

        # State Management
        # Role: normal, sentinel
        self.role = 'normal'
        # Mode: adaptive (default), alert (triggered), probe (short realert verification)
        self.mode = 'adaptive' 
        self.alert_timer = 0
        self.probe_timer = 0
        self.probe_elapsed = 0
        self.probe_weak_streak = 0
        self.probe_upgraded = False
        self.probe_failed = False
        self.probe_start_glr = 0.0
        self.probe_start_nis = 0.0
        self.probe_started_this_step = False
        
        # Cache for anomaly detection (before update)
        self.x_pred = None
        self.P_pred = None
        self.last_innovation = None
        self.last_innovation_var = None
        self.last_nis = None
        self.last_signed_norm_innovation = None
        self.trigger_mode = str(getattr(config, "SENTINEL_TRIGGER_MODE", "single")).strip().lower()
        self.consecutive_required = max(1, int(getattr(config, "SENTINEL_TRIGGER_CONSECUTIVE_STEPS", 2)))
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0
        self.glr_stat_up = 0.0
        self.glr_stat_down = 0.0
        self.mosum_stat_up = 0.0
        self.mosum_stat_down = 0.0
        self.detector_signal_buffer = []
        self.glr_background_stat_buffer = []
        self.self_trigger_enabled = bool(getattr(config, "NORMAL_SELF_TRIGGER_ENABLED", False))
        self.alert_elapsed = 0
        self.alert_bg_x = None
        self.alert_bg_P = None
        self.alert_exit_streak = 0
        self.alert_neighbor_quiet_streak = 0
        self.alert_early_exit_enabled = bool(getattr(config, "ALERT_EARLY_EXIT_ENABLED", False))
        self.alert_min_duration = max(1, int(getattr(config, "ALERT_MIN_DURATION_L", 2)))
        self.alert_exit_mode = str(getattr(config, "ALERT_EXIT_MODE", "threshold")).strip().lower()
        self.alert_verify_wait_steps = max(1, int(getattr(config, "ALERT_VERIFY_WAIT_STEPS", 5)))
        self.alert_exit_consecutive = max(1, int(getattr(config, "ALERT_EXIT_CONSECUTIVE_STEPS", 2)))
        self.alert_exit_abs_threshold = float(getattr(config, "ALERT_EXIT_ABS_THRESHOLD", 0.35))
        self.alert_exit_sigma_factor = float(getattr(config, "ALERT_EXIT_SIGMA_FACTOR", 1.2))
        self.alert_exit_glr_window_min = max(1, int(getattr(config, "ALERT_EXIT_GLR_WINDOW_MIN", 1)))
        self.alert_exit_glr_window_max = max(self.alert_exit_glr_window_min, int(getattr(config, "ALERT_EXIT_GLR_WINDOW_MAX", 8)))
        self.alert_exit_glr_threshold = float(getattr(config, "ALERT_EXIT_GLR_THRESHOLD", 6.0))
        self.alert_exit_glr_reset = float(getattr(config, "ALERT_EXIT_GLR_RESET", 1.0))
        self.alert_neighbor_silence_steps = max(0, int(getattr(config, "ALERT_EXIT_NEIGHBOR_SILENCE_STEPS", 2)))
        self.alert_neighbor_recovery_ratio = float(getattr(config, "ALERT_EXIT_NEIGHBOR_RECOVERY_RATIO", 0.0))
        self.alert_exit_cooldown_steps = max(0, int(getattr(config, "ALERT_EXIT_COOLDOWN_STEPS", 0)))
        self.alert_cooldown_timer = 0
        self.alert_exit_glr_stat = 0.0
        self.alert_exit_signal_buffer = []
        self.alert_exit_reference_sign = 0.0
        self.alert_exit_latched = False
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self.alert_relay_budget = 0
        self.alert_hop = 0
        self.alert_event_id = None
        self.event_watches = {}
        self.soft_watch_clock = 0
        self.budgeted_frontier_high_rate = False
        self.budgeted_frontier_active = False
        self.post_expiry_coverage_active = False
        self.post_expiry_coverage_full_rate = False
        self.last_detector_trigger_direction = 0
        self.failed_verification_count = 0
        
        # History for plotting
        self.history = {
            'estimated': [],
            'measured': [],
            'uncertainty_pred': [], # H*P_pred*H^T (Prior)
            'uncertainty_post': [], # H*P*H^T (Posterior)
            'sampled': [],          # 1 if sampled, 0 otherwise
            'predicted': [],        # predicted value (before update)
            'innovation': [],       # residual (y = z - Hx_pred)
            'nis': [],             # Normalized Innovation Squared
            'signed_norm_innovation': [],
            'glr_stat_up': [],
            'glr_stat_down': [],
            'mosum_stat_up': [],
            'mosum_stat_down': [],
            'mode': [],             # adaptive, alert
            'anomaly_flag': [],      # 1 if anomaly detected (Sentinel only)
            'detector_trigger_flag': [],  # 1 only on a sequential-detector trigger pulse
            'gt_anomaly_flag': [],    # 1 if ground truth is anomaly
            'gt_event_ids': []
        }
    def predict(self):
        """
        Kalman Filter Prediction Step
        x_{k|k-1} = F * x_{k-1|k-1}
        P_{k|k-1} = F * P_{k-1|k-1} * F^T + Q
        """
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q
        
        # Cache predicted state for anomaly detection
        self.x_pred = self.x.copy()
        self.P_pred = self.P.copy()
        if self.alert_bg_x is not None and self.alert_bg_P is not None:
            self.alert_bg_x = self.F @ self.alert_bg_x
            self.alert_bg_P = self.F @ self.alert_bg_P @ self.F.T + self.Q
        
        # Reset innovation/nis for this step (will be filled if sampled)
        self.last_innovation = np.nan
        self.last_innovation_var = np.nan
        self.last_nis = np.nan
        self.last_signed_norm_innovation = np.nan
        
        return self.x

    def update(self, z):
        """
        Kalman Filter Update Step
        """
        if z is None:
            # No measurement, state remains as predicted
            return

        # 1. Innovation (Residual) y = z - H * x_pred
        # Use cached predicted state to avoid using updated state
        y = z - self.H @ self.x_pred
        self.last_innovation = y[0, 0] # Scalar for single sensor
        
        # 2. Innovation Covariance S = H * P_pred * H^T + R
        S = self.H @ self.P_pred @ self.H.T + self.R
        s_scalar = float(S[0, 0])
        self.last_innovation_var = s_scalar
        if np.isfinite(s_scalar) and s_scalar > 1e-12:
            self.last_signed_norm_innovation = float(self.last_innovation / np.sqrt(s_scalar))
        else:
            self.last_signed_norm_innovation = np.nan
        
        # 3. Calculate NIS = y^T * S^-1 * y
        try:
            S_inv = np.linalg.inv(S)
            self.last_nis = (y.T @ S_inv @ y)[0, 0]
        except np.linalg.LinAlgError:
            S_inv = np.linalg.pinv(S) # Fallback to pseudo-inverse
            self.last_nis = (y.T @ S_inv @ y)[0, 0]
            
        # 4. Optimal Kalman Gain K = P_pred * H^T * S^-1
        K = self.P_pred @ self.H.T @ S_inv
        
        # 5. Update state x = x_pred + K * y
        self.x = self.x_pred + K @ y
        
        # 6. Update covariance (Joseph form for stability)
        # P = (I - KH)P(I - KH)^T + KRK^T
        I = np.eye(self.P.shape[0])
        I_KH = I - K @ self.H
        self.P = I_KH @ self.P_pred @ I_KH.T + K @ self.R @ K.T

    def should_sample(self):
        """
        Decide whether to sample based on role, mode and uncertainty.
        Using Predicted Observation Variance: sigma_y^2 = H * P_pred * H^T
        """
        # 1. Sentinel Role: Always sample
        if self.role == 'sentinel':
            return True
            
        # 2. Alert/Probe Mode: Triggered sampling
        if self.mode == 'probe':
            return True
        if self.mode == 'alert':
            if self.alert_confirmed and self.budgeted_frontier_active and bool(getattr(config, 'ALERT_BUDGETED_FRONTIER_TRACKING_ENABLED', False)):
                if self.budgeted_frontier_high_rate:
                    return True
                period = max(1, int(getattr(config, 'ALERT_SOFT_WATCH_PERIOD', 2)))
                return self.soft_watch_clock % period == 0
            if self.alert_confirmed and self.post_expiry_coverage_active and bool(getattr(config, 'ALERT_POST_EXPIRY_COVERAGE_SERVICE_ENABLED', False)):
                if self.post_expiry_coverage_full_rate:
                    return True
                period = max(1, int(getattr(config, 'ALERT_SOFT_WATCH_PERIOD', 2)))
                return self.soft_watch_clock % period == 0
            return True

        # A failed early verification does not imply that a delayed diffusion
        # front will never arrive. Soft-watch samples sparsely while retaining
        # event identity, allowing a later local confirmation to relay once.
        if self.event_watches and bool(getattr(config, 'ALERT_SOFT_WATCH_SAMPLING_ENABLED', True)):
            period = max(1, int(getattr(config, 'ALERT_SOFT_WATCH_PERIOD', 2)))
            if self.soft_watch_clock % period == 0:
                return True
        
        # 3. Adaptive Mode: Check uncertainty in observation space
        # Use Predicted Uncertainty (Prior)
        obs_uncertainty = (self.H @ self.P_pred @ self.H.T)[0, 0]
        
        if obs_uncertainty > self.gamma:
            return True
            
        return False

    def add_event_watch(self, event_id, remaining_steps, depth, component_id=None):
        existing = self.event_watches.get(int(event_id))
        watch = {
            'remaining_steps': max(1, int(remaining_steps)),
            'depth': max(0, int(depth)),
            'initial_verification_failed': False,
            'relayed': False,
            'component_id': int(component_id) if component_id is not None else None,
        }
        if existing is not None:
            watch['remaining_steps'] = max(watch['remaining_steps'], existing['remaining_steps'])
            watch['depth'] = min(watch['depth'], existing['depth'])
            watch['initial_verification_failed'] = existing['initial_verification_failed']
            watch['relayed'] = existing['relayed']
            if watch['component_id'] is None:
                watch['component_id'] = existing.get('component_id')
        self.event_watches[int(event_id)] = watch

    def active_event_watches(self):
        return {eid: watch for eid, watch in self.event_watches.items() if watch['remaining_steps'] > 0}

    def _reset_alert_exit_tracking(self):
        self.alert_exit_streak = 0
        self.alert_neighbor_quiet_streak = 0
        self.alert_exit_glr_stat = 0.0
        self.alert_exit_signal_buffer = []
        self.alert_exit_reference_sign = 0.0
        self.alert_exit_latched = False

    def confirm_alert(self):
        self.alert_confirmed = True
        self.alert_verify_elapsed = 0
        self._reset_alert_exit_tracking()

    def trigger_alert(self, duration, confirmed=False, relay_budget=None, alert_hop=None, event_id=None):
        """
        Trigger alert mode for a specific duration.
        """
        if self.mode != 'alert':
            self.alert_bg_x = self.x_pred.copy() if self.x_pred is not None else self.x.copy()
            self.alert_bg_P = self.P_pred.copy() if self.P_pred is not None else self.P.copy()
            self.alert_elapsed = 0
            self.alert_confirmed = bool(confirmed)
            self.alert_verify_elapsed = 0
            self.alert_relay_budget = max(0, int(relay_budget or 0))
            self.alert_hop = max(0, int(alert_hop or 0))
            self.alert_event_id = int(event_id) if event_id is not None else self.alert_event_id
            self._reset_alert_exit_tracking()
        elif confirmed and (not self.alert_confirmed):
            self.confirm_alert()
        if relay_budget is not None:
            self.alert_relay_budget = max(self.alert_relay_budget, max(0, int(relay_budget)))
        if alert_hop is not None:
            hop = max(0, int(alert_hop))
            self.alert_hop = hop if self.alert_hop <= 0 else min(self.alert_hop, hop)
        if event_id is not None:
            self.alert_event_id = int(event_id)
        self.alert_cooldown_timer = 0
        self.probe_timer = 0
        self.mode = 'alert'
        self.alert_timer = max(int(duration), int(self.alert_timer))

    def trigger_probe(self, duration, alert_hop=None, event_id=None, start_step=None):
        if self.mode == 'alert':
            return
        self.mode = 'probe'
        self.probe_timer = max(1, int(duration))
        self.probe_elapsed = 0
        self.probe_weak_streak = 0
        self.probe_upgraded = False
        self.probe_failed = False
        self.probe_start_glr = max(float(getattr(self, 'glr_stat_up', 0.0) or 0.0),
                                   float(getattr(self, 'glr_stat_down', 0.0) or 0.0))
        self.probe_start_nis = float(getattr(self, 'last_nis', 0.0) or 0.0)
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self.alert_hop = max(0, int(alert_hop or 0))
        self.alert_event_id = int(event_id) if event_id is not None else self.alert_event_id
        self.alert_cooldown_timer = 0
        self.probe_started_this_step = True
        self.probe_start_step = int(start_step) if start_step is not None else None
        self.probe_end_step = self.probe_start_step + int(duration) if self.probe_start_step is not None else None

    def _clear_probe_state(self, start_local_cooldown=False):
        failed_event_id = self.alert_event_id
        self.mode = 'adaptive'
        self.probe_timer = 0
        self.probe_elapsed = 0
        self.probe_weak_streak = 0
        self.probe_failed = True
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self.alert_hop = 0
        self.alert_event_id = None
        if start_local_cooldown and self.role != 'sentinel' and self.self_trigger_enabled:
            cooldown = max(
                self.alert_exit_cooldown_steps + 1,
                int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_COOLDOWN_STEPS', 8)),
            )
            self.alert_cooldown_timer = max(self.alert_cooldown_timer, cooldown)
        return failed_event_id

    def _clear_alert_state(self, start_local_cooldown=False):
        failed_event_id = self.alert_event_id if not self.alert_confirmed else None
        if not self.alert_confirmed:
            self.failed_verification_count += 1
            if self.alert_event_id is not None and int(self.alert_event_id) in self.event_watches:
                self.event_watches[int(self.alert_event_id)]['initial_verification_failed'] = True
            else:
                for watch in self.event_watches.values():
                    watch['initial_verification_failed'] = True
        self.mode = 'adaptive'
        self.alert_timer = 0
        self.alert_elapsed = 0
        self.alert_bg_x = None
        self.alert_bg_P = None
        self.alert_confirmed = False
        self.alert_verify_elapsed = 0
        self.alert_relay_budget = 0
        self.alert_hop = 0
        self.alert_event_id = None
        self._reset_alert_exit_tracking()
        if start_local_cooldown and self.role != 'sentinel' and self.self_trigger_enabled:
            self.alert_cooldown_timer = max(self.alert_cooldown_timer, self.alert_exit_cooldown_steps + 1)
        return failed_event_id

    def _background_prediction_stats(self):
        if self.alert_bg_x is None or self.alert_bg_P is None:
            return None, None
        bg_y = float((self.H @ self.alert_bg_x)[0, 0])
        bg_var = float((self.H @ self.alert_bg_P @ self.H.T)[0, 0] + self.R[0, 0])
        return bg_y, max(bg_var, 1e-9)

    def update_alert_exit_state(self, z):
        if self.mode != 'alert' or z is None:
            self._reset_alert_exit_tracking()
            return
        if not self.alert_early_exit_enabled:
            return
        if not self.alert_confirmed:
            self._reset_alert_exit_tracking()
            return
        bg_y, bg_var = self._background_prediction_stats()
        if bg_y is None:
            self._reset_alert_exit_tracking()
            return
        if self.alert_exit_mode == 'glr':
            bg_signed = float(float(z) - float(bg_y)) / float(np.sqrt(bg_var))
            if not np.isfinite(bg_signed):
                self.alert_exit_streak = 0
                self.alert_exit_glr_stat = 0.0
                self.alert_exit_signal_buffer = []
                self.alert_exit_reference_sign = 0.0
                self.alert_exit_latched = False
                return
            if self.alert_exit_reference_sign == 0.0 and abs(bg_signed) > 1e-9:
                self.alert_exit_reference_sign = 1.0 if bg_signed > 0.0 else -1.0
            if self.alert_exit_reference_sign == 0.0:
                self.alert_exit_streak = 0
                self.alert_exit_glr_stat = 0.0
                self.alert_exit_signal_buffer = []
                self.alert_exit_latched = False
                return
            exit_signal = -self.alert_exit_reference_sign * bg_signed
            self.alert_exit_signal_buffer.append(float(exit_signal))
            if len(self.alert_exit_signal_buffer) > self.alert_exit_glr_window_max:
                self.alert_exit_signal_buffer = self.alert_exit_signal_buffer[-self.alert_exit_glr_window_max:]
            vals = np.asarray(self.alert_exit_signal_buffer, dtype=float)
            n = len(vals)
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            glr_up = 0.0
            for win in range(self.alert_exit_glr_window_min, min(self.alert_exit_glr_window_max, n) + 1):
                seg_sum = float(csum[n] - csum[n - win])
                glr_up = max(glr_up, (max(0.0, seg_sum) ** 2) / (2.0 * float(win)))
            self.alert_exit_glr_stat = float(glr_up)
            if self.alert_exit_glr_stat < self.alert_exit_glr_reset:
                self.alert_exit_latched = False
                self.alert_exit_streak = 0
            elif self.alert_exit_glr_stat >= self.alert_exit_glr_threshold:
                if not self.alert_exit_latched:
                    self.alert_exit_latched = True
                self.alert_exit_streak = self.alert_exit_consecutive
            else:
                self.alert_exit_streak = 0
            return
        threshold = self.alert_exit_abs_threshold + self.alert_exit_sigma_factor * np.sqrt(bg_var)
        if abs(float(z) - float(bg_y)) <= float(threshold):
            self.alert_exit_streak += 1
        else:
            self.alert_exit_streak = 0

    def update_neighbor_quiet_state(self, neighborhood_active):
        if self.mode != 'alert':
            self.alert_neighbor_quiet_streak = 0
            return
        if neighborhood_active:
            self.alert_neighbor_quiet_streak = 0
        else:
            self.alert_neighbor_quiet_streak += 1

    def is_background_recovered(self):
        if self.mode != 'alert':
            return False
        if not self.alert_confirmed:
            return False
        if self.alert_exit_mode == 'glr':
            return bool(self.alert_exit_latched and self.alert_exit_glr_stat >= self.alert_exit_glr_threshold)
        return bool(self.alert_exit_streak >= self.alert_exit_consecutive)

    def in_alert_cooldown(self):
        return bool(self.alert_cooldown_timer > 0)

    def step_cooldown(self):
        self.soft_watch_clock += 1
        expired = []
        for event_id, watch in self.event_watches.items():
            watch['remaining_steps'] -= 1
            if watch['remaining_steps'] <= 0:
                expired.append(event_id)
        for event_id in expired:
            del self.event_watches[event_id]
        if self.alert_cooldown_timer > 0:
            self.alert_cooldown_timer -= 1

    def reset_detector_state(self):
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.last_detector_trigger_direction = 0
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0
        self.glr_stat_up = 0.0
        self.glr_stat_down = 0.0
        self.mosum_stat_up = 0.0
        self.mosum_stat_down = 0.0
        self.detector_signal_buffer = []

    def _detector_mode(self):
        return str(getattr(config, "SENTINEL_DETECTOR_MODE", "nis")).strip().lower()

    def _nis_signal(self):
        if self.last_nis is None or np.isnan(self.last_nis):
            return np.nan
        return float(np.sqrt(max(0.0, float(self.last_nis))))

    def _normalized_innovation_signal(self):
        if self.last_signed_norm_innovation is None or np.isnan(self.last_signed_norm_innovation):
            return np.nan
        return float(self.last_signed_norm_innovation)

    def _detector_direction(self, prefix):
        raw = str(getattr(config, prefix, "both")).strip().lower()
        if raw in {"up", "pos", "positive", "rise", "increase"}:
            return "up"
        if raw in {"down", "neg", "negative", "fall", "decrease"}:
            return "down"
        return "both"

    def _selected_detector_stat(self, up_stat, down_stat, direction):
        if direction == "up":
            return float(up_stat)
        if direction == "down":
            return float(down_stat)
        return float(max(up_stat, down_stat))

    def _dominant_detector_direction(self, up_stat, down_stat, signal_value=np.nan):
        up_val = float(up_stat)
        down_val = float(down_stat)
        if up_val > down_val:
            return 1
        if down_val > up_val:
            return -1
        if np.isfinite(signal_value) and float(signal_value) != 0.0:
            return 1 if float(signal_value) > 0.0 else -1
        return 0

    def _detector_buffer_maxlen(self):
        glr_max = max(1, int(getattr(config, "SENTINEL_GLR_WINDOW_MAX", 12)))
        mosum_max = max(1, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MAX", 6)))
        return max(glr_max, 2 * mosum_max)

    def _append_detector_signal(self, x):
        self.detector_signal_buffer.append(float(x))
        maxlen = self._detector_buffer_maxlen()
        if len(self.detector_signal_buffer) > maxlen:
            self.detector_signal_buffer = self.detector_signal_buffer[-maxlen:]

    def _update_glr_stat(self):
        vals = np.asarray(self.detector_signal_buffer, dtype=float)
        n = len(vals)
        min_w = max(1, int(getattr(config, "SENTINEL_GLR_WINDOW_MIN", 1)))
        max_w = max(min_w, int(getattr(config, "SENTINEL_GLR_WINDOW_MAX", 12)))
        up_stat = 0.0
        down_stat = 0.0
        if n > 0:
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            upper = min(max_w, n)
            for win in range(min_w, upper + 1):
                seg_sum = float(csum[n] - csum[n - win])
                up_stat = max(up_stat, (max(0.0, seg_sum) ** 2) / (2.0 * float(win)))
                down_stat = max(down_stat, (max(0.0, -seg_sum) ** 2) / (2.0 * float(win)))
        self.glr_stat_up = float(up_stat)
        self.glr_stat_down = float(down_stat)

    def _glr_relative_enabled(self):
        return bool(getattr(config, "SENTINEL_GLR_RELATIVE_ENABLED", False))

    def _glr_relative_window(self):
        return max(5, int(getattr(config, "SENTINEL_GLR_RELATIVE_WINDOW", 40)))

    def _glr_relative_min_count(self):
        return max(5, int(getattr(config, "SENTINEL_GLR_RELATIVE_MIN_COUNT", 12)))

    def _glr_relative_floor(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_FLOOR", 3.0))

    def _glr_relative_k(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_K", 3.5))

    def _glr_relative_scale_floor(self):
        return float(getattr(config, "SENTINEL_GLR_RELATIVE_SCALE_FLOOR", 0.35))

    def _glr_relative_background_cap(self, hard_threshold):
        frac = float(getattr(config, "SENTINEL_GLR_RELATIVE_BACKGROUND_MAX_FRACTION", 0.8))
        frac = min(max(frac, 0.05), 1.0)
        return float(hard_threshold) * frac

    def _glr_relative_threshold_stats(self):
        vals = np.asarray(self.glr_background_stat_buffer, dtype=float)
        vals = vals[np.isfinite(vals)]
        if len(vals) < self._glr_relative_min_count():
            return np.nan, np.nan, np.nan
        center = float(np.median(vals))
        mad = float(np.median(np.abs(vals - center)))
        scale = max(1.4826 * mad, self._glr_relative_scale_floor())
        threshold = max(self._glr_relative_floor(), center + self._glr_relative_k() * scale)
        return center, scale, float(threshold)

    def _glr_relative_hit(self, stat):
        if (not self._glr_relative_enabled()) or (not np.isfinite(stat)):
            return False
        _, _, threshold = self._glr_relative_threshold_stats()
        if not np.isfinite(threshold):
            return False
        return float(stat) >= float(threshold)

    def _update_glr_relative_background(self, stat, hard_threshold, should_trigger):
        if not self._glr_relative_enabled():
            return
        if self.mode == 'alert':
            return
        if should_trigger or (not np.isfinite(stat)):
            return
        background_cap = min(self._glr_relative_background_cap(hard_threshold), float(hard_threshold))
        if float(stat) >= background_cap:
            return
        self.glr_background_stat_buffer.append(float(stat))
        maxlen = self._glr_relative_window()
        if len(self.glr_background_stat_buffer) > maxlen:
            self.glr_background_stat_buffer = self.glr_background_stat_buffer[-maxlen:]

    def _update_mosum_stat(self):
        vals = np.asarray(self.detector_signal_buffer, dtype=float)
        n = len(vals)
        min_w = max(1, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MIN", 2)))
        max_w = max(min_w, int(getattr(config, "SENTINEL_MOSUM_WINDOW_MAX", 6)))
        up_stat = 0.0
        down_stat = 0.0
        if n >= 2:
            csum = np.concatenate(([0.0], np.cumsum(vals)))
            upper = min(max_w, n // 2)
            for win in range(min_w, upper + 1):
                recent_sum = float(csum[n] - csum[n - win])
                prev_sum = float(csum[n - win] - csum[n - 2 * win])
                diff = (recent_sum - prev_sum) / np.sqrt(2.0 * float(win))
                up_stat = max(up_stat, max(0.0, diff))
                down_stat = max(down_stat, max(0.0, -diff))
        self.mosum_stat_up = float(up_stat)
        self.mosum_stat_down = float(down_stat)

    def is_anomaly_signal(self):
        mode = self._detector_mode()
        if mode == 'nis':
            return self.is_anomaly_raw()
        if mode == 'cusum':
            return self.cusum_stat >= float(getattr(config, "SENTINEL_CUSUM_H", 3.2))
        if mode == 'page_hinkley':
            return (self.ph_cum - self.ph_min) >= float(getattr(config, "SENTINEL_PH_LAMBDA", 1.8))
        if mode == 'glr':
            direction = self._detector_direction("SENTINEL_GLR_DIRECTION")
            stat = self._selected_detector_stat(self.glr_stat_up, self.glr_stat_down, direction)
            return bool((stat >= float(getattr(config, "SENTINEL_GLR_THRESHOLD", 8.0))) or self._glr_relative_hit(stat))
        if mode == 'mosum':
            direction = self._detector_direction("SENTINEL_MOSUM_DIRECTION")
            stat = self._selected_detector_stat(self.mosum_stat_up, self.mosum_stat_down, direction)
            return stat >= float(getattr(config, "SENTINEL_MOSUM_THRESHOLD", 3.0))
        return self.is_anomaly_raw()

    def check_anomaly(self):
        mode = self._detector_mode()
        if self.last_nis is None or np.isnan(self.last_nis):
            self.reset_detector_state()
            return False
        if mode in {'glr', 'mosum'}:
            x = self._normalized_innovation_signal()
            if not np.isfinite(x):
                self.reset_detector_state()
                return False
            self._append_detector_signal(x)
            if mode == 'glr':
                self._update_glr_stat()
                direction = self._detector_direction("SENTINEL_GLR_DIRECTION")
                threshold = float(getattr(config, "SENTINEL_GLR_THRESHOLD", 8.0))
                reset = float(getattr(config, "SENTINEL_GLR_RESET", 1.0))
                stat = self._selected_detector_stat(self.glr_stat_up, self.glr_stat_down, direction)
                relative_hit = self._glr_relative_hit(stat)
            else:
                self._update_mosum_stat()
                direction = self._detector_direction("SENTINEL_MOSUM_DIRECTION")
                threshold = float(getattr(config, "SENTINEL_MOSUM_THRESHOLD", 3.0))
                reset = float(getattr(config, "SENTINEL_MOSUM_RESET", 0.5))
                stat = self._selected_detector_stat(self.mosum_stat_up, self.mosum_stat_down, direction)
                relative_hit = False
            if stat < reset:
                self.alert_latched = False
            dominant_direction = self._dominant_detector_direction(
                self.glr_stat_up if mode == 'glr' else self.mosum_stat_up,
                self.glr_stat_down if mode == 'glr' else self.mosum_stat_down,
                signal_value=x,
            )
            should_trigger = bool((stat >= threshold) or relative_hit)
            if mode == 'glr':
                self._update_glr_relative_background(stat, threshold, should_trigger)
            if should_trigger and self.mode == 'alert' and self.alert_confirmed:
                self.last_detector_trigger_direction = dominant_direction
                return False
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                self.last_detector_trigger_direction = dominant_direction
                return True
            return False
        if mode == 'cusum':
            x = self._nis_signal()
            k = float(getattr(config, "SENTINEL_CUSUM_K", 0.35))
            h = float(getattr(config, "SENTINEL_CUSUM_H", 3.2))
            reset = float(getattr(config, "SENTINEL_CUSUM_RESET", 0.6))
            self.cusum_stat = max(0.0, self.cusum_stat + x - k)
            if self.cusum_stat < reset:
                self.alert_latched = False
            should_trigger = self.cusum_stat >= h
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                return True
            return False
        if mode == 'page_hinkley':
            x = self._nis_signal()
            delta = float(getattr(config, "SENTINEL_PH_DELTA", 0.03))
            lamb = float(getattr(config, "SENTINEL_PH_LAMBDA", 1.8))
            reset = float(getattr(config, "SENTINEL_PH_RESET", 0.25))
            self.ph_count += 1
            if self.ph_count == 1:
                self.ph_mean = x
            else:
                self.ph_mean += (x - self.ph_mean) / self.ph_count
            self.ph_cum += x - self.ph_mean - delta
            self.ph_min = min(self.ph_min, self.ph_cum)
            gap = self.ph_cum - self.ph_min
            if gap < reset:
                self.alert_latched = False
            should_trigger = gap >= lamb
            if should_trigger and (not self.alert_latched):
                self.alert_latched = True
                return True
            return False
        raw = self.last_nis > float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63)))
        soft_factor = float(getattr(config, "SENTINEL_TRIGGER_SOFT_FACTOR", 0.75))
        soft_steps = max(1, int(getattr(config, "SENTINEL_TRIGGER_SOFT_CONSECUTIVE_STEPS", self.consecutive_required)))
        eta = float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63)))
        if self.last_nis > eta:
            self.nis_exceed_streak += 1
        else:
            self.nis_exceed_streak = 0
        if self.last_nis > eta * soft_factor:
            self.soft_exceed_streak += 1
        else:
            self.soft_exceed_streak = 0
        if self.nis_exceed_streak == 0 and self.soft_exceed_streak == 0:
            self.alert_latched = False
        if self.trigger_mode == 'consecutive':
            high_override = float(getattr(config, "SENTINEL_TRIGGER_HIGH_OVERRIDE_FACTOR", 1.2)) * eta
            should_trigger = (self.nis_exceed_streak >= self.consecutive_required) or (self.last_nis >= high_override) or (self.soft_exceed_streak >= soft_steps)
        else:
            should_trigger = raw or (self.soft_exceed_streak >= soft_steps)
        if should_trigger and (not self.alert_latched):
            self.alert_latched = True
            return True
        return False

    def is_anomaly_raw(self):
        if self.last_nis is None or np.isnan(self.last_nis):
            return False
        return bool(self.last_nis > float(getattr(self, "eta", getattr(config, "ANOMALY_THRESHOLD_ETA", 6.63))))

    def step_timer(self, neighbor_recovery_ratio=None, allow_probe_upgrade=True):
        if self.mode == 'probe':
            self.probe_elapsed += 1
            self.alert_verify_elapsed += 1
            upgrade_threshold = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD', 2.0))
            signed_innovation = float(getattr(self, 'last_signed_norm_innovation', 0.0) or 0.0)
            nis_val = float(getattr(self, 'last_nis', 0.0) or 0.0)
            glr_val = max(float(getattr(self, 'glr_stat_up', 0.0) or 0.0), float(getattr(self, 'glr_stat_down', 0.0) or 0.0))
            uncertainty = float((self.H @ self.P @ self.H.T)[0, 0]) if self.P is not None else 0.0
            loose_upgrade = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_LOOSE_UPGRADE_ENABLED', False))
            weak_threshold = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_WEAK_INNOVATION_THRESHOLD', 1.0))
            weak_hit = bool(np.isfinite(signed_innovation) and abs(signed_innovation) >= weak_threshold)
            self.probe_weak_streak = self.probe_weak_streak + 1 if weak_hit else 0
            should_upgrade = bool(np.isfinite(signed_innovation) and abs(signed_innovation) >= upgrade_threshold)
            upgrade_reason = 'abs_innovation' if should_upgrade else ''
            if loose_upgrade:
                nis_threshold = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_NIS_THRESHOLD', 2.0))
                glr_threshold = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_GLR_THRESHOLD', 2.0))
                uncertainty_threshold = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_UNCERTAINTY_FACTOR', 0.5)) * float(config.GAMMA)
                weak_streak_steps = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_WEAK_STREAK_STEPS', 2)))
                conditions = [
                    ('nis', np.isfinite(nis_val) and nis_val >= nis_threshold),
                    ('glr', np.isfinite(glr_val) and glr_val >= glr_threshold),
                    ('weak_streak', self.probe_weak_streak >= weak_streak_steps),
                ]
                if bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_UNCERTAINTY_ENABLED', True)):
                    conditions.append(('uncertainty', np.isfinite(uncertainty) and uncertainty >= uncertainty_threshold))
                if bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_RELATIVE_GLR_ENABLED', False)):
                    conditions.append(('glr_rising', np.isfinite(glr_val) and glr_val > self.probe_start_glr))
                for reason, hit in conditions:
                    if hit and not should_upgrade:
                        upgrade_reason = reason
                    should_upgrade = should_upgrade or bool(hit)
            if should_upgrade and allow_probe_upgrade:
                self.probe_upgraded = True
                duration = max(1, int(getattr(config, 'ALERT_DURATION_STEPS', 5)))
                event_id = self.alert_event_id
                self.trigger_alert(duration, confirmed=False, alert_hop=self.alert_hop, event_id=event_id)
                return {'probe_upgraded': True, 'upgrade_reason': upgrade_reason, 'failed_event_id': None}
            if self.probe_timer > 1:
                self.probe_timer -= 1
            else:
                failed_event_id = self._clear_probe_state(start_local_cooldown=True)
                return {'probe_failed': True, 'failed_event_id': failed_event_id}
            return {'failed_event_id': None}
        if self.mode == 'alert':
            self.alert_elapsed += 1
            if not self.alert_confirmed:
                self.alert_verify_elapsed += 1
                if bool(getattr(config, 'ALERT_VERIFICATION_FAIL_FAST', True)) and self.alert_verify_elapsed >= self.alert_verify_wait_steps:
                    failed_event_id = self._clear_alert_state(start_local_cooldown=False)
                    return {'failed_event_id': failed_event_id}
                return {'failed_event_id': None}
            allow_exit = False
            if (
                self.alert_early_exit_enabled
                and self.alert_elapsed >= self.alert_min_duration
            ):
                if self.alert_exit_mode == 'glr':
                    allow_exit = self.is_background_recovered()
                elif self.alert_exit_streak >= self.alert_exit_consecutive and self.alert_neighbor_recovery_ratio > 0.0:
                    ratio_val = 1.0 if neighbor_recovery_ratio is None else float(neighbor_recovery_ratio)
                    allow_exit = ratio_val >= self.alert_neighbor_recovery_ratio
                elif self.alert_exit_streak >= self.alert_exit_consecutive:
                    allow_exit = self.alert_neighbor_quiet_streak >= self.alert_neighbor_silence_steps
            if allow_exit:
                self._clear_alert_state(start_local_cooldown=True)
                return {'failed_event_id': None}
            if self.alert_exit_mode == 'glr':
                return {'failed_event_id': None}
            if self.alert_timer > 1:
                self.alert_timer -= 1
            else:
                failed_event_id = self._clear_alert_state()
                return {'failed_event_id': failed_event_id}
        return {'failed_event_id': None}

    def log_status(self, z=None, sampled=False, anomaly_detected=False, detector_triggered=False,
                   gt_anomaly=False, gt_event_ids=None):
        self.history['estimated'].append(self.x[0, 0])
        self.history['measured'].append(z if z is not None else np.nan)
        
        # Log Predicted Observation Variance (Prior) - Decision Basis
        unc_pred = (self.H @ self.P_pred @ self.H.T)[0, 0] if self.P_pred is not None else np.nan
        self.history['uncertainty_pred'].append(unc_pred)
        
        # Log Posterior Observation Variance (Post) - Resulting Confidence
        unc_post = (self.H @ self.P @ self.H.T)[0, 0]
        self.history['uncertainty_post'].append(unc_post)
        
        self.history['sampled'].append(1 if sampled else 0)
        
        # New fields
        pred_val = (self.H @ self.x_pred)[0, 0] if self.x_pred is not None else np.nan
        self.history['predicted'].append(pred_val)
        self.history['innovation'].append(self.last_innovation)
        self.history['nis'].append(self.last_nis)
        self.history['signed_norm_innovation'].append(self.last_signed_norm_innovation)
        self.history['glr_stat_up'].append(self.glr_stat_up)
        self.history['glr_stat_down'].append(self.glr_stat_down)
        self.history['mosum_stat_up'].append(self.mosum_stat_up)
        self.history['mosum_stat_down'].append(self.mosum_stat_down)
        self.history['mode'].append(self.mode)
        self.history['anomaly_flag'].append(1 if anomaly_detected else 0)
        self.history['detector_trigger_flag'].append(1 if detector_triggered else 0)
        self.history['gt_anomaly_flag'].append(1 if gt_anomaly else 0)
        if gt_event_ids is None:
            self.history['gt_event_ids'].append('')
        else:
            self.history['gt_event_ids'].append(','.join([str(x) for x in gt_event_ids]))


class Sentinel(Node):
    def __init__(self, node_id, initial_state, P0, F, H, Q, R, threshold_gamma, anomaly_threshold_eta, trigger_mode='single', consecutive_required=2):
        super().__init__(node_id, initial_state, P0, F, H, Q, R, threshold_gamma)
        self.role = 'sentinel'
        self.eta = anomaly_threshold_eta
        self.trigger_mode = str(trigger_mode).strip().lower()
        self.consecutive_required = max(1, int(consecutive_required))
        self.nis_exceed_streak = 0
        self.soft_exceed_streak = 0
        self.alert_latched = False
        self.cusum_stat = 0.0
        self.ph_mean = 0.0
        self.ph_cum = 0.0
        self.ph_min = 0.0
        self.ph_count = 0

    def _detector_mode(self):
        return super()._detector_mode()

    def _nis_signal(self):
        return super()._nis_signal()

    def is_anomaly_signal(self):
        return super().is_anomaly_signal()

    def check_anomaly(self):
        return super().check_anomaly()

    def is_anomaly_raw(self):
        return super().is_anomaly_raw()


from src.anomaly import AnomalyInjector

class SimulationEnvironment:
    def __init__(self, nodes, data_loader, start_time, time_step_sec=30, value_col='temperature', node_positions=None, alert_duration_steps=3, alert_neighbor_graph='communication', alert_propagation_mode='one_hop', alert_max_hops=1, enable_sentinel_alert_trigger=True, oracle_wakeup_enabled=False, oracle_wakeup_graph='spatial'):
        self.nodes = nodes
        self.data_loader = data_loader
        self.current_time = start_time
        self.time_step = pd.Timedelta(seconds=time_step_sec)
        self.value_col = value_col
        self.node_data = {}
        self.node_positions = node_positions if node_positions is not None else {}
        self.adjacency = {node_id: [] for node_id in self.nodes.keys()}
        self.topology_mode = None
        self.topology_params = {}
        self.communication_weights = {}
        self.communication_adjacency = {node_id: [] for node_id in self.nodes.keys()}
        self.communication_threshold = None
        self.communication_model = 'threshold_cut'
        self.alert_duration_steps = alert_duration_steps
        self.alert_neighbor_graph = alert_neighbor_graph
        self.alert_propagation_mode = alert_propagation_mode
        self.alert_max_hops = alert_max_hops
        self.enable_sentinel_alert_trigger = enable_sentinel_alert_trigger
        self.oracle_wakeup_enabled = oracle_wakeup_enabled
        self.oracle_wakeup_graph = oracle_wakeup_graph
        self.alert_events = []
        self.oracle_alert_events = []
        self.node_comm_energy_records = []
        self.previous_gt_anomaly_nodes = set()
        self.event_relay_events = {}
        self.next_relay_event_id = 1
        self.step_index = 0
        self.event_relay_stats = {
            'created_event_count': 0,
            'repropagation_count': 0,
            'late_confirm_rescue_count': 0,
            'soft_watch_sample_count': 0,
            'soft_watch_false_sample_count': 0,
            'raw_event_trigger_count': 0,
            'event_merge_count': 0,
            'directional_candidate_count': 0,
            'direction_confident_relay_count': 0,
            'direction_fallback_relay_count': 0,
            'direction_conflict_count': 0,
            'geometry_radial_count': 0,
            'geometry_directional_count': 0,
            'geometry_multisource_count': 0,
            'geometry_fallback_count': 0,
            'candidate_generated_count': 0,
            'candidate_duplicate_count': 0,
            'candidate_path_hops_total': 0,
            'candidate_path_count': 0,
            'time_requery_count': 0,
            'confirmation_requery_count': 0,
            'soft_trend_requery_count': 0,
            'realert_count': 0,
            'realert_source_count': 0,
            'realert_candidate_count': 0,
            'realert_selected_count': 0,
            'realert_success_count': 0,
            'event_expiry_clear_count': 0,
            'reactivated_failed_nodes': 0,
            'cooldown_suppression_count': 0,
            'budget_exhaustion_count': 0,
            'strict_gate_block_count': 0,
            'weakAND_block_count': 0,
            'front_approach_block_count': 0,
            'previous_false_candidate_count': 0,
            'previous_false_selected_count': 0,
            'probe_upgrade_cap_block_count': 0,
            'deferred_by_active_cap_count': 0,
            'probe_trigger_count': 0,
            'probe_upgrade_count': 0,
            'probe_fail_count': 0,
            'probe_upgrade_final_confirmed_count': 0,
            'full_alert_node_time': 0,
            'probe_node_time': 0,
        }
        self.directional_selections = []
        self.target_ranker_records = []
        self.realert_target_records = []
        # Append-only B2.3 diagnostics.  This collection is never consulted by
        # the relay policy, selector, RNG, or node-state transitions.
        self.realert_funnel_records = []
        self.realert_decision_context_records = []
        self.probe_evidence_records = []
        # Offline structural-localization traces.  These containers are
        # append-only observations and are deliberately excluded from all
        # runtime decision inputs.
        self.event_state_trace = []
        self.retained_record_timeline = []
        self.node_state_duration_trace = []
        # Append-only B2.7 audit; runtime never reads this collection.
        self.budgeted_frontier_selection_trace = []
        # Append-only B2.8-Y3 audit. Runtime selection writes records but never
        # reads this collection; the feature flag controls runtime behavior.
        self.post_expiry_coverage_selection_trace = []
        self._trace_previous_confirmed = {}
        self._target_ranker = None
        self._ap_dfrealert_model = None
        self._ap_dfrealert_policy = None
        self._false_wakeup_counts = {node_id: 0 for node_id in self.nodes}
        global_budget = int(getattr(config, 'ALERT_LEARNED_GLOBAL_MESSAGE_BUDGET', 0))
        self._learned_global_budget_remaining = global_budget if global_budget > 0 else None
        self.current_step_gt_event_ids = {}
        self.anomaly_injector = AnomalyInjector() # Initialize injector

    def _measurement_noise(self, node):
        """Generate method-invariant noise for a given node and timestamp.

        A global RNG makes paired treatments incomparable: extra alert samples
        consume random draws and change all later detector observations.  This
        stateless seed keeps the same node/time observation identical across
        propagation policies.
        """
        timestamp_ns = int(pd.Timestamp(self.current_time).value)
        seed_words = [
            int(getattr(config, "RANDOM_SEED", 0)) & 0xFFFFFFFF,
            int(node.node_id) & 0xFFFFFFFF,
            timestamp_ns & 0xFFFFFFFF,
            (timestamp_ns >> 32) & 0xFFFFFFFF,
        ]
        rng = np.random.default_rng(np.random.SeedSequence(seed_words))
        return float(rng.normal(0.0, np.sqrt(node.R[0, 0])))

    def _alert_duration_for_hop(self, hop):
        if not bool(getattr(config, 'ALERT_HOP_TTL_ENABLED', False)):
            return int(self.alert_duration_steps)
        ttl_map = getattr(config, 'ALERT_HOP_TTL_STEPS', {})
        hop = max(1, int(hop))
        if isinstance(ttl_map, dict):
            value = ttl_map.get(hop, ttl_map.get(str(hop), min(ttl_map.values()) if ttl_map else self.alert_duration_steps))
        else:
            value = self.alert_duration_steps
        return max(1, int(value))

    def _spatially_plausible_alert_targets(self, source_id, targets, max_distance):
        if source_id not in self.node_positions:
            return set(targets)
        source = self.node_positions[source_id]
        selected = set()
        for node_id in targets:
            if node_id not in self.node_positions:
                continue
            target = self.node_positions[node_id]
            distance = float(np.hypot(source['x'] - target['x'], source['y'] - target['y']))
            if distance <= float(max_distance):
                selected.add(node_id)
        return selected

    def _create_relay_event(self, source_id, max_hops):
        event_id = self.next_relay_event_id
        self.next_relay_event_id += 1
        lifetime = max(1, int(getattr(config, 'ALERT_EVENT_LIFETIME_STEPS', 48)))
        min_initial = max(1, int(getattr(config, 'ALERT_EVENT_INITIAL_HOPS', 2)))
        event_hop_limit = max(min_initial, int(getattr(config, 'ALERT_ADAPTIVE_MAX_HOPS', max_hops)))
        self.event_relay_events[event_id] = {
            'event_id': int(event_id),
            'source_id': int(source_id), 'created_step': int(self.step_index),
            # Initial evidence controls the first burst, not the lifetime cap.
            # Later confirmed frontier nodes may advance up to the configured
            # event limit, which is the point of event-level propagation.
            'expires_step': int(self.step_index + lifetime), 'max_hops': event_hop_limit,
            'alerted_nodes': {int(source_id)}, 'confirmed_nodes': {int(source_id)},
            'relayed_nodes': set(),
            'source_nodes': {int(source_id)},
            'components': {
                int(source_id): {
                    'source_id': int(source_id), 'confirmed_records': {},
                    'true_event_ids': set(), 'direction_history': [],
                }
            },
            'node_components': {int(source_id): int(source_id)},
            'last_time_requery_step': int(self.step_index),
            'anchor_last_requery': {},
            'last_alert_step': {int(source_id): int(self.step_index)},
            'realerted_sources': set(),
            'realert_message_count': 0,
            'realerted_nodes': set(),
            'realert_admitted_nodes': set(),
            'realert_admission_count': 0,
            'realert_success_nodes': set(),
            'failed_verification_nodes': set(),
        }
        self.nodes[source_id].add_event_watch(event_id, lifetime, depth=0, component_id=source_id)
        self.event_relay_stats['created_event_count'] += 1
        return event_id

    def _event_sign(self, node):
        direction = int(getattr(node, 'last_detector_trigger_direction', 0) or 0)
        return 1 if direction > 0 else (-1 if direction < 0 else 0)

    def _record_component_truth(self, component, node_id):
        event_ids = self.current_step_gt_event_ids.get(node_id, [])
        component.setdefault('true_event_ids', set()).update(event_ids)
        counts = component.setdefault('true_event_counts', {})
        for true_id in event_ids:
            counts[int(true_id)] = counts.get(int(true_id), 0) + 1

    def _find_mergeable_event(self, source_id, sign):
        if not bool(getattr(config, 'ALERT_EVENT_MERGE_ENABLED', False)):
            return None
        window = max(0, int(getattr(config, 'ALERT_EVENT_MERGE_WINDOW_STEPS', 12)))
        radius = float(getattr(config, 'ALERT_EVENT_MERGE_RADIUS', 12.0))
        min_remaining = max(0, int(getattr(config, 'ALERT_EVENT_MERGE_MIN_REMAINING_STEPS', 0)))
        source_pos = self.node_positions.get(source_id)
        best = None
        for event_id, event in self.event_relay_events.items():
            if (
                self.step_index >= event['expires_step']
                or int(event['expires_step']) - int(self.step_index) < min_remaining
                or self.step_index - event.get('last_update_step', event['created_step']) > window
            ):
                continue
            event_sign = int(event.get('sign', 0))
            if sign and event_sign and sign != event_sign:
                continue
            anchors = event.get('confirmed_nodes', set()) | event.get('source_nodes', set())
            min_distance = np.inf
            if source_pos is not None:
                for anchor in anchors:
                    anchor_pos = self.node_positions.get(anchor)
                    if anchor_pos is not None:
                        min_distance = min(min_distance, float(np.hypot(source_pos['x']-anchor_pos['x'], source_pos['y']-anchor_pos['y'])))
            if min_distance <= radius:
                candidate = (min_distance, -event.get('last_update_step', 0), event_id)
                if best is None or candidate < best:
                    best = candidate
        return None if best is None else best[2]

    def _attach_trigger_to_event(self, event_id, source_id):
        event = self.event_relay_events[event_id]
        event['source_nodes'].add(int(source_id))
        event['confirmed_nodes'].add(int(source_id))
        event['last_update_step'] = int(self.step_index)
        component_id = int(source_id)
        event.setdefault('components', {}).setdefault(component_id, {
            'source_id': component_id, 'confirmed_records': {},
            'true_event_ids': set(), 'direction_history': [],
        })
        event.setdefault('node_components', {})[int(source_id)] = component_id
        remaining = max(1, event['expires_step'] - self.step_index)
        self.nodes[source_id].add_event_watch(event_id, remaining, depth=0, component_id=component_id)
        self.event_relay_stats['event_merge_count'] += 1

    def _direction_diagnostics(self, event, component_id):
        component = event.get('components', {}).get(component_id, {})
        records = component.get('confirmed_records', {})
        minimum = max(2, int(getattr(config, 'ALERT_DIRECTION_MIN_CONFIRMATIONS', 3)))
        usable = [(nid, rec[0], max(1e-6, abs(float(rec[1])))) for nid, rec in records.items() if nid in self.node_positions]
        if len(usable) < minimum:
            return None, 0.0, True
        usable.sort(key=lambda x: (x[1], x[0]))
        split = max(1, len(usable) // 2)
        early, late = usable[:split], usable[split:]
        if not late:
            return None, 0.0, True
        def centroid(items):
            weights = np.asarray([x[2] for x in items], dtype=float)
            points = np.asarray([[self.node_positions[x[0]]['x'], self.node_positions[x[0]]['y']] for x in items], dtype=float)
            return np.average(points, axis=0, weights=weights)
        early_center, late_center = centroid(early), centroid(late)
        vector = late_center - early_center
        norm = float(np.linalg.norm(vector))
        if norm <= 1e-9:
            return None, 0.0, True
        unit = vector / norm
        times = np.asarray([x[1] for x in usable], dtype=float)
        projections = np.asarray([
            np.dot(unit, np.asarray([self.node_positions[x[0]]['x'], self.node_positions[x[0]]['y']]))
            for x in usable
        ], dtype=float)
        if np.std(times) <= 1e-9 or np.std(projections) <= 1e-9:
            monotonicity = 0.0
        else:
            monotonicity = float(np.corrcoef(times, projections)[0, 1])
            if not np.isfinite(monotonicity):
                monotonicity = 0.0
        min_disp = float(getattr(config, 'ALERT_DIRECTION_MIN_DISPLACEMENT', 2.0))
        min_mono = float(getattr(config, 'ALERT_DIRECTION_MIN_MONOTONICITY', 0.6))
        confidence = min(1.0, norm / max(min_disp, 1e-9)) * max(0.0, monotonicity)
        conflict = norm < min_disp or monotonicity < min_mono
        component.setdefault('direction_history', []).append(tuple(unit.tolist()))
        return unit, confidence, conflict

    def _shortest_comm_path(self, source, target, max_hops):
        parents = {source: None}
        queue = [source]
        for current in queue:
            depth = 0
            cursor = current
            while parents[cursor] is not None:
                depth += 1
                cursor = parents[cursor]
            if depth >= max_hops:
                continue
            for neighbor in self.get_comm_neighbors(current):
                if neighbor in parents:
                    continue
                parents[neighbor] = current
                if neighbor == target:
                    path = [target]
                    while path[-1] != source:
                        path.append(parents[path[-1]])
                    return list(reversed(path))
                queue.append(neighbor)
        return None

    def _directional_targets_and_routes(self, event, source_id, component_id):
        candidates = [nid for nid in self.get_neighbors(source_id) if nid not in event['alerted_nodes']]
        direction, confidence, conflict = self._direction_diagnostics(event, component_id)
        source_pos = self.node_positions.get(source_id)
        scored = []
        for target_id in candidates:
            target_pos = self.node_positions.get(target_id)
            if source_pos is None or target_pos is None:
                continue
            delta = np.asarray([target_pos['x'] - source_pos['x'], target_pos['y'] - source_pos['y']], dtype=float)
            norm = float(np.linalg.norm(delta))
            directional = 0.5 if direction is None or norm <= 1e-9 else max(0.0, float(np.dot(direction, delta / norm)))
            uncertainty = float((self.nodes[target_id].H @ self.nodes[target_id].P @ self.nodes[target_id].H.T)[0, 0])
            score = 0.75 * directional + 0.25 * min(1.0, uncertainty / max(1e-9, float(config.GAMMA)))
            scored.append((score, -target_id, target_id))
        scored.sort(reverse=True)
        top_m = max(1, int(getattr(config, 'ALERT_DIRECTION_TOP_M', 4)))
        targets, edges = set(), set()
        max_route = max(1, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
        if conflict:
            self.event_relay_stats['direction_fallback_relay_count'] += 1
            self.event_relay_stats['direction_conflict_count'] += 1
            chosen_ids = [x[2] for x in scored]
        else:
            self.event_relay_stats['direction_confident_relay_count'] += 1
            directional_ids = [x[2] for x in scored[:top_m]]
            safe_count = max(0, int(getattr(config, 'ALERT_DIRECTION_SAFE_LOCAL_COUNT', 2)))
            local_ids = sorted(candidates, key=lambda nid: (-len(self.get_neighbors(nid)), nid))[:safe_count]
            chosen_ids = list(dict.fromkeys(directional_ids + local_ids))
        for target_id in chosen_ids:
            path = self._shortest_comm_path(source_id, target_id, max_route)
            if path is None:
                continue
            targets.add(target_id)
            edges.update(zip(path[:-1], path[1:]))
        return targets, sorted(edges), (not conflict), confidence

    def _radial_frontier_targets_and_routes(self, event, source_id, component_id):
        component = event.get('components', {}).get(component_id, {})
        origin_id = component.get('source_id', component_id)
        origin = self.node_positions.get(origin_id)
        source = self.node_positions.get(source_id)
        if origin is None or source is None:
            return set(), []
        source_radius = float(np.hypot(source['x'] - origin['x'], source['y'] - origin['y']))
        scored = []
        for target_id in self.get_neighbors(source_id):
            if target_id in event['alerted_nodes'] or target_id not in self.node_positions:
                continue
            target = self.node_positions[target_id]
            target_radius = float(np.hypot(target['x'] - origin['x'], target['y'] - origin['y']))
            outward_gain = target_radius - source_radius
            if outward_gain < -1e-9:
                continue
            uncertainty = float((self.nodes[target_id].H @ self.nodes[target_id].P @ self.nodes[target_id].H.T)[0, 0])
            scored.append((outward_gain + 0.1 * uncertainty, -target_id, target_id))
        scored.sort(reverse=True)
        top_m = max(1, int(getattr(config, 'ALERT_RADIAL_TOP_M', 5)))
        targets, edges = set(), set()
        max_route = max(1, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
        for _, _, target_id in scored[:top_m]:
            path = self._shortest_comm_path(source_id, target_id, max_route)
            if path:
                targets.add(target_id)
                edges.update(zip(path[:-1], path[1:]))
        return targets, sorted(edges)

    def _classify_event_geometry(self, event, component_id):
        component = event.get('components', {}).get(component_id, {})
        records = component.get('confirmed_records', {})
        if len(event.get('components', {})) > 1:
            return 'multi_source', 1.0
        minimum = max(3, int(getattr(config, 'ALERT_DIRECTION_MIN_CONFIRMATIONS', 3)))
        usable = [(nid, rec[0]) for nid, rec in records.items() if nid in self.node_positions]
        if len(usable) < minimum:
            return 'uncertain', 0.0
        origin_id = component.get('source_id', component_id)
        origin = self.node_positions.get(origin_id)
        if origin is not None:
            times = np.asarray([x[1] for x in usable], dtype=float)
            radii = np.asarray([
                np.hypot(self.node_positions[x[0]]['x'] - origin['x'], self.node_positions[x[0]]['y'] - origin['y'])
                for x in usable
            ], dtype=float)
            if np.std(times) > 1e-9 and np.std(radii) > 1e-9:
                radial_corr = float(np.corrcoef(times, radii)[0, 1])
                if np.isfinite(radial_corr) and radial_corr >= float(getattr(config, 'ALERT_GEOBOUND_RADIAL_CORRELATION', 0.5)):
                    return 'radial', radial_corr
        _, direction_confidence, conflict = self._direction_diagnostics(event, component_id)
        threshold = float(getattr(config, 'ALERT_GEOBOUND_MIN_GEOMETRY_CONFIDENCE', 0.6))
        if not conflict and direction_confidence >= threshold:
            return 'directional', direction_confidence
        return 'uncertain', max(0.0, direction_confidence)

    def _budget_paths(self, source_id, target_ids, score_by_target, budget):
        chosen, edges, spent = set(), set(), 0
        max_route = max(1, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
        ranked = sorted(target_ids, key=lambda nid: (-score_by_target.get(nid, 0.0), nid))
        for target_id in ranked:
            path = self._shortest_comm_path(source_id, target_id, max_route)
            if not path:
                continue
            new_edges = set(zip(path[:-1], path[1:])) - edges
            if spent + len(new_edges) > budget:
                continue
            edges.update(new_edges)
            spent += len(new_edges)
            chosen.add(target_id)
        return chosen, sorted(edges)

    def _geobound_targets_and_routes(self, event, source_id, component_id):
        geometry, confidence = self._classify_event_geometry(event, component_id)
        budget = max(1, int(getattr(config, 'ALERT_GEOBOUND_MESSAGE_BUDGET', 20)))
        if geometry == 'radial':
            self.event_relay_stats['geometry_radial_count'] += 1
            raw_targets, _ = self._radial_frontier_targets_and_routes(event, source_id, component_id)
            scores = {nid: 1.0 for nid in raw_targets}
        elif geometry == 'directional':
            self.event_relay_stats['geometry_directional_count'] += 1
            raw_targets, _, _, _ = self._directional_targets_and_routes(event, source_id, component_id)
            scores = {nid: 1.0 for nid in raw_targets}
        elif geometry == 'multi_source':
            self.event_relay_stats['geometry_multisource_count'] += 1
            raw_targets = {
                nid for nid in self.get_neighbors(source_id)
                if nid not in event['alerted_nodes']
            }
            scores = {nid: 1.0 for nid in raw_targets}
        else:
            self.event_relay_stats['geometry_fallback_count'] += 1
            raw_targets, _, _ = self._resolve_alert_routes(source_id, dynamic_max_hops=2)
            raw_targets = {nid for nid in raw_targets if nid not in event['alerted_nodes']}
            scores = {}
            for nid in raw_targets:
                uncertainty = float((self.nodes[nid].H @ self.nodes[nid].P @ self.nodes[nid].H.T)[0, 0])
                scores[nid] = 0.5 + 0.5 * min(1.0, uncertainty / max(1e-9, float(config.GAMMA)))
        targets, edges = self._budget_paths(source_id, raw_targets, scores, budget)
        return targets, edges, geometry, confidence

    def _learned_candidate_features(self, event, source_id, target_id, path, component_id, depth):
        source_pos = self.node_positions.get(source_id, {})
        target_pos = self.node_positions.get(target_id, {})
        def distance(a, b):
            if not a or not b:
                return 0.0
            return float(np.hypot(float(a['x']) - float(b['x']), float(a['y']) - float(b['y'])))
        confirmed = [nid for nid in event.get('confirmed_nodes', set()) if nid in self.node_positions]
        confirmed_distances = [distance(target_pos, self.node_positions[nid]) for nid in confirmed]
        if confirmed:
            centroid = {
                'x': float(np.mean([self.node_positions[n]['x'] for n in confirmed])),
                'y': float(np.mean([self.node_positions[n]['y'] for n in confirmed])),
            }
        else:
            centroid = source_pos
        node = self.nodes[target_id]
        uncertainty = float((node.H @ node.P @ node.H.T)[0, 0])
        signed = float(node.last_signed_norm_innovation) if np.isfinite(node.last_signed_norm_innovation) else 0.0
        nis = float(node.last_nis) if np.isfinite(node.last_nis) else 0.0
        glr = max(float(getattr(node, 'glr_stat_up', 0.0)), float(getattr(node, 'glr_stat_down', 0.0)))
        event_sign = int(event.get('sign', 0))
        candidate_sign = 1 if signed > 0 else (-1 if signed < 0 else 0)
        tx = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
        rx = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
        hops = max(1, len(path) - 1)
        return {
            'comm_hops': hops, 'path_energy_mj': hops * (tx + rx),
            'spatial_distance_source': distance(source_pos, target_pos),
            'spatial_distance_confirmed_min': min(confirmed_distances) if confirmed_distances else 0.0,
            'spatial_distance_confirmed_mean': float(np.mean(confirmed_distances)) if confirmed_distances else 0.0,
            'distance_event_centroid': distance(target_pos, centroid),
            'uncertainty': uncertainty, 'abs_signed_innovation': abs(signed), 'nis': nis,
            'glr_strength': glr,
            'sign_consistency': float(event_sign == candidate_sign) if event_sign and candidate_sign else 0.5,
            'comm_degree': len(self.get_neighbors(target_id)),
            'spatial_degree': len(self.adjacency.get(target_id, [])),
            # Deployable proxy for historical false wake-up: no ground-truth
            # label is consulted online; only failed local verifications count.
            'already_false_woken': int(getattr(node, 'failed_verification_count', 0)),
            'event_age': max(0, self.step_index - event.get('created_step', self.step_index)),
            'confirmed_count': len(confirmed), 'source_depth': int(depth),
        }

    def _oracle_candidate_labels(self, target_id):
        """Return affected/front/arrival labels using future truth (upper bound only)."""
        horizon = max(1, int(getattr(config, 'ALERT_LEARNED_LABEL_HORIZON_STEPS', 20)))
        flags = []
        for offset in range(horizon + 1):
            future_time = self.current_time + offset * self.time_step
            _, affected, _ = self.anomaly_injector.get_injected_value(
                0.0, future_time, target_id, self.time_step,
                node_positions=self.node_positions, spatial_adjacency=self.adjacency,
                communication_adjacency=self.communication_adjacency
            )
            flags.append(bool(affected))
        arrival = next((i for i, flag in enumerate(flags) if flag), -1)
        affected = int(arrival >= 0)
        future_front = int(arrival > 0)
        return affected, future_front, arrival

    def _spatial_shell(self, anchors, max_hops):
        visited = {int(n): 0 for n in anchors if n in self.nodes}
        frontier = list(visited)
        while frontier:
            node_id = frontier.pop(0)
            if visited[node_id] >= max_hops:
                continue
            for neighbor in self.adjacency.get(node_id, []):
                if neighbor not in visited:
                    visited[neighbor] = visited[node_id] + 1
                    frontier.append(neighbor)
        return {nid for nid, hop in visited.items() if hop > 0}

    def _spatial_distance_to_set(self, source_id, targets):
        """Unweighted spatial-graph distance from a node to the nearest target."""
        targets = {int(n) for n in targets if n in self.nodes}
        if not targets:
            return np.inf
        source_id = int(source_id)
        if source_id in targets:
            return 0.0
        visited = {source_id}
        frontier = [(source_id, 0)]
        while frontier:
            node_id, depth = frontier.pop(0)
            for neighbor in self.adjacency.get(node_id, []):
                if neighbor in targets:
                    return float(depth + 1)
                if neighbor not in visited:
                    visited.add(neighbor)
                    frontier.append((neighbor, depth + 1))
        return np.inf

    def _confirmed_region_speed(self, event):
        """Estimate radial expansion in spatial-graph hops per simulation step."""
        records = event.get('confirmed_records', {})
        if len(records) < 2:
            return 0.05
        origin_id, origin_record = min(
            records.items(), key=lambda item: (int(item[1][0]), int(item[0]))
        )
        origin_step = int(origin_record[0])
        speeds = []
        for node_id, record in records.items():
            elapsed = int(record[0]) - origin_step
            if elapsed <= 0 or int(node_id) == int(origin_id):
                continue
            distance = self._spatial_distance_to_set(int(node_id), {int(origin_id)})
            if np.isfinite(distance) and distance > 0:
                speeds.append(float(distance) / float(elapsed))
        return max(0.05, float(np.median(speeds))) if speeds else 0.05

    def _failed_node_snapshot(self, event, node_id):
        node = self.nodes[int(node_id)]
        prior = event.get('failed_node_snapshots', {}).get(int(node_id), {})
        signed = float(getattr(node, 'last_signed_norm_innovation', 0.0) or 0.0)
        nis = float(getattr(node, 'last_nis', 0.0) or 0.0)
        glr = max(float(getattr(node, 'glr_stat_up', 0.0) or 0.0),
                  float(getattr(node, 'glr_stat_down', 0.0) or 0.0))
        uncertainty = float((node.H @ node.P @ node.H.T)[0, 0]) if node.P is not None else 0.0
        return {
            'step': int(self.step_index),
            'failure_count': int(prior.get('failure_count', 0)) + 1,
            'confirmed_distance': self._spatial_distance_to_set(node_id, event.get('confirmed_nodes', set())),
            'confirmed_nodes': tuple(sorted(int(nid) for nid in event.get('confirmed_nodes', set()))),
            'confirmed_version': int(len(event.get('confirmed_records', {}))),
            'abs_innovation': abs(signed), 'nis': nis, 'glr': glr, 'uncertainty': uncertainty,
        }

    def _frontier_anchor_routes(self, event, source_id, max_hops, ordinary_targets, ordinary_hops):
        """Add only retained failures reachable from the moving confirmed frontier."""
        targets = set(ordinary_targets)
        hop_map = dict(ordinary_hops)
        route_anchor = {int(nid): int(source_id) for nid in targets}
        confirmed = set(int(nid) for nid in event.get('confirmed_nodes', set())) | {int(source_id)}
        frontier = {
            anchor for anchor in confirmed
            if any(
                int(neighbor) not in confirmed and self.nodes[int(neighbor)].role != 'sentinel'
                for neighbor in self._get_alert_neighbors(anchor)
            )
        }
        if not frontier:
            frontier = {int(source_id)}
        retained = set(int(nid) for nid in event.get('failed_verification_nodes', set())) - confirmed
        for target_id in sorted(retained):
            if target_id in targets or target_id not in self.nodes or self.nodes[target_id].role == 'sentinel':
                continue
            routes = []
            for anchor in sorted(frontier):
                path = self._shortest_comm_path(anchor, target_id, max_hops)
                if path:
                    routes.append((len(path) - 1, int(anchor), path))
            if not routes:
                continue
            path_hops, anchor, _ = min(routes, key=lambda item: (item[0], item[1]))
            targets.add(target_id)
            hop_map[target_id] = int(path_hops)
            route_anchor[target_id] = int(anchor)
        return targets, hop_map, route_anchor, frontier

    def _failed_cooldown_released_by_front(self, event, target_id, snapshot, confirmed_now):
        if not bool(getattr(config, 'ALERT_FRONT_TRIGGERED_RECONSIDERATION_ENABLED', False)):
            return False, False, False
        if int(target_id) not in event.get('failed_verification_nodes', set()) or not snapshot:
            return False, False, False
        refractory = max(1, int(getattr(
            config, 'ALERT_FRONT_TRIGGERED_RECONSIDERATION_MIN_REFRACTORY_STEPS', 2
        )))
        failed_step = int(snapshot.get('step', -10**9))
        if int(self.step_index) - failed_step < refractory:
            return False, False, False
        distance_at_failure = float(snapshot.get('confirmed_distance', np.inf))
        distance_now = self._spatial_distance_to_set(int(target_id), set(confirmed_now))
        closer = bool(
            np.isfinite(distance_at_failure) and np.isfinite(distance_now)
            and float(distance_now) < float(distance_at_failure)
        )
        confirmed_at_failure = set(int(nid) for nid in snapshot.get('confirmed_nodes', ()))
        new_confirmed = set(int(nid) for nid in confirmed_now) - confirmed_at_failure
        monitor_neighbors = set(int(nid) for nid in self._get_alert_monitor_neighbors(int(target_id)))
        new_neighbor = bool(new_confirmed & monitor_neighbors)
        return bool(closer or new_neighbor), closer, new_neighbor

    def _candidate_pool(self, event, source_id):
        """Generate spatial/communication candidates independently of scoring."""
        generator = str(getattr(config, 'ALERT_CANDIDATE_GENERATOR', 'current')).strip().lower()
        comm_hops = max(1, int(getattr(config, 'ALERT_LEARNED_CANDIDATE_MAX_HOPS', 4)))
        anchors = set(event.get('confirmed_nodes', set())) or {source_id}
        if generator in {'current', 'comm_hop'}:
            raw, _, _ = self._resolve_alert_routes(source_id, dynamic_max_hops=comm_hops)
        elif generator == 'confirmed_frontier':
            raw = set()
            for anchor in anchors:
                around, _, _ = self._resolve_alert_routes(anchor, dynamic_max_hops=comm_hops)
                raw.update(around)
        elif generator == 'spatial_frontier':
            spatial_hops = max(1, int(getattr(config, 'ALERT_CANDIDATE_SPATIAL_HOPS', 1)))
            raw = self._spatial_shell(anchors, spatial_hops)
        elif generator == 'hybrid':
            raw, _, _ = self._resolve_alert_routes(source_id, dynamic_max_hops=comm_hops)
            spatial_hops = max(1, int(getattr(config, 'ALERT_CANDIDATE_SPATIAL_HOPS', 1)))
            raw.update(self._spatial_shell(anchors, spatial_hops))
        else:
            raise ValueError('Unknown ALERT_CANDIDATE_GENERATOR: ' + generator)
        raw.discard(source_id)
        previously_alerted = raw & set(event.get('alerted_nodes', set()))
        duplicates = set(previously_alerted)
        self.event_relay_stats['candidate_generated_count'] += len(raw)
        self.event_relay_stats['candidate_duplicate_count'] += len(duplicates)
        if not bool(getattr(config, 'ALERT_EVENT_REALERT_ENABLED', False)):
            return raw - previously_alerted
        cooldown = max(1, int(getattr(config, 'ALERT_EVENT_REALERT_COOLDOWN_STEPS', 4)))
        blocked = set()
        for nid in previously_alerted:
            last = event.get('last_alert_step', {}).get(nid, -10**9)
            node = self.nodes.get(nid)
            snapshot = event.get('failed_node_snapshots', {}).get(int(nid), {})
            failed_at = int(snapshot.get('step', -10**9))
            failed_cooldown = max(1, int(getattr(
                config, 'ALERT_CONFIRMATION_REALERT_PROBE_COOLDOWN_STEPS', 8
            )))
            if (
                self.step_index - last < cooldown
                or (snapshot and self.step_index - failed_at < failed_cooldown)
                or (node is not None and node.mode in ('alert', 'probe'))
            ):
                blocked.add(nid)
        return raw - blocked

    def _confirmation_realert_targets_and_routes(self, event, source_id):
        allow_source_repeat = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_ALLOW_SOURCE_REPEAT', False))
        source_cooldown = max(1, int(getattr(config, 'ALERT_EVENT_REQUERY_COOLDOWN_STEPS', 2)))
        last_source_step = int(event.setdefault('realert_source_last_step', {}).get(int(source_id), -10**9))
        if source_id in event.get('realerted_sources', set()) and (
            not allow_source_repeat or self.step_index - last_source_step < source_cooldown
        ):
            return set(), [], {source_id: 0}
        ranking_mode = str(getattr(config, 'ALERT_CONFIRMATION_REALERT_RANKING_MODE', 'full')).strip().lower()
        if ranking_mode == 'periodic':
            period = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PERIOD_STEPS', 4)))
            if int(self.step_index) % period != 0:
                return set(), [], {source_id: 0}
        if bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_FRONTIER_ONLY', False)):
            if all(nid in event.get('confirmed_nodes', set()) for nid in self._get_alert_neighbors(source_id)):
                return set(), [], {source_id: 0}
        max_hops = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_MAX_HOPS', 1)))
        confirmed_neighbors = set(event.get('confirmed_nodes', set()))
        decision_confirmed_neighbors = confirmed_neighbors | {int(source_id)}
        route_targets, forwarding_edges, hop_map = self._resolve_alert_routes(source_id, dynamic_max_hops=max_hops)
        route_anchor_by_target = {int(nid): int(source_id) for nid in route_targets}
        frontier_anchors = {int(source_id)}
        if bool(getattr(config, 'ALERT_FRONTIER_ANCHORED_RETAINED_SCOPE_ENABLED', False)):
            route_targets, hop_map, route_anchor_by_target, frontier_anchors = self._frontier_anchor_routes(
                event, source_id, max_hops, route_targets, hop_map
            )
        trace_enabled = bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False))
        if trace_enabled:
            route_target_set = set(route_targets)
            alerted_nodes = set(event.get('alerted_nodes', set()))
            failed_nodes = set(event.get('failed_verification_nodes', set()))
            for potential_id in sorted(self.nodes):
                if int(potential_id) == int(source_id):
                    reason = 'source'
                elif self.nodes[int(potential_id)].role == 'sentinel':
                    reason = 'sentinel_excluded'
                elif int(potential_id) in confirmed_neighbors:
                    reason = 'already_confirmed'
                elif int(potential_id) in route_target_set:
                    reason = ''
                else:
                    reason = 'no_communication_route_within_response_scope'
                route_anchor = int(route_anchor_by_target.get(int(potential_id), source_id))
                route_exists = bool(self._shortest_comm_path(route_anchor, potential_id, max_hops))
                self.realert_decision_context_records.append({
                    'step': int(self.step_index), 'time': self.current_time,
                    'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                    'configured_response_hops': int(max_hops), 'response_graph': 'communication',
                    'potential_target_id': int(potential_id),
                    'within_response_scope': int(potential_id in route_target_set),
                    'communication_route_exists': int(route_exists),
                    'generated_by_runtime_route_resolution': int(potential_id in route_target_set),
                    'candidate_generated_pre_cooldown': int(
                        potential_id in route_target_set and potential_id not in confirmed_neighbors
                    ),
                    'previously_alerted': int(potential_id in alerted_nodes),
                    'retained_negative_record_exists': int(potential_id in failed_nodes),
                    'route_anchor_id': route_anchor,
                    'frontier_anchored_scope': int(
                        potential_id in route_target_set and route_anchor != int(source_id)
                    ),
                    'exclusion_reason': reason,
                })
        cooldown = max(1, int(getattr(config, 'ALERT_EVENT_REALERT_COOLDOWN_STEPS', 4)))
        ap_enabled = bool(getattr(config, 'AP_DFREALERT_ENABLED', False))
        if ap_enabled and self._ap_dfrealert_policy is None:
            from src.ap_dfrealert import APDFReAlertPolicy, FrontLikelihoodModel
            self._ap_dfrealert_policy = APDFReAlertPolicy(
                min_candidates=int(getattr(config, 'AP_DFREALERT_MIN_CANDIDATES', 3)),
                max_candidates=int(getattr(config, 'AP_DFREALERT_MAX_CANDIDATES', 8)),
                min_probe_steps=int(getattr(config, 'AP_DFREALERT_MIN_PROBE_STEPS', 1)),
                max_probe_steps=int(getattr(config, 'AP_DFREALERT_MAX_PROBE_STEPS', 5)),
                min_cooldown_steps=int(getattr(config, 'AP_DFREALERT_MIN_COOLDOWN_STEPS', 1)),
                max_cooldown_steps=int(getattr(config, 'AP_DFREALERT_MAX_COOLDOWN_STEPS', 20)),
                probability_threshold=float(getattr(config, 'AP_DFREALERT_PROBABILITY_THRESHOLD', 0.35)),
            )
            model_path = str(getattr(config, 'AP_DFREALERT_MODEL_PATH', ''))
            if model_path and os.path.exists(model_path):
                self._ap_dfrealert_model = FrontLikelihoodModel.load(model_path)
        candidates = []
        require_evidence = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_REQUIRE_EVIDENCE', False))
        uncertainty_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_UNCERTAINTY_FACTOR', 0.8)) * float(config.GAMMA)
        innovation_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_INNOVATION_THRESHOLD', 1.0))
        false_penalty = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_FALSE_PENALTY', 1.0))
        strict_false_gate = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_STRICT_FALSE_GATE', False))
        require_new_confirmed = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_REQUIRE_NEW_CONFIRMED_NEIGHBOR', False))
        false_gate_mode = str(getattr(config, 'ALERT_CONFIRMATION_REALERT_FALSE_GATE_MODE', 'any')).strip().lower()
        strong_innovation_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_STRONG_INNOVATION_THRESHOLD', 2.0))
        weak_innovation_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_WEAK_INNOVATION_THRESHOLD', 1.0))
        weak_nis_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_WEAK_NIS_THRESHOLD', 2.0))
        weak_uncertainty_gate = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_WEAK_UNCERTAINTY_FACTOR', 0.5)) * float(config.GAMMA)
        approach_min_delta = max(0, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_FRONT_APPROACH_MIN_DELTA', 1)))
        evidence_trend_enabled = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_EVIDENCE_TREND_ENABLED', False))
        approach_weight = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_APPROACH_SCORE_WEIGHT', 3.0))
        close_bonus = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_CLOSE_FRONTIER_BONUS', 1.5))
        close_distance = max(0, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_CLOSE_FRONTIER_DISTANCE', 1)))
        trend_bonus = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_EVIDENCE_TREND_BONUS', 1.0))
        repeat_fail_penalty = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_REPEATED_FAIL_PENALTY', 1.0))
        weak_evidence_bonus = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_WEAK_EVIDENCE_BONUS', 1.0))
        extra_hop_penalty = float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PREVIOUS_FALSE_EXTRA_HOP_PENALTY', 0.0))
        funnel_pending = {}
        for target_id in route_targets:
            if target_id == source_id or target_id in confirmed_neighbors:
                continue
            node = self.nodes.get(target_id)
            if node is None:
                continue
            if target_id in event.get('alerted_nodes', set()):
                last = event.get('last_alert_step', {}).get(target_id, -10**9)
                node_cooldown = cooldown
                snapshot = event.get('failed_node_snapshots', {}).get(int(target_id), {})
                failed_at = int(snapshot.get('step', -10**9))
                failed_cooldown = max(1, int(getattr(
                    config, 'ALERT_CONFIRMATION_REALERT_PROBE_COOLDOWN_STEPS', 8
                )))
                release_failed, release_closer, release_new_neighbor = self._failed_cooldown_released_by_front(
                    event, target_id, snapshot, decision_confirmed_neighbors
                )
                blocked_event = bool(self.step_index - last < node_cooldown)
                blocked_failed = bool(
                    snapshot and self.step_index - failed_at < failed_cooldown and not release_failed
                )
                blocked_active = bool(node.mode in ('alert', 'probe'))
                if ap_enabled:
                    distance_for_cooldown = float(snapshot.get('confirmed_distance', 1.0))
                    speed_for_cooldown = self._confirmed_region_speed(event)
                    node_cooldown = self._ap_dfrealert_policy.decide(
                        0.0, distance_for_cooldown, speed_for_cooldown,
                    failure_count=int(snapshot.get('failure_count', 0)),
                    ).cooldown_steps
                    blocked_event = bool(self.step_index - last < node_cooldown)
                if blocked_event or blocked_failed or blocked_active:
                    self.event_relay_stats['cooldown_suppression_count'] += 1
                    if trace_enabled:
                        reasons = []
                        if blocked_event:
                            reasons.append('event_cooldown')
                        if blocked_failed:
                            reasons.append('failed_probe_cooldown')
                        if blocked_active:
                            reasons.append('active_alert_or_probe')
                        self.realert_funnel_records.append({
                            'step': int(self.step_index), 'time': self.current_time,
                            'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                            'target_id': int(target_id), 'within_response_scope': 1,
                            'communication_route_exists': int(bool(self._shortest_comm_path(source_id, target_id, max_hops))),
                            'candidate_generated_pre_cooldown': 1, 'previously_alerted': 1,
                            'retained_negative_record_exists': int(target_id in event.get('failed_verification_nodes', set())),
                            'blocked_by_event_cooldown': int(blocked_event),
                            'blocked_by_failed_probe_cooldown': int(blocked_failed),
                            'blocked_by_active_alert_or_probe': int(blocked_active),
                            'eligible_after_cooldown': 0, 'entered_rank_pool': 0, 'rank_position': '',
                            'selected_by_top_k': 0, 'entered_probe': 0, 'entered_full_alert': 0,
                            'probe_upgraded': 0, 'verification_confirmed': 0, 'timely_verification': 0,
                            'useful_front_observation': 0, 'suppression_reason': ';'.join(reasons),
                            'path_hops': int(hop_map.get(target_id, max_hops)), 'ranking_mode': ranking_mode,
                            'route_anchor_id': int(route_anchor_by_target.get(int(target_id), source_id)),
                            'front_triggered_reconsideration_released': int(release_failed),
                            'release_by_closer_confirmed_distance': int(release_closer),
                            'release_by_new_confirmed_neighbor': int(release_new_neighbor),
                        })
                    continue
            path_hops = max(1, int(hop_map.get(target_id, max_hops)))
            uncertainty = float((node.H @ node.P @ node.H.T)[0, 0]) if node.P is not None else 0.0
            signed_innovation = float(getattr(node, 'last_signed_norm_innovation', 0.0) or 0.0)
            nis_val = float(getattr(node, 'last_nis', 0.0) or 0.0)
            high_uncertainty = int(np.isfinite(uncertainty) and uncertainty >= uncertainty_gate)
            high_innovation = int(np.isfinite(signed_innovation) and abs(signed_innovation) >= innovation_gate)
            strong_innovation = int(np.isfinite(signed_innovation) and abs(signed_innovation) >= strong_innovation_gate)
            weak_local_evidence = int(
                (np.isfinite(signed_innovation) and abs(signed_innovation) >= weak_innovation_gate)
                or (np.isfinite(nis_val) and nis_val >= weak_nis_gate)
                or (np.isfinite(uncertainty) and uncertainty >= weak_uncertainty_gate)
            )
            neighbor_ids = set(self._get_alert_monitor_neighbors(target_id))
            near_confirmed = int(any(nid in confirmed_neighbors for nid in neighbor_ids))
            previous_false = int(target_id in event.get('failed_verification_nodes', set()))
            fail_snapshot = event.get('failed_node_snapshots', {}).get(int(target_id), {})
            distance_at_fail = float(fail_snapshot.get('confirmed_distance', np.inf))
            ranking_confirmed = (
                decision_confirmed_neighbors
                if ranking_mode == 'nearest_confirmed_lexicographic' else confirmed_neighbors
            )
            distance_now = self._spatial_distance_to_set(target_id, ranking_confirmed)
            if previous_false and not (
                np.isfinite(distance_at_fail) and np.isfinite(distance_now)
            ):
                # The confirmed-region approach term has no mathematical value
                # across disconnected components or without a failure snapshot.
                # Such retained records are outside the locked selector domain.
                if trace_enabled:
                    self.realert_funnel_records.append({
                        'step': int(self.step_index), 'time': self.current_time,
                        'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                        'target_id': int(target_id), 'within_response_scope': 1,
                        'communication_route_exists': 1, 'candidate_generated_pre_cooldown': 1,
                        'previously_alerted': 1, 'retained_negative_record_exists': 1,
                        'blocked_by_event_cooldown': 0, 'blocked_by_failed_probe_cooldown': 0,
                        'blocked_by_active_alert_or_probe': 0, 'eligible_after_cooldown': 1,
                        'entered_rank_pool': 0, 'rank_position': '', 'selected_by_top_k': 0,
                        'entered_probe': 0, 'entered_full_alert': 0, 'probe_upgraded': 0,
                        'verification_confirmed': 0, 'timely_verification': 0,
                        'useful_front_observation': 0,
                        'suppression_reason': 'retained_record_disconnected_from_confirmed_region',
                        'path_hops': int(path_hops), 'ranking_mode': ranking_mode,
                    })
                continue
            distance_delta = distance_at_fail - distance_now
            front_approaching = int(np.isfinite(distance_delta) and distance_delta >= approach_min_delta)
            approach_score = float(np.clip(distance_delta / max(distance_at_fail, 1.0), 0.0, 1.0)) if np.isfinite(distance_delta) else 0.0
            close_to_frontier = int(np.isfinite(distance_now) and distance_now <= close_distance)
            glr_val = max(float(getattr(node, 'glr_stat_up', 0.0) or 0.0), float(getattr(node, 'glr_stat_down', 0.0) or 0.0))
            evidence_increasing = int(
                abs(signed_innovation) > float(fail_snapshot.get('abs_innovation', np.inf))
                or nis_val > float(fail_snapshot.get('nis', np.inf))
                or glr_val > float(fail_snapshot.get('glr', np.inf))
                or uncertainty > float(fail_snapshot.get('uncertainty', np.inf))
            )
            delayed_front_weak_evidence = int(weak_local_evidence and (evidence_increasing or not evidence_trend_enabled))
            node_prior_failed = int(previous_false)
            fail_step = int(fail_snapshot.get('step', self.step_index))
            steps_since_failure = max(0, int(self.step_index) - fail_step)
            # Speed uses observed spatial-graph expansion, never future labels.
            front_speed = self._confirmed_region_speed(event)
            failure_count = int(fail_snapshot.get('failure_count', 1 if previous_false else 0))
            probe_horizon = max(1, int(getattr(
                config, 'ALERT_CONFIRMATION_REALERT_PROBE_STEPS', 3
            )))
            eta_remaining = (
                float(distance_now) / max(float(front_speed), 0.05)
                if np.isfinite(distance_now) else np.inf
            )
            temporal_compatibility = (
                float(np.exp(-abs(eta_remaining - probe_horizon) / probe_horizon))
                if np.isfinite(eta_remaining) else 0.0
            )
            eta_from_failure = (
                float(distance_at_fail) / max(float(front_speed), 0.05)
                if np.isfinite(distance_at_fail) else np.inf
            )
            failure_time_compatibility = (
                float(np.exp(-abs(eta_from_failure - steps_since_failure) / probe_horizon))
                if np.isfinite(eta_from_failure) else 0.0
            )
            history_compatibility = 0.5 * (
                float(weak_local_evidence) + float(evidence_increasing)
            )
            temporal_spatial_compatibility = temporal_compatibility * (
                1.0 + approach_score
            ) / 2.0
            dfo_compatibility_score = temporal_compatibility * (
                1.0 + approach_score + history_compatibility
            ) / 3.0
            dfo_failure_compatibility_score = failure_time_compatibility * (
                1.0 + approach_score + history_compatibility
            ) / 3.0
            ap_features = {
                'approach_score': approach_score, 'distance_now': distance_now if np.isfinite(distance_now) else 1e3,
                'distance_delta': distance_delta if np.isfinite(distance_delta) else 0.0,
                'front_speed': front_speed, 'local_evidence': max(abs(signed_innovation), np.sqrt(max(0.0, nis_val))),
                'probe_evidence': glr_val, 'route_cost': float(path_hops),
                'failure_count': failure_count, 'steps_since_failure': steps_since_failure,
                'eta_remaining_steps': eta_remaining if np.isfinite(eta_remaining) else 1e3,
                'eta_from_failure_steps': eta_from_failure if np.isfinite(eta_from_failure) else 1e3,
                'temporal_compatibility': temporal_compatibility,
                'failure_time_compatibility': failure_time_compatibility,
                'history_compatibility': history_compatibility,
                'temporal_spatial_compatibility': temporal_spatial_compatibility,
                'dfo_compatibility_score': dfo_compatibility_score,
                'dfo_failure_compatibility_score': dfo_failure_compatibility_score,
            }
            predicted_probability = np.nan
            ap_decision = None
            ap_eligible = bool(previous_false and np.isfinite(distance_at_fail))
            if ap_enabled and ap_eligible:
                # Collection mode deliberately has no learned model and ranks by
                # deployable approach score; future labels are added after the run.
                predicted_probability = (
                    self._ap_dfrealert_model.predict_proba(ap_features)
                    if self._ap_dfrealert_model is not None else (
                        1.0 if bool(getattr(config, 'AP_DFREALERT_COLLECT_ALL_ELIGIBLE', False)) else approach_score
                    )
                )
                energy_pressure = max(0.0, 1.0 - float(getattr(node, 'energy_ratio', 1.0)))
                ap_decision = self._ap_dfrealert_policy.decide(
                    predicted_probability, ap_features['distance_now'], front_speed,
                    uncertainty=min(1.0, uncertainty / max(float(config.GAMMA), 1e-9)),
                    candidate_density=min(1.0, len(route_targets) / max(1.0, len(self.nodes))),
                    energy_pressure=energy_pressure, failure_count=failure_count,
                )
            last_alert_step = int(event.get('last_alert_step', {}).get(target_id, -10**9))
            new_confirmed_neighbor = int(any(
                nid in confirmed_neighbors and int(event.get('confirmed_records', {}).get(int(nid), (-10**9, 0.0))[0]) > last_alert_step
                for nid in neighbor_ids
            ))
            gate_pass_reason = 'not_previous_false'
            gate_block_reason = ''
            if previous_false:
                self.event_relay_stats['previous_false_candidate_count'] += 1
                gate_pass_reason = ''
                if false_gate_mode in {'approach_score_soft'}:
                    gate_pass_reason = 'approach_score_soft_rank'
                elif false_gate_mode in {'front_approach', 'front_approach_weak', 'front_approach_hop2_strict', 'approach_score'}:
                    requires_weak = false_gate_mode != 'front_approach'
                    hop2_ok = false_gate_mode != 'front_approach_hop2_strict' or path_hops <= 1 or near_confirmed
                    if front_approaching and (not requires_weak or delayed_front_weak_evidence) and hop2_ok:
                        gate_pass_reason = 'front_approaching' + ('_and_weak_evidence' if requires_weak else '')
                    elif strict_false_gate:
                        gate_block_reason = 'previous_false_without_delayed_front_evidence'
                elif false_gate_mode == 'weak_and':
                    if new_confirmed_neighbor and weak_local_evidence:
                        gate_pass_reason = 'new_confirmed_neighbor_and_weak_evidence'
                    elif strict_false_gate:
                        gate_block_reason = 'previous_false_without_weak_and_evidence'
                elif false_gate_mode == 'all' or (false_gate_mode == 'hop_sensitive' and path_hops > 1):
                    if new_confirmed_neighbor and strong_innovation:
                        gate_pass_reason = 'new_confirmed_neighbor_and_strong_innovation'
                    elif strict_false_gate:
                        gate_block_reason = 'previous_false_without_joint_evidence'
                else:
                    if new_confirmed_neighbor:
                        gate_pass_reason = 'new_confirmed_neighbor'
                    elif strong_innovation:
                        gate_pass_reason = 'strong_innovation'
                    elif strict_false_gate:
                        gate_block_reason = 'previous_false_without_new_evidence'
                if gate_block_reason:
                    self.event_relay_stats['strict_gate_block_count'] += 1
                    if gate_block_reason == 'previous_false_without_delayed_front_evidence':
                        self.event_relay_stats['front_approach_block_count'] += 1
                    if gate_block_reason == 'previous_false_without_weak_and_evidence':
                        self.event_relay_stats['weakAND_block_count'] += 1
                    self.realert_target_records.append({
                        'time': self.current_time, 'step': int(self.step_index),
                        'event_id': int(event.get('event_id', 0)),
                        'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                        'target_id': int(target_id), 'event_age': int(self.step_index - event.get('created_step', self.step_index)),
                        'path_hops': int(path_hops), 'score': np.nan,
                        'previous_false_woken': int(previous_false), 'node_prior_failed_verification': int(node_prior_failed),
                        'high_uncertainty': int(high_uncertainty),
                        'high_abs_innovation': int(high_innovation), 'strong_innovation': int(strong_innovation),
                        'weak_local_evidence': int(weak_local_evidence),
                        'evidence_increasing': int(evidence_increasing), 'delayed_front_weak_evidence': int(delayed_front_weak_evidence),
                        'distance_at_fail': distance_at_fail, 'distance_now': distance_now,
                        'front_distance_delta': distance_delta, 'front_approaching': int(front_approaching),
                        'approach_score': approach_score, 'close_to_frontier': int(close_to_frontier),
                        'eta_remaining_steps': eta_remaining if np.isfinite(eta_remaining) else np.nan,
                        'eta_from_failure_steps': eta_from_failure if np.isfinite(eta_from_failure) else np.nan,
                        'temporal_compatibility': temporal_compatibility,
                        'failure_time_compatibility': failure_time_compatibility,
                        'history_compatibility': history_compatibility,
                        'temporal_spatial_compatibility': temporal_spatial_compatibility,
                        'dfo_compatibility_score': dfo_compatibility_score,
                        'dfo_failure_compatibility_score': dfo_failure_compatibility_score,
                        'near_confirmed': int(near_confirmed), 'new_confirmed_neighbor_since_fail': int(new_confirmed_neighbor),
                        'innovation_at_realert': float(signed_innovation), 'gate_pass_reason': gate_pass_reason,
                        'gate_block_reason': gate_block_reason, 'selected': 0, 'deferred_by_active_cap': 0,
                        'probe_upgraded': 0, 'probe_failed': 0, 'final_confirmed': 0,
                        'final_confirmed_by_probe_upgrade': 0, 'seed': int(getattr(config, 'RANDOM_SEED', 0)),
                        'true_event_ids_observed': ','.join(str(x) for x in sorted(set().union(*[
                            set(c.get('true_event_ids', set())) for c in event.get('components', {}).values()
                        ]))) if event.get('components') else '',
                    })
                    if trace_enabled:
                        self.realert_funnel_records.append({
                            'step': int(self.step_index), 'time': self.current_time,
                            'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                            'target_id': int(target_id), 'within_response_scope': 1,
                            'communication_route_exists': 1, 'candidate_generated_pre_cooldown': 1,
                            'previously_alerted': 1, 'retained_negative_record_exists': 1,
                            'blocked_by_event_cooldown': 0, 'blocked_by_failed_probe_cooldown': 0,
                            'blocked_by_active_alert_or_probe': 0, 'eligible_after_cooldown': 1,
                            'entered_rank_pool': 0, 'rank_position': '', 'selected_by_top_k': 0,
                            'entered_probe': 0, 'entered_full_alert': 0, 'probe_upgraded': 0,
                            'verification_confirmed': 0, 'timely_verification': 0,
                            'useful_front_observation': 0, 'suppression_reason': gate_block_reason,
                            'path_hops': int(path_hops), 'ranking_mode': ranking_mode,
                            'normalized_innovation': float(signed_innovation), 'nis': float(nis_val),
                            'glr': float(glr_val), 'uncertainty': float(uncertainty),
                            'weak_evidence': int(weak_local_evidence), 'failure_count': int(failure_count),
                        })
                    continue
                elif require_new_confirmed:
                    gate_block_reason = 'previous_false_without_new_confirmed_neighbor'
                    self.event_relay_stats['strict_gate_block_count'] += 1
                    continue
            if require_evidence and not (near_confirmed or high_uncertainty or high_innovation):
                if trace_enabled:
                    self.realert_funnel_records.append({
                        'step': int(self.step_index), 'time': self.current_time,
                        'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                        'target_id': int(target_id), 'within_response_scope': 1,
                        'communication_route_exists': 1, 'candidate_generated_pre_cooldown': 1,
                        'previously_alerted': int(previous_false),
                        'retained_negative_record_exists': int(previous_false),
                        'blocked_by_event_cooldown': 0, 'blocked_by_failed_probe_cooldown': 0,
                        'blocked_by_active_alert_or_probe': 0, 'eligible_after_cooldown': 1,
                        'entered_rank_pool': 0, 'rank_position': '', 'selected_by_top_k': 0,
                        'entered_probe': 0, 'entered_full_alert': 0, 'probe_upgraded': 0,
                        'verification_confirmed': 0, 'timely_verification': 0,
                        'useful_front_observation': 0, 'suppression_reason': 'required_evidence_gate',
                        'path_hops': int(path_hops), 'ranking_mode': ranking_mode,
                        'normalized_innovation': float(signed_innovation), 'nis': float(nis_val),
                        'glr': float(glr_val), 'uncertainty': float(uncertainty),
                        'weak_evidence': int(weak_local_evidence), 'failure_count': int(failure_count),
                    })
                continue
            score = 3.0 * int(target_id not in event.get('alerted_nodes', set()))
            score += 2.0 * near_confirmed
            score += 1.0 * high_uncertainty
            score += 1.0 * high_innovation
            score -= false_penalty * previous_false
            score -= 1.0 * path_hops
            if ap_enabled and ap_eligible:
                score = float(predicted_probability)
            if previous_false and false_gate_mode in {'approach_score', 'approach_score_soft'}:
                score += approach_weight * approach_score
                score += close_bonus * close_to_frontier
                score += trend_bonus * evidence_increasing
                score += weak_evidence_bonus * weak_local_evidence
                score -= extra_hop_penalty * max(0, path_hops - 1)
                score -= repeat_fail_penalty * max(0, failure_count - 1)
            # Budget-matched selectors share eligibility, route construction,
            # probe/confirmation rules and Top-K; only the ranking signal changes.
            if ranking_mode == 'random':
                words = (int(getattr(config, 'RANDOM_SEED', 0)), int(event.get('event_id', 0)), int(self.step_index), int(source_id), int(target_id))
                score = float(np.random.default_rng(np.random.SeedSequence(words)).random())
            elif ranking_mode == 'distance_only':
                source_distance = self._spatial_distance_to_set(target_id, {int(source_id)})
                score = -float(source_distance) if np.isfinite(source_distance) else -1e9
            elif ranking_mode == 'nearest_confirmed':
                score = -float(distance_now) if np.isfinite(distance_now) else -1e9
            elif ranking_mode == 'nearest_confirmed_lexicographic':
                score = -float(distance_now) if np.isfinite(distance_now) else -1e9
            elif ranking_mode == 'route_cost_only':
                score = -float(path_hops)
            elif ranking_mode == 'approach_only':
                score = float(approach_score)
            elif ranking_mode == 'probe_only':
                score = float(weak_local_evidence) + float(evidence_increasing) + min(3.0, glr_val) / 3.0
            elif ranking_mode in {'velocity_extrapolation', 'predicted_boundary'}:
                horizon = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PREDICTION_HORIZON_STEPS', 3)))
                eta = float(distance_now) / max(float(front_speed), 0.05) if np.isfinite(distance_now) else 1e9
                score = -abs(eta - horizon)
            elif ranking_mode == 'dfo_compatibility':
                score = float(dfo_compatibility_score)
            elif ranking_mode == 'failure_time_compatibility':
                score = float(failure_time_compatibility)
            elif ranking_mode == 'dfo_failure_compatibility':
                score = float(dfo_failure_compatibility_score)
            elif ranking_mode == 'periodic':
                score = 0.0
            candidates.append((
                score, path_hops, target_id, previous_false, node_prior_failed, high_uncertainty, high_innovation,
                strong_innovation, weak_local_evidence, near_confirmed, new_confirmed_neighbor, signed_innovation,
                gate_pass_reason, gate_block_reason, evidence_increasing, delayed_front_weak_evidence,
                distance_at_fail, distance_now, distance_delta, front_approaching,
                approach_score, close_to_frontier, ap_features, predicted_probability, ap_decision,
            ))
            funnel_pending[int(target_id)] = {'source_id': int(source_id), 'event_id': int(event.get('event_id', 0)),
                                              'previously_alerted': int(previous_false), 'path_hops': int(path_hops)}
        self.event_relay_stats['realert_candidate_count'] += len(candidates)
        if ranking_mode == 'nearest_confirmed':
            candidates.sort(key=lambda item: (
                float(item[17]) if np.isfinite(item[17]) else 1e9,
                int(item[2]),
            ))
        elif ranking_mode == 'route_cost_only':
            candidates.sort(key=lambda item: (int(item[1]), int(item[2])))
        elif ranking_mode == 'nearest_confirmed_lexicographic':
            candidates.sort(key=lambda item: (
                float(item[17]) if np.isfinite(item[17]) else 1e9,
                int(item[1]),
                -float(item[22].get('local_evidence', 0.0)),
                int(item[2]),
            ))
        else:
            candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
        top_m = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_TOP_M', 54)))
        ap_decisions = [item[-1] for item in candidates if item[-1] is not None]
        if ap_enabled and ap_decisions:
            top_m = max(item.candidate_budget for item in ap_decisions)
        # Learned previous-failure scores are probabilities in [0, 1], whereas
        # ordinary candidate scores are heuristic utilities that can exceed 1.
        # Comparing those values directly made the learned gate ineffective.
        # Reserve a bounded number of slots *within* Top-K, then fill all
        # remaining slots with the ordinary global ordering.
        selection_candidates = candidates
        reserved_slots = min(
            top_m,
            max(0, int(getattr(config, 'AP_DFREALERT_PREVIOUS_FALSE_RESERVED_SLOTS', 0))),
        )
        if ap_enabled and reserved_slots > 0:
            threshold = float(self._ap_dfrealert_policy.probability_threshold)
            learned_priority = [
                item for item in candidates
                if item[-1] is not None and float(item[0]) >= threshold
            ]
            learned_priority.sort(key=lambda item: (-item[0], item[1], item[2]))
            reserved = learned_priority[:reserved_slots]
            reserved_ids = {id(item) for item in reserved}
            selection_candidates = reserved + [item for item in candidates if id(item) not in reserved_ids]
        intervention_match = bool(getattr(config, 'CAUSAL_REALERT_INTERVENTION_ENABLED', False))
        intervention_match = intervention_match and all([
            int(self.step_index) == int(getattr(config, 'CAUSAL_REALERT_INTERVENTION_STEP', -1)),
            int(event.get('event_id', -1)) == int(getattr(config, 'CAUSAL_REALERT_INTERVENTION_EVENT_ID', -1)),
            int(source_id) == int(getattr(config, 'CAUSAL_REALERT_INTERVENTION_SOURCE_ID', -1)),
        ])
        intervention_target = int(getattr(config, 'CAUSAL_REALERT_INTERVENTION_TARGET_ID', -1))
        intervention_action = str(getattr(config, 'CAUSAL_REALERT_INTERVENTION_ACTION', 'none')).strip().lower()
        intervention_candidate = None
        if intervention_match:
            intervention_candidate = next(
                (item for item in candidates if int(item[2]) == intervention_target), None
            )
            if intervention_candidate is None:
                raise RuntimeError(
                    'Causal intervention target is absent from the eligible candidate pool: '
                    f'step={self.step_index}, event={event.get("event_id")}, '
                    f'source={source_id}, target={intervention_target}'
                )
            if intervention_action not in {'probe', 'skip'}:
                raise ValueError("CAUSAL_REALERT_INTERVENTION_ACTION must be 'probe' or 'skip'")
            # Both arms use the same ordinary selection after removing the focal
            # action.  The probe arm then adds that single action; the skip arm
            # does not.  This keeps all simultaneous non-focal choices common.
            selection_candidates = [
                item for item in selection_candidates if int(item[2]) != intervention_target
            ]
        budget = int(getattr(config, 'ALERT_CONFIRMATION_REALERT_EVENT_BUDGET', 0))
        spent = int(event.get('realert_message_count', 0))
        event_target_budget = max(0, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_EVENT_TARGET_BUDGET', 0)))
        event_action_budget = max(0, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_EVENT_ACTION_BUDGET', 0)))
        admitted_nodes = event.setdefault('realert_admitted_nodes', set())
        selected, selected_edges = set(), set()
        selection_suppression = {} if trace_enabled else None
        ap_selected_count = 0
        for candidate in selection_candidates:
            score, path_hops, target_id, previous_false = candidate[:4]
            ap_eligible = bool(previous_false and candidate[-1] is not None)
            if len(selected) >= top_m:
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'top_k_capacity'
                continue
            if ap_enabled and ap_eligible and score < self._ap_dfrealert_policy.probability_threshold:
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'ap_probability_threshold'
                continue
            if event_target_budget > 0 and target_id not in admitted_nodes and len(admitted_nodes) >= event_target_budget:
                self.event_relay_stats['budget_exhaustion_count'] += 1
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'event_target_budget'
                continue
            if event_action_budget > 0 and int(event.get('realert_admission_count', 0)) >= event_action_budget:
                self.event_relay_stats['budget_exhaustion_count'] += 1
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'event_action_budget'
                continue
            route_anchor = int(route_anchor_by_target.get(int(target_id), source_id))
            path = self._shortest_comm_path(route_anchor, target_id, max_hops)
            if not path:
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'route_missing_at_admission'
                continue
            new_edges = set(zip(path[:-1], path[1:])) - selected_edges
            if budget > 0 and spent + len(new_edges) > budget:
                self.event_relay_stats['budget_exhaustion_count'] += 1
                if selection_suppression is not None:
                    selection_suppression[int(target_id)] = 'event_message_budget'
                continue
            selected.add(target_id)
            admitted_nodes.add(target_id)
            event['realert_admission_count'] = int(event.get('realert_admission_count', 0)) + 1
            if ap_eligible:
                ap_selected_count += 1
            selected_edges.update(new_edges)
            spent += len(new_edges)
        if intervention_match and intervention_action == 'probe':
            _, path_hops, target_id = intervention_candidate[:3]
            route_anchor = int(route_anchor_by_target.get(int(target_id), source_id))
            path = self._shortest_comm_path(route_anchor, target_id, max_hops)
            if not path:
                raise RuntimeError("Causal probe intervention has no communication route")
            new_edges = set(zip(path[:-1], path[1:])) - selected_edges
            selected.add(target_id)
            admitted_nodes.add(target_id)
            event['realert_admission_count'] = int(event.get('realert_admission_count', 0)) + 1
            selected_edges.update(new_edges)
            spent += len(new_edges)
        selected_lookup = set(selected)
        for candidate in candidates:
            (
                score, path_hops, target_id, previous_false, node_prior_failed, high_uncertainty, high_innovation,
                strong_innovation, weak_local_evidence, near_confirmed, new_confirmed_neighbor, signed_innovation,
                gate_pass_reason, gate_block_reason, evidence_increasing, delayed_front_weak_evidence,
                distance_at_fail, distance_now, distance_delta, front_approaching,
                approach_score, close_to_frontier, ap_features, predicted_probability, ap_decision,
            ) = candidate
            record = {
                'time': self.current_time, 'step': int(self.step_index),
                'event_id': int(event.get('event_id', 0)),
                'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                'target_id': int(target_id), 'event_age': int(self.step_index - event.get('created_step', self.step_index)),
                'path_hops': int(path_hops), 'score': float(score),
                'previous_false_woken': int(previous_false), 'node_prior_failed_verification': int(node_prior_failed),
                'high_uncertainty': int(high_uncertainty),
                'high_abs_innovation': int(high_innovation), 'strong_innovation': int(strong_innovation),
                'weak_local_evidence': int(weak_local_evidence),
                'evidence_increasing': int(evidence_increasing), 'delayed_front_weak_evidence': int(delayed_front_weak_evidence),
                'distance_at_fail': distance_at_fail, 'distance_now': distance_now,
                'front_distance_delta': distance_delta, 'front_approaching': int(front_approaching),
                'approach_score': approach_score, 'close_to_frontier': int(close_to_frontier),
                'near_confirmed': int(near_confirmed), 'new_confirmed_neighbor_since_fail': int(new_confirmed_neighbor),
                'innovation_at_realert': float(signed_innovation), 'gate_pass_reason': gate_pass_reason,
                'gate_block_reason': gate_block_reason, 'selected': int(target_id in selected_lookup),
                'deferred_by_active_cap': 0, 'probe_upgraded': 0, 'probe_failed': 0,
                'final_confirmed': 0, 'final_confirmed_by_probe_upgrade': 0,
                'seed': int(getattr(config, 'RANDOM_SEED', 0)),
                **{name: float(ap_features[name]) for name in ap_features},
                'predicted_probability': float(predicted_probability) if np.isfinite(predicted_probability) else np.nan,
                'selected_K': max(
                    int(ap_decision.candidate_budget) if ap_decision else top_m,
                    len(selected_lookup),
                ),
                'probe_horizon': int(ap_decision.probe_steps) if ap_decision else int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_STEPS', 2)),
                'cooldown': int(ap_decision.cooldown_steps) if ap_decision else cooldown,
                'candidate_source': str(getattr(config, 'ALERT_CANDIDATE_GENERATOR', 'current')),
                'route_anchor_id': int(route_anchor_by_target.get(int(target_id), source_id)),
                'frontier_anchored_scope': int(
                    int(route_anchor_by_target.get(int(target_id), source_id)) != int(source_id)
                ),
                'ranking_mode': ranking_mode,
                'ap_eligible_previous_false': int(previous_false and np.isfinite(distance_at_fail)),
                'decision': 'selected' if target_id in selected_lookup else 'not_selected',
                'message_delta': int(path_hops) if target_id in selected_lookup else 0,
                'causal_intervention_targeted': int(intervention_match and int(target_id) == intervention_target),
                'causal_intervention_action': intervention_action if intervention_match and int(target_id) == intervention_target else '',
                'energy_delta': float(path_hops) * (
                    float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                    + float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                ) if target_id in selected_lookup else 0.0,
                'true_event_ids_observed': ','.join(str(x) for x in sorted(set().union(*[
                    set(c.get('true_event_ids', set())) for c in event.get('components', {}).values()
                ]))) if event.get('components') else '',
            }
            funnel_idx = None
            if trace_enabled:
                funnel_idx = len(self.realert_funnel_records)
                self.realert_funnel_records.append({
                    'step': int(self.step_index), 'time': self.current_time,
                    'relay_event_id': int(event.get('event_id', 0)), 'source_id': int(source_id),
                    'target_id': int(target_id), 'within_response_scope': 1,
                    'communication_route_exists': 1, 'candidate_generated_pre_cooldown': 1,
                    'previously_alerted': int(previous_false),
                    'retained_negative_record_exists': int(previous_false),
                    'blocked_by_event_cooldown': 0, 'blocked_by_failed_probe_cooldown': 0,
                    'blocked_by_active_alert_or_probe': 0, 'eligible_after_cooldown': 1,
                    'entered_rank_pool': 1, 'rank_position': int(candidates.index(candidate) + 1),
                    'selected_by_top_k': int(target_id in selected_lookup),
                    'entered_probe': 0, 'entered_full_alert': 0, 'probe_upgraded': 0,
                    'verification_confirmed': 0, 'timely_verification': 0,
                    'useful_front_observation': 0,
                    'suppression_reason': '' if target_id in selected_lookup else selection_suppression.get(int(target_id), 'not_selected_top_k'),
                    'path_hops': int(path_hops), 'ranking_mode': ranking_mode,
                    'rank_score': float(score),
                    'approach_score': float(approach_score),
                    'distance_at_failure': float(distance_at_fail),
                    'distance_now': float(distance_now), 'distance_delta': float(distance_delta),
                    'front_speed': float(ap_features['front_speed']),
                    'steps_since_failure': int(ap_features['steps_since_failure']),
                    'eta_remaining_steps': float(ap_features['eta_remaining_steps']),
                    'eta_from_failure_steps': float(ap_features['eta_from_failure_steps']),
                    'temporal_compatibility': float(ap_features['temporal_compatibility']),
                    'failure_time_compatibility': float(ap_features['failure_time_compatibility']),
                    'dfo_compatibility_score': float(ap_features['dfo_compatibility_score']),
                    'normalized_innovation': float(signed_innovation), 'nis': float(nis_val),
                    'glr': float(glr_val), 'uncertainty': float(uncertainty),
                    'weak_evidence': int(weak_local_evidence), 'failure_count': int(failure_count),
                })
            record_idx = len(self.realert_target_records)
            self.realert_target_records.append(record)
            if target_id in selected_lookup:
                if previous_false:
                    self.event_relay_stats['previous_false_selected_count'] += 1
                event.setdefault('active_realert_record_indices', {}).setdefault(int(target_id), []).append(record_idx)
                if funnel_idx is not None:
                    event.setdefault('active_realert_funnel_indices', {}).setdefault(int(target_id), []).append(funnel_idx)
        event['realert_message_count'] = spent
        if selected:
            event.setdefault('realerted_sources', set()).add(source_id)
            event.setdefault('realert_source_last_step', {})[int(source_id)] = int(self.step_index)
            self.event_relay_stats['realert_count'] += 1
            self.event_relay_stats['realert_source_count'] += 1
            self.event_relay_stats['realert_selected_count'] += len(selected)
        return selected, sorted(selected_edges), hop_map

    def _update_realert_target_records(self, event_id, target_id, **updates):
        event = self.event_relay_events.get(int(event_id))
        if not event:
            return
        indices = event.get('active_realert_record_indices', {}).get(int(target_id), [])
        for idx in indices:
            if 0 <= int(idx) < len(self.realert_target_records):
                self.realert_target_records[int(idx)].update(updates)

    def _update_realert_funnel_records(self, event_id, target_id, **updates):
        """Update trace-only outcome flags; never read by the runtime policy."""
        if not bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
            return
        event = self.event_relay_events.get(int(event_id))
        if not event:
            return
        indices = event.get('active_realert_funnel_indices', {}).get(int(target_id), [])
        for idx in indices:
            if 0 <= int(idx) < len(self.realert_funnel_records):
                self.realert_funnel_records[int(idx)].update(updates)

    def _learned_targets_and_routes(self, event, source_id, component_id, depth):
        from src.target_ranker import FEATURE_NAMES, load_target_ranker
        max_hops = max(1, int(getattr(config, 'ALERT_CANDIDATE_ROUTE_MAX_HOPS',
                                      getattr(config, 'ALERT_LEARNED_CANDIDATE_MAX_HOPS', 4))))
        candidate_ids = sorted(self._candidate_pool(event, source_id))
        scored, feature_rows = [], []
        for target_id in candidate_ids:
            path = self._shortest_comm_path(source_id, target_id, max_hops)
            if not path:
                continue
            self.event_relay_stats['candidate_path_hops_total'] += max(1, len(path) - 1)
            self.event_relay_stats['candidate_path_count'] += 1
            features = self._learned_candidate_features(event, source_id, target_id, path, component_id, depth)
            row = {'step': int(self.step_index), 'time': self.current_time, 'event_id': int(event.get('event_id', 0)),
                   'component_id': int(component_id), 'source_id': int(source_id),
                   'target_id': int(target_id), 'seed': int(getattr(config, 'RANDOM_SEED', 0)), **features}
            feature_rows.append(row)
        collect_only = bool(getattr(config, 'ALERT_LEARNED_RANKER_COLLECT', False))
        oracle_scoring = bool(getattr(config, 'ALERT_LEARNED_ORACLE_SCORING', False))
        if oracle_scoring:
            scored = []
            for row in feature_rows:
                affected, front, arrival = self._oracle_candidate_labels(row['target_id'])
                row['oracle_affected'] = affected; row['oracle_front'] = front; row['oracle_arrival'] = arrival
                # Lexicographic-like utility: front visibility, affected membership,
                # early arrival, then path cost. Unaffected nodes remain negative.
                score = 100.0 * front + 50.0 * affected
                if arrival >= 0:
                    score += max(0.0, 20.0 - arrival)
                score -= 0.1 * row['comm_hops']
                scored.append((score, row))
        elif collect_only:
            # A deterministic distance/cost ordering drives data collection;
            # every feasible candidate is nevertheless logged for offline labels.
            scored = [(-r['comm_hops'] - 0.05 * r['spatial_distance_confirmed_min'], r) for r in feature_rows]
        else:
            if self._target_ranker is None:
                model_path = str(getattr(config, 'ALERT_LEARNED_RANKER_MODEL', '')).strip()
                if not model_path:
                    raise ValueError('ALERT_LEARNED_RANKER_MODEL is required for learned inference')
                self._target_ranker = load_target_ranker(model_path)
                if self._target_ranker.feature_names != FEATURE_NAMES:
                    raise ValueError('Target-ranker feature schema mismatch')
            scored = [(self._target_ranker.score(r), r) for r in feature_rows]
        scored.sort(key=lambda item: (-item[0], item[1]['target_id']))
        top_m = max(1, int(getattr(config, 'ALERT_LEARNED_TOP_M', 6)))
        min_score = float(getattr(config, 'ALERT_LEARNED_MIN_SCORE', -999.0))
        budget = max(1, int(getattr(config, 'ALERT_LEARNED_MESSAGE_BUDGET', 20)))
        policy = str(getattr(config, 'ALERT_LEARNED_POLICY', 'pure')).strip().lower()
        forced_ids = set()
        ranked_rows = list(scored)
        if policy == 'one_hop_core':
            forced_ids = {row['target_id'] for _, row in scored if int(row['comm_hops']) <= 1}
        elif policy == 'prune_2hop':
            forced_ids = {row['target_id'] for _, row in scored if int(row['comm_hops']) <= 1}
            outer = [(score, row) for score, row in scored if int(row['comm_hops']) == 2]
            keep = int(np.ceil(len(outer) * float(getattr(config, 'ALERT_LEARNED_PRUNE_FRACTION', 0.8))))
            allowed = forced_ids | {row['target_id'] for _, row in outer[:keep]}
            ranked_rows = [(score, row) for score, row in scored if row['target_id'] in allowed]
            top_m = max(top_m, len(allowed))
        chosen, edges, spent = set(), set(), 0
        # Core nodes are placed first and cannot be removed by the learner.
        ranked_rows.sort(key=lambda item: (item[1]['target_id'] not in forced_ids, -item[0], item[1]['target_id']))
        for score, row in ranked_rows:
            row['rank_score'] = float(score)
            row['selected'] = 0
            forced = row['target_id'] in forced_ids
            if (len(chosen) >= top_m and not forced) or (score < min_score and not forced):
                continue
            path = self._shortest_comm_path(source_id, row['target_id'], max_hops)
            new_edges = set(zip(path[:-1], path[1:])) - edges
            global_remaining = self._learned_global_budget_remaining
            if (spent + len(new_edges) > budget and not forced) or (global_remaining is not None and len(new_edges) > global_remaining):
                continue
            edges.update(new_edges); spent += len(new_edges)
            chosen.add(row['target_id']); row['selected'] = 1
            if self._learned_global_budget_remaining is not None:
                self._learned_global_budget_remaining -= len(new_edges)
        self.target_ranker_records.extend(feature_rows)
        return chosen, sorted(edges)

    def _event_relay_sources(self, triggered_alert_sources, pre_alert_nodes):
        actions = []
        for source_id, score in triggered_alert_sources.items():
            node = self.nodes[source_id]
            watches = node.active_event_watches()
            eligible = []
            for event_id, watch in watches.items():
                event = self.event_relay_events.get(event_id)
                if event is None or self.step_index >= event['expires_step'] or watch['relayed']:
                    continue
                eligible.append((event_id, watch))
            if not eligible and node.role == 'sentinel':
                self.event_relay_stats['raw_event_trigger_count'] += 1
                sign = self._event_sign(node)
                event_id = self._find_mergeable_event(source_id, sign)
                if event_id is None:
                    max_hops = self._compute_dynamic_alert_hops(score, source_id=source_id, active_nodes=pre_alert_nodes)
                    event_id = self._create_relay_event(source_id, max_hops)
                    event = self.event_relay_events[event_id]
                    event['sign'] = sign
                    event['source_nodes'] = {int(source_id)}
                    event['confirmed_records'] = {int(source_id): (int(self.step_index), float(score) if np.isfinite(score) else 0.0)}
                    event['components'][int(source_id)]['confirmed_records'][int(source_id)] = (
                        int(self.step_index), float(score) if np.isfinite(score) else 0.0
                    )
                    self._record_component_truth(event['components'][int(source_id)], source_id)
                    event['last_update_step'] = int(self.step_index)
                else:
                    self._attach_trigger_to_event(event_id, source_id)
                eligible = [(event_id, self.nodes[source_id].event_watches[event_id])]
            for event_id, watch in eligible:
                if int(watch.get('depth', 0)) > 0:
                    self.event_relay_stats['confirmation_requery_count'] += 1
                actions.append((source_id, event_id, watch))
        mode = str(getattr(config, 'ALERT_EVENT_REQUERY_MODE', 'none')).strip().lower()
        interval = max(1, int(getattr(config, 'ALERT_EVENT_REQUERY_INTERVAL_STEPS', 3)))
        cooldown = max(1, int(getattr(config, 'ALERT_EVENT_REQUERY_COOLDOWN_STEPS', 2)))
        max_anchors = max(1, int(getattr(config, 'ALERT_EVENT_REQUERY_MAX_ANCHORS', 3)))
        for event_id, event in self.event_relay_events.items():
            if self.step_index >= event.get('expires_step', 0):
                continue
            scheduled = mode in {'time', 'time_confirmation', 'hybrid'} and (
                self.step_index - event.get('last_time_requery_step', event['created_step']) >= interval
            )
            anchors = []
            if scheduled:
                records = event.get('confirmed_records', {})
                anchors = sorted(event.get('confirmed_nodes', set()),
                                 key=lambda n: (-records.get(n, (event['created_step'], 0))[0], n))[:max_anchors]
                event['last_time_requery_step'] = int(self.step_index)
                self.event_relay_stats['time_requery_count'] += 1
            if mode in {'soft_trend', 'hybrid'}:
                threshold = float(getattr(config, 'ALERT_EVENT_SOFT_TREND_THRESHOLD', 2.0))
                for nid in sorted(event.get('alerted_nodes', set())):
                    node = self.nodes.get(nid)
                    if node is None or nid in event.get('confirmed_nodes', set()):
                        continue
                    trend = max(float(getattr(node, 'glr_stat_up', 0.0)), float(getattr(node, 'glr_stat_down', 0.0)))
                    last = event.get('anchor_last_requery', {}).get(nid, -10**9)
                    if trend >= threshold and self.step_index - last >= cooldown:
                        anchors.append(nid)
                        event.setdefault('anchor_last_requery', {})[nid] = int(self.step_index)
                        self.event_relay_stats['soft_trend_requery_count'] += 1
            existing = {(a[0], a[1]) for a in actions}
            for anchor in list(dict.fromkeys(anchors)):
                if (anchor, event_id) in existing:
                    continue
                component_id = event.get('node_components', {}).get(anchor, event.get('source_id', anchor))
                actions.append((anchor, event_id, {
                    'depth': min(max(1, int(self.nodes[anchor].alert_hop or 1)), max(1, event['max_hops'] - 1)),
                    'component_id': component_id, 'relayed': False,
                    'initial_verification_failed': False, 'scheduled_requery': True,
                }))
        return actions

    def _run_event_relay(self, triggered_alert_sources, pre_alert_nodes):
        newly_alerted, event_rows = set(), []
        tx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
        rx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
        for source_id, event_id, watch in self._event_relay_sources(triggered_alert_sources, pre_alert_nodes):
            event = self.event_relay_events[event_id]
            depth = int(watch['depth'])
            component_id = watch.get('component_id')
            if component_id is None:
                component_id = event.get('node_components', {}).get(source_id, source_id)
            if depth >= event['max_hops'] and not watch.get('scheduled_requery', False):
                watch['relayed'] = True
                continue
            if depth == 0 and bool(getattr(config, 'ALERT_LEARNED_RANKER_ENABLED', False)):
                candidates, forwarding_edges = self._learned_targets_and_routes(
                    event, source_id, component_id, depth
                )
                hop_map = {source_id: 0}
                for target_id in candidates:
                    path = self._shortest_comm_path(
                        source_id, target_id,
                        int(getattr(config, 'ALERT_CANDIDATE_ROUTE_MAX_HOPS', 6))
                    )
                    hop_map[target_id] = max(1, len(path) - 1) if path else 1
            elif depth == 0:
                initial_hops = min(event['max_hops'], max(1, int(getattr(config, 'ALERT_EVENT_INITIAL_HOPS', 2))))
                route_targets, forwarding_edges, hop_map = self._resolve_alert_routes(source_id, dynamic_max_hops=initial_hops)
                candidates = {nid for nid in route_targets if nid not in event['alerted_nodes']}
            else:
                if bool(getattr(config, 'ALERT_LEARNED_RANKER_ENABLED', False)):
                    candidates, forwarding_edges = self._learned_targets_and_routes(
                        event, source_id, component_id, depth
                    )
                    hop_map = {source_id: 0}
                    for target_id in candidates:
                        path = self._shortest_comm_path(source_id, target_id, int(getattr(config, 'ALERT_LEARNED_CANDIDATE_MAX_HOPS', 4)))
                        hop_map[target_id] = max(1, len(path) - 1) if path else 1
                elif bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_POLICY_ENABLED', False)):
                    candidates, forwarding_edges, hop_map = self._confirmation_realert_targets_and_routes(event, source_id)
                elif bool(getattr(config, 'ALERT_GEOBOUND_ENABLED', False)):
                    candidates, forwarding_edges, geometry, geometry_confidence = self._geobound_targets_and_routes(
                        event, source_id, component_id
                    )
                    direction_available, direction_confidence = geometry != 'uncertain', geometry_confidence
                    for target_id in candidates:
                        self.directional_selections.append({
                            'time': self.current_time, 'step': self.step_index, 'event_id': event_id,
                            'source_id': source_id, 'target_id': target_id,
                            'direction_available': int(direction_available),
                            'direction_confidence': float(geometry_confidence),
                            'selection_mode': 'geobound_' + geometry,
                        })
                    hop_map = {source_id: 0}
                    for target_id in candidates:
                        path = self._shortest_comm_path(source_id, target_id, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
                        hop_map[target_id] = max(1, len(path) - 1) if path else 1
                elif bool(getattr(config, 'ALERT_EVENT_RADIAL_FRONTIER_ENABLED', False)):
                    candidates, forwarding_edges = self._radial_frontier_targets_and_routes(event, source_id, component_id)
                    direction_available, direction_confidence = False, 0.0
                    for target_id in candidates:
                        self.directional_selections.append({
                            'time': self.current_time, 'step': self.step_index,
                            'event_id': event_id, 'source_id': source_id,
                            'target_id': target_id, 'direction_available': 0,
                            'direction_confidence': 0.0, 'selection_mode': 'radial',
                        })
                    hop_map = {source_id: 0}
                    for target_id in candidates:
                        path = self._shortest_comm_path(source_id, target_id, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
                        hop_map[target_id] = max(1, len(path) - 1) if path else 1
                elif bool(getattr(config, 'ALERT_EVENT_DIRECTIONAL_ENABLED', False)):
                    candidates, forwarding_edges, direction_available, direction_confidence = self._directional_targets_and_routes(
                        event, source_id, component_id
                    )
                    self.event_relay_stats['directional_candidate_count'] += len(candidates)
                    for target_id in candidates:
                        self.directional_selections.append({
                            'time': self.current_time, 'step': self.step_index,
                            'event_id': event_id, 'source_id': source_id,
                            'target_id': target_id, 'direction_available': int(direction_available),
                            'direction_confidence': float(direction_confidence),
                        })
                    hop_map = {source_id: 0}
                    for target_id in candidates:
                        path = self._shortest_comm_path(source_id, target_id, int(getattr(config, 'ALERT_DIRECTION_MAX_ROUTE_HOPS', 4)))
                        hop_map[target_id] = max(1, len(path) - 1) if path else 1
                else:
                    candidates = {
                        nid for nid in self._get_alert_neighbors(source_id)
                        if nid in self.nodes and nid != source_id and nid not in event['alerted_nodes']
                    }
                    forwarding_edges = [(source_id, nid) for nid in candidates]
                    hop_map = {source_id: 0, **{nid: 1 for nid in candidates}}
            if bool(getattr(config, 'ALERT_SPATIAL_TARGET_GATE', False)):
                radius = float(getattr(config, 'ALERT_SPATIAL_RADIUS_PER_HOP', config.NEIGHBOR_RADIUS))
                candidates = self._spatially_plausible_alert_targets(source_id, candidates, radius)
            watch['relayed'] = True
            event['relayed_nodes'].add(source_id)
            event['confirmed_nodes'].add(source_id)
            event.setdefault('confirmed_records', {})[int(source_id)] = (
                int(self.step_index), float(triggered_alert_sources.get(source_id, 0.0) or 0.0)
            )
            component = event.setdefault('components', {}).setdefault(int(component_id), {
                'source_id': int(component_id), 'confirmed_records': {},
                'true_event_ids': set(), 'direction_history': [],
            })
            component['confirmed_records'][int(source_id)] = (
                int(self.step_index), float(triggered_alert_sources.get(source_id, 0.0) or 0.0)
            )
            self._record_component_truth(component, source_id)
            event.setdefault('node_components', {})[int(source_id)] = int(component_id)
            event['last_update_step'] = int(self.step_index)
            if depth > 0:
                self.event_relay_stats['repropagation_count'] += 1
                if watch.get('initial_verification_failed', False):
                    self.event_relay_stats['late_confirm_rescue_count'] += 1
                if int(source_id) in event.get('realerted_nodes', set()) and int(source_id) not in event.get('realert_success_nodes', set()):
                    event.setdefault('realert_success_nodes', set()).add(int(source_id))
                    self.event_relay_stats['realert_success_count'] += 1
                if int(source_id) in event.get('realerted_nodes', set()):
                    indices = event.get('active_realert_record_indices', {}).get(int(source_id), [])
                    was_probe_upgraded = any(
                        0 <= int(idx) < len(self.realert_target_records)
                        and int(self.realert_target_records[int(idx)].get('probe_upgraded', 0)) == 1
                        for idx in indices
                    )
                    self._update_realert_target_records(event_id, source_id, final_confirmed=1)
                    self._update_realert_funnel_records(
                        event_id, source_id, verification_confirmed=1,
                        verification_step=int(self.step_index),
                    )
                    if was_probe_upgraded:
                        self.event_relay_stats['probe_upgrade_final_confirmed_count'] += 1
                        self._update_realert_target_records(event_id, source_id, final_confirmed_by_probe_upgrade=1)
            remaining = max(1, event['expires_step'] - self.step_index)
            active_full_alert_cap = int(getattr(config, 'ALERT_CONFIRMATION_REALERT_ACTIVE_FULL_ALERT_CAP', 0))
            active_full_alert_count = sum(
                1 for nid in event.get('alerted_nodes', set())
                if nid in self.nodes and self.nodes[nid].mode == 'alert' and not self.nodes[nid].alert_confirmed
            )
            for target_id in candidates:
                was_previously_alerted = target_id in event.get('alerted_nodes', set())
                target = self.nodes[target_id]
                was_alert = target.mode == 'alert'
                target_depth = depth + int(hop_map.get(target_id, 1))
                probe_previous_false_only = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_PREVIOUS_FALSE_ONLY', False))
                use_probe = bool(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_ENABLED', False)) and was_previously_alerted
                if use_probe and probe_previous_false_only:
                    use_probe = int(target_id) in event.get('failed_verification_nodes', set())
                if active_full_alert_cap > 0 and not use_probe and not was_alert and active_full_alert_count >= active_full_alert_cap:
                    self.event_relay_stats['deferred_by_active_cap_count'] += 1
                    self._update_realert_target_records(event_id, target_id, deferred_by_active_cap=1)
                    self._update_realert_funnel_records(
                        event_id, target_id, suppression_reason='active_full_alert_cap'
                    )
                    continue
                event['alerted_nodes'].add(target_id)
                event.setdefault('last_alert_step', {})[int(target_id)] = int(self.step_index)
                if was_previously_alerted:
                    event.setdefault('realerted_nodes', set()).add(int(target_id))
                    if int(target_id) in event.get('failed_verification_nodes', set()):
                        self.event_relay_stats['reactivated_failed_nodes'] += 1
                if bool(getattr(config, 'ALERT_EVENT_REALERT_ENABLED', False)) and event_id in target.event_watches:
                    # A new opportunity must not inherit the previous watch's
                    # relayed=True latch; verification history remains on node.
                    del target.event_watches[event_id]
                target.add_event_watch(
                    event_id, min(remaining, int(getattr(config, 'ALERT_SOFT_WATCH_STEPS', 20))),
                    target_depth, component_id=component_id
                )
                event.setdefault('node_components', {})[int(target_id)] = int(component_id)
                alert_duration = self._alert_duration_for_hop(target_depth)
                if use_probe:
                    indices = event.get('active_realert_record_indices', {}).get(int(target_id), [])
                    probe_steps = max(1, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_STEPS', 2)))
                    if indices:
                        probe_steps = int(self.realert_target_records[int(indices[-1])].get('probe_horizon', probe_steps))
                    target.trigger_probe(probe_steps, alert_hop=target_depth, event_id=event_id, start_step=self.step_index)
                    self.event_relay_stats['probe_trigger_count'] += 1
                    self._update_realert_funnel_records(
                        event_id, target_id, entered_probe=1, action_step=int(self.step_index)
                    )
                else:
                    target.trigger_alert(alert_duration, confirmed=False, alert_hop=target_depth, event_id=event_id)
                    self._update_realert_funnel_records(
                        event_id, target_id, entered_full_alert=1, action_step=int(self.step_index)
                    )
                if not was_alert and target.mode in ('alert', 'probe'):
                    newly_alerted.add(target_id)
                self.node_comm_energy_records.append({
                    'time': self.current_time, 'step_type': 'event_probe_rx' if use_probe else 'event_alert_rx', 'node_id': int(target_id),
                    'peer_count': 1, 'comm_energy_mj': float(rx_energy)
                })
            for tx_node in sorted({src for src, _ in forwarding_edges}):
                edge_count = sum(1 for src, _ in forwarding_edges if src == tx_node)
                self.node_comm_energy_records.append({
                    'time': self.current_time, 'step_type': 'event_relay_tx', 'node_id': int(tx_node),
                    'peer_count': edge_count, 'comm_energy_mj': float(tx_energy * edge_count)
                })
            if candidates:
                event_rows.append({
                    'time': self.current_time, 'sentinels': [int(source_id)],
                    'neighbor_count': len(candidates), 'neighbors': sorted(candidates),
                    'max_hops': max(depth + int(hop_map.get(nid, 1)) for nid in candidates),
                    'forwarding_message_count': len(forwarding_edges),
                    'relay_event_id': event_id,
                })
        return newly_alerted, event_rows
        
    def load_node_data(self, moteid, dataframe):
        self.node_data[moteid] = dataframe

    def load_node_positions(self, node_positions):
        self.node_positions = node_positions

    def build_topology(self, mode='radius', radius=None, k=None):
        node_ids = sorted([node_id for node_id in self.nodes.keys() if node_id in self.node_positions])
        if len(node_ids) == 0:
            self.adjacency = {}
            self.topology_mode = mode
            self.topology_params = {'radius': radius, 'k': k}
            return self.adjacency
        adjacency_set = {node_id: set() for node_id in node_ids}
        if mode == 'radius':
            if radius is None or radius <= 0:
                raise ValueError('radius mode requires radius > 0')
            for i, src in enumerate(node_ids):
                src_pos = self.node_positions[src]
                for dst in node_ids[i + 1:]:
                    dst_pos = self.node_positions[dst]
                    dx = src_pos['x'] - dst_pos['x']
                    dy = src_pos['y'] - dst_pos['y']
                    dist = np.sqrt(dx * dx + dy * dy)
                    if dist <= radius:
                        adjacency_set[src].add(dst)
                        adjacency_set[dst].add(src)
        elif mode == 'knn':
            if k is None or k <= 0:
                raise ValueError('knn mode requires k > 0')
            k_eff = min(k, max(0, len(node_ids) - 1))
            for src in node_ids:
                src_pos = self.node_positions[src]
                dist_pairs = []
                for dst in node_ids:
                    if dst == src:
                        continue
                    dst_pos = self.node_positions[dst]
                    dx = src_pos['x'] - dst_pos['x']
                    dy = src_pos['y'] - dst_pos['y']
                    dist = np.sqrt(dx * dx + dy * dy)
                    dist_pairs.append((dist, dst))
                dist_pairs.sort(key=lambda x: (x[0], x[1]))
                for _, dst in dist_pairs[:k_eff]:
                    adjacency_set[src].add(dst)
                    adjacency_set[dst].add(src)
        else:
            raise ValueError("mode must be 'radius' or 'knn'")
        self.adjacency = {node_id: sorted(list(neighbors)) for node_id, neighbors in adjacency_set.items()}
        self.topology_mode = mode
        self.topology_params = {'radius': radius, 'k': k}
        return self.adjacency

    def get_neighbors(self, node_id):
        return self.adjacency.get(node_id, [])

    def load_communication_weights(self, communication_weights):
        self.communication_weights = communication_weights

    def build_communication_topology(self, threshold, directed=True, model='threshold_cut', random_seed=None):
        node_ids = sorted(self.nodes.keys())
        adjacency_set = {node_id: set() for node_id in node_ids}
        rng = np.random.default_rng(random_seed) if random_seed is not None else None
        for src in node_ids:
            for dst in node_ids:
                if src == dst:
                    continue
                weight = self.communication_weights.get(src, {}).get(dst, 0.0)
                keep_edge = False
                if model == 'threshold_cut':
                    keep_edge = weight >= threshold
                elif model == 'probability_propagation':
                    if weight > 0:
                        sampled = rng.random() if rng is not None else np.random.random()
                        keep_edge = sampled <= weight
                else:
                    raise ValueError("model must be 'threshold_cut' or 'probability_propagation'")
                if keep_edge:
                    adjacency_set[src].add(dst)
                    if not directed:
                        adjacency_set[dst].add(src)
        self.communication_adjacency = {node_id: sorted(list(neighbors)) for node_id, neighbors in adjacency_set.items()}
        self.communication_threshold = threshold
        self.communication_model = model
        return self.communication_adjacency

    def get_comm_neighbors(self, node_id):
        return self.communication_adjacency.get(node_id, [])

    def get_comm_reverse_neighbors(self, node_id):
        reverse_neighbors = set()
        for src, dst_list in self.communication_adjacency.items():
            if node_id in dst_list:
                reverse_neighbors.add(src)
        return sorted(list(reverse_neighbors))

    def _get_alert_neighbors(self, node_id):
        if self.alert_neighbor_graph == 'communication':
            return self.get_comm_neighbors(node_id)
        if self.alert_neighbor_graph == 'spatial':
            return self.get_neighbors(node_id)
        raise ValueError("alert_neighbor_graph must be 'communication' or 'spatial'")

    def _get_alert_monitor_neighbors(self, node_id):
        if self.alert_neighbor_graph == 'communication':
            neighbors = set(self.get_comm_neighbors(node_id))
            neighbors.update(self.get_comm_reverse_neighbors(node_id))
            if node_id in neighbors:
                neighbors.remove(node_id)
            return sorted(list(neighbors))
        neighbors = set(self._get_alert_neighbors(node_id))
        if node_id in neighbors:
            neighbors.remove(node_id)
        return sorted(list(neighbors))

    def _resolve_alert_routes(self, sentinel_id, dynamic_max_hops=None):
        """Resolve targets plus the actual forwarding tree used by the alert."""
        max_hops = 1 if self.alert_propagation_mode == 'one_hop' else (
            max(1, int(self.alert_max_hops)) if dynamic_max_hops is None else max(1, int(dynamic_max_hops))
        )
        if self.alert_propagation_mode not in {'one_hop', 'k_hop'}:
            raise NotImplementedError("alert_propagation_mode only supports one_hop or k_hop")
        adjacency = {nid: self._get_alert_neighbors(nid) for nid in self.nodes}
        parents, hops = bfs_routes(adjacency, sentinel_id, max_hops, allowed_nodes=self.nodes)
        targets = {nid for nid in hops if nid != sentinel_id and self.nodes[nid].role != 'sentinel'}
        # Sentinel relay nodes are omitted from wake-up targets but retained in
        # the forwarding tree, since they still spend TX/RX energy.
        forwarding_edges = [(parent, child) for child, parent in parents.items()]
        return targets, forwarding_edges, hops

    def _resolve_alert_targets(self, sentinel_id, dynamic_max_hops=None):
        targets, _, _ = self._resolve_alert_routes(sentinel_id, dynamic_max_hops)
        return targets

    def _resolve_alert_targets_legacy(self, sentinel_id, dynamic_max_hops=None):
        if self.alert_propagation_mode == 'one_hop':
            return {nid for nid in self._get_alert_neighbors(sentinel_id) if nid in self.nodes and self.nodes[nid].role != 'sentinel'}
        if self.alert_propagation_mode == 'k_hop':
            if dynamic_max_hops is None:
                max_hops = max(1, int(self.alert_max_hops))
            else:
                max_hops = max(1, int(dynamic_max_hops))
            visited = {sentinel_id: 0}
            queue = [sentinel_id]
            head = 0
            while head < len(queue):
                cur = queue[head]
                head += 1
                cur_hop = visited[cur]
                if cur_hop >= max_hops:
                    continue
                for nxt in self._get_alert_neighbors(cur):
                    if nxt in visited:
                        continue
                    visited[nxt] = cur_hop + 1
                    queue.append(nxt)
            targets = set(visited.keys())
            if sentinel_id in targets:
                targets.remove(sentinel_id)
            return {nid for nid in targets if nid in self.nodes and self.nodes[nid].role != 'sentinel'}
        raise NotImplementedError("alert_propagation_mode only supports one_hop or k_hop")

    def _compute_dynamic_alert_hops(self, nis_value, source_id=None, active_nodes=None):
        base_hops = max(1, int(self.alert_max_hops))
        if (not config.ALERT_ADAPTIVE_HOPS_ENABLED) or self.alert_propagation_mode != 'k_hop':
            return base_hops
        if nis_value is None or np.isnan(nis_value):
            return base_hops
        max_allow = max(base_hops, int(config.ALERT_ADAPTIVE_MAX_HOPS))
        confirmed = 0
        if source_id is not None and active_nodes is not None:
            confirmed = sum(1 for n in self._get_alert_monitor_neighbors(source_id) if n in active_nodes)
        policy = AdaptiveHopPolicy(
            min_hops=base_hops,
            max_hops=max_allow,
            medium_score=float(config.ALERT_ADAPTIVE_NIS_MEDIUM),
            high_score=float(config.ALERT_ADAPTIVE_NIS_HIGH),
            confirmation_threshold=int(getattr(config, 'ALERT_ADAPTIVE_CONFIRMATION_THRESHOLD', 2)),
            fast_diffusion_threshold=float(getattr(config, 'ALERT_ADAPTIVE_FAST_DIFFUSION_THRESHOLD', 0.5)),
            low_energy_threshold=float(getattr(config, 'ALERT_ADAPTIVE_LOW_ENERGY_THRESHOLD', 0.2)),
        )
        return policy.choose_hops(AlertContext(detector_score=nis_value, confirmed_neighbors=confirmed))

    def _get_oracle_neighbors(self, node_id):
        if self.oracle_wakeup_graph == 'communication':
            return self.get_comm_neighbors(node_id)
        if self.oracle_wakeup_graph == 'spatial':
            return self.get_neighbors(node_id)
        raise ValueError("oracle_wakeup_graph must be 'communication' or 'spatial'")

    def get_ground_truth(self, moteid, timestamp):
        if moteid not in self.node_data:
            return None, False, []
            
        df = self.node_data[moteid]
        try:
            val = None
            if timestamp in df.index:
                val = df.loc[timestamp][self.value_col]
                if pd.isna(val):
                    val = None
            
            # Inject Anomaly if val exists
            if val is not None:
                injected_val, is_anomaly, event_ids = self.anomaly_injector.get_injected_value(
                    val, timestamp, moteid, self.time_step,
                    node_positions=self.node_positions,
                    spatial_adjacency=self.adjacency,
                    communication_adjacency=self.communication_adjacency
                )
                return injected_val, is_anomaly, event_ids
            return None, False, []
            
        except KeyError:
            return None, False, []

    def _append_structural_trace(self, step_records, current_front_nodes, slot_states=None):
        """Append B2.1 diagnostics after a slot without affecting simulation state."""
        if not bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
            return

        step = int(self.step_index)
        timestamp = self.current_time
        if bool(getattr(config, 'ALERT_POST_EXPIRY_COVERAGE_SERVICE_ENABLED', False)):
            for row in self.post_expiry_coverage_selection_trace:
                if row.get('record_type') != 'physical' or int(row.get('step', -1)) != step:
                    continue
                node_id = int(row['node_id']); node = self.nodes[node_id]; rec = step_records[node_id]
                row['initial_sample_command'] = int(bool(rec.get('initial_sample_command', False)))
                row['observation_available'] = int(rec.get('gt_val') is not None)
                row['parent_late_sample_override'] = int(bool(rec.get('parent_late_sample_override', False)))
                row['actual_sample'] = int(bool(rec.get('sampled', False)))
                row['sampled'] = row['actual_sample']
                row['logical_mode_after'] = str(node.mode)
                row['alert_confirmed_after'] = int(bool(node.alert_confirmed))
                row['alert_event_id_after'] = '' if node.alert_event_id is None else int(node.alert_event_id)
                row['event_watch_ids_after'] = ';'.join(map(str, sorted(int(e) for e in node.event_watches)))
                row['failure_count_after'] = int(node.failed_verification_count)
        comm_rows = [
            row for row in self.node_comm_energy_records
            if row.get('time') == timestamp
        ]
        comm_by_node = {}
        for row in comm_rows:
            node_id = int(row['node_id'])
            counts = comm_by_node.setdefault(node_id, {'tx_packets': 0, 'rx_packets': 0, 'tx_energy_mj': 0.0, 'rx_energy_mj': 0.0})
            packet_count = int(row.get('peer_count', 0))
            energy = float(row.get('comm_energy_mj', 0.0))
            if 'tx' in str(row.get('step_type', '')):
                counts['tx_packets'] += packet_count
                counts['tx_energy_mj'] += energy
            elif 'rx' in str(row.get('step_type', '')):
                counts['rx_packets'] += packet_count
                counts['rx_energy_mj'] += energy

        for event_id in sorted(self.event_relay_events):
            event = self.event_relay_events[event_id]
            confirmed = sorted(int(node_id) for node_id in event.get('confirmed_records', {}))
            true_event_ids = sorted(set().union(*[
                set(component.get('true_event_ids', set()))
                for component in event.get('components', {}).values()
            ]) if event.get('components') else set(event.get('true_event_ids', set())))
            true_front = sorted(int(node_id) for node_id, ids in self.current_step_gt_event_ids.items()
                                if node_id in current_front_nodes and set(ids).intersection(true_event_ids))
            self.event_state_trace.append({
                'step': step, 'time': timestamp, 'event_id': int(event_id),
                'created_step': int(event.get('created_step', step)),
                'expires_step': int(event.get('expires_step', step)),
                'active': int(step < int(event.get('expires_step', step + 1))),
                'source_id': event.get('source_id'),
                'confirmed_node_count': len(confirmed),
                'confirmed_node_ids': ';'.join(map(str, confirmed)),
                'true_event_ids_observed': ';'.join(map(str, true_event_ids)),
                'true_event_front_node_count': len(true_front),
                'true_event_front_node_ids': ';'.join(map(str, true_front)),
                'global_gt_front_node_count': len(current_front_nodes),
                'global_gt_front_node_ids': ';'.join(map(str, sorted(current_front_nodes))),
                'realert_record_count': sum(1 for row in self.realert_target_records if row.get('event_id') == event_id),
            })

        for record_index, record in enumerate(self.realert_target_records):
            event_id = record.get('event_id')
            event = self.event_relay_events.get(int(event_id)) if event_id is not None else None
            self.retained_record_timeline.append({
                'step': step, 'time': timestamp, 'record_index': int(record_index),
                'event_id': event_id, 'target_id': record.get('target_id'),
                'event_active': int(event is not None and step < int(event.get('expires_step', step + 1))),
                'selected': int(bool(record.get('selected', False))),
                'probe_upgraded': int(bool(record.get('probe_upgraded', False))),
                'probe_failed': int(bool(record.get('probe_failed', False))),
                'final_confirmed': int(bool(record.get('final_confirmed', False))),
                'final_confirmed_by_probe_upgrade': int(bool(record.get('final_confirmed_by_probe_upgrade', False))),
                'deferred_by_active_cap': int(bool(record.get('deferred_by_active_cap', False))),
                'cooldown': record.get('cooldown'), 'path_hops': record.get('path_hops'),
            })

        duration_sec = float(self.time_step.total_seconds())
        sensing_duration_sec = float(getattr(config, 'SENSING_DURATION_SEC', 0.0))
        for node_id in sorted(self.nodes):
            node = self.nodes[node_id]
            rec = step_records[node_id]
            comm = comm_by_node.get(node_id, {})
            slot = (slot_states or {}).get(node_id, {})
            raw_mode = slot.get('mode', node.history['mode'][-1] if node.history['mode'] else node.mode)
            if node.role == 'sentinel':
                slot_mode = 'sentinel'
            elif raw_mode == 'probe':
                slot_mode = 'probe'
            elif raw_mode == 'alert':
                slot_mode = 'confirmed_tracking' if slot.get('alert_confirmed', False) else 'unconfirmed_alert_verification'
            elif slot.get('has_event_watch', False):
                slot_mode = 'soft_watch'
            else:
                slot_mode = 'adaptive'
            self.node_state_duration_trace.append({
                'step': step, 'time': timestamp, 'node_id': int(node_id),
                'state_during_slot': slot_mode, 'state_after_slot': node.mode,
                'state_duration_sec': duration_sec,
                'sampled': int(bool(rec.get('sampled', False))),
                'sample_duration_sec': sensing_duration_sec if rec.get('sampled', False) else 0.0,
                'tx_packets': int(comm.get('tx_packets', 0)), 'rx_packets': int(comm.get('rx_packets', 0)),
                'tx_energy_mj': float(comm.get('tx_energy_mj', 0.0)), 'rx_energy_mj': float(comm.get('rx_energy_mj', 0.0)),
                'budgeted_frontier_active': int(bool(slot.get('budgeted_frontier_active', False))),
                'budgeted_frontier_high_rate': int(bool(slot.get('budgeted_frontier_high_rate', False))),
            })

    def _handoff_confirmed_alert_after_event_expiry(self):
        """End confirmed full-rate tracking when its runtime relay event expires."""
        if not bool(getattr(config, 'ALERT_EVENT_EXPIRY_CONFIRMED_HANDOFF_ENABLED', False)):
            return
        for node_id, node in self.nodes.items():
            if node.role == 'sentinel' or node.mode != 'alert' or not node.alert_confirmed:
                continue
            event_id = node.alert_event_id
            if event_id is None:
                continue
            event = self.event_relay_events.get(int(event_id))
            if event is None or self.step_index < int(event.get('expires_step', 10**9)):
                continue
            # Preserve confirmation/event history and avoid failure semantics.
            node.mode = 'adaptive'; node.alert_timer = 0; node.alert_elapsed = 0
            node.alert_bg_x = None; node.alert_bg_P = None; node.alert_hop = 0
            node.alert_event_id = int(event_id); node.alert_verify_elapsed = 0
            # Event relay is over, but retain a bounded soft-watch window so
            # expiry release does not erase all subsequent observation.
            node.add_event_watch(int(event_id), int(getattr(config, 'ALERT_SOFT_WATCH_STEPS', 20)),
                                 depth=int(getattr(node, 'alert_hop', 0)),
                                 component_id=event.get('node_components', {}).get(int(node_id), node_id))
            self.event_relay_stats['confirmed_tracking_expiry_release_count'] = int(self.event_relay_stats.get('confirmed_tracking_expiry_release_count', 0)) + 1

    def _apply_confirmed_tracking_handoff_release(self):
        """Handoff interior confirmed nodes after the formal three-slot minimum."""
        if not bool(getattr(config, 'ALERT_FRONTIER_PRESERVING_CONFIRMED_HANDOFF_ENABLED', False)):
            return
        minimum = max(3, int(getattr(config, 'ALERT_CONFIRMED_TRACKING_MIN_STEPS', 3)))
        for node_id, node in self.nodes.items():
            if node.role == 'sentinel' or node.mode != 'alert' or not node.alert_confirmed:
                continue
            event_id = node.alert_event_id
            event = self.event_relay_events.get(int(event_id)) if event_id is not None else None
            if event is None or self.step_index >= int(event.get('expires_step', 10**9)):
                continue
            record = event.get('confirmed_records', {}).get(int(node_id)); watch = node.event_watches.get(int(event_id), {})
            if record is None or not bool(watch.get('relayed', False)) or self.step_index - int(record[0]) < minimum:
                continue
            confirmed = set(int(n) for n in event.get('confirmed_nodes', set()))
            frontier = any(int(n) not in confirmed and self.nodes[int(n)].role != 'sentinel' for n in self._get_alert_neighbors(node_id) if int(n) in self.nodes)
            if frontier:
                continue
            node.mode = 'adaptive'; node.alert_timer = 0; node.alert_elapsed = 0
            node.alert_bg_x = None; node.alert_bg_P = None; node.alert_hop = 0
            # Keep event id and confirmed flag/history; event watch drives soft-watch sampling.
            self.event_relay_stats['confirmed_tracking_handoff_release_count'] = int(self.event_relay_stats.get('confirmed_tracking_handoff_release_count', 0)) + 1

    def _prepare_budgeted_frontier_sampling(self):
        if not bool(getattr(config, 'ALERT_BUDGETED_FRONTIER_TRACKING_ENABLED', False)):
            for n in self.nodes.values(): n.budgeted_frontier_active=False; n.budgeted_frontier_high_rate=False
            return
        selected=set(); active_nodes=set(); event_rows=[]
        for eid,event in self.event_relay_events.items():
            if self.step_index >= int(event.get('expires_step', 10**9)): continue
            confirmed=set(int(n) for n in event.get('confirmed_nodes',set()))
            frontier=[n for n in confirmed if n in self.nodes and self.nodes[n].role!='sentinel' and self.nodes[n].mode=='alert' and self.nodes[n].alert_confirmed and any(int(nb) not in confirmed and self.nodes[int(nb)].role!='sentinel' for nb in self._get_alert_neighbors(n) if int(nb) in self.nodes)]
            active_nodes.update(frontier)
            records=event.get('confirmed_records',{})
            def frontier_key(n):
                unconfirmed_count=sum(1 for nb in self._get_alert_neighbors(n) if int(nb) not in confirmed and int(nb) in self.nodes and self.nodes[int(nb)].role!='sentinel')
                # Route depth is event-specific. node.alert_hop is shared by
                # overlapping events, whereas the event watch retains the
                # depth for this exact relay event.
                route_hops=int(self.nodes[n].event_watches.get(int(eid),{}).get('depth',getattr(self.nodes[n],'alert_hop',0)))
                return (-int(records.get(n,(self.step_index,0))[0]),-unconfirmed_count,route_hops,int(n))
            frontier.sort(key=frontier_key)
            mandatory=[]
            if bool(getattr(config,'ALERT_BUDGETED_FRONTIER_UNIQUE_COVERAGE_ENABLED',False)):
                for n in frontier:
                    if any(sum(1 for q in frontier if int(u) in self._get_alert_neighbors(q))==1 for u in self._get_alert_neighbors(n) if int(u) not in confirmed and int(u) in self.nodes and self.nodes[int(u)].role!='sentinel'): mandatory.append(n)
            ordered=[]
            for n in mandatory+frontier:
                if n not in ordered: ordered.append(n)
            event_selected=set(ordered[:int(getattr(config,'ALERT_CONFIRMATION_REALERT_TOP_M',5))])
            selected.update(event_selected)
            if bool(getattr(config,'STRUCTURAL_TRACE_ENABLED',False)):
                for position,n in enumerate(ordered,start=1):
                    key=frontier_key(n)
                    event_rows.append({'step':int(self.step_index),'event_id':int(eid),'node_id':int(n),'confirmation_step':int(-key[0]),'unconfirmed_nonsentinel_neighbor_count':int(-key[1]),'event_route_hops':int(key[2]),'unique_coverage_mandatory':int(n in mandatory),'rank_position':int(position),'selected_for_event_high_rate':int(n in event_selected)})
        for n in self.nodes.values():
            n.budgeted_frontier_active=n.node_id in active_nodes; n.budgeted_frontier_high_rate=n.node_id in selected
        if bool(getattr(config,'STRUCTURAL_TRACE_ENABLED',False)):
            for row in event_rows:
                row['selected_by_any_event_high_rate']=int(row['node_id'] in selected)
                self.budgeted_frontier_selection_trace.append(row)

    def _post_expiry_active_event_involvement(self, node_id):
        """Frozen conservative OR over current unexpired event relationships."""
        node = self.nodes[int(node_id)]
        for eid, event in self.event_relay_events.items():
            if self.step_index >= int(event.get('expires_step', 0)):
                continue
            involved = (
                int(node_id) == int(event.get('source_id', -1))
                or int(node_id) in set(int(n) for n in event.get('alerted_nodes', set()))
                or int(node_id) in set(int(n) for n in event.get('confirmed_nodes', set()))
                or int(node_id) in set(int(n) for n in event.get('confirmed_records', {}))
                or (
                    int(eid) in node.event_watches
                    and int(node.event_watches[int(eid)].get('remaining_steps', 0)) > 0
                )
                or (
                    node.mode in ('alert', 'probe')
                    and node.alert_event_id is not None
                    and int(node.alert_event_id) == int(eid)
                )
            )
            if involved:
                return True
        return False

    def _post_expiry_non_y3_forced_full_rate(self, node_id, active_involvement):
        """Explicit preregistered whitelist; excludes bare expired confirmed tracking."""
        node = self.nodes[int(node_id)]
        if node.role == 'sentinel' or node.mode == 'probe':
            return True
        if node.mode == 'alert' and not node.alert_confirmed:
            return True
        if bool(node.budgeted_frontier_active) and bool(node.budgeted_frontier_high_rate):
            return True
        # Active involvement restores unchanged parent service. It is a known
        # full-rate observer only when the current parent state samples full;
        # an active-event budget demotion is not mislabeled as full-rate.
        if active_involvement and node.mode == 'alert' and node.alert_confirmed:
            return not bool(node.budgeted_frontier_active) or bool(node.budgeted_frontier_high_rate)
        return False

    def _prepare_post_expiry_coverage_sampling(self):
        """B2.8-Y3 deterministic event cover and cross-event physical OR."""
        logical_before_y3 = {
            int(node_id): (
                str(node.mode), bool(node.alert_confirmed), node.alert_event_id,
                tuple(sorted(int(e) for e in node.event_watches)),
                int(node.failed_verification_count),
            )
            for node_id, node in self.nodes.items()
        }
        for node in self.nodes.values():
            node.post_expiry_coverage_active = False
            node.post_expiry_coverage_full_rate = False
        if not bool(getattr(config, 'ALERT_POST_EXPIRY_COVERAGE_SERVICE_ENABLED', False)):
            return

        active = {
            int(node_id): self._post_expiry_active_event_involvement(node_id)
            for node_id in self.nodes
        }
        expired_membership = {int(node_id): set() for node_id in self.nodes}
        expired_events = []
        for eid, event in self.event_relay_events.items():
            if self.step_index < int(event.get('expires_step', 10**9)):
                continue
            confirmed = set(int(n) for n in event.get('confirmed_records', {}))
            if not confirmed:
                continue
            expired_events.append((int(eid), event, confirmed))
            for node_id in confirmed:
                if node_id in expired_membership:
                    expired_membership[node_id].add(int(eid))

        eligible = {
            int(node_id) for node_id, node in self.nodes.items()
            if node.role != 'sentinel'
            and node.mode == 'alert'
            and bool(node.alert_confirmed)
            and bool(expired_membership.get(int(node_id)))
            and not active[int(node_id)]
        }
        selected_by_node = {node_id: set() for node_id in eligible}
        fail_closed_nodes = set()
        event_rows = []

        for eid, event, confirmed in sorted(expired_events, key=lambda item: item[0]):
            event_eligible = sorted(confirmed.intersection(eligible))
            forced = {
                node_id for node_id in confirmed if node_id in self.nodes
                and self._post_expiry_non_y3_forced_full_rate(node_id, active[int(node_id)])
            }
            service_observers = set(event_eligible).union(forced)
            unresolved = set()
            coverage = {}
            for node_id in service_observers:
                covered = {
                    int(nb) for nb in self._get_alert_neighbors(node_id)
                    if int(nb) in self.nodes
                    and self.nodes[int(nb)].role != 'sentinel'
                    and int(nb) not in confirmed
                }
                coverage[int(node_id)] = covered
                unresolved.update(covered)
            remaining = unresolved.difference(set().union(*(coverage[n] for n in forced)) if forced else set())
            chosen = []
            failure_reason = ''
            records = event.get('confirmed_records', {})
            confirmation_step = {}
            for node_id in event_eligible:
                record = records.get(int(node_id))
                try:
                    confirmation_step[node_id] = int(record[0])
                except (TypeError, ValueError, IndexError, KeyError):
                    failure_reason = 'invalid_confirmation_step'
                    break
            if not failure_reason:
                while remaining:
                    ranked = []
                    for node_id in event_eligible:
                        if node_id in chosen:
                            continue
                        gain = len(coverage.get(node_id, set()).intersection(remaining))
                        if gain > 0:
                            ranked.append((-gain, -confirmation_step[node_id], int(node_id)))
                    if not ranked:
                        failure_reason = 'uncoverable_remaining_after_candidate_filter'
                        break
                    _, _, node_id = min(ranked)
                    chosen.append(int(node_id))
                    remaining.difference_update(coverage.get(int(node_id), set()))
            invariant_pass = not failure_reason and not remaining
            if invariant_pass:
                for node_id in chosen:
                    selected_by_node.setdefault(node_id, set()).add(int(eid))
            else:
                fail_closed_nodes.update(event_eligible)

            if bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
                event_rows.append({
                    'step': int(self.step_index), 'record_type': 'event',
                    'event_id': int(eid), 'node_id': '',
                    'retained_confirmed_count': int(len(confirmed)),
                    'eligible_candidate_count': int(len(event_eligible)),
                    'forced_full_observer_count': int(len(forced)),
                    'coverable_unresolved_count': int(len(unresolved)),
                    'selected_count': int(len(chosen) if invariant_pass else 0),
                    'selected_node_ids': ';'.join(map(str, chosen)) if invariant_pass else '',
                    'coverage_invariant_pass': int(invariant_pass),
                    'failure_reason': failure_reason,
                    'active_event_involvement': '',
                    'retained_expired_event_count': '',
                    'selected_by_event_count': '',
                    'physical_full_rate': '',
                    'period2_due_after_clock': '',
                    'physical_service_command': '', 'initial_sample_command': '',
                    'observation_available': '', 'parent_late_sample_override': '',
                    'actual_sample': '', 'sampled': '',
                    'logical_state_preserved_by_y3': '',
                    'logical_mode_before': '', 'logical_mode_after': '',
                    'alert_confirmed_before': '', 'alert_confirmed_after': '',
                    'alert_event_id_before': '', 'alert_event_id_after': '',
                    'event_watch_ids_before': '', 'event_watch_ids_after': '',
                    'failure_count_before': '', 'failure_count_after': '',
                })

        period = max(1, int(getattr(config, 'ALERT_SOFT_WATCH_PERIOD', 2)))
        for node_id in sorted(eligible):
            node = self.nodes[node_id]
            full_rate = node_id in fail_closed_nodes or bool(selected_by_node.get(node_id))
            period2_due = int((int(node.soft_watch_clock) + 1) % period == 0)
            node.post_expiry_coverage_active = True
            node.post_expiry_coverage_full_rate = bool(full_rate)
            logical_after_y3 = (
                str(node.mode), bool(node.alert_confirmed), node.alert_event_id,
                tuple(sorted(int(e) for e in node.event_watches)),
                int(node.failed_verification_count),
            )
            if bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
                event_rows.append({
                    'step': int(self.step_index), 'record_type': 'physical',
                    'event_id': '', 'node_id': int(node_id),
                    'retained_confirmed_count': '',
                    'eligible_candidate_count': '',
                    'forced_full_observer_count': '',
                    'coverable_unresolved_count': '',
                    'selected_count': '',
                    'selected_node_ids': '',
                    'coverage_invariant_pass': int(node_id not in fail_closed_nodes),
                    'failure_reason': 'event_fail_closed' if node_id in fail_closed_nodes else '',
                    'active_event_involvement': int(active[node_id]),
                    'retained_expired_event_count': int(len(expired_membership[node_id])),
                    'selected_by_event_count': int(len(selected_by_node.get(node_id, set()))),
                    'physical_full_rate': int(full_rate),
                    'period2_due_after_clock': period2_due,
                    'physical_service_command': int(bool(full_rate) or bool(period2_due)),
                    'initial_sample_command': '', 'observation_available': '',
                    'parent_late_sample_override': '', 'actual_sample': '', 'sampled': '',
                    'logical_state_preserved_by_y3': int(logical_before_y3[node_id] == logical_after_y3),
                    'logical_mode_before': str(node.mode), 'logical_mode_after': '',
                    'alert_confirmed_before': int(bool(node.alert_confirmed)), 'alert_confirmed_after': '',
                    'alert_event_id_before': '' if node.alert_event_id is None else int(node.alert_event_id),
                    'alert_event_id_after': '',
                    'event_watch_ids_before': ';'.join(map(str, sorted(int(e) for e in node.event_watches))),
                    'event_watch_ids_after': '',
                    'failure_count_before': int(node.failed_verification_count), 'failure_count_after': '',
                })
        if bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
            self.post_expiry_coverage_selection_trace.extend(event_rows)

    def step(self):
        self._handoff_confirmed_alert_after_event_expiry()
        self._apply_confirmed_tracking_handoff_release()
        self._prepare_budgeted_frontier_sampling()
        self._prepare_post_expiry_coverage_sampling()
        trace_slot_states = None
        if bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
            trace_slot_states = {
                int(node_id): {
                    'mode': node.mode,
                    'alert_confirmed': bool(getattr(node, 'alert_confirmed', False)),
                    'has_event_watch': bool(node.active_event_watches()),
                    'budgeted_frontier_active': bool(getattr(node,'budgeted_frontier_active',False)),
                    'budgeted_frontier_high_rate': bool(getattr(node,'budgeted_frontier_high_rate',False)),
                }
                for node_id, node in self.nodes.items()
            }
        for node in self.nodes.values():
            node.step_cooldown()
            if (
                bool(getattr(config, 'ALERT_CLEAR_ON_EVENT_EXPIRY', False))
                and node.mode in ('alert', 'probe')
                and node.alert_event_id is not None
            ):
                event = self.event_relay_events.get(int(node.alert_event_id))
                if event is not None and self.step_index >= int(event.get('expires_step', 10**9)):
                    if node.mode == 'probe':
                        node._clear_probe_state(start_local_cooldown=False)
                    else:
                        node._clear_alert_state(start_local_cooldown=False)
                    self.event_relay_stats['event_expiry_clear_count'] += 1
        pre_alert_nodes = {node_id for node_id, node in self.nodes.items() if node.mode == 'alert'}
        pre_timer_nodes = {node_id for node_id, node in self.nodes.items() if node.mode in ('alert', 'probe')}
        for node in self.nodes.values():
            node.predict()
        triggered_alert_sources = {}
        gt_anomaly_nodes = set()
        step_records = {}
        
        for node_id, node in self.nodes.items():
            gt_val, gt_anomaly, gt_event_ids = self.get_ground_truth(node_id, self.current_time)
            if gt_anomaly:
                gt_anomaly_nodes.add(node_id)
            is_sampled = node.should_sample()
            anomaly_detected = False
            local_trigger = False
            z = None
            
            if is_sampled and gt_val is not None:
                if node.mode != 'alert' and node.active_event_watches():
                    self.event_relay_stats['soft_watch_sample_count'] += 1
                    if not gt_anomaly:
                        self.event_relay_stats['soft_watch_false_sample_count'] += 1
                noise = self._measurement_noise(node)
                z = gt_val + noise
                node.update(z)
                node.update_alert_exit_state(z)
                anomaly_detected = node.is_anomaly_signal()
                if node.role == 'sentinel':
                    local_trigger = bool(node.check_anomaly())
                    if local_trigger and node.mode == 'alert':
                        node.confirm_alert()
                    if local_trigger:
                        nis_val = float(node.last_nis) if node.last_nis is not None and not np.isnan(node.last_nis) else np.nan
                        old = triggered_alert_sources.get(node_id, np.nan)
                        if np.isnan(old) or (not np.isnan(nis_val) and nis_val > old):
                            triggered_alert_sources[node_id] = nis_val
                elif node.self_trigger_enabled and (not node.in_alert_cooldown()):
                    local_trigger = bool(node.check_anomaly())
                    if local_trigger and node.mode == 'alert':
                        node.confirm_alert()
                    if local_trigger:
                        nis_val = float(node.last_nis) if node.last_nis is not None and not np.isnan(node.last_nis) else np.nan
                        old = triggered_alert_sources.get(node_id, np.nan)
                        if np.isnan(old) or (not np.isnan(nis_val) and nis_val > old):
                            triggered_alert_sources[node_id] = nis_val
            else:
                node.update(None)
                # Soft-watch intentionally samples intermittently. Resetting
                # the sequential detector on every skipped slot makes delayed
                # confirmation mathematically impossible.
                if not node.active_event_watches():
                    node.reset_detector_state()
            step_records[node_id] = {
                "sampled": bool(is_sampled and gt_val is not None),
                "initial_sample_command": bool(is_sampled),
                "parent_late_sample_override": False,
                "anomaly_detected": bool(anomaly_detected),
                "detector_triggered": bool(local_trigger),
                "gt_anomaly": bool(gt_anomaly),
                "gt_event_ids": gt_event_ids,
                "z": z,
                "gt_val": gt_val
            }
        self.current_step_gt_event_ids = {
            int(node_id): list(rec.get("gt_event_ids", [])) for node_id, rec in step_records.items()
        }
        newly_alerted_nodes = set()
        if (
            bool(getattr(config, 'ALERT_EVENT_RELAY_ENABLED', False))
            and self.enable_sentinel_alert_trigger
            and self.alert_duration_steps > 0
            and (len(triggered_alert_sources) > 0 or str(getattr(config, 'ALERT_EVENT_REQUERY_MODE', 'none')).lower() != 'none')
        ):
            event_new_nodes, event_rows = self._run_event_relay(triggered_alert_sources, pre_alert_nodes)
            newly_alerted_nodes.update(event_new_nodes)
            self.alert_events.extend(event_rows)
        elif self.enable_sentinel_alert_trigger and self.alert_duration_steps > 0 and len(triggered_alert_sources) > 0:
            triggered_nodes = set()
            event_max_hop = 0
            event_forwarding_count = 0
            for source_id, nis_val in triggered_alert_sources.items():
                source_node = self.nodes[source_id]
                gated = bool(getattr(config, 'ALERT_CONFIRMATION_GATED_RELAY', False))
                if gated and source_node.role != 'sentinel':
                    planned_hops = max(0, int(source_node.alert_relay_budget))
                else:
                    planned_hops = self._compute_dynamic_alert_hops(nis_val, source_id=source_id, active_nodes=pre_alert_nodes)
                if gated and planned_hops <= 0:
                    source_node.alert_relay_budget = 0
                    continue
                initial_hops = max(1, int(getattr(config, 'ALERT_GATED_INITIAL_HOPS', 1)))
                route_hops = min(planned_hops, initial_hops) if gated else planned_hops
                alert_targets, forwarding_edges, hop_map = self._resolve_alert_routes(source_id, dynamic_max_hops=route_hops)
                if bool(getattr(config, 'ALERT_SPATIAL_TARGET_GATE', False)):
                    radius_per_hop = float(getattr(config, 'ALERT_SPATIAL_RADIUS_PER_HOP', config.NEIGHBOR_RADIUS))
                    alert_targets = self._spatially_plausible_alert_targets(
                        source_id, alert_targets, radius_per_hop * max(1, route_hops)
                    )
                if gated:
                    alert_targets = {nid for nid in alert_targets if nid not in pre_alert_nodes}
                    required_nodes = set(alert_targets)
                    parent_by_child = {child: parent for parent, child in forwarding_edges}
                    for target_id in list(alert_targets):
                        current = target_id
                        while current in parent_by_child and current != source_id:
                            current = parent_by_child[current]
                            required_nodes.add(current)
                    forwarding_edges = [(src, dst) for src, dst in forwarding_edges if dst in required_nodes]
                    hop_map = {nid: hop for nid, hop in hop_map.items() if nid == source_id or nid in required_nodes}
                tx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                rx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                self.node_comm_energy_records.append({
                    "time": self.current_time,
                    "step_type": "sentinel_tx",
                    "node_id": int(source_id),
                    "peer_count": int(sum(1 for src, _ in forwarding_edges if src == source_id)),
                    "comm_energy_mj": float(tx_energy * sum(1 for src, _ in forwarding_edges if src == source_id))
                })
                for relay_id in sorted({src for src, _ in forwarding_edges if src != source_id}):
                    relay_count = sum(1 for src, _ in forwarding_edges if src == relay_id)
                    self.node_comm_energy_records.append({
                        "time": self.current_time, "step_type": "alert_relay_tx",
                        "node_id": int(relay_id), "peer_count": int(relay_count),
                        "comm_energy_mj": float(tx_energy * relay_count)
                    })
                self.nodes[source_id].trigger_alert(self._alert_duration_for_hop(max(1, source_node.alert_hop)), confirmed=True)
                if gated:
                    source_node.alert_relay_budget = 0
                for neighbor_id in alert_targets:
                    if neighbor_id in self.nodes and neighbor_id != source_id:
                        was_alert = self.nodes[neighbor_id].mode == 'alert'
                        local_hop = int(hop_map.get(neighbor_id, 1))
                        target_hop = int(source_node.alert_hop) + local_hop if gated else local_hop
                        target_budget = max(0, planned_hops - local_hop) if gated else 0
                        self.nodes[neighbor_id].trigger_alert(
                            self._alert_duration_for_hop(target_hop), confirmed=False,
                            relay_budget=target_budget, alert_hop=target_hop
                        )
                        if not was_alert:
                            newly_alerted_nodes.add(neighbor_id)
                        triggered_nodes.add(neighbor_id)
                        self.node_comm_energy_records.append({
                            "time": self.current_time,
                            "step_type": "alert_rx",
                            "node_id": int(neighbor_id),
                            "peer_count": 1,
                            "comm_energy_mj": float(rx_energy)
                        })
                        event_max_hop = max(event_max_hop, target_hop)
                # Relay sentinels also receive the packet even though they are
                # intentionally excluded from normal-node wake-up targets.
                for relay_target in sorted(set(hop_map) - {source_id} - set(alert_targets)):
                    self.node_comm_energy_records.append({
                        "time": self.current_time, "step_type": "alert_relay_rx",
                        "node_id": int(relay_target), "peer_count": 1,
                        "comm_energy_mj": float(rx_energy)
                    })
                event_forwarding_count += len(forwarding_edges)
            self.alert_events.append({
                'time': self.current_time,
                'sentinels': sorted(list(triggered_alert_sources.keys())),
                'neighbor_count': len(triggered_nodes),
                'neighbors': sorted(list(triggered_nodes)),
                'max_hops': event_max_hop,
                'forwarding_message_count': event_forwarding_count
            })
        if self.oracle_wakeup_enabled and self.alert_duration_steps > 0 and len(gt_anomaly_nodes) > 0:
            oracle_triggered_nodes = set()
            # Oracle-local reacts once when the diffusion front reaches a new
            # node; rebroadcasting from every active node at every step would
            # be an unrealistically expensive oracle rather than an upper
            # bound on targeted wake-up.
            source_nodes = sorted(list(gt_anomaly_nodes - self.previous_gt_anomaly_nodes))
            for source_id in source_nodes:
                oracle_targets = set(self._get_oracle_neighbors(source_id))
                oracle_targets.add(source_id)
                tx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_TX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                rx_energy = float(config.NODE_SUPPLY_VOLTAGE_V) * float(config.ALERT_RX_CURRENT_MA) / 1000.0 * float(config.ALERT_PACKET_DURATION_SEC) * 1000.0
                self.node_comm_energy_records.append({
                    "time": self.current_time,
                    "step_type": "oracle_tx",
                    "node_id": int(source_id),
                    "peer_count": int(len(oracle_targets)),
                    "comm_energy_mj": float(tx_energy * len(oracle_targets))
                })
                for target_id in oracle_targets:
                    if target_id in self.nodes:
                        was_alert = self.nodes[target_id].mode == 'alert'
                        self.nodes[target_id].trigger_alert(self.alert_duration_steps, confirmed=False)
                        if not was_alert:
                            newly_alerted_nodes.add(target_id)
                        oracle_triggered_nodes.add(target_id)
                        self.node_comm_energy_records.append({
                            "time": self.current_time,
                            "step_type": "oracle_rx",
                            "node_id": int(target_id),
                            "peer_count": 1,
                            "comm_energy_mj": float(rx_energy)
                        })
            oracle_event = {
                'time': self.current_time,
                'sentinels': source_nodes,
                'neighbor_count': len(oracle_triggered_nodes),
                'neighbors': sorted(list(oracle_triggered_nodes))
            }
            self.alert_events.append(oracle_event)
            self.oracle_alert_events.append(oracle_event)
        for node_id in sorted(list(newly_alerted_nodes)):
            rec = step_records.get(node_id, None)
            if rec is None:
                continue
            if rec["sampled"]:
                continue
            gt_val = rec["gt_val"]
            if gt_val is None:
                continue
            node = self.nodes[node_id]
            if node.mode == 'probe':
                # Probe horizon L means future observations t+1..t+L. Do not
                # force an immediate t observation when the probe is admitted.
                continue
            noise = self._measurement_noise(node)
            z = gt_val + noise
            node.update(z)
            node.update_alert_exit_state(z)
            late_detected = bool(node.is_anomaly_signal())
            rec["sampled"] = True
            rec["parent_late_sample_override"] = True
            rec["z"] = z
            rec["anomaly_detected"] = bool(rec["anomaly_detected"] or late_detected)
        current_front_nodes = set(gt_anomaly_nodes) - set(self.previous_gt_anomaly_nodes)
        self.previous_gt_anomaly_nodes = set(gt_anomaly_nodes)
        if bool(getattr(config, 'STRUCTURAL_TRACE_ENABLED', False)):
            for event_id, event in self.event_relay_events.items():
                linked_true_ids = set().union(*[
                    set(component.get('true_event_ids', set()))
                    for component in event.get('components', {}).values()
                ]) if event.get('components') else set()
                for node_id in current_front_nodes:
                    rec = step_records.get(int(node_id), {})
                    if rec.get('sampled') and linked_true_ids.intersection(set(rec.get('gt_event_ids', []))):
                        self._update_realert_funnel_records(
                            event_id, node_id, useful_front_observation=1,
                            useful_front_observation_step=int(self.step_index),
                        )
        for node_id, node in self.nodes.items():
            rec = step_records[node_id]
            node.log_status(
                rec["z"],
                sampled=rec["sampled"],
                anomaly_detected=rec["anomaly_detected"],
                detector_triggered=rec["detector_triggered"],
                gt_anomaly=rec["gt_anomaly"],
                gt_event_ids=rec["gt_event_ids"]
            )

        triggered_source_nodes = set(triggered_alert_sources.keys())
        self.event_relay_stats['full_alert_node_time'] += sum(
            1 for node_id in pre_timer_nodes if self.nodes[node_id].mode == 'alert'
        )
        self.event_relay_stats['probe_node_time'] += sum(
            1 for node_id in pre_timer_nodes if self.nodes[node_id].mode == 'probe'
        )
        for node_id in pre_timer_nodes:
            node = self.nodes[node_id]
            if node.mode == 'probe' and node.probe_started_this_step:
                node.probe_started_this_step = False
                continue
            monitor_neighbors = set(self._get_alert_monitor_neighbors(node_id))
            if node.mode == 'alert':
                node.update_neighbor_quiet_state(len(monitor_neighbors & triggered_source_nodes) > 0)
            alert_neighbors = [nid for nid in monitor_neighbors if nid in self.nodes and self.nodes[nid].mode == 'alert']
            if len(alert_neighbors) == 0:
                neighbor_recovery_ratio = 1.0
            else:
                recovered_neighbors = sum(1 for nid in alert_neighbors if self.nodes[nid].is_background_recovered())
                neighbor_recovery_ratio = float(recovered_neighbors) / float(len(alert_neighbors))
            was_probe = node.mode == 'probe'
            probe_upgrade_cap = max(0, int(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_ACTIVE_CAP', 0)))
            allow_probe_upgrade = True
            if was_probe and probe_upgrade_cap > 0:
                probe_event_id = getattr(node, 'alert_event_id', None)
                active_for_event = sum(
                    1 for other in self.nodes.values()
                    if other.mode == 'alert' and getattr(other, 'alert_event_id', None) == probe_event_id
                )
                allow_probe_upgrade = active_for_event < probe_upgrade_cap
                if not allow_probe_upgrade:
                    self.event_relay_stats['probe_upgrade_cap_block_count'] += 1
            timer_result = node.step_timer(
                neighbor_recovery_ratio=neighbor_recovery_ratio,
                allow_probe_upgrade=allow_probe_upgrade,
            ) or {}
            failed_event_id = timer_result.get('failed_event_id')
            if was_probe:
                rec = step_records.get(node_id, {})
                glr_value = max(float(getattr(node, 'glr_stat_up', 0.0) or 0.0),
                                float(getattr(node, 'glr_stat_down', 0.0) or 0.0))
                predicted_value = float((node.H @ node.x_pred)[0, 0]) if node.x_pred is not None else np.nan
                event_id_for_trace = getattr(node, 'alert_event_id', None)
                if event_id_for_trace is None:
                    event_id_for_trace = failed_event_id
                self.probe_evidence_records.append({
                    'step': int(self.step_index), 'time': self.current_time,
                    'event_id': event_id_for_trace, 'node_id': int(node_id),
                    'probe_sample_step': int(getattr(node, 'probe_elapsed', 0)),
                    'probe_start_step': getattr(node, 'probe_start_step', None),
                    'probe_end_step': getattr(node, 'probe_end_step', None),
                    'observation_available': int(rec.get('gt_val') is not None),
                    'ground_truth_affected': int(bool(rec.get('gt_anomaly', False))),
                    'ground_truth_front': int(node_id in current_front_nodes),
                    'raw_value': rec.get('gt_val', np.nan), 'predicted_value': predicted_value,
                    'innovation': float(getattr(node, 'last_innovation', np.nan)),
                    'abs_innovation': abs(float(getattr(node, 'last_signed_norm_innovation', 0.0) or 0.0)),
                    'nis': float(getattr(node, 'last_nis', np.nan)), 'glr': glr_value,
                    'weak_streak': int(getattr(node, 'probe_weak_streak', 0)),
                    'upgrade_threshold': float(getattr(config, 'ALERT_CONFIRMATION_REALERT_PROBE_UPGRADE_INNOVATION_THRESHOLD', 2.0)),
                    'upgrade_decision': int(bool(timer_result.get('probe_upgraded'))),
                    'probe_failed': int(bool(timer_result.get('probe_failed'))),
                })
            if failed_event_id is not None and int(failed_event_id) in self.event_relay_events:
                failed_event = self.event_relay_events[int(failed_event_id)]
                failed_event.setdefault('failed_verification_nodes', set()).add(int(node_id))
                failed_event.setdefault('failed_node_snapshots', {})[int(node_id)] = self._failed_node_snapshot(failed_event, node_id)
            if was_probe and timer_result.get('probe_upgraded'):
                self.event_relay_stats['probe_upgrade_count'] += 1
                event_id = getattr(node, 'alert_event_id', None)
                if event_id is not None:
                    self._update_realert_target_records(
                        event_id, node_id, probe_upgraded=1,
                        upgrade_reason=timer_result.get('upgrade_reason', ''),
                    )
                    self._update_realert_funnel_records(
                        event_id, node_id, probe_upgraded=1,
                        probe_upgrade_step=int(self.step_index),
                    )
            elif was_probe and timer_result.get('probe_failed'):
                self.event_relay_stats['probe_fail_count'] += 1
                if failed_event_id is not None:
                    self._update_realert_target_records(failed_event_id, node_id, probe_failed=1)
        self._append_structural_trace(step_records, current_front_nodes, trace_slot_states)
        self.current_time += self.time_step
        self.step_index += 1
