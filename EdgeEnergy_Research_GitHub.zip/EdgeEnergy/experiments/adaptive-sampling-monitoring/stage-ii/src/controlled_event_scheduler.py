"""Offline-only controlled A/B/C anomaly scheduling.

The manifest is consumed only by the anomaly injector.  Online policies never
receive template roles, targets, masks, or future outcomes.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def graph_hash(adjacency):
    edges = sorted((int(a), int(b)) for a, ns in adjacency.items() for b in ns if int(a) < int(b))
    return hashlib.sha256(json.dumps(edges, separators=(",", ":")).encode()).hexdigest()


def load_bank(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def make_manifest(bank, seed, total_steps=48):
    templates = bank["templates"]
    by_type = {kind: [t for t in templates if t["contract_type"] == kind]
               for kind in ("A2", "A3", "B", "C")}
    rng = __import__("numpy").random.default_rng(int(seed))
    events = []
    starts = [3, 14, 25, 36]
    for index, kind in enumerate(("A2", "A3", "B", "C")):
        choices = by_type[kind]
        if not choices:
            raise ValueError(f"controlled template bank has no {kind} template")
        template = dict(choices[int(rng.integers(0, len(choices)))])
        event = {
            **template,
            "manifest_event_id": index + 1,
            "start_step": starts[index],
            "duration_steps": min(11, total_steps - starts[index]),
            "propagation_delay_steps": 2,
            "magnitude": float(rng.choice([-1, 1]) * rng.uniform(2.8, 3.8)),
            "hop_decay": float(rng.uniform(0.72, 0.84)),
        }
        events.append(event)
    return {"schema": "controlled_gate_a_manifest_v1", "seed": int(seed),
            "graph_sha256": bank["graph_sha256"], "events": events}


def install_manifest(injector, manifest, start_time, time_step_delta):
    configured = []
    for item in manifest["events"]:
        event_id = injector.add_spatiotemporal_diffusion_anomaly(
            start_time=start_time + int(item["start_step"]) * time_step_delta,
            duration_steps=int(item["duration_steps"]),
            source_node_id=int(item["source_node"]),
            base_magnitude=float(item["magnitude"]), graph="spatial",
            max_hops=int(item["max_hops"]),
            propagation_delay_steps=int(item["propagation_delay_steps"]),
            hop_decay=float(item["hop_decay"]), temporal_growth_steps=0,
            onset_mode="abrupt", recovery_mode="abrupt", recovery_steps=0,
            propagation_edges=item["active_spatial_edges"],
            allowed_nodes=item["allowed_nodes"], contract_type=item["contract_type"],
        )
        configured.append({
            "event_id": event_id, "type": "controlled_diffusion",
            "contract_type": item["contract_type"], "template_id": item["template_id"],
            "start_step": item["start_step"], "duration_steps": item["duration_steps"],
            "center_or_source_node": item["source_node"], "radius_or_hops": item["max_hops"],
            "magnitude": item["magnitude"], "graph": "spatial",
            "propagation_delay_steps": item["propagation_delay_steps"],
            "hop_decay": item["hop_decay"], "positive_targets": ",".join(map(str, item.get("positive_targets", []))),
            "negative_targets": ",".join(map(str, item.get("negative_targets", []))),
        })
    return configured

