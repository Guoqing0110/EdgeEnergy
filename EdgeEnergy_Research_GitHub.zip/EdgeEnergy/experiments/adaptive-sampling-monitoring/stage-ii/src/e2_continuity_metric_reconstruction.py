"""Read-only Phase II-E2 continuity and wake-up metric reconstruction.

This script never imports or invokes the simulator.  It reads only the
explicit, pre-existing run roots below and fails closed on seed scope,
duplicate physical node-slots, missing joins, or schema drift.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "phase2_paper_evidence" / "e2_continuity_metric_reconstruction"


@dataclass(frozen=True)
class Source:
    block: str
    method: str
    role: str
    comparability: str
    root: Path
    seeds: tuple[int, ...]
    seed_width: int


SOURCES = (
    Source(
        "E1_401_420",
        "DF-ReAlert",
        "primary_frozen_method",
        "paired_within_E1_only",
        ROOT / "phase2_paper_evidence/e1_budget_matched_baselines/runs/DF-ReAlert",
        tuple(range(401, 421)),
        0,
    ),
    Source(
        "E1_401_420",
        "Random Top-K",
        "budget_matched_selector_control",
        "paired_within_E1_only",
        ROOT / "phase2_paper_evidence/e1_budget_matched_baselines/runs/Random-TopK",
        tuple(range(401, 421)),
        0,
    ),
    Source(
        "E1_401_420",
        "Nearest-front Top-K",
        "budget_matched_selector_control",
        "paired_within_E1_only",
        ROOT / "phase2_paper_evidence/e1_budget_matched_baselines/runs/Nearest-front-TopK",
        tuple(range(401, 421)),
        0,
    ),
    Source(
        "E1_401_420",
        "Lowest-route-cost Top-K",
        "budget_matched_selector_control",
        "paired_within_E1_only",
        ROOT / "phase2_paper_evidence/e1_budget_matched_baselines/runs/Lowest-route-cost-TopK",
        tuple(range(401, 421)),
        0,
    ),
    Source(
        "E3_421_440",
        "DF-ReAlert",
        "second_window_frozen_method",
        "paired_within_E3_only",
        ROOT / "phase2_paper_evidence/e3_second_temporal_window/runs/DF-ReAlert",
        tuple(range(421, 441)),
        0,
    ),
    Source(
        "E3_421_440",
        "Random Top-K",
        "second_window_budget_matched_selector_control",
        "paired_within_E3_only",
        ROOT / "phase2_paper_evidence/e3_second_temporal_window/runs/Random-TopK",
        tuple(range(421, 441)),
        0,
    ),
    Source(
        "E3_421_440",
        "Nearest-front Top-K",
        "second_window_budget_matched_selector_control",
        "paired_within_E3_only",
        ROOT / "phase2_paper_evidence/e3_second_temporal_window/runs/Nearest-front-TopK",
        tuple(range(421, 441)),
        0,
    ),
    Source(
        "E3_421_440",
        "Lowest-route-cost Top-K",
        "second_window_budget_matched_selector_control",
        "paired_within_E3_only",
        ROOT / "phase2_paper_evidence/e3_second_temporal_window/runs/Lowest-route-cost-TopK",
        tuple(range(421, 441)),
        0,
    ),
    Source(
        "E3_421_440",
        "Matched fixed two-hop verify=3",
        "second_window_fixed_regional_response_control",
        "paired_within_E3_only",
        ROOT / "phase2_paper_evidence/e3_second_temporal_window/runs/Fixed-two-hop-verify3",
        tuple(range(421, 441)),
        0,
    ),
    Source(
        "VIEWED_B2_7_201_220",
        "DF-ReAlert (corrected Y1 identity)",
        "viewed_diagnostic_continuity_bridge",
        "not_independent_paper_evidence",
        ROOT / "phase2_method_development/b2_7_budgeted_frontier_tracking/corrected_runs/Y1",
        tuple(range(201, 221)),
        0,
    ),
    Source(
        "VIEWED_B2_3_201_220",
        "Matched fixed two-hop verify=3",
        "fixed_regional_response_control",
        "viewed_diagnostic_only",
        ROOT / "phase2_method_development/b2_3_full_development_replay/runs/matched_fixed_two_hop_verify3",
        tuple(range(201, 221)),
        0,
    ),
    Source(
        "LEGACY_1_10",
        "ISSC-like one-hop reference",
        "legacy_reference_provenance_unverified",
        "not_paired_to_current_blocks",
        ROOT / "src/output/journal_ablation/one_hop",
        tuple(range(1, 11)),
        4,
    ),
)

REQUIRED = (
    "step_node_status.csv",
    "anomaly_active_nodes_by_step.csv",
    "task8_metrics_main.csv",
    "task6_energy_proxy.csv",
)
FORBIDDEN = set(range(121, 141)) | set(range(301, 341))


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def one_row(path: Path) -> dict[str, str]:
    rows = read_rows(path)
    if len(rows) != 1:
        raise RuntimeError(f"{path}: expected one data row, found {len(rows)}")
    return rows[0]


def number(value: str | None) -> float:
    if value is None or value == "":
        return math.nan
    return float(value)


def close(a: float, b: float, tol: float = 1e-10) -> bool:
    return (math.isnan(a) and math.isnan(b)) or math.isclose(a, b, rel_tol=tol, abs_tol=tol)


def run_dir(source: Source, seed: int) -> Path:
    if seed in FORBIDDEN:
        raise RuntimeError(f"forbidden seed requested: {seed}")
    suffix = f"{seed:0{source.seed_width}d}" if source.seed_width else str(seed)
    parent = source.root / f"seed_{suffix}"
    runs = sorted(path for path in parent.iterdir() if path.is_dir()) if parent.is_dir() else []
    if len(runs) != 1:
        raise RuntimeError(f"{source.method} seed {seed}: expected one run, found {len(runs)}")
    for name in REQUIRED:
        if not (runs[0] / name).is_file():
            raise RuntimeError(f"missing {name}: {runs[0]}")
    return runs[0]


def percentile95(values: list[int]) -> float:
    return float(np.percentile(np.asarray(values, dtype=float), 95, method="linear")) if values else math.nan


def reconstruct(source: Source, seed: int, path: Path) -> tuple[dict[str, object], dict[str, int]]:
    raw_status = read_rows(path / "step_node_status.csv")
    status: dict[tuple[int, int], dict[str, object]] = {}
    for row in raw_status:
        node_text = row.get("node_id", "")
        if node_text in ("", "-1"):
            continue
        key = (int(row["step"]), int(node_text))
        if key in status:
            raise RuntimeError(f"duplicate physical node-slot {key}: {path}")
        sampled = int(float(row["sampled"]))
        if sampled not in (0, 1):
            raise RuntimeError(f"non-binary physical sample at {key}: {sampled}")
        status[key] = {
            "sampled": sampled,
            "alert": int(row["mode"] == "alert"),
            "affected": int(float(row["gt_anomaly_flag"])) == 1,
        }
    if not status:
        raise RuntimeError(f"no physical node-slots: {path}")

    active_rows = read_rows(path / "anomaly_active_nodes_by_step.csv")
    active: dict[int, dict[int, set[int]]] = {}
    active_keys: set[tuple[int, int, int]] = set()
    awsr_numerator = 0
    for row in active_rows:
        event_id, step, node = int(row["event_id"]), int(row["step"]), int(row["node_id"])
        membership = (event_id, step, node)
        if membership in active_keys:
            raise RuntimeError(f"duplicate event membership {membership}: {path}")
        active_keys.add(membership)
        if (step, node) not in status:
            raise RuntimeError(f"active membership missing physical slot {membership}: {path}")
        active.setdefault(event_id, {}).setdefault(step, set()).add(node)
        awsr_numerator += int(status[(step, node)]["sampled"])

    detected_delays: list[int] = []
    restricted_delays: list[int] = []
    missed_durations: list[int] = []
    front_total = 0
    front_hits = 0
    for event_steps in active.values():
        previous: set[int] = set()
        for arrival in sorted(event_steps):
            current = event_steps[arrival]
            front = current - previous
            front_total += len(front)
            for node in front:
                slot = status[(arrival, node)]
                front_hits += int(bool(slot["alert"]) and bool(slot["sampled"]))
                support = [step for step in sorted(event_steps) if step >= arrival and node in event_steps[step]]
                hit = next(
                    (
                        step
                        for step in support
                        if bool(status[(step, node)]["alert"]) and bool(status[(step, node)]["sampled"])
                    ),
                    None,
                )
                if hit is None:
                    penalty = int(max(support) - arrival + 1) if support else 1
                    missed_durations.append(penalty)
                    restricted_delays.append(penalty)
                else:
                    delay = int(hit - arrival)
                    detected_delays.append(delay)
                    restricted_delays.append(delay)
            previous = current

    ordered_keys = sorted(status)
    sampled_count = sum(int(status[key]["sampled"]) for key in ordered_keys)
    total_slots = len(ordered_keys)
    alert_count = sum(int(status[key]["alert"]) for key in ordered_keys)
    false_count = sum(int(status[key]["alert"]) and not bool(status[key]["affected"]) for key in ordered_keys)
    useful_sample_count = sum(
        int(status[key]["alert"]) and int(status[key]["sampled"]) and bool(status[key]["affected"])
        for key in ordered_keys
    )
    false_episodes = 0
    nodes = sorted({node for _, node in ordered_keys})
    for node in nodes:
        previous_false = False
        for step in sorted(step for step, candidate in ordered_keys if candidate == node):
            slot = status[(step, node)]
            current_false = bool(slot["alert"]) and not bool(slot["affected"])
            false_episodes += int(current_false and not previous_false)
            previous_false = current_false

    task8 = one_row(path / "task8_metrics_main.csv")
    energy = one_row(path / "task6_energy_proxy.csv")
    awsr = awsr_numerator / len(active_keys) if active_keys else math.nan
    gsr = sampled_count / total_slots
    front_recall = front_hits / front_total if front_total else math.nan
    detected_mean = statistics.fmean(detected_delays) if detected_delays else math.nan
    restricted_mean = statistics.fmean(restricted_delays) if restricted_delays else math.nan
    over_wakeup = false_count / alert_count if alert_count else math.nan
    useful_precision = useful_sample_count / alert_count if alert_count else math.nan

    def optional_close(actual: float, expected_text: str | None) -> int | None:
        expected = number(expected_text)
        return None if math.isnan(expected) else int(close(actual, expected))

    def optional_integer(actual: int, expected_text: str | None) -> int | None:
        expected = number(expected_text)
        return None if math.isnan(expected) else int(actual == int(expected))

    # Legacy references do not export every front metric.  Missing source fields
    # are explicitly NA and do not abort reconstruction; an exported value that
    # disagrees with the trace remains a hard failure.
    legacy_front_definition = source.role == "legacy_reference_provenance_unverified"
    checks = {
        "awsr_matches_runtime": optional_close(awsr, task8.get("anomaly_window_sampling_ratio")),
        "gsr_matches_runtime": optional_close(gsr, energy.get("sampling_ratio_vs_full")),
        "front_recall_matches_runtime": None if legacy_front_definition else optional_close(front_recall, task8.get("diffusion_front_recall")),
        "detected_delay_matches_runtime": None if legacy_front_definition else optional_close(detected_mean, task8.get("front_detection_delay_detected_mean_steps")),
        "restricted_delay_matches_runtime": None if legacy_front_definition else optional_close(restricted_mean, task8.get("front_detection_delay_mean_steps")),
        "miss_count_matches_runtime": None if legacy_front_definition else optional_integer(len(missed_durations), task8.get("front_detection_miss_count")),
        "false_node_time_matches_runtime": None if legacy_front_definition else optional_integer(false_count, task8.get("false_wakeup_node_time")),
        "over_wakeup_matches_runtime": None if legacy_front_definition else optional_close(over_wakeup, task8.get("over_wakeup_ratio")),
    }
    row: dict[str, object] = {
        "evidence_block": source.block,
        "method": source.method,
        "method_role": source.role,
        "comparability": source.comparability,
        "seed": seed,
        "awsr_affected_event_membership": awsr,
        "awsr_sampled_memberships": awsr_numerator,
        "awsr_eligible_memberships": len(active_keys),
        "gsr_physical_node_slots": gsr,
        "sampled_physical_node_slots": sampled_count,
        "eligible_physical_node_slots": total_slots,
        "front_recall": front_recall,
        "front_delay_detected_mean_slots": detected_mean,
        "front_delay_detected_p95_slots": percentile95(detected_delays),
        "front_delay_restricted_mean_slots": restricted_mean,
        "missed_front_count": len(missed_durations),
        "missed_front_duration_total_slots": sum(missed_durations),
        "missed_front_duration_mean_slots": statistics.fmean(missed_durations) if missed_durations else 0.0,
        "coverage": number(task8.get("alert_coverage_l")),
        "over_wakeup_ratio": over_wakeup,
        "false_wakeup_node_time": false_count,
        "false_wakeup_episode_count": false_episodes,
        "useful_wakeup_precision": useful_precision,
        "useful_sampled_alert_node_time": useful_sample_count,
        "total_alert_node_time": alert_count,
        "normal_detector_false_alarm_steps_not_false_wakeup_count": number(task8.get("normal_false_alarm_steps")),
        "run_dir": str(path.relative_to(ROOT)).replace("\\", "/"),
    }
    return row, checks


def mean(values: Iterable[object]) -> float:
    numeric = [float(value) for value in values if value is not None and not math.isnan(float(value))]
    return statistics.fmean(numeric) if numeric else math.nan


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    run_rows: list[dict[str, object]] = []
    check_totals: dict[str, int] = {}
    check_counts: dict[str, int] = {}
    input_hash_lines: list[str] = []
    for source in SOURCES:
        for seed in source.seeds:
            path = run_dir(source, seed)
            row, checks = reconstruct(source, seed, path)
            run_rows.append(row)
            for key, passed in checks.items():
                if passed is None:
                    continue
                check_counts[key] = check_counts.get(key, 0) + 1
                check_totals[key] = check_totals.get(key, 0) + passed
                if not passed:
                    raise RuntimeError(f"reconstruction mismatch: {key}: {path}")
            for name in REQUIRED:
                file = path / name
                input_hash_lines.append(f"{file.relative_to(ROOT).as_posix()}\t{sha256(file)}")

    run_file = OUT / "E2_CORRECTED_RUN_LEVEL_METRICS.csv"
    write_csv(run_file, run_rows)
    metric_names = [
        key
        for key in run_rows[0]
        if key
        not in {
            "evidence_block",
            "method",
            "method_role",
            "comparability",
            "seed",
            "run_dir",
        }
    ]
    aggregates: list[dict[str, object]] = []
    for source in SOURCES:
        rows = [row for row in run_rows if row["evidence_block"] == source.block and row["method"] == source.method]
        aggregate: dict[str, object] = {
            "evidence_block": source.block,
            "method": source.method,
            "method_role": source.role,
            "comparability": source.comparability,
            "seed_range": f"{min(source.seeds)}-{max(source.seeds)}",
            "n_runs": len(rows),
        }
        aggregate.update({f"mean_{key}": mean(row[key] for row in rows) for key in metric_names})
        aggregates.append(aggregate)

    primary_file = OUT / "E2_CORRECTED_PRIMARY_METHOD_METRICS.csv"
    write_csv(primary_file, aggregates)
    inventory_digest = hashlib.sha256("\n".join(sorted(input_hash_lines)).encode("utf-8")).hexdigest().upper()
    receipt = {
        "phase": "Phase II-E2",
        "status": "PASS_WITH_DEFINITION_LIMITATION",
        "execution_type": "READ_ONLY_RECONSTRUCTION_NO_SIMULATION",
        "supersession": "Supersedes the earlier E2 reconstruction for derived P95/count/precision metrics; earlier files are preserved.",
        "superseded_outputs": [
            "E2_PRIMARY_METHOD_METRICS.csv",
            "E2_RECONSTRUCTION_RECEIPT.json",
            "E2_CONTINUITY_METRIC_REPORT.md"
        ],
        "exact_issc_continuity_definition": "NOT_VERIFIABLE",
        "conceptual_issc_formula_match": "PASS",
        "reason": "Public ISSC text gives ratio-level descriptions but not executable node eligibility, overlap, and aggregation semantics; local Phase I lineage audit was BLOCKED.",
        "runs_reconstructed": len(run_rows),
        "sources": [
            {
                "block": source.block,
                "method": source.method,
                "seed_range": [min(source.seeds), max(source.seeds)],
                "n": len(source.seeds),
                "role": source.role,
                "comparability": source.comparability,
            }
            for source in SOURCES
        ],
        "checks": {
            key: {
                "passed": check_totals.get(key, 0),
                "checked": check_counts.get(key, 0),
                "na_not_exported": len(run_rows) - check_counts.get(key, 0),
                "status": "PASS",
            }
            for key in sorted(set(check_totals) | set(check_counts))
        },
        "corrections": {
            "front_delay_p95": "Reconstructed from per-front-node detected delays; E1's old derived column incorrectly read event-onset delay and is superseded.",
            "false_wakeup_count": "Defined as maximal contiguous false alert-state episodes per physical node; E1's old derived column incorrectly reused detector false-alarm steps and is superseded.",
            "useful_wakeup_precision": "Affected AND alert-mode AND physically sampled node-time divided by alert-mode node-time; not the command-level future-hit quantity named wakeup_effectiveness in task8.",
        },
        "forbidden_seed_policy": {
            "121_140": "NOT_READ_OR_RUN_BY_THIS_SCRIPT",
            "301_340": "NOT_READ_OR_RUN_BY_THIS_SCRIPT",
        },
        "input_inventory_sha256": inventory_digest,
        "analysis_script": str(Path(__file__).resolve().relative_to(ROOT)).replace("\\", "/"),
        "analysis_script_sha256": sha256(Path(__file__).resolve()),
        "outputs": {
            run_file.name: sha256(run_file),
            primary_file.name: sha256(primary_file),
        },
    }
    receipt_file = OUT / "E2_CORRECTED_RECONSTRUCTION_RECEIPT.json"
    receipt_file.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    report = [
        "# E2 Corrected Continuity and Wake-up Metric Report",
        "",
        "Status: **PASS WITH DEFINITION LIMITATION**",
        "",
        "This read-only reconstruction ran on existing traces only; no simulation was run. "
        "It **supersedes the earlier E2 reconstruction for derived P95/count/precision metrics**. "
        "The earlier files are retained as historical receipts.",
        "",
        "## Corrected definitions",
        "",
        "- Front Delay P95 is computed from per-front-node detected delays, not event-onset detector delay.",
        "- False-wakeup count is the number of maximal contiguous false alert-state episodes per physical node, not normal detector false-positive steps.",
        "- Useful-wakeup precision is affected AND alert-mode AND physically sampled node-time divided by alert-mode node-time.",
        "- A legacy source field that was not exported is `NA_NOT_EXPORTED`; it does not abort the other trace-derived metrics.",
        "",
        "AWSR and GSR retain formula-level agreement with the ISSC text. Exact executable overlap, eligibility, missing-node, and aggregation lineage remains **NOT_VERIFIABLE**.",
        "",
        f"Runs reconstructed: **{len(run_rows)}**.",
        "",
        "The aggregate method table is `E2_CORRECTED_PRIMARY_METHOD_METRICS.csv`; the complete run-level audit is `E2_CORRECTED_RUN_LEVEL_METRICS.csv`.",
    ]
    (OUT / "E2_CORRECTED_CONTINUITY_METRIC_REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps({"runs": len(run_rows), "methods": len(aggregates), "receipt": str(receipt_file)}, indent=2))


if __name__ == "__main__":
    main()
