# Stage II reference results

Each run contains one policy evaluated on one seed. Compare methods **within** the same study and seed; the primary and transfer windows use different dates, events and placements.

| File | What it establishes |
| --- | --- |
| `primary_per_run.csv` | Historical records for 4 rankings × 20 seeds: service, command receptions and modelled energy. |
| `transfer_per_run.csv` | Historical service measures for 5 policies × 20 seeds in the second window. |
| `backbone_per_run.csv` | Historical records for 2 policies × 20 seeds with a common signed GLR detector and spatial-cover placement. |
| `figure_6_8_differences.csv` | DF-ReAlert minus each of three primary-window controls: 60 matched pairs, each with differences in recall, delay, receptions and energy. |
| `table_values.csv` | The 221 displayed result cells of Tables 6.6–6.8 and D.4–D.8. The `evidence` column distinguishes values backed by historical per-run records from reported method means. |
| [Independent transfer-window runs](reproduction/transfer_window_reproduction.csv) | A complete rerun, 5 policies × 20 seeds. All ten command-reception and energy means match the [reported means](reproduction/transfer_window_mean_comparison.csv) at thesis precision. The [reproduction record](reproduction/transfer_window_reproduction_provenance.json) identifies the inputs, implementation and runtime. |

The historical transfer archive contains service results by seed and costs as method means. Thus the per-seed cost records in `reproduction/` are **new simulation outputs**. The same ten historical cost means appear in two tables (6.6 and D.6).

**Reading the metrics.** Rates are fractions. Front recall measures the share of front arrivals sampled in alert mode at the arrival slot; coverage measures the share of affected node-time sampled in alert mode. AWSR is the sampling fraction over affected event memberships; GSR is the sampling fraction over all physical node-slots. Detected-front delay excludes missed arrivals; restricted delay includes them. The reported p95 is the mean of within-seed percentiles. Routed receptions count intermediate hops. Run files express modelled energy in mJ (1,000 mJ = 1 J).

Useful-wakeup precision divides affected, actually sampled alert-state node-slots by all alert-state node-slots **within each seed**, then averages across seeds. The primary-window means are 0.105 for DF-ReAlert, 0.107 for random ranking, 0.105 for nearest-front ranking and 0.105 for lowest-route-cost ranking.

From the Stage II directory, run `python scripts/verify_reference.py` to compare the tables and paired differences. Add `--output-dir results/tables --plot` to export the numerical checks and draw Figure 6.8. The checks use the Python standard library; plotting uses Matplotlib.
