# E5-3 Protocol Clarification 01 (Append-only)

This clarification resolves implementation ambiguity without changing seeds,
metrics, scientific question, or either method's frozen identity.

## Policy boundary

`DF-ReAlert-corrected-B2.7-Y1` uses the complete corrected Y1 post-trigger
semantics: merged candidate admission with K=5, probe horizon 3, retained
negative records, frontier anchoring, and the K=5 confirmed-service budget.

`Fixed-two-hop-verify3` does **not** use Top-K admission, retained negative
records, probes, Y1 ranking, frontier anchoring, or the Y1 service budget. It is
the fixed two-hop response with verification horizon 3. The two methods share
only the upstream detector/placement, exogenous realizations, graph/data
availability, packet and energy accounting, and the explicitly common
verification horizon.

## Executable ISSC surrogate

The deterministic reconstruction used by the control is fixed as follows:

- signed-normalized-innovation, two-sided GLR;
- candidate windows 1 through 8 slots;
- absolute GLR threshold 6.0;
- node-relative elevation factor 3.0 with floor 3.4;
- reset/rearm after trigger at GLR reset level 1.0;
- missing measurements do not advance a window and cannot trigger; the node
  remains eligible once the minimum contiguous observations are available;
- spatial coverage masks use the existing Euclidean coverage radius;
- sentinel count is `max(1, round(0.15 * available_nodes))`, capped at available
  nodes;
- optimal-cover search maximizes covered available-node mask, then minimizes
  selected count, with lexicographic node-ID tie-break;
- unavailable nodes are excluded from candidates and masks;
- disconnected graph components are handled independently by the same greedy/
  deterministic search, with no cross-component edge fabricated.

This is a formula-level ISSC continuity surrogate. It is not claimed to be an
exact reproduction of an unavailable original executable.
