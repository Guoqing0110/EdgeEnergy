# E5-3 ISSC Backbone Continuity Control

Status: **PROTOCOL_FROZEN_PRE_RUN** (2026-08-29)

This is a 40-run continuity control, not a method-development cycle and not a
Gate A-D evaluation. It tests whether the frozen corrected B2.7 Y1 selective
delayed re-alert policy and a matched fixed two-hop verify-3 policy retain their
communication/visibility relationship when they share the ISSC detector and
sentinel-placement backbone.

## Design

- Seeds: **441-460**, each used once for each method (20 paired seeds, 40 runs).
- Methods: `DF-ReAlert-corrected-B2.7-Y1` and `Fixed-two-hop-verify3`.
- Shared backbone: two-sided GLR detector with node-relative elevation rule and
  spatial optimal-cover sentinel placement, sentinel ratio **0.15**.
- Shared post-trigger constants: K=5, probe horizon=3, verification horizon=3,
  event cooldown=4 slots, failed verification fallback cooldown=8 slots,
  deterministic packet/energy accounting, and the frozen Y1 post-trigger state
  semantics. No ranking-baseline variants are included.

## Backbone definitions

The GLR statistic is the two-sided Gaussian mean-shift generalized likelihood
ratio over the frozen sentinel input history. A detection requires the statistic
to exceed the preregistered threshold and the node-relative elevation rule to
hold; threshold, reference window, variance treatment, and rearm rule are
inherited from the ISSC source artifact and recorded in the effective run
configuration. Sentinel placement is the deterministic spatial optimal-cover
search at ratio 0.15, with the source algorithm's deterministic tie-break.

The local TeX source establishes these formula-level definitions. It does not
expose every executable detail (notably overlap handling and missing-node
eligibility); therefore this control claims **formula-level ISSC backbone
continuity**, not byte-identical reproduction of an unavailable executable.

## Metrics and analysis

Every run records Front Recall, mean and P95 Front Delay, restricted delay,
missed-front count/duration, AWSR, GSR, routed RX, alert/probe/relay/confirmation
traffic, over-wakeup ratio, absolute false-wakeup node-time/count, useful-wakeup
precision, sensing/communication/idle/computation energy, and model-based total
energy. Report paired differences `DF-ReAlert - Fixed-two-hop` by seed. There are
no success gates; interpretation is descriptive and direction-focused.

## Freeze and exclusions

All detector, placement, anomaly, graph, data, packet, energy, and policy
parameters are frozen before seed 441. No calibration, threshold tuning, method
changes, preview runs, or discarded/replaced failures are permitted. Seeds
121-140, 301-320, 321-340, and 401-440 are not reused. Formal execution is not
authorized by this document alone until implementation audit and the companion
freeze manifest are complete.
