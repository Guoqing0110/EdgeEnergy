# E3 — Second Independent Temporal Window Preregistration

Status: **FROZEN_BEFORE_421_440** (2026-08-29)

E3 is a temporal-transfer evaluation, not method development. It does not reopen B2.7–B2.10 or alter the E1 implementation.

## Window selection

Primary window: `2004-02-28 01:03:00–05:03:00`.

Second window: **`2004-03-05 08:00:00–12:00:00`**, selected prospectively as the next predeclared non-overlapping four-hour Intel Berkeley window satisfying the same strict shared-data completeness rule. The timestamp intervals are disjoint.

## Methods and controls

The frozen DF-ReAlert, Random Top-K, Nearest-front Top-K, and Lowest-route-cost Top-K selectors from E1 are carried forward unchanged. A fixed two-hop reference with the predeclared three-step verification horizon is added. No ranking, detector, probe, verification, cooldown, packet, graph, or energy parameter is recalibrated in the second window.

All methods use the same candidate/data generation, node availability rule, topology construction rule, anomaly/noise realization per seed, and metric definitions. E3 seeds are **421–440** only; no historical or locked seed is reused.

## Metrics and interpretation

Report the E1/E2 metric set: Front Recall, delay mean/P95, restricted delay, missed-front count, AWSR, GSR, routed/alert/probe/relay traffic, over-wakeup and absolute/useful wake-up metrics, and model-based sensing/communication/idle/computation/total energy. No Gate A–D or minimum-effect threshold is imposed. The analysis is descriptive and tests whether the visibility–communication/energy trade-off transfers, changes magnitude, or reverses.

## Exclusions

No calibration on 421–440; no preview subset; no method or gate changes after freeze; no access to 121–140, 301–320, or 321–340.
