# Phase II-E / E0 — Paper-Evidence Preregistration

Status: **FROZEN BEFORE E1** (2026-08-29)

This protocol opens a separate paper-evidence phase. It does not reopen or modify the closed B2.7–B2.10 method-development chain. No E1–E4 runs are included in this freeze.

## Primary method and naming

The primary method is the frozen DF-ReAlert configuration represented by corrected B2.7 Y1, identified in the paper as **DF-ReAlert** (the internal Y1 label is not used as a paper method name). No Y3 rule is a paper primary method.

## E1 budget-matched ranking experiment

Four selectors are evaluated on the same candidate set and the same paired seed:

1. **DF-ReAlert** — existing frozen ranking and tie-break rules.
2. **Random Top-K** — uniform random ordering of the shared eligible candidate set, with a reproducible RNG derived from the experiment seed and selection context; it must not consume or alter anomaly/noise RNG streams.
3. **Nearest-front Top-K** — ascending `distance_now` to the current confirmed/active front (runtime-visible); deterministic tie-break by `node_id` only.
4. **Lowest-route-cost Top-K** — ascending existing runtime communication route cost; deterministic tie-break by node id.

Only the ranking rule changes. All selectors share:

`candidate generation, K, probe budget, verification horizon, candidate budget, response hops, event cooldown, communication graph, detector, anomaly realization, noise realization, packet model, and energy model`.

The E1 seed namespace is **401–420**, with all four selectors paired on each seed. There is no calibration block: DF-ReAlert is frozen and the three controls have no fitted parameters. No evaluation-seed tuning, future truth, affected labels, post-hoc outcomes, or new energy/degree features may enter ranking.

## Metrics frozen for E1/E2

Quality: Front Recall, coverage, Front Delay mean/P95, restricted front delay, missed-front count.

ISSC continuity: AWSR and GSR.

Communication: routed alert-command RX, alert TX/RX, probe TX/RX, relay TX/RX, and total alert-related messages.

Wake-up: over-wakeup ratio, absolute false-wakeup node-time, false-wakeup count, and useful-wakeup precision.

Energy: sensing, TX, RX, idle, computation/probe, and total **model-based energy estimate**. Packet lengths, radio assumptions, and parameter sources must be reported with the accounting table; energy is not claimed as direct physical measurement.

## E2 reconstruction

AWSR, GSR, false-wakeup absolute metrics, P95 delay, and missed-front duration/count are to be reconstructed from existing traces wherever fields are sufficient. Re-running B2.7 solely to obtain derived metrics is prohibited.

## Later evidence phases (predeclared scope)

E3 may evaluate the frozen protocol on a non-overlapping Intel Berkeley temporal window (proposed seeds 421–440), with no recalibration. E4 may run a small-scale HIL mechanism demonstration (multi-hop alert, failed prior verification, delayed front, probe/re-alert, packet count, and delay). Neither phase may alter the frozen method or gates; E4 is not a Gate A–D study.

## Stop conditions and exclusions

Seeds 201–220, 301–320, 321–340, and 121–140 retain their historical roles and are excluded from E1. No Y3.1/Y3.2 tuning, gate redefinition, or same-block post-hoc selector is permitted. Any deviation requires a new preregistration and new seed namespace.
