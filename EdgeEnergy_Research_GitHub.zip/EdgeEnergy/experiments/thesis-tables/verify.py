"""Recalculate the comparisons documented in README.md (Python 3.9+, standard library)."""
from collections import defaultdict
import csv
import gzip
from itertools import groupby
import math
from pathlib import Path
from statistics import fmean

HERE = Path(__file__).resolve().parent


def read(name):
    opener = gzip.open if name.endswith(".gz") else open
    with opener(HERE / name, "rt", encoding="ascii", newline="") as f:
        return list(csv.DictReader(f))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(actual, expected, label, tolerance=1e-8):
    require(math.isclose(float(actual), float(expected), rel_tol=1e-10, abs_tol=tolerance),
            f"{label}: calculated {actual}, expected {expected}")


def paired_rows(name, seeds, methods):
    rows = read(f"{name}-runs.csv.gz")
    cells = defaultdict(dict)
    for r in rows:
        cell = cells[int(r["seed"]), r["condition"]]
        require(r["method"] not in cell and int(r["slots"]) == 480, "Invalid trajectory")
        cell[r["method"]] = r
    require(len(rows) == seeds * 7 * methods and len(cells) == seeds * 7, "Incomplete grid")
    require(len({s for s, c in cells}) == seeds and len({c for s, c in cells}) == 7,
            "Unexpected seed or condition count")
    for cell in cells.values():
        require(len(cell) == methods and len({r["trace_hash"] for r in cell.values()}) == 1,
                "Unmatched policy inputs")
    for r in read(f"{name}-contrasts.csv"):
        metric = r["metric"]
        if name == "heldout":
            left, right = "p_da_ies_s", "b4_queue_belief_age_direct"
            target = r["delta"]
        else:
            left, right = r["method_left"], r["method_right"]
            target = r["mean_difference_left_minus_right"]
        byseed = defaultdict(list)
        for (seed, _), cell in cells.items():
            byseed[seed].append(float(cell[left][metric]) - float(cell[right][metric]))
        close(fmean(fmean(x) for x in byseed.values()), target, f"{name}/{metric}")
    print(f"{name}: {len(rows)} trajectories, {seeds} paired seeds; contrast means agree.")


def candidate_scores():
    rows = read("report-candidates.csv.gz")
    cells = defaultdict(list)
    ids = set()
    for r in rows:
        k = (r["seed"], r["scenario"], r["report_interval"])
        i = (*k, r["slot"], r["node"])
        require(i not in ids, "Duplicate report candidate")
        ids.add(i)
        cells[k].append(r)
    require(len(rows) == 19440 and len(cells) == 90, "Candidate counts do not agree")
    positive = lambda row: float(row["offline_true_value"]) > 0
    require(sum(positive(r) for r in rows) == 340, "Unexpected number of positive candidates")
    targets = {"full_voei_score": (.5794,.9673,.9705), "age_score": (.0442,.3219,.3108),
               "uncertainty_score": (.0474,.3064,.2989)}
    for score, reference in targets.items():
        per_cell = []
        for rs in cells.values():
            pos = sum(positive(r) for r in rs)
            if not pos:
                continue
            ordered = sorted(rs, key=lambda r: -float(r[score]))
            n = true = 0
            ap = 0.
            for _, ties in groupby(ordered, key=lambda r: float(r[score])):
                tied = list(ties)
                added = sum(positive(r) for r in tied)
                true += added
                n += len(tied)
                ap += (added/pos) * (true/n)
            slots = defaultdict(list)
            for r in rs:
                slots[r["slot"]].append(r)
            top = [r for slot in slots.values() for r in sorted(
                slot, key=lambda x: (-float(x[score]), int(x["node"])))[:3]]
            value = lambda x: max(0., float(x["offline_true_value"]))
            per_cell.append((ap, sum(positive(r) for r in top)/pos,
                             sum(map(value,top))/sum(map(value,rs))))
        require(len(per_cell) == 83, "Wrong number of eligible ranking cells")
        for i, target in enumerate(reference):
            close(round(fmean(x[i] for x in per_cell),4), target, score)
    print("Report ranking: 19,440 candidates; 340 positives; all nine displayed metrics agree.")


def reporting():
    rows = read("reporting-factors.csv.gz")
    keys = ["field_payload_bytes", "link_success_probability", "path_length_hops", "report_budget_j"]
    index = {}
    for r in rows:
        key = tuple(float(r[k]) for k in keys)
        ident = (key,r["seed"],r["method"])
        require(ident not in index, "Duplicate reporting cell")
        index[ident] = r
    seeds = {r["seed"] for r in rows}
    refs = read("reporting-contrasts.csv")
    families = ["full_voei_selective_eetor","collect_all_eetor",
                "independent_periodic_direct","age_ranked_eetor"]
    panel = defaultdict(list)
    for (key,seed,method),r in index.items():
        payload,success,hops,budget=key
        if (payload,success,budget)==(64,.9,.12) and method in families:
            panel[method,int(hops)].append(float(r["ratio_information_value_per_sensor_joule"]))
    require(len(rows)==360 and len(seeds)==15 and len(panel)==16 and
            all(len(v)==15 for v in panel.values()), "Unexpected panel A comparison size")
    print("Reporting crossover, Figure 5.6A: mean delivered value per sensor joule by hop count")
    for m in families:
        print(m, {h: round(fmean(panel[m,h]),6) for mm,h in sorted(panel) if mm==m})
    pairs={(float(r["link_success_probability"]),int(r["path_length_hops"])) for r in refs}
    require(len(refs)==len(pairs)==12 and all(
        float(r["field_payload_bytes"])==512 and float(r["report_budget_j"])==.5
        and float(r["paired_bootstrap_95_ci_low"])<=float(r["mean_difference"])<=
            float(r["paired_bootstrap_95_ci_high"]) for r in refs), "Invalid panel B source")
    print("Figure 5.6B: 12 archived effects available; their underlying per-seed arms are not in this table.")



def sensing():
    rows = read("sensing-sessions.csv.gz")
    require(len(rows)==len({r["session_id"] for r in rows})==91, "Unexpected session inventory")
    for r in read("sensing-policy-means.csv"):
        rs = [s for s in rows if s["lab"]==r["lab"] and s["method"]==r["method"]]
        require(len(rs)==len({s["block_id"] for s in rs})==int(r["runs"])==12, "Unpaired sensing blocks")
        for s in rs:
            for out,num,den in [("AWSR_sink","anomaly_delivered","anomaly_node_steps"),
                                ("GSR_sink","logical_delivered_scored","scored_node_steps"),
                                ("EDR","matched_events","event_count")]:
                close(float(s[num])/float(s[den]),s[out],out)
        for k in ("AWSR_sink","GSR_sink","EDR","ODD_mean_steps","RMSE_a","ACU"):
            close(fmean(float(s[k]) for s in rs if s[k]),r[k],k)
    primary=[r for r in rows if r["lab"]=="05" and r["method"]=="P"]
    require(sum(int(r["control_ack_received"]) for r in primary)==395
            and sum(int(r["control_targets"]) for r in primary)==396, "Command counts disagree")
    print("Sensing: 91 physical sessions indexed; 6 policy-by-lab summaries and 395/396 acknowledgements verified.")


if __name__ == "__main__":
    paired_rows("heldout",30,2)
    paired_rows("attribution",15,5)
    candidate_scores()
    reporting()
    sensing()
