#!/usr/bin/env python3
"""Verify the three study demos and run them with a separate output directory."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

# Guoqing Lu supplies his research-code contributions for reproduction of the
# thesis studies. The scope of this permission is listed in ../legal/LICENSE_SCOPE.md.
try:
    import resource
except ImportError:
    resource = None

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent if (ROOT.parent / "reproduce.py").is_file() else ROOT
STUDIES = {
    "dynamic-k": "dynamic-k",
    "da-ies-s": "da-ies-s",
    "adaptive-sampling-monitoring": "adaptive-sampling-monitoring",
}


def verify():
    rows = (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines()
    for row in rows:
        expected, name = row.split("  ", 1)
        path = ROOT / name
        if (path.is_symlink() or not path.is_file()
                or not path.resolve().is_relative_to(ROOT)):
            raise ValueError(f"Required study file missing or unsafe: {name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"File differs from SHA256SUMS: {name}")
    return len(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", choices=["all", *STUDIES], default="all")
    parser.add_argument("--output", type=Path, help="new or empty folder outside the repository")
    parser.add_argument("--verify-only", action="store_true", help="check file hashes and exit")
    args = parser.parse_args()
    n = verify()
    print(f"PASS: verified {n} distributed files", flush=True)
    if args.verify_only:
        return 0
    studies = list(STUDIES) if args.only == "all" else [args.only]
    if "da-ies-s" in studies and os.name != "posix":
        parser.error("The DA-IES-S drivers need POSIX resource support; use Linux or WSL.")
    if args.output is None:
        parser.error("Give --output and a fresh results directory outside the repository.")
    out = args.output.resolve()
    if out.is_relative_to(REPOSITORY):
        parser.error("Choose an output directory outside the repository.")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        parser.error("Output must be new or empty, so no past results are overwritten or reused.")
    out.mkdir(exist_ok=True, parents=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", MPLBACKEND="Agg")
    packages = {}
    for name in ("numpy", "matplotlib", "pandas", "PyYAML"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    summary = {
        "package_version": (ROOT / "VERSION").read_text().strip(),
        "inputs_verified": n,
        "python": platform.python_version(),
        "platform": f"{platform.system()} {platform.machine()}",
        "packages": packages,
        "studies": [],
    }
    for name in studies:
        print(f"Running {name}...", flush=True)
        start = time.perf_counter()
        log = out / f"{name}.log"
        command = [sys.executable, "-B", str(ROOT / STUDIES[name] / "demo.py"),
                   "--output", str(out / name)]
        with log.open("w", encoding="utf-8") as stream:
            result = subprocess.run(command, cwd=out, env=env, stdout=stream, stderr=subprocess.STDOUT)
        wall = round(time.perf_counter() - start, 3)
        summary["studies"].append({"study": name, "exit_code": result.returncode,
                                   "wall_seconds": wall, "log": log.name})
        if resource is not None:
            rss = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
            summary["maximum_child_RSS_MiB_where_available"] = round(
                rss / (1024**2 if sys.platform == "darwin" else 1024), 1)
        (out / "run_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        if result.returncode:
            print(f"FAILED: see {log}", file=sys.stderr)
            return result.returncode
        print(f"PASS: {name} ({wall} s)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
